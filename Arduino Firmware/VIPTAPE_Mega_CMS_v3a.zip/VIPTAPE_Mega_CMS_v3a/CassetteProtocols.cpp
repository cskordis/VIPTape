#include "CassetteProtocols.h"

// NOTE: Keep the protocol table *only* in this .cpp so the array is complete here.
// This prevents "incomplete type" sizeof errors and avoids multiple-definition issues.
//
// Field order (existing entries):
//   name, bit0, bit0_min, bit0_max, bit1, bit1_min, bit1_max,
//   leaderBit, leaderBits, leaderTime, startBit, bitOrder, parity,
//   interByteTimeout_us, stopBit, stopBits, trailerBit, trailerTime,
//   bit0_cycle, bit1_cycle, polarity
//
// Two extra fields exist after polarity (framing, oraoType).  Existing entries
// don't list them so they default to FRAMING_ASYNC / ORAO_TYPE_NONE.
//
// ORAO timings (full cycle in us) are derived from the Orao 2007 ROM and verified
// against real cassette WAV captures: bit-0 ~362us (~2.76kHz), bit-1 ~726us
// (~1.38kHz).  Min/max bounds are widened to absorb tape speed wobble and clock
// drift.  Discrimination threshold sits roughly at the geometric mean (~540us).

const CassetteParams cassetteProtocols[] = {

  {"VIP", 500, 420, 620, 1250, 1050, 1450, 0, 200, 5000, 1, LSB_FIRST, PARITY_EVEN, 20000, 0, 0, 0, 0, 1, 1, POLARITY_POSITIVE},
  {"ELF II", 833, 600, 1350, 416, 300, 520, 1, 200, 8000, 0, MSB_FIRST, PARITY_ODD, 20000, 0, 0, 0, 0, 1, 1,  POLARITY_NEGATIVE},
  {"HUG 1802", 2000, 1400, 2600, 1000, 200, 1200, 1, 200, 5000, 0, MSB_FIRST, PARITY_ODD, 20000, 0, 0, 0, 0, 1, 1, POLARITY_NEGATIVE},
  {"KCS 300", 833, 600, 1350, 416, 300, 520, 0, 0, 5000, 1, LSB_FIRST, PARITY_EVEN, 20000, 0, 0, 0, 0, 4, 8, POLARITY_POSITIVE},
  {"KCS 1200", 416, 300, 520, 208, 150, 350, 0, 0, 5000, 1, LSB_FIRST, PARITY_EVEN, 20000, 0, 0, 0, 0, 4, 8, POLARITY_POSITIVE},
  {"ORAO B", 362, 280, 540, 726, 540, 950, 1, 32, 2500, 0, LSB_FIRST, PARITY_NONE, 0, 0, 0, 0, 0, 1, 1, POLARITY_POSITIVE, FRAMING_BLOCK_ORAO, ORAO_TYPE_BASIC},
  {"ORAO O", 362, 280, 540, 726, 540, 950, 1, 32, 2500, 0, LSB_FIRST, PARITY_NONE, 0, 0, 0, 0, 0, 1, 1, POLARITY_POSITIVE, FRAMING_BLOCK_ORAO, ORAO_TYPE_OBJECT}
  //{"DREAM 6800", 833, 700, 950, 400, 320, 520, 1, 200, 5000, 0, LSB_FIRST, PARITY_NONE, 50000, 1, 1, 0, 0, 4, 8, POLARITY_POSITIVE},

  };

const uint8_t cassetteProtocolCount = sizeof(cassetteProtocols) / sizeof(cassetteProtocols[0]);
