/////////////////////////////////////////////////////////////////
/*             Costas Skordis July 2025                        */
/*                                                             */
/*          Configure your screen settings here                */
/*    Modify lines appropriate to your device                  */
/*                                                             */
/*                                                             */
/////////////////////////////////////////////////////////////////

#define TITLE           "VIPTAPE II"          // Title
#define VERSION         "CMS v5a"             // Version
#define DISPLAY_SPLASH  1                     // Splash screen 0 - disabled, 1 - enabled
#define DISPLAY_TITLE   1                     // Display title screen 0 - disabled, 1 - enabled
#define SERIAL_BAUD     115200
                                              // Serial 0 - disabled, 1 - enabled, 2 - verbose (Note: When serial is enabled, may affect timings with the protocols to some computer types like the Dream 6800)
#define SERIALDEBUG_BOOT_DEFAULT 0            // boot default (0=off, 1=on)
extern uint8_t SERIALDEBUG; 
#define ORIENTATION     0                     // Portrait
#define SD_CS           10                    // SD card chip select pin
#define DEFAULT_MODE    0                     // Default casette mode at start up
#define BASEFILE        "FILE"                // Default base name for unspecified file when saving
#define FILENAME_SIZE   9                     // Maximum filename size (characters + terminator)

#define MESSAGE1        "Designed By"         // Line 1 of message on initial load screen
#define MESSAGE2        "JOSH BENSADON"       // Line 2 of message on initial load screen
#define MESSAGE3        "Software By"         // Line 3 of message on screen saver
#define MESSAGE4        "COSTAS SKORDIS"      // Line 4 of message on screen saver

#define MESSAGE5        "THANK YOU"           // Line 1 of message on screen saver
#define MESSAGE6        "JOSEPH WEISBECKER"   // Line 2 of message on screen saver

/* Ram SPI */
#define ramCS   27
#define ramMISO 26
#define ramCLK  25
#define ramMOSI 24

#define tapeOut A9
#define tapeIn  18

/* Ram Test*/
#define RAMTEST 2                            // Clear and verify onboard Ram :  0 - Disabled, 1 - Read, 2 - Read and Verify
#define RAMSTART 0
#define RAMSIZE 65356UL

/* Touchscreen pins (adjust based on your shield) */
#define XP 8
#define YP A3
#define XM A2
#define YM 9

/* Touch screen calibrated co-ordinates - adjust accordingly after running calibration */
#define TS_MINX 933
#define TS_MAXX 90
#define TS_MINY 72
#define TS_MAXY 919

#define MINPRESSURE 2
#define MAXPRESSURE 1000

#define TEXTSIZE    2
#define TEXTSIZE1   1
#define TEXTSIZE2   2
#define TEXTSIZE3   3
#define TEXTSIZE4   4

// ---- FILE LIST CAPACITY -- NOW COSTS FIXED STATIC RAM --------------------
// The list used to be 128 Arduino Strings: 768 bytes static PLUS a heap
// allocation per entry, refilled on every browse, with the insertion sort
// assigning Strings around.  That churn fragmented the heap, and an Arduino
// String that fails to allocate goes silently empty -- which is what made the
// file list look odd and hung the browser right after a large transfer.
//
// It is now fixed char storage, MAX_NAME_LEN (14) bytes per slot: no heap at
// all, but the whole cost is paid up front.
//
//     128 slots -> 1792 bytes   (+1024 vs the String array -- too much here)
//      96 slots -> 1344 bytes   (+576)
//      80 slots -> 1120 bytes   (+352)   <-- chosen
//      64 slots ->  896 bytes   (+128)
//
// This board compiles at 76% SRAM with ~1.9 KB free for stack and heap, and
// that 1.9 KB was previously shared with a list that could eat most of it.
// 80 slots trades a modest static increase for a heap that no longer grows
// with the number of files, which is the entire point.
//
// A folder with more entries than this is TRUNCATED, and loadDirectory() now
// says so on screen and on serial rather than silently hiding files the way
// the old 128 cap did.  Raise this only after checking the free-RAM figure the
// IDE reports on compile; every extra slot is 14 bytes gone for good.
// ---- CHANGE THESE TWO TOGETHER, ALWAYS ----------------------------------
// fileList[] is declared with MAX_ARRAY but every bounds check in
// loadDirectory() uses MAX_FILECOUNT.  If MAX_FILECOUNT ever exceeds
// MAX_ARRAY the clear loop and the fill loop both run off the end of the
// array and quietly corrupt whatever follows it in RAM -- no warning, no
// crash at the point of damage, just inexplicable behaviour later.
// The #error below turns that mistake into a build failure instead.
// 128 is affordable again BECAUSE the list no longer uses the heap.
// Before, ~1.9 KB of free RAM was shared with a file list that allocated per
// entry and fragmented as you browsed, so the usable figure fell in use and a
// big folder could exhaust it.  Now the list costs a fixed 1792 bytes and the
// browser allocates nothing, so what is left is almost pure stack headroom --
// and the deepest stack frame in this sketch is 125 bytes.  ~1.3 KB of that is
// ample, where 1.9 KB of shared-and-fragmenting was not.
//
// The IDE will print "Low memory available" because globals pass 75%.  That
// warning is a fixed threshold, not a measurement of this program's safety.
#define MAX_ARRAY     128
#define MAX_FILECOUNT 128

#if MAX_FILECOUNT > MAX_ARRAY
#error "MAX_FILECOUNT exceeds MAX_ARRAY: loadDirectory() would write past the end of fileList[]. Set them to the same value."
#endif

#define TOP_DISP        45
#define ITEMS_PER_PAGE  10
#define CHAR_HEIGHT     (8 * TEXTSIZE + 3)
#define CHAR_WIDTH      8
#define Y_OFFSET        60 
#define FILE_DISP       TOP_DISP - 2
#define INACTIVITY_THRESHOLD 300000  // 5 minutes in milliseconds

/* Assign human-readable names to some common 16-bit color values: */
#define BLACK         0x0000
#define BLUE          0x001F
#define RED           0xF800
#define GREEN         0x07E0
#define CYAN          0x07FF
#define MAGENTA       0xF81F
#define YELLOW        0xFFE0
#define WHITE         0xFFFF
#define GRAY          0x8410
#define NAVY          0x0080
#define DARKBLUE      0x008B
#define MEDIUMBLUE    0x00CD
#define DARKGREEN     0x6400
#define TEAL          0x8080
#define DARKCYAN      0x8B8B
#define DEEPSKYBLUE   0xBFFF
#define DARKTURQUOISE 0xCED1

#define BACKGROUND BLUE                  // Background color
#define FOREGROUND WHITE                 // Foreground color
#define DIRECTORY  WHITE                 // Directory text color
#define HILIGHT    YELLOW                // Highlight text color 
#define ALERT      RED                   // Alert color


/* Physical buttons */
#define BUTTONS      4 
#define BUTTON_UP    44
#define BUTTON_DOWN  36 
#define BUTTON_YES   30 
#define BUTTON_NO    22   

/* Keyboard Button dimensions and spacing */
#define BUTTON_WIDTH  35
#define BUTTON_HEIGHT 30
#define BUTTON_SPACING 2
#define BUTTON_START_X 10
#define BUTTON_START_Y 55

/*Screen buttons*/
#define NUM_SCREENS  3
#define NUM_BUTTONS  7



