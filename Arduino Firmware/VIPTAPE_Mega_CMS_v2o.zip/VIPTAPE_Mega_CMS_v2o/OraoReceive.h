#pragma once
#include <Arduino.h>
#include "RamExternal.h"
#include "CassetteDecoder.h"

// ============================================================================
// OraoReceive
// ----------------------------------------------------------------------------
// Consumes the byte stream emitted by CassetteDecoder when running an ORAO
// FRAMING_BLOCK_ORAO protocol entry.  Two distinct on-tape formats are
// supported, both as the original Orao 2007 / Eagle Extended BASIC ROMs save
// them:
//
//   'B' (BASIC source)
//     Multi-block.  Each 256-byte block has its own sync ($1B*4) + type +
//     filename + blknum + 240 bytes of payload (ASCII source terminated by
//     $1A).  Block numbers run 0,1,2,...
//
//   'O' (Object / memory image)
//     TWO logical blocks:
//       (a) HEADER block: full sync header + payload bytes 0..3 = load_lo,
//           load_hi, length-helper-lo, length-helper-hi.  Bytes 4..239 are
//           $20 padding.  Block# = 0.
//       (b) DATA block: per-block leader + transition + 2 bytes of length
//           on tape (FE_tape, FF_tape) + N raw data bytes.  NO SYNC.
//           N = FE_tape + 256 * (FF_tape - 1).
//     After consuming the header block, OraoReceive instructs the decoder
//     to skip sync hunt for the next leader-end transition.  The two length
//     bytes are read and the byte count is computed; subsequent bytes are
//     stored in RAM at load_addr, load_addr+1, ... until the count is reached.
// ============================================================================

class OraoReceive {
public:
    enum Status {
        OR_RUNNING,   // still consuming bytes
        OR_DONE,      // file complete -- caller should write to SD
        OR_ERROR      // protocol violation (bad type / filename mismatch / bad block#)
    };

    OraoReceive(RamExternal& ram, CassetteDecoder& decoder);

    // Reset to a fresh state, ready to receive a new file from block 0.
    void begin();

    // Feed one byte from the decoder.  Returns the running status.
    Status feed(uint8_t b);

    // Accessors valid after OR_DONE (and partly during OR_RUNNING):
    Status      status() const     { return _status;        }
    char        type() const       { return _type;          }
    const char* filename() const   { return _filename;      }
    uint16_t    loadAddr() const   { return _loadAddr;      }
    uint16_t    endAddr() const    { return _endAddr;       }
    uint32_t    dataBytes() const  { return _ramBytes;      }
    uint8_t     blocksReceived() const { return _expectedBlock; }

private:
    enum Field {
        F_TYPE,         // expecting 1 type byte
        F_NAME,         // expecting 10 filename bytes
        F_BLKNUM,       // expecting 1 block-number byte
        F_PAYLOAD,      // 240 payload bytes (block 0 of 'O', any block of 'B')
        // 'O' files only -- consumed AFTER the 256-byte header block.
        F_RAW_LEN_LO,   // first byte of the raw data block (FE_tape)
        F_RAW_LEN_HI,   // second byte of the raw data block (FF_tape)
        F_RAW_DATA      // N raw data bytes -> RAM at loadAddr++
    };

    RamExternal&     _ram;
    CassetteDecoder& _decoder;

    Status   _status;
    Field    _field;

    char     _type;
    char     _filename[11];
    uint8_t  _filenameIdx;
    uint8_t  _expectedBlock;
    uint16_t _payloadIdx;

    // 'O' header-block state
    bool     _firstBlock;
    uint8_t  _addrIdx;
    uint16_t _loadAddr;
    uint16_t _endAddr;
    uint8_t  _helperLo;
    uint8_t  _helperHi;

    // 'O' raw-data-block state
    uint16_t _addrPtr;
    uint32_t _rawBytesRemaining;

    uint32_t _ramBytes;
};
