#ifndef CASSETTE_ENCODER_H
#define CASSETTE_ENCODER_H

#include <Arduino.h>
#include "CassetteParams.h"

// ---- Encoder error reporting ----
enum EncodeError {
    ENCODE_OK = 0,
    ENCODE_ERR_NO_PARAMS,
    ENCODE_ERR_INVALID_PARAMS,
    ENCODE_ERR_ABORTED,
    ENCODE_ERR_UNKNOWN
};

class CassetteEncoder {
public:
    explicit CassetteEncoder(uint8_t outPin);

    void begin();
    void configure(const CassetteParams* p);
    void setParams(const CassetteParams* p);
    void reset();

    // Async-serial send path (unchanged for FRAMING_ASYNC entries).
    // For FRAMING_BLOCK_ORAO entries, sendByte() emits 8 raw data bits with
    // no start/parity/stop bits.  In ORAO mode you typically don't call
    // sendByte() / sendLeader() / sendTrailer() directly -- use sendOraoFile()
    // below, which handles per-block leaders and 256-byte block assembly.
    void sendLeader();
    void sendByte(uint8_t b);
    void sendTrailer();

    // ---- ORAO block-mode send (only valid when params->framing == FRAMING_BLOCK_ORAO)
    //
    // Sends a complete ORAO file as one or more 256-byte blocks, each preceded
    // by its own leader.  The byte source is a callback so the encoder stays
    // decoupled from RAM/SD/whatever the caller is reading from.
    //
    //   filename       : up to 10 ASCII chars, space-padded; nullptr -> all spaces.
    //   totalDataBytes : number of bytes the reader callback will be asked to
    //                    return (NOT counting address bytes or EOF marker).
    //                    For BASIC mode this is the source size; for OBJECT mode
    //                    this is the program size (endAddr - loadAddr + 1).
    //   loadAddr,
    //   endAddr        : used only when oraoType == ORAO_TYPE_OBJECT, written
    //                    into the first 4 payload bytes of the first block.
    //   reader, ctx    : reader(srcIndex, ctx) is called with srcIndex = 0..N-1
    //                    where N == totalDataBytes; the byte returned is sent
    //                    next on tape.
    //
    typedef uint8_t (*OraoByteReader)(uint32_t srcIndex, void* ctx);

    void sendOraoFile(const char* filename,
                      uint32_t totalDataBytes,
                      uint16_t loadAddr,
                      uint16_t endAddr,
                      OraoByteReader reader,
                      void* readerCtx);

    // CMS compatibility (used for UI test pulse)
    void pulseBit(uint8_t bit) { sendBit(bit); }

    // Error handling
    EncodeError lastError() const { return _lastError; }
    bool hasError() const { return _lastError != ENCODE_OK; }
    void clearError() { _lastError = ENCODE_OK; }
    void abort() { _lastError = ENCODE_ERR_ABORTED; }

private:
    void sendBit(uint8_t bit);
    void sendByteRaw(uint8_t b);   // 8 raw data bits, no framing (used by ORAO)
    void writeHigh();
    void writeLow();

    uint8_t _pin;
    const CassetteParams* _p = nullptr;

    uint16_t _half0_us = 0;
    uint16_t _half1_us = 0;

    EncodeError _lastError = ENCODE_OK;
};

#endif
