#include "CassetteDecoder.h"

CassetteDecoder* CassetteDecoder::instance = nullptr;

CassetteDecoder::CassetteDecoder(uint8_t pin)
: _pin(pin),
  _p(nullptr)
{
}

CassetteDecoder::CassetteDecoder(uint8_t pin, const CassetteParams* params)
  : _p(params),
    _pin(pin),
    _out(nullptr),
    _lastEdge(0),
    _qHead(0),
    _qTail(0),
    _diagQueueDrops(0),
    _diagQueueHighWater(0),
    _waitStartTime(0),
    _startQual(0),
    _state(WAIT_LEADER),
    _bitCount(0),
    _byte(0),
    _parity(0),
    _leaderCount(0),
    _stopCount(0),
    _cycle0Count(0),
    _cycle1Count(0),
    _done(false),
    _counter(0),
    _syncMatch(0),
    _blockBytesRead(0) {
}

void CassetteDecoder::begin(Stream& s) {
  _out = &s;
  instance = this;
  pinMode(_pin, INPUT);
  // Interrupt edge mode depends on the protocol's framing -- see
  // applyInterruptMode().  ORAO uses RISING (full-cycle, phase-immune);
  // async protocols use CHANGE + half-cycle pairing as originally validated.
  applyInterruptMode();
  clearDecodeFinished();
  if (_out) _out->println(String(_p->name) + F(" CASSETTE DECODER READY"));
}

void CassetteDecoder::applyInterruptMode() {
  // Choose the edge mode for the active protocol.  Default to CHANGE when no
  // params are set yet (matches the async path, which is the safe default).
  int mode = (_p && _p->framing == FRAMING_BLOCK_ORAO) ? RISING : CHANGE;

  detachInterrupt(digitalPinToInterrupt(_pin));

  // Clear edge/pairing/queue state so the new mode starts from a clean phase.
  noInterrupts();
  _lastEdge   = 0;
  _haveHalf   = false;
  _halfAccum  = 0;
  _qHead      = 0;
  _qTail      = 0;
  interrupts();

  // Only arm the interrupt once begin() has registered this instance for the
  // ISR; otherwise an early edge could dereference a null instance.
  if (instance == this) {
    attachInterrupt(digitalPinToInterrupt(_pin), isrThunk, mode);
  }
}

void CassetteDecoder::setParams(const CassetteParams* params) {
  _p = params;
  reset();
  // Protocol may have changed framing (e.g. async <-> ORAO), so re-arm the
  // interrupt in the correct edge mode.  No-op before begin() registers us.
  applyInterruptMode();
}

void CassetteDecoder::feedPeriod(uint32_t us) {
  handlePeriod(us);
}

uint8_t CassetteDecoder::read() {
  _byteReady = false;
  return _lastByte;
}

void CassetteDecoder::reset() {
  _state = WAIT_LEADER;
  _leaderCount = 0;
  _startQual = 0;
  _bitCount = 0;
  _byte = 0;
  _parity = 0;
  _stopCount = 0;
  _waitStartTime = 0;
  _decodeFinished = false;
  _byteReady = false;
  _done = false;
  _counter = 0;
  _syncMatch = 0;
  _blockBytesRead = 0;
  _oraoNextBlock = ORAO_NEXT_SYNC;
  _syncShift = 0;
  _syncHuntBits = 0;
  _halfAccum = 0;
  _haveHalf  = false;
  _anyByteEmitted = false;
  // Diagnostic counters
  _diagEdges = 0;
  _diagFullCycles = 0;
  _diagBit0 = 0;
  _diagBit1 = 0;
  _diagOutOfRange = 0;
  _diagLastCycleUs = 0;
  _diagMinCycleUs = 0xFFFFFFFFUL;
  _diagMaxCycleUs = 0;
  _diagBytesOut = 0;
  _diagMaxState = 0;
  _diagSyncEnters = 0;
  _diagSyncFails = 0;
  _diagSyncLocks = 0;
  _diagLastSyncShift = 0;
  // Clear ISR-shared state too -- otherwise a second LOAD attempt inherits
  // _lastEdge from the previous run, which makes isDone() fire instantly.
  noInterrupts();
  _lastEdge = 0;
  _qHead = 0;
  _qTail = 0;
  _diagQueueDrops = 0;
  _diagQueueHighWater = 0;
  interrupts();
  clearError();
}


void CassetteDecoder::isrThunk() {
  uint32_t now = micros();
  // Counter incremented unconditionally so it tallies even the very first
  // edge before _lastEdge is initialized.  ~1 extra cycle in the ISR.
  instance->_diagEdges++;
  if (instance->_lastEdge == 0) {
    instance->_lastEdge = now;
    return;
  }
  uint32_t delta = now - instance->_lastEdge;
  instance->_lastEdge = now;
  // Push into the ring buffer.  If full, drop the oldest-pending behaviour
  // would corrupt bit phase; instead drop THIS period and record the loss.
  // 32-slot buffer handles ~5.8 ms of main-loop blocking before this trips.
  uint8_t h = instance->_qHead;
  uint8_t next = (uint8_t)((h + 1) & PERIOD_QUEUE_MASK);
  if (next != instance->_qTail) {
    instance->_periodQueue[h] = delta;
    instance->_qHead = next;
  } else {
    // Queue full -- bit phase will be corrupted from here.  Count it so the
    // main loop can surface the failure mode after the load attempt.
    instance->_diagQueueDrops++;
  }
}

bool CassetteDecoder::decodeFinished() const {
  return _decodeFinished;
}

void CassetteDecoder::clearDecodeFinished() {
  _decodeFinished = false;
}

void CassetteDecoder::poll() {
  // Silence timeout: 1500ms with no edges => assume the tape ended.
  // This is gated on TWO conditions to avoid spurious aborts on real audio:
  //   1.  We're past WAIT_LEADER  (i.e. some edges have been processed)
  //   2.  AND we've actually emitted at least one byte to the consumer.
  // Without (2), a noisy audio startup (phone-jack pop, ALC settling, etc.)
  // can briefly advance the state out of WAIT_LEADER before any real data
  // arrives; if the audio then dips for 1.5s before the real signal kicks
  // in, the load is aborted before a single byte was decoded.  Once any
  // byte has been emitted we know the signal pipeline is working, so a
  // subsequent 1.5s silence really does mean end-of-tape.
  //
  // Read _lastEdge atomically -- on AVR, 32-bit accesses are NOT atomic
  // (four separate byte loads), so without protection the ISR can update
  // the variable mid-read.  A torn read can produce a value much greater
  // than the current micros(), which makes the unsigned subtraction below
  // underflow to ~2^32 (= 4300 seconds), instantly tripping the timeout
  // and setting _done even though edges are arriving continuously.
  uint32_t lastEdgeSnapshot;
  noInterrupts();
  lastEdgeSnapshot = _lastEdge;
  interrupts();
  if (lastEdgeSnapshot != 0 && _state != WAIT_LEADER && _anyByteEmitted) {
      if ((micros() - lastEdgeSnapshot) > 1500000UL) {
          _done = true;
          return;
      }
  }

  // Drain ALL queued periods, not just one.  This is the SAVE-direction fix.
  // The ISR pushes one period per edge; if we processed only one per poll()
  // call, then any main-loop blocking (e.g. the 520us bit-banged SPI write
  // in RamExternal::writeByte) would let the queue grow indefinitely OR --
  // with the old single-slot variable -- silently lose periods, scrambling
  // bit phase from the first byte where a RAM write fires.
  //
  // _qHead is read once into a local; new ISR pushes after this point will
  // be picked up on the NEXT poll() call.  The slot read does not need the
  // interrupt mask because: (a) ISR only writes at _qHead which is always
  // ahead of _qTail when the queue is non-empty, (b) on AVR an 8-bit index
  // load is atomic, and (c) the queue is never overwritten in-place.
  uint8_t headSnap = _qHead;
  // Track high-water mark for diagnostics (lossless; never resets within a run).
  uint8_t occ = (uint8_t)((headSnap - _qTail) & PERIOD_QUEUE_MASK);
  if (occ > _diagQueueHighWater) _diagQueueHighWater = occ;

  if (_p && _p->framing == FRAMING_BLOCK_ORAO) {
    // ORAO: drain ALL queued periods each poll.  OraoReceive's SPI-RAM write
    // (~520us) blocks the main loop long enough that several edges queue up;
    // draining them all here is what prevents lost periods / scrambled phase.
    while (_qTail != headSnap) {
      uint32_t p = _periodQueue[_qTail];
      _qTail = (uint8_t)((_qTail + 1) & PERIOD_QUEUE_MASK);
      handlePeriod(p);
    }
  } else {
    // Async (VIP / ELF II / KCS / DREAM): process AT MOST ONE period per poll,
    // exactly as the original decoder did.  These protocols were validated with
    // one-period-per-poll + half-cycle pairing.  Draining the whole queue in a
    // single poll() (added for ORAO) -- combined with the per-byte Serial print
    // in emitByte() running mid-drain -- regressed them, so the async path keeps
    // the original one-at-a-time cadence.  The 32-slot ring buffer still gives
    // far more cushion than the original single slot.
    if (_qTail != headSnap) {
      uint32_t p = _periodQueue[_qTail];
      _qTail = (uint8_t)((_qTail + 1) & PERIOD_QUEUE_MASK);
      handlePeriod(p);
    }
  }
}

bool CassetteDecoder::periodToBit(uint32_t fullCycle, uint8_t& bit) {

  if (fullCycle >= _p->bit1_min && fullCycle <= _p->bit1_max) {
    bit = 1;
    _diagBit1++;
    return true;
  }
  if (fullCycle >= _p->bit0_min && fullCycle <= _p->bit0_max) {
    bit = 0;
    _diagBit0++;
    return true;
  }
  _diagOutOfRange++;
  return false;
}

void CassetteDecoder::handlePeriod(uint32_t us) {
  uint32_t fullCycle;

  if (_p && _p->framing == FRAMING_BLOCK_ORAO) {
    // ORAO: RISING interrupt -- `us` is already one full cycle (rising-to-
    // rising), immune to half-cycle phase.  No pairing.
    fullCycle = us;
  } else {
    // Async (VIP/ELF II/KCS/DREAM): CHANGE interrupt delivers half-cycles
    // (edge-to-edge).  Pair two consecutive halves into one full cycle, which
    // is exactly how these protocols were originally validated.  Switching
    // this path to rising-only measurement regressed their decode, so it is
    // kept distinct from the ORAO path above.
    if (!_haveHalf) {
      _halfAccum = us;
      _haveHalf  = true;
      return;
    }
    fullCycle  = _halfAccum + us;
    _haveHalf  = false;
  }

  // Diagnostic tallies for the full cycle.
  _diagFullCycles++;
  _diagLastCycleUs = fullCycle;
  if (fullCycle < _diagMinCycleUs) _diagMinCycleUs = fullCycle;
  if (fullCycle > _diagMaxCycleUs) _diagMaxCycleUs = fullCycle;

  uint8_t bit;
  uint8_t xbit;
 
  if (!periodToBit(fullCycle, xbit)) {
    if (_state == READ_DATA && _startQual == 1) {
      _decodeFinished = true;
      _state = WAIT_LEADER;
      _leaderCount = 0;
      _startQual = 0;
      _waitStartTime = micros();
    }
    else if (_state == ORAO_HUNT_SYNC) {
      // During sync hunt, a single out-of-range cycle is *not* fatal.
      // Real-tape audio routinely produces a few jitter cycles per second
      // and falling back to WAIT_LEADER here means we'll never re-acquire
      // (the data block bits don't form a long-enough leader to satisfy
      // _leaderCount >= leaderBits).  Just drop the bad cycle and keep
      // the existing shift register so good bits before and after still
      // line up in the sliding-window match.
      return;
    }
    else if (_state == ORAO_READ_BLOCK || _state == ORAO_READ_RAW) {
      // Inside a block, an oor cycle USED TO bail out with _done = true on the
      // theory it would signal end-of-tape.  Real-hardware traces show
      // ~20-25% oor rate in the data block of phone-played audio, so a single
      // oor cycle hits within the first 1-2 bytes -- which means the load
      // ends before any meaningful data is emitted.  End-of-block is already
      // detected by byte count (252 in ORAO_READ_BLOCK, expected length in
      // OraoReceive's F_RAW_DATA state for ORAO_READ_RAW), and genuine
      // end-of-tape is handled by the silence-timeout in poll() (no edges for
      // 1.5s).  So inside a block we just drop the bad cycle and keep going,
      // accepting that we'll lose ONE bit and the byte it lands in.  This is
      // far less destructive than aborting the whole load.
      return;
    }
    else {return;}
  }

  if (xbit == 0) {
    ++_cycle0Count;
    _cycle1Count = 0;
  }
  if (xbit == 1) {
    ++_cycle1Count;
    _cycle0Count = 0;
  }
  
  if (_p->bit0_cycle > 0 && _p->bit0_cycle == _cycle0Count) {
    bit = 0;
  
  } else if (_p->bit1_cycle > 0 && _p->bit1_cycle == _cycle1Count) {
    bit = 1;

  } else {
    return;
  }
  _cycle0Count = 0;
  _cycle1Count = 0;

 switch (_state) {
    case WAIT_LEADER:
      if (bit == _p->leaderBit) {
        if (_leaderCount < 0xFFFF) _leaderCount++;
        // Async: lock onto leader as soon as the threshold is reached.
        // ORAO  : stay in WAIT_LEADER -- transition happens on the FIRST
        //         non-leader bit (which is bit 2 of the first $1B sync byte).
        if (_p->framing != FRAMING_BLOCK_ORAO &&
            _leaderCount >= _p->leaderBits) {
          _state = WAIT_START;
          _startQual = 0;
        }
      } else {
        // Non-leader bit
        if (_p->framing == FRAMING_BLOCK_ORAO &&
            _leaderCount >= _p->leaderBits) {
          // ORAO leader-to-data transition.  The bit we just received is the
          // single 0-bit transition marker that the original Orao 2007 ROM
          // SAVE emits between the leader's last 1 and the first data bit.
          // We CONSUME this bit (don't store it) and start byte assembly fresh.
          _byte     = 0;
          _bitCount = 0;
          _syncMatch = 0;
          if (_oraoNextBlock == ORAO_NEXT_RAW) {
            // Real Orao 'O' format: data block has NO sync, just length+data.
            // OraoReceive sets this after consuming the 'O' header block.
            _state = ORAO_READ_RAW;
            _oraoNextBlock = ORAO_NEXT_SYNC;   // reset to default for any next file
            if (ORAO_READ_RAW > _diagMaxState) _diagMaxState = ORAO_READ_RAW;
          } else {
            _state = ORAO_HUNT_SYNC;
            _syncShift = 0;
            _syncHuntBits = 0;
            _diagSyncEnters++;
            if (ORAO_HUNT_SYNC > _diagMaxState) _diagMaxState = ORAO_HUNT_SYNC;
          }
        } else {
          _leaderCount = 0;
        }
      }
      break;

    case WAIT_START:
      if (_startQual == 1 && _p->interByteTimeout_us > 0 && (micros() - _waitStartTime) > _p->interByteTimeout_us) {
        _decodeFinished = true;
        _lastError = DECODE_ERR_TIMEOUT;
        _state = WAIT_LEADER;
        _leaderCount = 0;
        _startQual = 0;
        _waitStartTime = micros();
        break;
      }
      
      if (bit == _p->startBit) {
        _state = READ_DATA;
        _bitCount = 0;
        _byte = 0;
        _parity = 0;
      }
      break;

    case READ_DATA:
      if (_p->bitOrder == LSB_FIRST) {
        _byte |= (bit << _bitCount);
      } else {
        _byte = (_byte << 1) | bit;
      }
      _parity ^= bit;
      _bitCount++;
      if (_bitCount == 8) {
           if (_p->parity != PARITY_NONE) {
          _state = READ_PARITY;
        } else {
          emitByte();
          goto after_byte;
        }
      }
      break;

    case READ_PARITY:
      if (_p->parity == PARITY_ODD) {
        if ((_parity ^ bit) != 1) goto parity_error;
      } else if (_p->parity == PARITY_EVEN) {
        if ((_parity ^ bit) != 0) goto parity_error;
      }
      emitByte();
      goto after_byte;

parity_error:
      if (_out) _out->println(F("PARITY ERROR"));
      _lastError = DECODE_ERR_PARITY;
      _decodeFinished = true;
      _state = WAIT_LEADER;
      _leaderCount = 0;
      _startQual = 0;
      break;

after_byte:
      if (_p->stopBits > 0) {
        _state = READ_STOP;
        _stopCount = 0;
      } else {
        _state = WAIT_START;
        _startQual = 1;
        _waitStartTime = micros();
      }
      break;

    case READ_STOP:
      if (bit == _p->stopBit) {
        if (++_stopCount >= _p->stopBits) {
          _state = WAIT_START;
          _startQual = 1;
          _waitStartTime = micros();
          _byteReady = true;

        }
      } else {
        if (_out) _out->println(F("STOP BIT ERROR"));
        _lastError = DECODE_ERR_STOPBIT;
        _decodeFinished = true;
        _state = WAIT_LEADER;
        _leaderCount = 0;
        _startQual = 0;
      }
      break;

    // -------- ORAO block-mode --------

    case ORAO_HUNT_SYNC:
      // Bit-shift register sync hunt.  We slide a 32-bit window over the
      // incoming bit stream and trigger when it matches 4×$1B in
      // little-endian-on-tape order.
      //
      // $1B = 0001 1011, sent LSB-first: bits in time order are 1,1,0,1,1,0,0,0.
      // Shifting each bit into LSB and pushing previous bits left, after 8
      // bits the register holds 0xD8 (the bit-reversed byte).  After 32
      // bits of sync, register == 0xD8D8D8D8.
      //
      // This handles the common real-hardware failure mode: a single
      // misclassified bit anywhere in or just before the sync sequence
      // would otherwise make the byte-aligned hunt see a non-$1B and abort.
      // With sliding hunt we recover within a few bits and lock cleanly.
      _syncShift = (_syncShift << 1) | (uint32_t)(bit & 1);
      _syncHuntBits++;
      if (_syncShift == 0xD8D8D8D8UL) {
        // Sync locked.  Byte-align here: next bit starts the type byte.
        _byte = 0;
        _bitCount = 0;
        _syncMatch = 4;
        _state = ORAO_READ_BLOCK;
        _blockBytesRead = 0;
        _diagSyncLocks++;
        if (ORAO_READ_BLOCK > _diagMaxState) _diagMaxState = ORAO_READ_BLOCK;
      } else if (_syncHuntBits > 96) {
        // Tried too long without finding sync (4×$1B = 32 bits, allow up to
        // 96 = some leader noise + sync + a bit of slack).  Bail to leader.
        _diagLastSyncShift = _syncShift;
        _diagSyncFails++;
        _state = WAIT_LEADER;
        _leaderCount = 0;
        _syncMatch = 0;
        _byte = 0;
        _bitCount = 0;
      }
      break;

    case ORAO_READ_BLOCK:
      // Same bit-to-byte assembly as ORAO_HUNT_SYNC, but every completed byte
      // is emitted to the consumer.  After 252 bytes the block is done and we
      // go back to leader hunt to wait for the next block (or end-of-tape).
      if (bit) _byte |= (uint8_t)(1 << _bitCount);
      _bitCount++;
      if (_bitCount == 8) {
        emitByte();
        _byte = 0;
        _bitCount = 0;
        _blockBytesRead++;
        if (_blockBytesRead >= 252) {
          _state = WAIT_LEADER;
          _leaderCount = 0;
          _syncMatch = 0;
        }
      }
      break;

    case ORAO_READ_RAW:
      // Real Orao 'O' data block: no sync, no fixed block size.  Every 8 bits
      // becomes a byte that's emitted to OraoReceive.  The receiver decides
      // when the file is complete based on the on-tape length header (the
      // first two bytes) and ends the session by stopping consumption (or by
      // letting the silence-timeout fire when the tape runs out).
      if (bit) _byte |= (uint8_t)(1 << _bitCount);
      _bitCount++;
      if (_bitCount == 8) {
        emitByte();
        _byte = 0;
        _bitCount = 0;
      }
      break;
  }
}

void CassetteDecoder::emitByte() {
  _lastByte = _byte;
  _byteReady = true;
  _anyByteEmitted = true;
  _diagBytesOut++;

  // Optional debug print.  During an ORAO block read this prints ~300us
  // of UART per byte (3-4 chars at 115200), which combined with the SPI
  // RAM write inside OraoReceive::feed would blow past one half-period of
  // headroom (~181us for bit-0).  The ring-buffer fix in poll() now
  // absorbs that latency safely, but we still skip the print inside ORAO
  // block states to leave maximum margin -- the per-byte stream isn't
  // useful diagnostic info anyway; the sticky counters in debug*() are.
  if (_out && _state != ORAO_READ_BLOCK && _state != ORAO_READ_RAW) {
    if (_byte < 0x10) _out->print('0');
    _out->print(_byte, HEX);
    _out->print(" ");
    if (_counter++ == 16 ) {_out->println(); _counter = 0;}
  }
}
