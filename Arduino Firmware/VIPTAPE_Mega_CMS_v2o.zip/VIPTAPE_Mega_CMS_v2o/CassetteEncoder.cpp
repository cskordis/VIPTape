#include "CassetteEncoder.h"

CassetteEncoder::CassetteEncoder(uint8_t outPin)
: _pin(outPin)
{
    pinMode(_pin, OUTPUT);
    digitalWrite(_pin, LOW);
}

void CassetteEncoder::setParams(const CassetteParams* p) {
  _p = p;
}


void CassetteEncoder::configure(const CassetteParams* p)
{
    _p = p;
    _lastError = ENCODE_OK;

    if (!_p) {
        _lastError = ENCODE_ERR_NO_PARAMS;
        return;
    }

    _half0_us = p->bit0 / 2;
    _half1_us = p->bit1 / 2;

    if (_half0_us == 0 || _half1_us == 0 ||
        p->bit0_cycle == 0 || p->bit1_cycle == 0) {
        _lastError = ENCODE_ERR_INVALID_PARAMS;
    }
}

void CassetteEncoder::reset()
{
    digitalWrite(_pin, LOW);
    clearError();
}

void CassetteEncoder::sendLeader()
{
    if (_lastError != ENCODE_OK || !_p) return;

    if (_p->leaderBit == 0 || _p->leaderBit == 1) {
        for (uint16_t i = 0; i < _p->leaderTime; i++) {
            sendBit(_p->leaderBit);
        }
    }
}

void CassetteEncoder::sendByte(uint8_t b)
{
    if (_lastError != ENCODE_OK || !_p) return;

    // ORAO block framing: no start/parity/stop bits, just 8 raw data bits.
    if (_p->framing == FRAMING_BLOCK_ORAO) {
        sendByteRaw(b);
        return;
    }

    uint8_t ones = 0;

    // Start bit
    if (_p->startBit == 0 || _p->startBit == 1) {
        sendBit(_p->startBit);
    }
    // Data bit
    if (_p->bitOrder == LSB_FIRST) {
        for (uint8_t i = 0; i < 8; i++) {
            uint8_t bit = (b >> i) & 1;
            if (bit) ones++;
            sendBit(bit);
        }
    } else {
        for (int8_t i = 7; i >= 0; i--) {
            uint8_t bit = (b >> i) & 1;
            if (bit) ones++;
            sendBit(bit);
        }
    }

    // Parity
    if (_p->parity != PARITY_NONE) {
        uint8_t parity = ones & 1;
        if (_p->parity == PARITY_ODD) {parity = !parity;}  // even = invert odd result
        sendBit(parity);
    }

    // Stop bits
    for (uint8_t i = 0; i < _p->stopBits; i++) {
        Serial.println(_p->stopBits);
        sendBit(_p->stopBit);
    }
}

void CassetteEncoder::sendByteRaw(uint8_t b)
{
    // ORAO is LSB-first; honour _p->bitOrder anyway for symmetry/future use.
    if (!_p || _p->bitOrder == LSB_FIRST) {
        for (uint8_t i = 0; i < 8; i++) {
            sendBit((b >> i) & 1);
        }
    } else {
        for (int8_t i = 7; i >= 0; i--) {
            sendBit((b >> i) & 1);
        }
    }
}

void CassetteEncoder::sendTrailer()
{
    if (_lastError != ENCODE_OK || !_p) return;

    if (_p->trailerBit == 0 || _p->trailerBit == 1) {
        for (uint16_t i = 0; i < _p->trailerTime; i++) {
            sendBit(_p->trailerBit);
        }
    }
}

void CassetteEncoder::sendBit(uint8_t bit)
{
    uint16_t half   = (bit == 0) ? _half0_us : _half1_us;
    uint16_t cycles = (bit == 0) ? _p->bit0_cycle : _p->bit1_cycle;
    for (uint16_t i = 0; i < cycles; i++) {
        writeHigh();
        delayMicroseconds(half);
        writeLow();
        delayMicroseconds(half);
    }
}

void CassetteEncoder::writeHigh()
{


    if (_p->polarity == POLARITY_POSITIVE)
        digitalWrite(_pin, HIGH);
    else
        digitalWrite(_pin, LOW);
}

void CassetteEncoder::writeLow()
{
    if (_p->polarity == POLARITY_POSITIVE)
        digitalWrite(_pin, LOW);
    else
        digitalWrite(_pin, HIGH);
}


// ---------------------------------------------------------------------------
// ORAO block-mode high-level send
// ---------------------------------------------------------------------------
//
// Two on-tape formats are produced, matching what the original Orao 2007 and
// Eagle Extended BASIC ROMs emit on SAVE:
//
//   'B' (BASIC source) -- multi-block with sync per block
//
//     Each 256-byte block:
//       offset 0..3   : sync $1B $1B $1B $1B
//       offset 4      : type byte ('B' = $42)
//       offset 5..14  : filename, ASCII, padded to 10 bytes with $20
//       offset 15     : block number (0, 1, 2, ...)
//       offset 16..255: 240 bytes of payload (source bytes; final byte is
//                       $1A EOF, then $20 padding to 240).
//     Each block is preceded by its own leader and a single 0-bit transition.
//
//   'O' (Object / memory image) -- header block + raw data block
//
//     Block 0 (256 bytes, with sync header) is the file *metadata*:
//       offset 0..3   : sync $1B $1B $1B $1B
//       offset 4      : type byte ('O' = $4F)
//       offset 5..14  : filename
//       offset 15     : block number = 0
//       offset 16..17 : load address (lo, hi)
//       offset 18..19 : length helper (lo, hi).  This is FE_orig / FF_orig
//                       which in the SAVE code becomes the on-tape FE/FF
//                       AFTER `INC FE` / `INC FF`.  We choose them so that
//                         (FE_orig + 1) + 256 * FF_orig == totalDataBytes
//       offset 20..255: $20 padding
//
//     After block 0 is sent, a NEW leader+transition is emitted, followed by
//     the on-tape 2-byte length header (FE_orig+1, FF_orig+1) and the raw
//     program bytes.  No sync $1B is emitted for the data block.

void CassetteEncoder::sendOraoFile(const char* filename,
                                   uint32_t totalDataBytes,
                                   uint16_t loadAddr,
                                   uint16_t endAddr,
                                   OraoByteReader reader,
                                   void* readerCtx)
{
    if (_lastError != ENCODE_OK || !_p) {
        _lastError = ENCODE_ERR_NO_PARAMS;
        return;
    }
    if (_p->framing != FRAMING_BLOCK_ORAO || !reader) {
        _lastError = ENCODE_ERR_INVALID_PARAMS;
        return;
    }

    // Build a 10-byte space-padded filename buffer once.
    char fnPadded[10];
    {
        bool exhausted = false;
        for (uint8_t i = 0; i < 10; i++) {
            if (exhausted || filename == nullptr || filename[i] == '\0') {
                fnPadded[i] = ' ';
                exhausted = true;
            } else {
                fnPadded[i] = filename[i];
            }
        }
    }

    const bool isObject = (_p->oraoType == ORAO_TYPE_OBJECT);
    const uint8_t typeByte = isObject ? (uint8_t)ORAO_TYPE_OBJECT
                                      : (uint8_t)ORAO_TYPE_BASIC;

    // 256-byte SRAM scratch buffer used for the header block (and for 'B'
    // mode for every block).  See the build-then-stream rationale below.
    uint8_t blockBuf[256];

    // ===========================================================================
    // 'O' files: emit header block, then the raw data block.
    // ===========================================================================
    if (isObject) {
        // Compute FE_orig / FF_orig such that
        //   (FE_orig + 1) + 256 * FF_orig == totalDataBytes
        // For totalDataBytes >= 1: FF_orig = (N-1) >> 8, FE_orig = (N-1) & 0xFF.
        // (For N == 0 we still emit a header block but no data.)
        uint8_t feOrig = 0, ffOrig = 0;
        if (totalDataBytes > 0) {
            uint32_t nMinus = totalDataBytes - 1;
            feOrig = (uint8_t)(nMinus & 0xFF);
            ffOrig = (uint8_t)((nMinus >> 8) & 0xFF);
        }

        // ---- Build the 256-byte header block in SRAM --------------------------
        blockBuf[0] = 0x1B;  blockBuf[1] = 0x1B;
        blockBuf[2] = 0x1B;  blockBuf[3] = 0x1B;
        blockBuf[4] = typeByte;
        for (uint8_t i = 0; i < 10; i++) blockBuf[5 + i] = (uint8_t)fnPadded[i];
        blockBuf[15] = 0x00;                                   // block# = 0
        blockBuf[16] = (uint8_t)( loadAddr        & 0xFF);     // load_lo
        blockBuf[17] = (uint8_t)((loadAddr >> 8 ) & 0xFF);     // load_hi
        blockBuf[18] = feOrig;                                 // length helper lo
        blockBuf[19] = ffOrig;                                 // length helper hi
        for (uint16_t i = 20; i < 256; i++) blockBuf[i] = 0x20; // $20 padding

        // ---- Send the header block ------------------------------------------
        sendLeader();
        sendBit(0);                              // leader-to-data transition
        for (uint16_t i = 0; i < 256; i++) sendByteRaw(blockBuf[i]);

        if (_lastError == ENCODE_ERR_ABORTED) return;

        // ---- Send the raw data block ----------------------------------------
        // Format: leader + 0-bit transition + (FE_orig+1) + (FF_orig+1) + N bytes.
        // Note that on real hardware the SAVE code does `INC FE` / `INC FF`
        // (8-bit wraps), so we mirror that here.
        sendLeader();
        sendBit(0);
        sendByteRaw((uint8_t)(feOrig + 1));      // FE_tape
        sendByteRaw((uint8_t)(ffOrig + 1));      // FF_tape
        for (uint32_t i = 0; i < totalDataBytes; i++) {
            if (_lastError == ENCODE_ERR_ABORTED) return;
            sendByteRaw(reader(i, readerCtx));
        }
        // One trailing bit so the decoder can finish the last byte's cycle.
        // Without it the receiver is always one byte short on data blocks.
        sendBit(_p->leaderBit);
        return;
    }

    // ===========================================================================
    // 'B' files: classic multi-block-with-sync, payload is source + $1A + $20 pad.
    // ===========================================================================
    const uint32_t logical   = totalDataBytes + 1;             // +1 for $1A EOF
    uint32_t blockCount = (logical + 239) / 240;
    if (blockCount == 0) blockCount = 1;

    uint32_t srcIndex   = 0;
    uint32_t logicalPos = 0;

    for (uint32_t blk = 0; blk < blockCount; blk++) {
        if (_lastError == ENCODE_ERR_ABORTED) return;

        // Phase 1: build the block in SRAM.
        blockBuf[0] = 0x1B;  blockBuf[1] = 0x1B;
        blockBuf[2] = 0x1B;  blockBuf[3] = 0x1B;
        blockBuf[4] = typeByte;
        for (uint8_t i = 0; i < 10; i++) blockBuf[5 + i] = (uint8_t)fnPadded[i];
        blockBuf[15] = (uint8_t)(blk & 0xFF);

        for (uint16_t i = 0; i < 240; i++) {
            uint8_t b = 0x20;
            if (logicalPos < logical) {
                if (logicalPos == totalDataBytes) {
                    b = 0x1A;                                  // EOF marker
                } else {
                    b = reader(srcIndex, readerCtx);
                    srcIndex++;
                }
            }
            blockBuf[16 + i] = b;
            logicalPos++;
        }

        // Phase 2: transmit (no slow calls here).
        sendLeader();
        sendBit(0);
        for (uint16_t i = 0; i < 256; i++) sendByteRaw(blockBuf[i]);
    }
}
