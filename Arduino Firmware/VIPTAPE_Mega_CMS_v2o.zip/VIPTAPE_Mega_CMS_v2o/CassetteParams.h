#pragma once
#include <Arduino.h>

enum BitOrder {
  MSB_FIRST,
  LSB_FIRST
};

enum ParityMode {
  PARITY_NONE,
  PARITY_ODD,
  PARITY_EVEN
};

enum PolarityMode {
  POLARITY_NEGATIVE,
  POLARITY_POSITIVE
};

// ---- Framing mode -------------------------------------------------------
//
// FRAMING_ASYNC      : classic UART-style framing (start bit / data / parity / stop bits).
//                      This is the original behaviour and the default for every
//                      existing protocol entry, since unspecified trailing fields
//                      in a brace-initialiser default to zero.
//
// FRAMING_BLOCK_ORAO : ORAO 6502 cassette framing.
//                      No byte-level framing at all -- bytes are 8 raw data bits
//                      back-to-back.  Framing is at the block level: a long leader
//                      precedes a 256-byte block of (4x $1B sync, 1 type byte,
//                      10-byte filename, 1 block-number byte, 240 byte payload).
//                      Multi-block files send the same filename in each block with
//                      an incrementing block number, each preceded by its own leader.
//
enum FramingMode {
  FRAMING_ASYNC      = 0,
  FRAMING_BLOCK_ORAO = 1
};

// ---- ORAO block type byte ----------------------------------------------
//
// Only meaningful when framing == FRAMING_BLOCK_ORAO.  The byte is written into
// every block at offset 4 and tells the receiver how to interpret the payload.
//
//   ORAO_TYPE_BASIC  ('B') : payload is BASIC source as LIST would emit it,
//                            terminated by $1A (Ctrl-Z) and space-padded to 240.
//   ORAO_TYPE_OBJECT ('O') : the first 4 bytes of the FIRST block's payload are
//                            load_lo, load_hi, end_lo, end_hi.  The remaining
//                            payload bytes (across all blocks) are the program
//                            bytes from load_addr to end_addr inclusive,
//                            space-padded in the final block.
//
enum OraoType {
  ORAO_TYPE_NONE   = 0,
  ORAO_TYPE_BASIC  = 0x42,    // 'B'
  ORAO_TYPE_OBJECT = 0x4F     // 'O'
};


struct CassetteParams {
  const char* name;
  uint16_t bit0;
  uint16_t bit0_min;
  uint16_t bit0_max;

  uint16_t bit1;
  uint16_t bit1_min;
  uint16_t bit1_max;

  uint8_t  leaderBit;
  uint16_t leaderBits;
  uint16_t leaderTime;

  uint8_t  startBit;

  BitOrder   bitOrder;
  ParityMode parity;

  uint32_t interByteTimeout_us;

  uint8_t  stopBit;
  uint8_t  stopBits;

  uint8_t  trailerBit;
  uint16_t trailerTime;

  uint16_t bit0_cycle;
  uint16_t bit1_cycle;

  PolarityMode polarity;

  // ---- New fields (added at end so existing brace-initializers stay valid) ----
  // Existing entries default these to FRAMING_ASYNC / ORAO_TYPE_NONE via zero-init.
  FramingMode framing;
  OraoType    oraoType;
};
