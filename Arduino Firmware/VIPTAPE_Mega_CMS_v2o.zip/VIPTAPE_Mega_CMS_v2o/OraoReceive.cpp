#include "OraoReceive.h"
#include <string.h>

OraoReceive::OraoReceive(RamExternal& ram, CassetteDecoder& decoder)
    : _ram(ram), _decoder(decoder) {
    begin();
}

void OraoReceive::begin() {
    _status            = OR_RUNNING;
    _field             = F_TYPE;
    _type              = '\0';
    memset(_filename, 0, sizeof(_filename));
    _filenameIdx       = 0;
    _expectedBlock     = 0;
    _payloadIdx        = 0;
    _firstBlock        = true;
    _addrIdx           = 0;
    _loadAddr          = 0;
    _endAddr           = 0;
    _helperLo          = 0;
    _helperHi          = 0;
    _addrPtr           = 0;
    _rawBytesRemaining = 0;
    _ramBytes          = 0;
}

OraoReceive::Status OraoReceive::feed(uint8_t b) {
    if (_status != OR_RUNNING) return _status;

    switch (_field) {

    case F_TYPE:
        // Each block (header block of 'O' or any block of 'B') begins with
        // the type byte (after the decoder has stripped sync $1B*4).
        if (_firstBlock) {
            if (b != (uint8_t)'B' && b != (uint8_t)'O') {
                _status = OR_ERROR;
                return _status;
            }
            _type = (char)b;
        } else {
            // 'B' multi-block: subsequent blocks must agree on the type.
            // ('O' files don't reach here -- they switch to F_RAW_DATA after
            // block 0 instead of going back to F_TYPE.)
            if ((char)b != _type) {
                _status = OR_ERROR;
                return _status;
            }
        }
        _filenameIdx = 0;
        _field       = F_NAME;
        break;

    case F_NAME:
        if (_firstBlock) {
            _filename[_filenameIdx] = (char)b;
        } else {
            if ((char)b != _filename[_filenameIdx]) {
                _status = OR_ERROR;
                return _status;
            }
        }
        _filenameIdx++;
        if (_filenameIdx >= 10) {
            _filename[10] = '\0';
            _field        = F_BLKNUM;
        }
        break;

    case F_BLKNUM:
        if (b != _expectedBlock) {
            _status = OR_ERROR;
            return _status;
        }
        _expectedBlock++;
        _payloadIdx = 0;
        _addrIdx    = 0;
        _field      = F_PAYLOAD;
        break;

    case F_PAYLOAD:
        if (_type == 'O') {
            // -------- 'O' header block --------
            // Block 0's 240-byte payload begins with 4 bytes:
            //   [0] load_lo   [1] load_hi
            //   [2] helper_lo [3] helper_hi
            // The remaining 236 bytes are $20 padding (we ignore them).
            if (_firstBlock && _addrIdx < 4) {
                switch (_addrIdx) {
                    case 0: _loadAddr  =  (uint16_t)b;        break;
                    case 1: _loadAddr |= ((uint16_t)b) << 8;  break;
                    case 2: _helperLo  = b;                   break;
                    case 3: _helperHi  = b;                   break;
                }
                _addrIdx++;
            }
            // else: trailing $20 padding -- ignore.

            _payloadIdx++;
            if (_payloadIdx >= 240) {
                // End of 'O' header block.  The next leader-end transition
                // must be treated as a RAW data block (no sync), so tell the
                // decoder ahead of time.  After that we read 2 length bytes
                // followed by N data bytes.
                _decoder.setOraoNextBlockMode(CassetteDecoder::ORAO_NEXT_RAW);
                _firstBlock = false;
                _addrPtr    = _loadAddr;
                _field      = F_RAW_LEN_LO;
            }
        } else {
            // -------- 'B' multi-block source --------
            // Write source bytes to RAM until we see $1A (Ctrl-Z EOF).  Note
            // RAM addressing here uses a plain running counter starting at 0,
            // matching the historical behaviour.  The caller (writeOraoBasic
            // path) reads back from address 0 for _ramBytes bytes.
            if (b == 0x1A) {
                _status = OR_DONE;
            } else {
                _ram.writeByte((uint16_t)_ramBytes, b);
                _ramBytes++;
            }

            _payloadIdx++;
            if (_payloadIdx >= 240) {
                _firstBlock = false;
                _field      = F_TYPE;   // expect next block's full header
            }
        }
        break;

    case F_RAW_LEN_LO:
        // First byte of the data block on tape.  This is FE_tape (= original
        // FE+1 from the SAVE INC).  We just store it; the count is computed
        // when FF_tape arrives.
        _helperLo = b;   // re-use slot -- value is FE_tape, not original
        _field    = F_RAW_LEN_HI;
        break;

    case F_RAW_LEN_HI:
        // Second byte of the data block on tape: FF_tape.
        // Total bytes in the data block, exactly mirroring the SAVE/LOAD
        // inner loop arithmetic on a real Orao:
        //
        //   first_chunk = (FE_tape == 0) ? 256 : FE_tape
        //   total       = first_chunk + ((uint8_t)(FF_tape - 1)) * 256
        //
        // Thus the maximum is 256 * 256 = 65536 bytes (FE=0, FF=0).
        {
            uint8_t  feTape = _helperLo;       // stored from F_RAW_LEN_LO
            uint8_t  ffTape = b;
            uint16_t firstChunk = (feTape == 0) ? 256 : (uint16_t)feTape;
            uint8_t  outer = (uint8_t)(ffTape - 1);
            uint32_t n = (uint32_t)firstChunk + (uint32_t)outer * 256u;
            _rawBytesRemaining = n;
            _endAddr = (uint16_t)(_loadAddr + n - 1);
            if (n == 0) {
                _status = OR_DONE;
            } else {
                _field = F_RAW_DATA;
            }
        }
        break;

    case F_RAW_DATA:
        // Plain data byte to be stored at load_addr++.
        _ram.writeByte(_addrPtr, b);
        _addrPtr++;
        _ramBytes++;
        if (_rawBytesRemaining > 0) _rawBytesRemaining--;
        if (_rawBytesRemaining == 0) {
            _status = OR_DONE;
        }
        break;
    }

    return _status;
}
