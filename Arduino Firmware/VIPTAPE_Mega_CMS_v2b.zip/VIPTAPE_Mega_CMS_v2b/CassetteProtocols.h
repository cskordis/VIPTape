#pragma once

#include <stdint.h>
#include "CassetteParams.h"

// Protocol table is defined in CassetteProtocols.cpp
extern const CassetteParams cassetteProtocols[];
extern const uint8_t cassetteProtocolCount;
