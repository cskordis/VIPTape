#ifndef CASSETTE_ENCODER_H
#define CASSETTE_ENCODER_H

#include <Arduino.h>
#include "CassetteParams.h"

// ---- Encoder error reporting ----
enum EncodeError {
    ENCODE_OK = 0,
    ENCODE_ERR_NO_PARAMS,
    ENCODE_ERR_INVALID_PARAMS,
    ENCODE_ERR_ABORTED,
    ENCODE_ERR_UNKNOWN
};

class CassetteEncoder {
public:
    explicit CassetteEncoder(uint8_t outPin);

    void begin();
    void configure(const CassetteParams* p);
    void setParams(const CassetteParams* p);
    void reset();

    void sendLeader();
    void sendByte(uint8_t b);
    void sendTrailer();

    // CMS compatibility (used for UI test pulse)
    void pulseBit(uint8_t bit) { sendBit(bit); }

    // Error handling
    EncodeError lastError() const { return _lastError; }
    bool hasError() const { return _lastError != ENCODE_OK; }
    void clearError() { _lastError = ENCODE_OK; }
    void abort() { _lastError = ENCODE_ERR_ABORTED; }

private:
    void sendBit(uint8_t bit);
    void writeHigh();
    void writeLow();

    uint8_t _pin;
    const CassetteParams* _p = nullptr;

    uint16_t _half0_us = 0;
    uint16_t _half1_us = 0;

    EncodeError _lastError = ENCODE_OK;
};

#endif
