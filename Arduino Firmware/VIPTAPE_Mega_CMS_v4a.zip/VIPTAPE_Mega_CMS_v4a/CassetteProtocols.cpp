#include "CassetteProtocols.h"

// NOTE: Keep the protocol table *only* in this .cpp so the array is complete here.
// This prevents "incomplete type" sizeof errors and avoids multiple-definition issues.
//
// Field order (existing entries):
//   name, bit0, bit0_min, bit0_max, bit1, bit1_min, bit1_max,
//   leaderBit, leaderBits, leaderTime, startBit, bitOrder, parity,
//   interByteTimeout_us, stopBit, stopBits, trailerBit, trailerTime,
//   bit0_cycle, bit1_cycle, polarity
//
// Two extra fields exist after polarity (framing, oraoType).  Existing entries
// don't list them so they default to FRAMING_ASYNC / ORAO_TYPE_NONE.
//
// ORAO timings (full cycle in us) are derived from the Orao 2007 ROM and verified
// against real cassette WAV captures: bit-0 ~362us (~2.76kHz), bit-1 ~726us
// (~1.38kHz).  Min/max bounds are widened to absorb tape speed wobble and clock
// drift.  Discrimination threshold sits roughly at the geometric mean (~540us).

const CassetteParams cassetteProtocols[] = {

  {"VIP", 500, 420, 620, 1250, 1050, 1450, 0, 200, 5000, 1, LSB_FIRST, PARITY_EVEN, 20000, 0, 0, 0, 0, 1, 1, POLARITY_POSITIVE},
  {"ELF II", 833, 600, 1350, 416, 300, 520, 1, 200, 8000, 0, MSB_FIRST, PARITY_ODD, 20000, 0, 0, 0, 0, 1, 1,  POLARITY_NEGATIVE},
  {"HUG 1802", 2000, 1400, 2600, 1000, 200, 1200, 1, 200, 5000, 0, MSB_FIRST, PARITY_ODD, 20000, 0, 0, 0, 0, 1, 1, POLARITY_NEGATIVE},
  {"KCS 300", 833, 600, 1350, 416, 300, 520, 0, 0, 5000, 1, LSB_FIRST, PARITY_EVEN, 20000, 0, 0, 0, 0, 4, 8, POLARITY_POSITIVE},
  {"KCS 1200", 416, 300, 520, 208, 150, 350, 0, 0, 5000, 1, LSB_FIRST, PARITY_EVEN, 20000, 0, 0, 0, 0, 4, 8, POLARITY_POSITIVE},
  {"ORAO B", 362, 280, 540, 726, 540, 950, 1, 32, 2500, 0, LSB_FIRST, PARITY_NONE, 0, 0, 0, 0, 0, 1, 1, POLARITY_POSITIVE, FRAMING_BLOCK_ORAO, ORAO_TYPE_BASIC},
  {"ORAO O", 362, 280, 540, 726, 540, 950, 1, 32, 2500, 0, LSB_FIRST, PARITY_NONE, 0, 0, 0, 0, 0, 1, 1, POLARITY_POSITIVE, FRAMING_BLOCK_ORAO, ORAO_TYPE_OBJECT},

  // ---- COMX-35 (RCA CDP1802, BASIC V1.03 ROM) -----------------------------
  // Verified against three real-machine SAVE captures (Raider/Diver/CrossFire,
  // 22050Hz mono 16-bit).  Physical layer is plain 2-tone FSK, one full cycle
  // per bit (CHANGE-edge half-cycle pairing, same as the async protocols):
  //
  //   bit-0 : ~500us full cycle  (~2000 Hz)   <- also the leader tone
  //   bit-1 : ~1220us full cycle (~820 Hz)
  //
  // Framing is BIT-SYNCHRONOUS (FRAMING_SYNC_COMX), not UART-async.  After the
  // leader (a long run of bit-0 cells) locks, data is read as fixed 10-cycle
  // cells: cell[0] lead framing cycle, cell[1..8] = 8 data bits LSB-first,
  // cell[9] trail framing cycle.  The framing cycles are NOT fixed 1/0 values,
  // so phase is locked once at the leader and maintained by counting cells --
  // a per-byte start-bit hunt (the async path) would mis-sync.  This was
  // confirmed empirically: fixed 10-cell extraction recovers the program image
  // byte-perfect (header 00 11 LL 00, the CDP1802 loader stub, and in-program
  // ASCII strings all decode cleanly), whereas start-bit resync drifts.
  //
  // The two period windows are the only bench-tunable values: if a real load
  // misreads, capture a known-good SAVE, read the two cycle-length peaks, and
  // nudge bit0/bit1 (and their min/max) to match.  Min/max are widened well
  // clear of the ~860us inter-symbol threshold to absorb tape-speed wobble.
  //
  // On-tape program image begins with a 4-byte header: 00 11 LL 00, where LL is
  // a length/page byte; the bytes that follow are the raw CDP1802 program image
  // (COMX 'M' machine-code save).  Header parsing is left to FileAnalyzer.
  //
  // Field notes:
  //   leaderBit  = 0           : leader is the bit-0 (~2kHz) tone.
  //   leaderBits = 256         : decoder lock threshold (~0.13s; real leader is
  //                              ~49000 cells, so lock is effectively instant).
  //   leaderTime = 8000        : leader cells the ENCODER emits on SAVE (~4s).
  //   startBit/stopBit/stopBits/parity : UNUSED in FRAMING_SYNC_COMX (the cell
  //                              counter does the framing); left 0 / NONE.
  //   interByteTimeout_us = 0  : no inter-byte idle; timeout disabled.
  //   bit0_cycle = bit1_cycle = 1 : one full cycle per bit.
  // Tone periods from a GENUINE Diver tape (22050Hz) that decodes BYTE-PERFECT
  // to the known Diver image (00 11 6A 00 ... F8 44 B7 ...):
  //   bit0 = 408us (2450 Hz)    bit1 = 1043us (959 Hz)    ratio 2.556
  // Leader ~49000 cells x 408us = ~20-23s (matches the real tape).
  // NOTE: earlier detours to 500us and 816us came from mis-recorded captures
  // (a ~25%-slow file and a half-speed 44.1kHz file whose periods read 2x).
  // This is the verified value -- VIPTAPE's ORIGINAL uncalibrated output was
  // already ~408us, i.e. essentially correct from the start.
  {"COMX-35", 408, 300, 620, 1043, 760, 1300, 0, 256, 49000, 0, LSB_FIRST, PARITY_NONE, 0, 0, 0, 0, 0, 1, 1, POLARITY_NEGATIVE, FRAMING_SYNC_COMX, ORAO_TYPE_NONE}
  //{"DREAM 6800", 833, 700, 950, 400, 320, 520, 1, 200, 5000, 0, LSB_FIRST, PARITY_NONE, 50000, 1, 1, 0, 0, 4, 8, POLARITY_POSITIVE},

  };

const uint8_t cassetteProtocolCount = sizeof(cassetteProtocols) / sizeof(cassetteProtocols[0]);
