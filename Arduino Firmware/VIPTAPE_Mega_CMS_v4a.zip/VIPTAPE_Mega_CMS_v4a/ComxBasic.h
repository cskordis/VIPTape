#ifndef COMX_BASIC_H
#define COMX_BASIC_H

#include <Arduino.h>
#include <string.h>
#include "RamExternal.h"

// ---------------------------------------------------------------------------
// COMX-35 BASIC tokeniser (on-device, external-RAM based)
// ---------------------------------------------------------------------------
// Converts COMX BASIC *source text* into the tokenised on-tape *image* the COMX
// LOAD routine expects.  Raw ASCII text will NOT load on a COMX (the LOAD code
// looks for the 16-byte header + tokenised line records and otherwise waits
// forever); this class produces the real image so the COMX-35 (FRAMING_SYNC_COMX)
// encoder path can SAVE a program that actually loads.
//
// Format verified byte-for-byte against two real COMX SAVE captures:
//   HEADER (16 bytes):
//     00 11 01 00 00 00 <ENDPTR> 16 71 FE 37 EC 34 9F 7B 1F
//       byte 6 ENDPTR = (offset of the FF FF end marker) + 1, from image byte 0.
//   PROGRAM: per line  ->  00 <lineno> <link> <tokens...> 0D
//       link = offset from the link byte to the next record (record length from
//              the link byte through the 0D inclusive).
//   END: FF FF
//   TOKENS: 86=PRINT 87=GOTO  CF/CE=string open/close  D1=assign-lead  CC='='
//           D2 + 4-byte BIG-ENDIAN int = numeric constant.
//   Variable names and string contents are raw ASCII.
//
// SCOPE: only the verified subset (PRINT, GOTO, string literals, single-var
// assignment, integer constants 0..0xFFFFFFFF, line numbers 0..255) is encoded.
// Anything else makes tokenise() fail with a clear error rather than emit a
// guessed (wrong) token -- a wrong token is exactly what makes the COMX hang,
// so we fail on the bench, not on the tape.
//
// Memory model: the source text is already in external SPI RAM (loaded from SD
// by FileLoader) at [srcStart .. srcEnd].  We read it from there and write the
// image to a DIFFERENT region of the same external RAM (default: high end), so
// nothing needs to fit in the Mega's SRAM.  Returns the image length, or 0 on
// error (errorMsg set).

class ComxBasic {
public:
    explicit ComxBasic(RamExternal& ram) : _ram(ram) {}

    // Tokenise source text in RAM[srcStart..srcEnd] -> image at RAM[dstStart..].
    // On success, returns image length and sets dstStart..dstStart+len-1 as the
    // bytes to SAVE.  On failure returns 0 and fills _err.
    // dstStart must not overlap [srcStart..srcEnd].
    uint16_t tokeniseInRam(uint16_t srcStart, uint16_t srcEnd, uint16_t dstStart);

    const char* error() const { return _err; }

private:
    RamExternal& _ram;
    char _err[40] = {0};

    // Source cursor over external RAM.
    uint16_t _s = 0, _sEnd = 0;
    int  peek();                 // current char or -1 at end
    int  next();                 // consume + return char or -1
    void skipSpaces();
    bool matchKeyword(const char* kw, uint8_t len);  // case-insensitive, advances on match
    bool readUint(uint32_t& out);                    // base-10 uint at cursor

    // Image write cursor.
    uint16_t _d = 0;
    void emit(uint8_t b) { _ram.writeByte(_d++, b); }
    void emitNum(uint32_t n);       // D2 + 4-byte BE integer
    void emitFloat(double x);       // D3 + [exp+128] + 24-bit mantissa

    // Extended tokenizer (validated byte-for-byte vs genuine COMX PSAVE):
    uint8_t matchKeywordTable();    // greedy keyword match at cursor -> token or 0
    void    tokeniseBody();         // tokenise one line body to end-of-line

    void fail(const char* m) { strncpy(_err, m, sizeof(_err)-1); }
};

#endif
