#include "ComxBasic.h"
#include <avr/pgmspace.h>

// ============================================================================
//  COMX-35 BASIC V1.03 tokeniser  (EXTENDED)
// ----------------------------------------------------------------------------
//  Converts COMX BASIC source text into the tokenised on-tape image the COMX
//  LOAD routine expects.  The full token set was extracted from the genuine
//  ROM (comx35_1_3.bin, keyword table @ 0x1100) and the numeric/variable/
//  operator encodings were verified BYTE-FOR-BYTE against genuine COMX PSAVE
//  captures (PSAVEToken.wav, PSAVEToken2.wav):
//
//    variable ref : D1 + ASCII name
//    integer      : D2 + 4-byte BIG-endian
//    float        : D3 + [exp+128] + 24-bit mantissa (frac in [0.5,1), top bit
//                   is the implied leading 1; sign in top bit of first mantissa
//                   byte).  e.g. 3.14 -> D3 82 48 F5 C3
//    string       : CF <ascii> CE
//    operators/punct: single tokens ( = CC  * CA  + C8  - C9  / CB  ( D6  ) C4
//                     , C2  ; C3  > C7  < C6  >= BD  <= BE  <> BF  ^ BB  : CD )
//    keywords     : from COMX_KW_BLOB below (packed PROGMEM table)
//    REM          : 80 then the REST OF THE LINE as literal ASCII (verified)
//
//  Header + ENDPTR + block-count logic is unchanged from the verified loader.
// ============================================================================

static const uint8_t HDR_PRE[6]  = {0x00,0x11,0x01,0x00,0x00,0x00};
static const uint8_t HDR_POST[8] = {0x21,0xEC,0x37,0xAC,0x14,0x9D,0x23,0x1B};
static const uint16_t ENDPTR_BASE = 0x1000;

// Token constants
static const uint8_t TOK_VAR       = 0xD1;
static const uint8_t TOK_INT       = 0xD2;
static const uint8_t TOK_FLT       = 0xD3;
static const uint8_t TOK_STR_OPEN  = 0xCF;
static const uint8_t TOK_STR_CLOSE = 0xCE;
static const uint8_t TOK_REM       = 0x80;

// ---- keyword table (from ROM) as a packed PROGMEM blob --------------------
// Layout: repeated [len][chars...][token], terminated by a 0 length byte.
// Stored ENTIRELY in flash (PROGMEM) so it uses ZERO SRAM.  Entries are ordered
// longest-first so the greedy matcher picks e.g. RESTORE before RE, CHR$ before
// a bare variable, etc.
static const uint8_t COMX_KW_BLOB[] PROGMEM = {
  0x08,0x52,0x45,0x4E,0x55,0x4D,0x42,0x45,0x52,0xB1,0x07,0x52,0x45,0x53,0x54,0x4F,
  0x52,0x45,0x9D,0x06,0x44,0x45,0x46,0x49,0x4E,0x54,0x96,0x06,0x52,0x45,0x54,0x55,
  0x52,0x4E,0x8C,0x06,0x53,0x43,0x52,0x45,0x45,0x4E,0xA4,0x06,0x54,0x49,0x4D,0x4F,
  0x55,0x54,0xA2,0x06,0x56,0x4F,0x4C,0x55,0x4D,0x45,0xA9,0x05,0x43,0x4F,0x4C,0x4F,
  0x52,0xA5,0x05,0x43,0x54,0x4F,0x4E,0x45,0xA6,0x05,0x44,0x45,0x46,0x55,0x53,0x99,
  0x05,0x44,0x4C,0x4F,0x41,0x44,0xA1,0x05,0x44,0x53,0x41,0x56,0x45,0xA0,0x05,0x46,
  0x49,0x58,0x45,0x44,0x91,0x05,0x47,0x4F,0x53,0x55,0x42,0x8B,0x05,0x49,0x4E,0x50,
  0x55,0x54,0x89,0x05,0x4D,0x55,0x53,0x49,0x43,0x95,0x05,0x4E,0x4F,0x49,0x53,0x45,
  0xA3,0x05,0x50,0x4C,0x4F,0x41,0x44,0x98,0x05,0x50,0x52,0x49,0x4E,0x54,0x86,0x05,
  0x50,0x53,0x41,0x56,0x45,0x97,0x05,0x53,0x48,0x41,0x50,0x45,0xAB,0x05,0x54,0x52,
  0x41,0x43,0x45,0xA7,0x04,0x43,0x41,0x4C,0x4C,0xA8,0x04,0x43,0x48,0x52,0x24,0xB9,
  0x04,0x43,0x50,0x4F,0x53,0xB0,0x04,0x44,0x41,0x54,0x41,0x9B,0x04,0x45,0x44,0x49,
  0x54,0xB2,0x04,0x45,0x58,0x49,0x54,0xAE,0x04,0x46,0x4E,0x55,0x4D,0xE3,0x04,0x46,
  0x56,0x41,0x4C,0xEC,0x04,0x47,0x4F,0x54,0x4F,0x87,0x04,0x49,0x4E,0x55,0x4D,0xE1,
  0x04,0x4C,0x49,0x53,0x54,0x8A,0x04,0x4D,0x49,0x44,0x24,0xBA,0x04,0x4E,0x45,0x58,
  0x54,0x90,0x04,0x50,0x45,0x45,0x4B,0xDD,0x04,0x50,0x4F,0x4B,0x45,0x92,0x04,0x50,
  0x4F,0x55,0x54,0xAD,0x04,0x52,0x45,0x41,0x44,0x9C,0x04,0x53,0x54,0x45,0x50,0xC0,
  0x04,0x53,0x54,0x52,0x24,0xED,0x04,0x54,0x48,0x45,0x4E,0xC5,0x04,0x54,0x49,0x4D,
  0x45,0xAF,0x04,0x54,0x4F,0x4E,0x45,0xAA,0x04,0x57,0x41,0x49,0x54,0x8D,0x03,0x41,
  0x42,0x53,0xDE,0x03,0x41,0x4E,0x44,0xB5,0x03,0x41,0x53,0x43,0xE4,0x03,0x41,0x54,
  0x4E,0xD8,0x03,0x43,0x4C,0x44,0x9F,0x03,0x43,0x4F,0x53,0xD5,0x03,0x44,0x45,0x47,
  0x93,0x03,0x44,0x49,0x4D,0x8E,0x03,0x44,0x4F,0x53,0xAC,0x03,0x45,0x4E,0x44,0x84,
  0x03,0x45,0x4F,0x44,0x9E,0x03,0x45,0x4F,0x50,0x9A,0x03,0x45,0x58,0x50,0xD9,0x03,
  0x46,0x4F,0x52,0x8F,0x03,0x49,0x4E,0x54,0xDC,0x03,0x4B,0x45,0x59,0xF0,0x03,0x4C,
  0x45,0x4E,0xE5,0x03,0x4C,0x45,0x54,0x85,0x03,0x4C,0x4F,0x47,0xDA,0x03,0x4D,0x45,
  0x4D,0xEE,0x03,0x4D,0x4F,0x44,0xE8,0x03,0x4E,0x45,0x57,0x82,0x03,0x4E,0x4F,0x54,
  0xEA,0x03,0x52,0x41,0x44,0x94,0x03,0x52,0x45,0x4D,0x80,0x03,0x52,0x4E,0x44,0xDF,
  0x03,0x52,0x55,0x4E,0x83,0x03,0x53,0x47,0x4E,0xE7,0x03,0x53,0x49,0x4E,0xD4,0x03,
  0x53,0x51,0x52,0xDB,0x03,0x54,0x41,0x42,0xBC,0x03,0x55,0x53,0x52,0xE0,0x03,0x58,
  0x4F,0x52,0xB6,0x02,0x49,0x46,0x88,0x02,0x4F,0x52,0xB7,0x02,0x50,0x49,0xEB,0x02,
  0x54,0x4F,0xC1,0x00,
};

// ---- single-char operator/punctuation tokens -------------------------------
static uint8_t op1(uint8_t c) {
  switch (c) {
    case '^': return 0xBB;  case ',': return 0xC2;  case ';': return 0xC3;
    case ')': return 0xC4;  case '<': return 0xC6;  case '>': return 0xC7;
    case '+': return 0xC8;  case '-': return 0xC9;  case '*': return 0xCA;
    case '/': return 0xCB;  case '=': return 0xCC;  case ':': return 0xCD;
    case '(': return 0xD6;  case '\\': return 0xE6;
    default:  return 0x00;
  }
}

// ---- source cursor ---------------------------------------------------------
int ComxBasic::peek() { if (_s > _sEnd) return -1; return _ram.readByte(_s); }
int ComxBasic::next() { if (_s > _sEnd) return -1; return _ram.readByte(_s++); }
void ComxBasic::skipSpaces() {
  while (_s <= _sEnd) { uint8_t c=_ram.readByte(_s); if (c==' '||c=='\t') _s++; else break; }
}

void ComxBasic::emitNum(uint32_t n) {
  emit(TOK_INT);
  emit((uint8_t)((n>>24)&0xFF)); emit((uint8_t)((n>>16)&0xFF));
  emit((uint8_t)((n>> 8)&0xFF)); emit((uint8_t)( n     &0xFF));
}

// ---- float encoder: value = mantissa(frac in [0.5,1)) * 2^exp ---------------
// Stored: D3 [exp+128] [3-byte 24-bit mantissa, top bit implied 1, sign in bit7]
void ComxBasic::emitFloat(double x) {
  emit(TOK_FLT);
  if (x == 0.0) { emit(0); emit(0); emit(0); emit(0); return; }
  uint8_t sign = (x < 0.0) ? 0x80 : 0x00;
  if (x < 0.0) x = -x;
  int exp = 0;
  while (x >= 1.0) { x /= 2.0; exp++; }
  while (x <  0.5) { x *= 2.0; exp--; }
  // x now in [0.5,1); 24-bit mantissa
  uint32_t m = (uint32_t)(x * 16777216.0 + 0.5);   // *2^24, rounded
  if (m > 0xFFFFFF) m = 0xFFFFFF;
  uint8_t b1 = (uint8_t)((m>>16)&0x7F) | sign;      // top bit = sign (implied 1 dropped)
  uint8_t b2 = (uint8_t)((m>> 8)&0xFF);
  uint8_t b3 = (uint8_t)( m     &0xFF);
  emit((uint8_t)((exp+128)&0xFF));
  emit(b1); emit(b2); emit(b3);
}

// ---- match a keyword at the cursor (case-insensitive, greedy) --------------
// Returns token (>0) and advances past it, or 0 if no keyword matches here.
uint8_t ComxBasic::matchKeywordTable() {
  uint16_t p = 0;                       // index into COMX_KW_BLOB (PROGMEM)
  for (;;) {
    uint8_t len = pgm_read_byte(&COMX_KW_BLOB[p]);
    if (len == 0) break;                // end of table
    uint16_t wp = p + 1;                // keyword chars
    uint8_t  tk = pgm_read_byte(&COMX_KW_BLOB[wp + len]);
    p = wp + len + 1;                   // advance to next entry now
    if (_s + len - 1 > _sEnd) continue;
    bool ok = true;
    for (uint8_t i = 0; i < len; i++) {
      uint8_t ch = _ram.readByte(_s + i);
      if (ch >= 'a' && ch <= 'z') ch -= 32;
      if (ch != pgm_read_byte(&COMX_KW_BLOB[wp + i])) { ok = false; break; }
    }
    if (!ok) continue;
    // don't match a keyword that is only a prefix of a longer identifier
    if (_s + len <= _sEnd) {
      uint8_t nx = _ram.readByte(_s + len);
      if ((nx>='A'&&nx<='Z')||(nx>='a'&&nx<='z')||(nx>='0'&&nx<='9')) continue;
    }
    _s += len;
    return tk;
  }
  return 0;
}

// ---- tokenise one statement/expression body up to end-of-line --------------
// Reads from the cursor until '\n', '\r', or _sEnd; emits tokens into the image.
void ComxBasic::tokeniseBody() {
  bool prevWasValueOrClose = false;   // (reserved for future numeric-sign logic)
  (void)prevWasValueOrClose;
  while (_s <= _sEnd) {
    uint8_t c = _ram.readByte(_s);
    if (c=='\n' || c=='\r') break;
    if (c==' ' || c=='\t') { _s++; continue; }

    // string literal
    if (c=='"') {
      _s++; emit(TOK_STR_OPEN);
      while (_s <= _sEnd) {
        uint8_t ch=_ram.readByte(_s);
        if (ch=='"' || ch=='\n' || ch=='\r') break;
        emit(ch); _s++;
      }
      if (_s<=_sEnd && _ram.readByte(_s)=='"') _s++;
      emit(TOK_STR_CLOSE);
      continue;
    }

    // two-char comparison operators
    if (_s+1 <= _sEnd) {
      uint8_t d=_ram.readByte(_s+1);
      if (c=='>'&&d=='=') { emit(0xBD); _s+=2; continue; }
      if (c=='<'&&d=='=') { emit(0xBE); _s+=2; continue; }
      if (c=='<'&&d=='>') { emit(0xBF); _s+=2; continue; }
    }

    // number (integer or float)
    if ((c>='0'&&c<='9') || (c=='.' && _s+1<=_sEnd &&
         _ram.readByte(_s+1)>='0' && _ram.readByte(_s+1)<='9')) {
      // scan the numeric literal
      uint32_t ipart=0; bool isFloat=false;
      double dval=0.0; double frac=0.0; double scale=0.1;
      while (_s<=_sEnd) {
        uint8_t ch=_ram.readByte(_s);
        if (ch>='0'&&ch<='9') {
          if (!isFloat) ipart = ipart*10 + (ch-'0');
          else { frac += (ch-'0')*scale; scale/=10.0; }
          _s++;
        } else if (ch=='.' && !isFloat) { isFloat=true; dval=(double)ipart; _s++; }
        else break;
      }
      if (isFloat) { dval += frac; emitFloat(dval); }
      else emitNum(ipart);
      continue;
    }

    // keyword?
    if ((c>='A'&&c<='Z')||(c>='a'&&c<='z')) {
      // REM is special: emit token then copy the REST of the line literally.
      // (matchKeywordTable would also match REM, but we must NOT tokenise the
      // remainder, so handle it explicitly.)
      if (_s+2<=_sEnd) {
        uint8_t a=_ram.readByte(_s), b=_ram.readByte(_s+1), e=_ram.readByte(_s+2);
        uint8_t A=(a>='a'&&a<='z')?a-32:a, B=(b>='a'&&b<='z')?b-32:b, E=(e>='a'&&e<='z')?e-32:e;
        bool remEnd = true;
        if (_s+3<=_sEnd) { uint8_t nx=_ram.readByte(_s+3);
          if ((nx>='A'&&nx<='Z')||(nx>='a'&&nx<='z')||(nx>='0'&&nx<='9')) remEnd=false; }
        if (A=='R'&&B=='E'&&E=='M'&&remEnd) {
          _s+=3; emit(TOK_REM);
          while (_s<=_sEnd) { uint8_t ch=_ram.readByte(_s); if (ch=='\n'||ch=='\r') break; emit(ch); _s++; }
          continue;
        }
      }
      uint8_t tk = matchKeywordTable();
      if (tk) { emit(tk); continue; }
      // otherwise a variable name.  Determine its extent and whether it is a
      // STRING variable (name ends in '$').  Verified against genuine COMX:
      //   numeric var -> 0xD1 + name           (A  -> D1 41)
      //   string  var -> 0xD7 + name WITHOUT $ (A$ -> D7 41)
      // The '$' is implied by the marker and is NOT stored.
      {
        uint16_t vs = _s;                       // start of name
        uint16_t ve = _s;                       // one past end
        bool isStr = false;
        while (ve <= _sEnd) {
          uint8_t ch = _ram.readByte(ve);
          if ((ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z')||(ch>='0'&&ch<='9')) { ve++; }
          else if (ch=='$') { isStr = true; ve++; break; }   // $ ends the name
          else break;
        }
        emit(isStr ? 0xD7 : TOK_VAR);
        uint16_t nameEnd = isStr ? (uint16_t)(ve-1) : ve;    // exclude the $
        for (uint16_t k = vs; k < nameEnd; k++) {
          uint8_t ch = _ram.readByte(k);
          uint8_t up = (ch>='a'&&ch<='z') ? ch-32 : ch;
          emit(up);
        }
        _s = ve;                                // advance past name (and $)
      }
      continue;
    }

    // single-char operator/punctuation
    uint8_t ot = op1(c);
    if (ot) { emit(ot); _s++; continue; }

    // anything else: skip (shouldn't occur in valid source)
    _s++;
  }
}

// ============================================================================
uint16_t ComxBasic::tokeniseInRam(uint16_t srcStart, uint16_t srcEnd, uint16_t dstStart)
{
  _err[0] = 0;
  _d = dstStart;
  for (uint8_t i=0;i<6;i++) emit(HDR_PRE[i]);
  uint16_t endptrPos = _d; emit(0x00); emit(0x00);
  for (uint8_t i=0;i<8;i++) emit(HDR_POST[i]);

  _s = srcStart; _sEnd = srcEnd;

  while (_s <= _sEnd) {
    uint8_t c = _ram.readByte(_s);
    if (c=='\n'||c=='\r'||c==' '||c=='\t') { _s++; continue; }

    // line number
    uint32_t lineno=0; bool gotDigit=false;
    while (_s<=_sEnd) { uint8_t ch=_ram.readByte(_s);
      if (ch>='0'&&ch<='9') { lineno=lineno*10+(ch-'0'); _s++; gotDigit=true; } else break; }
    if (!gotDigit) { fail("no line number"); return 0; }
    if (lineno>65535) { fail("lineno>65535"); return 0; }

    emit((uint8_t)((lineno>>8)&0xFF));
    emit((uint8_t)(lineno&0xFF));
    uint16_t linkPos=_d; emit(0x00);          // link placeholder

    skipSpaces();
    tokeniseBody();                            // <-- validated expression tokenizer
    emit(0x0D);

    // patch link = bytes from link byte through 0D inclusive
    uint16_t recEnd=_d;
    _ram.writeByte(linkPos, (uint8_t)((recEnd - linkPos) & 0xFF));

    while (_s<=_sEnd) { uint8_t ch=_ram.readByte(_s); if (ch=='\n'||ch=='\r') _s++; else break; }
  }

  // end marker + ENDPTR
  uint16_t ffPos=_d; emit(0xFF); emit(0xFF);
  uint16_t endptr=(uint16_t)(ENDPTR_BASE + (ffPos - dstStart) + 1);
  _ram.writeByte(endptrPos,     (uint8_t)( endptr     &0xFF));
  _ram.writeByte(endptrPos+1,   (uint8_t)((endptr>>8) &0xFF));

  // header block-count fields (byte 2 = nBlocks-1, byte 5 = nBlocks-2)
  uint16_t imgLenLocal=(uint16_t)(_d - dstStart);
  uint16_t dataBlocks=(imgLenLocal<=257)?1:(uint16_t)(1+(imgLenLocal-257+255)/256);
  uint16_t nBlocks=dataBlocks+1;
  _ram.writeByte(dstStart+2,(uint8_t)(nBlocks-1));
  _ram.writeByte(dstStart+5,(uint8_t)(nBlocks-2));

  return (uint16_t)(_d - dstStart);
}

// ---- kept for compatibility (unused by the new path) -----------------------
bool ComxBasic::matchKeyword(const char* kw, uint8_t len) {
  if (_s+len-1 > _sEnd) return false;
  for (uint8_t i=0;i<len;i++){ uint8_t ch=_ram.readByte(_s+i); if(ch>='a'&&ch<='z')ch-=32; if(ch!=(uint8_t)kw[i])return false; }
  _s+=len; return true;
}
bool ComxBasic::readUint(uint32_t& out) {
  out=0; bool got=false;
  while(_s<=_sEnd){ uint8_t ch=_ram.readByte(_s); if(ch>='0'&&ch<='9'){out=out*10+(ch-'0');_s++;got=true;} else break; }
  return got;
}
