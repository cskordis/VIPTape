/*
Main Code by Josh Bensadon, with the help of some Libraries. :)
The regular Adafruit "TouchScreen.h" library only works on AVRs
Different mcufriend shields have Touchscreen on different pins and rotation.
Run the TouchScreen_Calibr_native sketch for calibration of your shield and substitute values in SystemConfig.h
Added Cassette protocol for VIP, ELF II and HEC/ETI660

User interface by Costas Skordis July 2025

All files can be found at https://github.com/cskordis/VIPTape.git
 

Version 0.5 - Refactored for new user interface and made code more modularized
Version 1.0 - Release new user interface with bug fixes to UI screen
Version 2.0 - Add logic to cater for KCS300, KCS1200, ELF II, HEC/ETI-660 and VIP cassette protocols
			      - Modularized functions
            - 0 = big endian (MSB-first), 1 = little endian (LSB-first)
            - Polarity, 0 = Low to High (Rising), 1 = High to Low ()
            - Refactored more to improve functionality and expandability. CassetteProtocols hold the definition of the cassette interfaces
            - Decoding and Encoding are done in seperate modules.
            - Removal of unused variables and arrays.
            - must be used on VIPTAPE PCB version 2 and above that uses D18 for the input pin with updated LM358 op amp / comparator circuit
            - save last mode type to SD to set up the modetype on reboot
Version 3.0 - Add logic to cater for ORAO cassette protocols            
Version 3.0a- Add logic if Yes button is depressed at boot up will toggle the SERIALDEBUG flag
Version 4.0 - Add COMX 35 protocol
Version 4.0a- Add logic to sort Direcories and Files alphabetically
*/
#include <Adafruit_GFX.h>
#include <TouchScreen.h>
#include <SD.h>
#include <SPI.h>
#include <stdint.h>
#include "SplashImage.h"
#include "SystemConfig.h"
#include "Utility.h"
#include "RamExternal.h"
#include "FileLoader.h"
#include "Display.h"
#include "CassetteParams.h"
#include "CassetteProtocols.h"
#include "CassetteDecoder.h"
#include "CassetteEncoder.h"
#include "ComxBasic.h"
#include "OraoReceive.h"

uint8_t currentProtocol = DEFAULT_MODE;
uint8_t lastProtocol = DEFAULT_MODE;
CassetteEncoder cassetteEncoder(tapeOut);
CassetteDecoder cassetteDecoder(tapeIn, &cassetteProtocols[currentProtocol]);

unsigned long highStartUs = 0;
bool lastLevel = LOW;
uint32_t lastByteTime = 0;

/* Initialize TouchScreen */
TouchScreen ts = TouchScreen(XP, YP, XM, YM, 300);

// Button objects
Adafruit_GFX_Button up_btn, down_btn, next_btn, prev_btn, yes_btn, no_btn, play_btn, rec_btn;

// Setup external ram
RamExternal ram(ramCS, ramMOSI, ramMISO, ramCLK);
uint32_t ramAddr = 0;

FileLoader loader(ram);

/* File system variables */
File root;
File myFile;

// Global variables for touch coordinates
String currentFile = "";
String currentName = "";
String currentPath = "/";
int fileCount = 0;
int currentIndex = 0;
int displayStart = 0;
int actionFlag = 0;          // Flag to drive current Record or Play logic. 0 - Record or 1 - Play or 2 - Yes/No
String fileList[MAX_ARRAY];  // Array to store file/directory names
char fileName[16];

/*File and SRAM attributes*/
uint16_t startAddr = 0;
uint16_t endAddr = 0;
String fileExt = "";
unsigned long fileSize = 0;

// Runtime debug flag.  Backs the SERIALDEBUG name used everywhere via the
// extern declaration in SystemConfig.h.  Starts at SERIALDEBUG_BOOT_DEFAULT
// and is set to 1 in setup() if BUTTON_YES is held during boot, so a
// debug session can be toggled on without reflashing.
//   0 - disabled, 1 - enabled, 2 - verbose
uint8_t SERIALDEBUG = SERIALDEBUG_BOOT_DEFAULT;

long pages = 0;  // Number of 255 byte pages

/* Screen saver variables*/
unsigned long lastActivityTime = 0;  // Timestamp of the last user activity
bool screensaverActive = false;      // Flag to indicate screensaver state
int hangTime = 0;                    // default hangtime for displays

// Keyboard layout (simplified: A-Z, 0-9, _, ., *)
const char keys[7][6] = {
  { 'A', 'B', 'C', 'D', 'E', 'F' },
  { 'G', 'H', 'I', 'J', 'K', 'L' },
  { 'M', 'N', 'O', 'P', 'Q', 'R' },
  { 'S', 'T', 'U', 'V', 'W', 'X' },
  { 'Y', 'Z', '0', '1', '2', '3' },
  { '4', '5', '6', '7', '8', '9' },
  { '_', '.', ' ', '@', ' ', '*' }
};

int keyboardEntry = 0;
// saveFilename storage
char saveFilename[FILENAME_SIZE] = "";  // Max characters + null terminator
int saveFilenameLength = 0;

/* Buttons */
String pressed;
int touched;
// Structure to hold button state for debouncing
struct ButtonState {
  int currentState;                // Current state of the button
  int lastState;                   // Previous state of the button
  unsigned long lastDebounceTime;  // Last time the button was toggled
};

ButtonState buttonStates[BUTTONS];                                           // Array to store state for each button
const unsigned long debounceDelay = 50;                                      // Debounce time in milliseconds
const int buttonPins[] = { BUTTON_UP, BUTTON_DOWN, BUTTON_YES, BUTTON_NO };  // Array of button pins
const int numButtons = BUTTONS;                                              // Number of buttons

int selectedItem = 0;  // Currently selected item index
int currentPage = 0;   // Current page number
unsigned long lastDebounceTime = 0;

// Define touch areas (for 240x320 portrait orientation)
int numAreas;

struct ButtonCoords {
  uint16_t xMin, xMax, yMin, yMax;
  const char *name;
};

const uint8_t numValidButtons[NUM_SCREENS] = { 6, 6, 2 };

ButtonCoords screenButtons[NUM_SCREENS][NUM_BUTTONS] = {
  {
    { 0, 40, 0, 40, "Up" },
    { 45, 195, 0, 40, "Type" },
    { 200, 240, 0, 40, "Down" },
    { 0, 40, 270, 310, "Prev" },
    { 200, 240, 270, 310, "Next" },
    { 100, 140, 270, 310, "Record" },
  },
  {
    { 0, 40, 0, 40, "Up" },
    { 45, 195, 0, 40, "Type" },
    { 200, 240, 0, 40, "Down" },
    { 0, 40, 270, 310, "Prev" },
    { 200, 240, 270, 310, "Next" },
    { 100, 140, 270, 310, "Play" },
  },
  {
    { 0, 40, 270, 310, "Yes" },
    { 200, 240, 270, 310, "No" },
  },
};


bool getLastMode() {
  lastProtocol = DEFAULT_MODE; // default / safe value

  File f = SD.open("_VIP.CFG", FILE_READ);
  if (!f) return false;

  f.seek(0);

  if (!f.available()) {   // empty file
    f.close();
    return false;
  }

  long v = f.parseInt();  // parse as long to avoid uint8 wrap issues
  f.close();

  if (SERIALDEBUG) {
    Serial.print(F("Read protocol "));
    Serial.println(v);
  }

  if (v >= 0 && v < cassetteProtocolCount) {
    currentProtocol = (uint8_t)v;
    lastProtocol    = (uint8_t)v;
    return true;
  }

  // invalid number in file
  return false;
}

bool saveLastMode() {
  if ((int)lastProtocol == (int)currentProtocol) {return true;}
  SD.remove("_VIP.CFG");
  File f = SD.open("_VIP.CFG", FILE_WRITE);
  if (!f) {
    if (SERIALDEBUG) Serial.println(F("Open failed"));
    return false;
  }

  f.seek(0);
  f.println((int)currentProtocol); 
  f.close();

  if (SERIALDEBUG) {
     Serial.println();
     Serial.println(F("Protocol saved "));
     Serial.println((int)currentProtocol);
     }
  return true;
}

// ------------------------------------------------------------------
// PROTOCOL SELECTION
// ------------------------------------------------------------------

void nextProtocol() {
  currentProtocol++;
  if (currentProtocol >= cassetteProtocolCount)
    currentProtocol = 0;

  applyProtocol();
}

void prevProtocol() {
  if (currentProtocol == 0)
    currentProtocol = cassetteProtocolCount - 1;
  else
    currentProtocol--;

  applyProtocol();
}

void applyProtocol() {
  const CassetteParams *p = &cassetteProtocols[currentProtocol];
  cassetteDecoder.setParams(p);
  cassetteEncoder.setParams(p);
  cassetteDecoder.reset();
}

bool eraseRam(uint32_t sizeBytes) {
  const uint32_t step = sizeBytes / 10;  // 10% progress
  uint32_t nextMark = step;
  uint8_t pct = 0;

  if (SERIALDEBUG) {
    Serial.println(F("Erasing AND TESTING external ram with 0xFF"));
    Serial.println(F("Press 'NO' button to abort"));
  }
  tft.setTextColor(YELLOW, BACKGROUND);
  tft.setCursor(0, tft.height() - 120);
  tft.println("Clearing RAM");
  tft.setCursor(tft.width() - 20, tft.height() - 120);
  tft.print("%");
  for (uint32_t addr = 0; addr < sizeBytes; addr++) {
    ram.writeByte((uint16_t)addr, 0x00);
    uint8_t v = ram.readByte((uint16_t)addr);
    if (v != 0x00) {
      if (SERIALDEBUG) {
        Serial.print(F("SRAM ERROR at 0x"));
        Serial.print(addr, HEX);
        Serial.print(F(" read "));
        Serial.println(v, HEX);
      }
      char addrStr[5];
      sprintf(addrStr, "%04X", addr);
      tft.setCursor(tft.width(), tft.height() - 100);
      tft.setTextColor(BLACK, RED);
      tft.print(String("Error at ") + addrStr);
      tft.setTextColor(FOREGROUND, BACKGROUND);
      delay(1000);
      return false;
    }
    if (digitalRead(BUTTON_NO) == LOW) {
      if (SERIALDEBUG) { Serial.println(F("SRAM erase/test CANCELED")); }
      centerText(tft, "Cancelled", tft.height() - 100, 0, RED, BLACK, 2);
      delay(1000);
      return false;
    }
    if (addr >= nextMark && pct < 100) {
      pct += 10;
      nextMark += step;
      if (SERIALDEBUG) {
        Serial.print(F("Clearing RAM "));
        Serial.print(pct);
        Serial.println(F("%"));
      }
      tft.setCursor(tft.width() - 55, tft.height() - 120);
      tft.print(pct);
      delay(5);
    }
  }
  if (SERIALDEBUG) { Serial.println(F("SRAM erase + test PASSED (100%)")); }
  tft.setCursor(tft.width() - 30, tft.height() - 120);
  tft.setTextColor(WHITE, GREEN);
  tft.print("OK");
  return true;
}

void setup() {

  // Boot-time debug override: if BUTTON_YES is held during reset/power-on,
  // force SERIALDEBUG = true regardless of SERIALDEBUG_BOOT_DEFAULT.  This is
  // the very first thing setup() does so we can decide whether to bring up
  // Serial below.  pinMode + a brief settle delay are enough; INPUT_PULLUP
  // gives HIGH when idle, LOW when the button is grounded.
  pinMode(BUTTON_YES, INPUT_PULLUP);
  delay(20);                                   // let the internal pull-up settle
  if (digitalRead(BUTTON_YES) == LOW) {
    if (SERIALDEBUG > 0) {SERIALDEBUG=0;}
    else {SERIALDEBUG=1;}
  }
  /*Initialize Serrial if flagged to start*/
  if (SERIALDEBUG) {
    Serial.begin(SERIAL_BAUD);
    delay(1000);
    Serial.println(F(""));
    Serial.println(F("Starting....."));
  }

  /* Initialize TFT */
  tft.reset();
  tft.begin(tft.readID());
  tft.setRotation(0);  // Portrait orientation
  tft.fillScreen(BLACK);
  tft.setTextColor(WHITE);
  tft.setTextSize(TEXTSIZE);

   // Start decoder
  cassetteDecoder.begin(Serial);

  /* Initialize external ram */
  ram.begin();
  ramAddr = 0;
  /* Initialize SD card */
  if (!SD.begin(SD_CS)) {
    tft.setTextColor(RED);
    tft.setCursor(10, 10);
    tft.println("SD Card Init Failed");
    while (1);
  }
  /* get last saved protocol*/
  getLastMode();
  applyProtocol();

  // Initialize SPI
  SPI.begin();
  delay(500);
  pinMode(SS, OUTPUT);

  // Initialize external 23LC512 SRAM (used by the "decode to SRAM" path)
  /*Set up modes*/

  pinMode(BUTTON_YES, INPUT_PULLUP);
  pinMode(BUTTON_NO, INPUT_PULLUP);
  pinMode(BUTTON_UP, INPUT_PULLUP);
  pinMode(BUTTON_DOWN, INPUT_PULLUP);

  pinMode(tapeOut, OUTPUT);
  cassetteEncoder.pulseBit(0);

  // --- COMX timing self-check -------------------------------------------
  // The COMX needs bit-0 ~500us and bit-1 ~1220us full-cycle on the WIRE.
  // delayMicroseconds() + loop overhead vary per board, so here we MEASURE
  // what VIPTAPE actually emits for the COMX protocol and print it, so the
  // ENC_CAL_* constants in CassetteEncoder.h can be trimmed to hit target.
  // Runs only with SERIALDEBUG on; emits a brief burst on tapeOut.
  if (SERIALDEBUG && currentProtocol==7) {
    int comxIdx = -1;
    for (uint8_t i = 0; i < cassetteProtocolCount; i++) {
      if (cassetteProtocols[i].framing == FRAMING_SYNC_COMX) { comxIdx = i; break; }
    }
    if (comxIdx >= 0) {
      cassetteEncoder.configure(&cassetteProtocols[comxIdx]);
      const uint16_t N = 200;
      // Measure with interrupts ENABLED (micros() needs Timer0; it freezes
      // under noInterrupts()).  delayMicroseconds() is a busy-wait so timing
      // stays accurate either way; we're only timing the loop, not driving
      // the COMX.
      unsigned long t0 = micros();
      for (uint16_t i = 0; i < N; i++) cassetteEncoder.pulseBit(0);
      unsigned long t1 = micros();
      for (uint16_t i = 0; i < N; i++) cassetteEncoder.pulseBit(1);
      unsigned long t2 = micros();
      float c0 = (float)(t1 - t0) / N;
      float c1 = (float)(t2 - t1) / N;
      Serial.println(F("--- COMX timing self-check ---"));
      Serial.print(F("bit0 cell measured: ")); Serial.print(c0,1);
      Serial.println(F(" us  (target 408)"));
      Serial.print(F("bit1 cell measured: ")); Serial.print(c1,1);
      Serial.println(F(" us  (target 1043)"));
      Serial.print(F("cal overhead=")); Serial.print(ENC_CAL_OVERHEAD_US);
      Serial.println(F("us/half"));

      // Validity gate: only act on a sane reading (bit1 must be the longer
      // tone; both in plausible range).  Prevents a glitched measurement from
      // emitting a bogus correction.
      bool sane = (c0 > 50.0f && c0 < 5000.0f &&
                   c1 > 50.0f && c1 < 8000.0f &&
                   c1 > c0 * 1.5f);
      if (!sane) {
        Serial.println(F("MEASUREMENT INVALID - ignoring."));
      } else if (c0 < 395.0f || c0 > 425.0f) {
        // Each 1us of ENC_CAL_OVERHEAD_US changes the bit0 CELL by ~2us/half.
        // To move c0 toward the ~455us target:
        long suggest = (long)ENC_CAL_OVERHEAD_US + (long)((c0 - 408.0f) / 2.0f + 0.5f);
        if (suggest < 0)  suggest = 0;
        if (suggest > 120) suggest = 120;
        Serial.print(F("suggest ENC_CAL_OVERHEAD_US=")); Serial.println(suggest);
      } else {
        Serial.println(F("bit0 within target window - timing looks good."));
      }
      Serial.println(F("------------------------------"));
      digitalWrite(tapeOut, LOW);
    }
  }

  pinMode(tapeIn, INPUT);
  digitalWrite(tapeIn, HIGH);

  for (int i = 0; i < numButtons; i++) {
    pinMode(buttonPins[i], INPUT_PULLUP);  // Button pins with internal pull-up
    // Initialize button states
    buttonStates[i].currentState = HIGH;
    buttonStates[i].lastState = HIGH;
    buttonStates[i].lastDebounceTime = 0;
  }
  

  /* Navigation buttons*/
  up_btn.initButton(&tft, tft.width() - 218, tft.height() - 300, 40, 40, WHITE, CYAN, BLACK, "Up", 2);
  down_btn.initButton(&tft, tft.width() - 28, tft.height() - 300, 50, 40, WHITE, CYAN, BLACK, "Down", 2);

  next_btn.initButton(&tft, tft.width() - 28, tft.height() - 22, 50, 40, WHITE, YELLOW, BLACK, "Next", 2);
  prev_btn.initButton(&tft, tft.width() - 212, tft.height() - 22, 50, 40, WHITE, YELLOW, BLACK, "Prev", 2);

  play_btn.initButton(&tft, tft.width() - 115, tft.height() - 22, 60, 40, WHITE, CYAN, BLACK, "Play", 2);
  rec_btn.initButton(&tft, tft.width() - 120, tft.height() - 22, 90, 40, WHITE, RED, BLACK, "Record", 2);

  yes_btn.initButton(&tft, tft.width() - 212, tft.height() - 22, 50, 40, WHITE, CYAN, BLACK, "Yes", 2);
  no_btn.initButton(&tft, tft.width() - 28, tft.height() - 22, 50, 40, WHITE, RED, BLACK, "No", 2);
  
  tft.fillScreen(BACKGROUND);
  if (DISPLAY_TITLE) { displayTitle(1000); }
  if (RAMTEST) {
    eraseRam(RAMSIZE);
    delay(1000);
  }
  if (DISPLAY_SPLASH) { showScreenSaver(1000); }
  ResetMode(1);
  loadDirectory(currentPath);
  displayFiles(1);
  lastActivityTime = millis();  // Initialize activity time
}

/* Button debounce method to return button pressed*/
bool debounceButton(int index) {
  bool buttonPressed = false;
  int reading = digitalRead(buttonPins[index]);

  // Check if the button state has changed
  if (reading != buttonStates[index].lastState) {
    buttonStates[index].lastDebounceTime = millis();  // Reset debounce timer
  }

  // Check if the button state has been stable for the debounce delay
  if ((millis() - buttonStates[index].lastDebounceTime) > debounceDelay) {
    if (reading != buttonStates[index].currentState) {
      buttonStates[index].currentState = reading;
      // Detect button press (LOW due to INPUT_PULLUP)
      if (buttonStates[index].currentState == LOW) {
        buttonPressed = true;
        lastActivityTime = millis();  // Reset activity timer
      }
    }
  }

  buttonStates[index].lastState = reading;
  return buttonPressed;
}

/* Display file attributes */
void displayInfo(uint16_t startAddr, uint16_t endAddr, uint32_t fileSize, String fileExt) {
  int dotIndex = currentName.lastIndexOf('.');
  String fname;

  if (dotIndex != -1) {
    fname = currentName.substring(0, dotIndex);
  } else {
    fname = currentName;
  }

  tft.fillScreen(BACKGROUND);
  centerText(tft, "File To Be Loaded", 10, 0, BLUE, CYAN, 2);
  centerText(tft, fname.c_str(), 40, 0, WHITE, BACKGROUND, 2);
  tft.setCursor(228, 40);
  tft.print(fileExt);
  if (fileExt == 'H') {
    centerText(tft, "Hex Mode", 55, 0, BLUE, GREEN, 2);
    tft.setTextColor(YELLOW, BLUE);
    if (SERIALDEBUG) { Serial.println(F("Hex Mode")); }
  }
  tft.setCursor(0, 80);
  tft.print("Bytes: ");
  tft.print(fileSize);
  tft.setCursor(0, 100);
  if (currentProtocol == 5 || currentProtocol == 6) {tft.print("Blocks: ");}
  else {tft.print("Pages: ");}
  tft.print((fileSize + 255) / 256);
  if (fileExt != "H") {
    if (currentProtocol == 0 || currentProtocol == 1) {
      startAddr = 0;
      endAddr = fileSize - 1;
    } else if (currentProtocol == 2) {
      startAddr = 1536;
      endAddr = startAddr + endAddr;
    } else if (currentProtocol == 3) {
      startAddr = 512;
      endAddr = startAddr + endAddr;
    } else if (currentProtocol == 5 || currentProtocol == 6) {
      startAddr = 1024;
      endAddr = startAddr + endAddr;
    }
  }
  char hexStart[5];
  char hexEnd[5];
  sprintf(hexStart, "%04X", startAddr);
  sprintf(hexEnd, "%04X", endAddr);
  tft.setCursor(0, 120);
  tft.print("Start Address : " + String(hexStart));
  tft.setCursor(0, 140);
  tft.print("End Address   : " + String(hexEnd));
  centerText(tft, "Proceed?", 160, 0, BLUE, YELLOW, 2);
}


/* Display files and directories of the current page */
void displayFiles(int erase) {
  if (erase == 1) { tft.fillScreen(BACKGROUND); }
  const CassetteParams *p = cassetteDecoder.getParams();
  if (p) {
    centerText(tft, p->name, 10, 0, WHITE, BLUE, TEXTSIZE);
    if (SERIALDEBUG) { Serial.println(p->name); }
  }
  drawButtons(); /*Draw navigation buttons*/

  String dirName = currentPath;
  if (dirName == "/") { dirName = "Root"; }
  tft.setTextColor(WHITE);
  root.rewindDirectory();
  centerText(tft, dirName.c_str(), FILE_DISP, 0, WHITE, BLUE, TEXTSIZE);

  tft.setTextSize(TEXTSIZE);
  if (SERIALDEBUG) {
    Serial.print(F("Directory : ")); Serial.println(dirName);
    Serial.println(F("File List"));
  }

  // Display files
  for (int i = 0; i < ITEMS_PER_PAGE; i++) {
    int fileIndex = displayStart + i;
    if (fileIndex >= fileCount) break;

    // Highlight current selection
    if (fileIndex == currentIndex) {
      tft.fillRect(0, ((i + 1) * CHAR_HEIGHT) + TOP_DISP, tft.width(), CHAR_HEIGHT, YELLOW);
      tft.setTextColor(BLACK);
    } else {
      tft.setTextColor(WHITE);
    }
    tft.setCursor(0, ((i + 1) * CHAR_HEIGHT) + TOP_DISP);
    tft.println(fileList[fileIndex]);
    if (SERIALDEBUG) { Serial.println(fileList[fileIndex]); }
  }
}

/* Display file attributes */
void displayFileToSaveInfo() {
  tft.fillScreen(BACKGROUND);
  centerText(tft, "File To Save", 10, 0, BLUE, CYAN, 2);
  tft.setCursor(0, 30);
  tft.setTextColor(YELLOW, BLUE);
  tft.println(currentFile);
  tft.setCursor(228, 30);
  centerText(tft, "Proceed To Save", 120, 0, BLUE, YELLOW, 2);
}

void displayTitle(int hangTime) {
  tft.fillScreen(BACKGROUND);
  centerText(tft, TITLE, 5, 0, YELLOW, BACKGROUND, 3);
  centerText(tft, VERSION, 40, 0, FOREGROUND, BACKGROUND, 2);
  /*Special messaging*/
  centerText(tft, MESSAGE1, 70, 0, FOREGROUND, BACKGROUND, 2);
  centerText(tft, MESSAGE2, 90, 0, FOREGROUND, BACKGROUND, 2);

  centerText(tft, MESSAGE3, 120, 0, FOREGROUND, BACKGROUND, 2);
  centerText(tft, MESSAGE4, 140, 0, FOREGROUND, BACKGROUND, 2);
  tft.setTextSize(2);

  if (SERIALDEBUG) { Serial.println(VERSION); }
  if (hangTime > 0) { delay(hangTime); }
}

/* Directory methods */
bool fileEntryGreater(const String &a, const String &b);   // forward declaration
void loadDirectory(String path) {
  // Clear previous list
  fileCount = 0;
  for (int i = 0; i < MAX_FILECOUNT; i++) {
    fileList[i] = "";
  }
  // Open directory
  root = SD.open(path);
  if (!root) {
    tft.fillScreen(BACKGROUND);
    tft.setCursor(0, 0);
    tft.println("Failed to open directory!");
    return;
  }
  // If not root, add parent directory option
  if (path != "/") {
    fileList[fileCount] = "..";
    fileCount++;
  }
  // Read directory contents
  while (true) {
    File entry = root.openNextFile();
    if (!entry) break;
    String name = String(entry.name());
    if (name.equalsIgnoreCase("System Volume Information") || name.equalsIgnoreCase("SYSTEM~1")) {
      continue;
    } else if (name.equalsIgnoreCase(".Trashes") || name.equalsIgnoreCase("$RECYCLE.BIN")) {
      continue;
     } else if (name.equalsIgnoreCase("_VIP.CFG")) {
      continue;  
    } else if (name.charAt(0) == '.')  {
      continue;
    }
    if (fileCount < MAX_FILECOUNT) {
      fileList[fileCount] = String(entry.name());
      if (entry.isDirectory()) {
        fileList[fileCount] += "/";
      }
      fileCount++;
    }
    entry.close();
  }
  root.close();

  /* Sort the list alphabetically (case-insensitive), keeping ".." pinned at the
     top and grouping directories (names ending in '/') before files.  Insertion
     sort -- fileCount is small (<= MAX_FILECOUNT) so this is fast and needs no
     extra memory. */
  {
    // The ".." entry, if present, is always at index 0; leave it there.
    int firstSortable = (fileCount > 0 && fileList[0] == "..") ? 1 : 0;
    for (int i = firstSortable + 1; i < fileCount; i++) {
      String key = fileList[i];
      int j = i - 1;
      while (j >= firstSortable && fileEntryGreater(fileList[j], key)) {
        fileList[j + 1] = fileList[j];
        j--;
      }
      fileList[j + 1] = key;
    }
  }

  /* Reset selection */
  currentIndex = 0;
  displayStart = 0;
}

/* Order comparison for the file browser: directories (trailing '/') come before
   files; within each group, compare names case-insensitively.  Returns true if
   entry 'a' should sort AFTER entry 'b'. */
bool fileEntryGreater(const String &a, const String &b) {
  bool aDir = a.endsWith("/");
  bool bDir = b.endsWith("/");
  if (aDir != bDir) return !aDir;          // a is a file, b a dir -> a is greater
  // Same group: case-insensitive lexical compare.
  int la = a.length(), lb = b.length();
  int n = (la < lb) ? la : lb;
  for (int k = 0; k < n; k++) {
    char ca = a[k], cb = b[k];
    if (ca >= 'a' && ca <= 'z') ca -= 32;
    if (cb >= 'a' && cb <= 'z') cb -= 32;
    if (ca != cb) return ca > cb;
  }
  return la > lb;                           // prefix ties: longer name sorts later
}

void navigateToSelection(int display) {
  // Handle directory navigation
  if (fileList[currentIndex] == "..") {
    // Go up one directory
    int lastSlash = currentPath.lastIndexOf('/', currentPath.length() - 2);
    if (lastSlash >= 0) {
      currentPath = currentPath.substring(0, lastSlash + 1);
      loadDirectory(currentPath);
    }
  } else if (fileList[currentIndex].endsWith("/")) {
    // Enter directory
    currentPath += fileList[currentIndex];
    loadDirectory(currentPath);
  }
  if (display) { displayFiles(1); }
}

void moveSelection(int delta) {
  int newIndex = currentIndex + delta;

  // Constrain index
  if (newIndex < 0) newIndex = 0;
  if (newIndex >= fileCount) newIndex = fileCount - 1;

  // Update display start if needed
  if (newIndex < displayStart) {
    displayStart = newIndex - (newIndex % ITEMS_PER_PAGE);
  }
  if (newIndex >= displayStart + ITEMS_PER_PAGE) {
    displayStart = newIndex - (ITEMS_PER_PAGE - 1);
  }

  // Update selection
  currentIndex = newIndex;
  displayFiles(1);
}

void drawButtons() {
  if (SERIALDEBUG) { Serial.print(F("Action Flag: ")); Serial.println(actionFlag); }
  if (actionFlag == 0) {
    down_btn.drawButton(false);
    next_btn.drawButton(false);
    prev_btn.drawButton(false);
    up_btn.drawButton(false);
    rec_btn.drawButton(false);

  } else if (actionFlag == 1) {
    down_btn.drawButton(false);
    next_btn.drawButton(false);
    prev_btn.drawButton(false);
    up_btn.drawButton(false);
    play_btn.drawButton(false);

  } else if (actionFlag == 2) {
    yes_btn.drawButton(false);
    no_btn.drawButton(false);
  }
}
void drawKeyboard() {
  tft.fillRect(10, 10, tft.width() - 20, 40, GRAY);
  tft.setCursor(15, 25);
  tft.setTextColor(BLACK);
  tft.setTextSize(2);
  tft.print(saveFilename);

  for (int row = 0; row < 7; row++) {
    for (int col = 0; col < 6; col++) {
      int x = BUTTON_START_X + col * (BUTTON_WIDTH + BUTTON_SPACING);
      int y = BUTTON_START_Y + row * (BUTTON_HEIGHT + BUTTON_SPACING);
      tft.fillRect(x, y, BUTTON_WIDTH, BUTTON_HEIGHT, BLUE);
      tft.setCursor(x + 12, y + 10);
      tft.setTextColor(WHITE);
      tft.setTextSize(2);
      if (keys[row][col] == '*') {
        tft.print("OK");
      } else if (keys[row][col] == '@') {
        tft.print("<<");
      } else {
        tft.print(keys[row][col]);
      }
    }
  }
}

void updatesaveFilenameDisplay() {
  // Clear saveFilename area
  tft.fillRect(10, 10, tft.width() - 20, 40, GRAY);
  // Display updated saveFilename
  tft.setCursor(15, 25);
  tft.setTextColor(BLACK);
  tft.setTextSize(2);
  tft.print(saveFilename);
}

String buildBaseName(const String &baseFile, uint32_t number, int totalLen) {
  String result = baseFile;
  if (result.length() > totalLen)
    result = result.substring(0, totalLen);
  int missing = totalLen - result.length();
  if (missing > 0) {
    // Make a padded number wide enough
    char buf[16];
    snprintf(buf, sizeof(buf), "%015lu", (unsigned long)number);
    int bufLen = strlen(buf);
    const char *tail = buf + (bufLen - missing);
    result += tail;  // append just enough digits to reach totalLen
  }
  return result;
}

// Convert a raw 10-byte, space-padded tape-header filename into a safe SD
// filename.  Trailing pad spaces are trimmed, letters are upper-cased, anything
// that isn't A-Z/0-9/_/- becomes '_', and the result is capped at 8 chars so it
// stays friendly to the SD library's 8.3 naming.  Returns "" when the header
// carried no name (all spaces / empty) -- the caller then keeps VIPTAPE's own
// filename, so a nameless SAVE is unaffected.
String sanitizeTapeName(const char* raw) {
  if (raw == nullptr) return String("");
  char buf[11];
  uint8_t n = 0;
  for (uint8_t i = 0; i < 10 && raw[i] != '\0'; i++) buf[n++] = raw[i];
  buf[n] = '\0';
  while (n > 0 && buf[n - 1] == ' ') buf[--n] = '\0';   // trim pad spaces
  String out;
  for (uint8_t i = 0; i < n; i++) {
    char c = buf[i];
    if (c == ' ') continue;                 // drop spaces (Char 4096 -> CHAR4096)
    if (c >= 'a' && c <= 'z') c -= 32;
    bool ok = (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
              c == '_' || c == '-';
    out += ok ? c : '_';
    if (out.length() >= 8) break;
  }
  return out;
}

String getUniqueFileName() {
  uint32_t fileNumber = 0;
  const int TOTAL_LEN = FILENAME_SIZE - 1;
  String fileName;

  while (fileNumber < 100000000UL) {
    String baseName = buildBaseName(BASEFILE, fileNumber, TOTAL_LEN);
    fileName = String(currentPath) + baseName + ".BIN";

    if (!SD.exists(fileName.c_str())) {
      return fileName;
    }
    if (SERIALDEBUG) { Serial.println(fileName); }
    fileNumber++;
  }
  if (SERIALDEBUG) { Serial.println(F("Error: no unique filename available.")); }
  return "";
}

void drawFileSaved() {
  tft.fillScreen(BACKGROUND);
  tft.setCursor(0, 80);
  tft.print("Bytes: ");
  tft.print(ramAddr);
  tft.setCursor(0, 100);
  if (currentProtocol == 5 || currentProtocol == 6) {tft.print("Blocks: ");}
  else {tft.print("Pages: ");}
  tft.print((ramAddr + 255) / 256);
}

/* Get file information*/
void getFile(uint16_t &startAddr, uint16_t &endAddr, unsigned long &fileSize, String &fileExt) {

  if (SERIALDEBUG) { Serial.print(F("Opening file: ")); Serial.println(currentFile); }

  File f = SD.open(currentFile);
  if (!f) {
    centerText(tft, "ERROR Opening File", 200, 0, BLACK, RED, 2);
    if (SERIALDEBUG) { Serial.println(F("ERROR Opening File")); }
    return;
  }
  FileLoader loader(ram);
  loader.loadFile(f, startAddr, endAddr, fileSize, fileExt);
  f.close();
  if (SERIALDEBUG) {
    Serial.println(F("Load complete."));
    Serial.print(F("File type : ")); Serial.println(fileExt);
    Serial.print(F("File size : ")); Serial.println(fileSize);
    Serial.print(F("Start     : 0x"));
    Serial.println(startAddr, HEX);
    Serial.print(F("End       : 0x"));
    Serial.println(endAddr, HEX);
  }
}
/*
========================================================================================================================================
Tape Methods
========================================================================================================================================
*/
// ----------------------------------------------------------------------------
// Helper: write an ORAO 'O' (object) file to SD as Intel HEX so the load
// address is preserved and the existing FileLoader can re-read it.
// 'B' (BASIC) files use the existing writeFile() path -- they're plain text.
// ----------------------------------------------------------------------------
static void writeOraoIntelHex(uint16_t loadAddr, uint32_t size) {
  // Open with the current filename (the user has already chosen the SD path)
  myFile = SD.open(currentFile, FILE_WRITE);
  if (!myFile) {
    if (SERIALDEBUG) Serial.println(F("Error opening file"));
    centerText(tft, "ERROR", 10, 0, WHITE, RED, 2);
    delay(1000);
    return;
  }
  centerText(tft, "Writing HEX", 10, 0, BLUE, CYAN, 2);
  delay(500);

  static const char hexChars[] = "0123456789ABCDEF";
  uint32_t off = 0;
  while (off < size) {
    uint8_t recLen = (size - off > 16) ? 16 : (uint8_t)(size - off);
    uint16_t addr  = (uint16_t)(loadAddr + off);
    uint8_t  sum   = recLen + (uint8_t)(addr >> 8) + (uint8_t)(addr & 0xFF) + 0x00;

    myFile.write(':');
    myFile.write(hexChars[recLen >> 4]);            myFile.write(hexChars[recLen & 0x0F]);
    myFile.write(hexChars[(addr >> 12) & 0x0F]);    myFile.write(hexChars[(addr >> 8) & 0x0F]);
    myFile.write(hexChars[(addr >> 4)  & 0x0F]);    myFile.write(hexChars[ addr       & 0x0F]);
    myFile.write('0');                              myFile.write('0');   // record type 00 = data

    for (uint8_t i = 0; i < recLen; i++) {
      uint8_t v = ram.readByte((uint16_t)(loadAddr + off + i));
      sum += v;
      myFile.write(hexChars[v >> 4]);  myFile.write(hexChars[v & 0x0F]);
    }
    uint8_t cs = (uint8_t)(-(int8_t)sum);
    myFile.write(hexChars[cs >> 4]);   myFile.write(hexChars[cs & 0x0F]);
    myFile.write('\r');                myFile.write('\n');
    off += recLen;
    lastActivityTime = millis();
  }
  // EOF record
  myFile.print(F(":00000001FF\r\n"));
  myFile.close();

  tft.fillScreen(BLACK);
  centerText(tft, "Writing completed", 10, 0, BLUE, YELLOW, 2);
  delay(1000);
}

void ReadData() {
  ramAddr = 0;
  bool okToFile = false;
  const char *errMsg = "";

  // Re-arm the decoder for the protocol we're about to decode.  setParams()
  // does reset() AND re-applies the correct interrupt edge mode (ORAO=RISING,
  // async=CHANGE).  This guarantees a decode can never run with a stale edge
  // mode left over from a previous operation -- a stale RISING mode on an async
  // protocol doubles every measured period out of its accept window, so the
  // leader never locks and only a single stray byte is ever captured.  That is
  // exactly the "async saves only 1 byte" failure; this line prevents it.
  const CassetteParams *p = cassetteDecoder.getParams();
  cassetteDecoder.setParams(p);

  bool oraoMode = (p->framing == FRAMING_BLOCK_ORAO);

  if (oraoMode) {
    // -------------------- ORAO 'B' / 'O' framing --------------------
    OraoReceive oraoRx(ram, cassetteDecoder);
    lastByteTime = millis();
    unsigned long startTime = millis();

    while (true) {
      cassetteDecoder.poll();

      if (cassetteDecoder.available()) {
        uint8_t b = cassetteDecoder.read();
        OraoReceive::Status s = oraoRx.feed(b);
        lastByteTime = millis();

        if (s == OraoReceive::OR_DONE) {
          ramAddr = oraoRx.dataBytes();
          // Append the $1A EOF marker so the stored file matches what a real
          // ORAO tape carries (and what loads back cleanly via SendData()).
          ram.writeByte((uint16_t)ramAddr, 0x1A);
          ramAddr++;
          okToFile = true;
          break;
        }
        if (s == OraoReceive::OR_ERROR) {
          errMsg = "Decode error";
          okToFile = false;
          break;
        }
      }

      // No bytes at all after 15 s -> nothing is coming; abort.
      if (oraoRx.dataBytes() == 0 && (millis() - startTime) > 15000UL) {
        errMsg = "No data";
        okToFile = false;
        break;
      }

      // Data started but the tape died mid-file (never saw $1A).  Wait longer
      // than the ~2.3 s inter-block leader gap before giving up, then save
      // what we have so a partial capture isn't lost.
      if (oraoRx.dataBytes() > 0 && (millis() - lastByteTime) > 5000UL) {
        ramAddr = oraoRx.dataBytes();
        ram.writeByte((uint16_t)ramAddr, 0x1A);
        ramAddr++;
        okToFile = true;
        break;
      }

      lastActivityTime = millis();
    }

    // If the SAVE carried a filename in its header (e.g. SAVE"TEST" -> "TEST"),
    // use that as the output file name, overriding whatever VIPTAPE had chosen.
    // A blank/nameless header leaves currentFile untouched (typed name or the
    // auto FILExxxx default).  Only done once we know we'll actually write.
    if (okToFile) {
      String tapeNameStr = sanitizeTapeName(oraoRx.filename());
      if (tapeNameStr.length() > 0) {
        currentFile = currentPath + tapeNameStr + ".BIN";
        if (SERIALDEBUG) Serial.print(F("Tape filename   : ")); Serial.println(currentFile);
      }
    }

    if (errMsg[0] != '\0') {
      centerText(tft, errMsg, 100, 0, WHITE, RED, 2);
      delay(1000);
      cassetteDecoder.clearError();
    }

  } else {
    // -------------------- original async-protocol path (unchanged) --------
    while (true) {
      cassetteDecoder.poll();
      if (cassetteDecoder.available()) {
        uint8_t b = cassetteDecoder.read();
        ram.writeByte(ramAddr++, b);
        lastByteTime = millis();
      }

      if (errMsg[0] != '\0') { okToFile = false; break; }

      if (ramAddr > 0 && millis() - lastByteTime > 2000) {
        okToFile = true;
        break;
      }

      if (cassetteDecoder.decodeFinished()) {
        if (cassetteDecoder.hasError()) {
          okToFile = false;
          switch (cassetteDecoder.lastError()) {
            case DECODE_ERR_PARITY:  errMsg = "Parity error";  goto message_error;
            case DECODE_ERR_STOPBIT: errMsg = "Stop bit error"; goto message_error;
            case DECODE_ERR_TIMEOUT: errMsg = "Tape timeout";  goto message_error;
            default:                 errMsg = "Error unknown"; goto message_error;
message_error:
            centerText(tft, errMsg, 100, 0, WHITE, RED, 2);
            delay(1000);
            cassetteDecoder.clearError();
            break;
          }
        }
      }
      lastActivityTime = millis();
    }
  }

  saveLastMode();
  if (SERIALDEBUG) Serial.println(okToFile);
  if (okToFile) { writeFile(); }
}

void ReadDataX() {
  ramAddr = 0;
  bool okToFile = true;
  const char *errMsg = "";
  cassetteDecoder.reset();

  const CassetteParams *p = cassetteDecoder.getParams();
  const bool oraoMode = (p && p->framing == FRAMING_BLOCK_ORAO);
  OraoReceive oraoRx(ram, cassetteDecoder);
  if (oraoMode) oraoRx.begin();

  // Live diagnostic state for ORAO-mode hardware troubleshooting.
  // Prints a one-line summary every ~1s so you can see, in real time,
  // whether edges are arriving, whether cycles fall in the bit-0/bit-1
  // windows, and how far the decoder has progressed.  Quiet when SERIALDEBUG=0.
  unsigned long loadStartMs = millis();
  unsigned long lastDiagMs  = loadStartMs;
  const unsigned long HARD_TIMEOUT_MS = 30000UL;  // safety net so the LOAD
                                                  // always terminates even
                                                  // if no byte ever decodes
  if (oraoMode && SERIALDEBUG) {
    Serial.println(F("--- ORAO LOAD START (live diagnostics) ---"));
    Serial.println(F("t(ms)  state             edges  cycles  bit0  bit1  oor   lastUs  min/max         bytes maxState        sEnt sFail sLock lastShift"));
  }

  while (true) {
    cassetteDecoder.poll();
    if (cassetteDecoder.available()) {
      uint8_t b = cassetteDecoder.read();
      if (oraoMode) {
        OraoReceive::Status s = oraoRx.feed(b);
        if (s == OraoReceive::OR_DONE) {
          ramAddr = oraoRx.dataBytes();
          if (oraoRx.type() == 'O') {
            startAddr = oraoRx.loadAddr();
            endAddr   = oraoRx.endAddr();
          } else {
            startAddr = 0;
            endAddr   = (ramAddr > 0) ? (uint16_t)(ramAddr - 1) : 0;
          }
          break;
        }
        if (s == OraoReceive::OR_ERROR) {
          okToFile = false;
          errMsg = "ORAO format error";
          break;
        }
      } else {
        ram.writeByte(ramAddr++, b);
      }
      lastByteTime = millis();
    }

    // Live diagnostic line every ~1s
    if (oraoMode && SERIALDEBUG && (millis() - lastDiagMs) >= 1000) {
      lastDiagMs = millis();
      Serial.print(millis() - loadStartMs); Serial.print('\t');
      Serial.print(cassetteDecoder.debugStateName()); Serial.print('\t');
      Serial.print(cassetteDecoder.debugEdgesSeen());     Serial.print('\t');
      Serial.print(cassetteDecoder.debugFullCycles());    Serial.print('\t');
      Serial.print(cassetteDecoder.debugBit0Count());     Serial.print('\t');
      Serial.print(cassetteDecoder.debugBit1Count());     Serial.print('\t');
      Serial.print(cassetteDecoder.debugOutOfRange());    Serial.print('\t');
      Serial.print(cassetteDecoder.debugLastCycleUs());   Serial.print('\t');
      Serial.print(cassetteDecoder.debugMinCycleUs());    Serial.print('/');
      Serial.print(cassetteDecoder.debugMaxCycleUs());    Serial.print('\t');
      Serial.print(cassetteDecoder.debugBytesEmitted());  Serial.print('\t');
      Serial.print(cassetteDecoder.debugMaxStateName());  Serial.print('\t');
      Serial.print(cassetteDecoder.debugSyncEnters());    Serial.print('\t');
      Serial.print(cassetteDecoder.debugSyncFails());     Serial.print('\t');
      Serial.print(cassetteDecoder.debugSyncLocks());     Serial.print('\t');
      Serial.println(cassetteDecoder.debugLastSyncShift(), HEX);
    }

    if (errMsg!= "") {
          okToFile= false;
          break;
    }

    // Async-mode end-of-tape: 2s of silence after at least one byte received.
    if (!oraoMode && ramAddr > 0 && millis() - lastByteTime >2000) {
      okToFile= true;
      break;
    }

    // Hard 30s timeout for ORAO mode -- protects against "just sits waiting"
    // when no byte ever decodes, which the silence-timeout (gated on
    // _anyByteEmitted) deliberately can't catch.
    if (oraoMode && (millis() - loadStartMs) > HARD_TIMEOUT_MS) {
      okToFile = false;
      errMsg = "Timeout (no decode)";
      if (SERIALDEBUG) {
        Serial.println(F("--- ORAO HARD TIMEOUT (30s) ---"));
        Serial.print(F("decoder state    : "));
        Serial.println(cassetteDecoder.debugStateName());
        Serial.print(F("leaderCount      : "));
        Serial.println(cassetteDecoder.debugLeaderCount());
        Serial.print(F("edges total      : "));
        Serial.println(cassetteDecoder.debugEdgesSeen());
        Serial.print(F("bit0/bit1/oor    : "));
        Serial.print(cassetteDecoder.debugBit0Count());  Serial.print(F(" / "));
        Serial.print(cassetteDecoder.debugBit1Count());  Serial.print(F(" / "));
        Serial.println(cassetteDecoder.debugOutOfRange());
        Serial.print(F("max state reached: "));
        Serial.println(cassetteDecoder.debugMaxStateName());
        Serial.print(F("sync enters/fails/locks: "));
        Serial.print(cassetteDecoder.debugSyncEnters()); Serial.print(F(" / "));
        Serial.print(cassetteDecoder.debugSyncFails());  Serial.print(F(" / "));
        Serial.println(cassetteDecoder.debugSyncLocks());
        Serial.print(F("last shift reg   : 0x"));
        Serial.println(cassetteDecoder.debugLastSyncShift(), HEX);
        Serial.print(F("bytes emitted    : "));
        Serial.println(cassetteDecoder.debugBytesEmitted());
      }
      break;
    }

    // ORAO-mode end-of-tape: decoder reports tape silence (>500ms no edges).
    // Accept whatever we received as long as at least one full block came in.
    if (oraoMode && cassetteDecoder.isDone()) {
      if (oraoRx.dataBytes() > 0) {
        ramAddr = oraoRx.dataBytes();
        if (oraoRx.type() == 'O') {
          startAddr = oraoRx.loadAddr();
          endAddr   = oraoRx.endAddr();
        } else {
          startAddr = 0;
          endAddr   = (uint16_t)(ramAddr - 1);
        }
        okToFile = true;
      } else {
        okToFile = false;
        errMsg = "No data received";
        // Diagnostic: dump decoder state so we can see WHERE on the tape we
        // bailed.  state/leaderCount/syncMatch tell us if we got past the
        // leader and how far the sync hunt progressed; type/blocksReceived
        // tell us if any block header was parsed.
        if (SERIALDEBUG) {
          Serial.println(F("--- ORAO LOAD FAILED ---"));
          Serial.print(F("decoder state    : "));
          Serial.println(cassetteDecoder.debugStateName());
          Serial.print(F("leaderCount      : "));
          Serial.println(cassetteDecoder.debugLeaderCount());
          Serial.print(F("syncMatch        : "));
          Serial.println(cassetteDecoder.debugSyncMatch());
          Serial.print(F("blockBytesRead   : "));
          Serial.println(cassetteDecoder.debugBlockBytesRead());
          Serial.print(F("bitCount in byte : "));
          Serial.println(cassetteDecoder.debugBitCount());
          Serial.print(F("us since lastEdge: "));
          Serial.println(cassetteDecoder.debugUsSinceLastEdge());
          Serial.print(F("anyByteEmitted   : "));
          Serial.println(cassetteDecoder.debugAnyByteEmitted() ? F("true") : F("false"));
          Serial.print(F("edges total      : "));
          Serial.println(cassetteDecoder.debugEdgesSeen());
          Serial.print(F("full cycles      : "));
          Serial.println(cassetteDecoder.debugFullCycles());
          Serial.print(F("bit0 / bit1 / oor: "));
          Serial.print(cassetteDecoder.debugBit0Count());  Serial.print(F(" / "));
          Serial.print(cassetteDecoder.debugBit1Count());  Serial.print(F(" / "));
          Serial.println(cassetteDecoder.debugOutOfRange());
          Serial.print(F("last cycle us    : "));
          Serial.println(cassetteDecoder.debugLastCycleUs());
          Serial.print(F("min/max cycle us : "));
          Serial.print(cassetteDecoder.debugMinCycleUs()); Serial.print(F(" / "));
          Serial.println(cassetteDecoder.debugMaxCycleUs());
          Serial.print(F("rx type          : '"));
          Serial.print(oraoRx.type() ? oraoRx.type() : '?');
          Serial.println(F("'"));
          Serial.print(F("rx blocks recv'd : "));
          Serial.println(oraoRx.blocksReceived());
          Serial.print(F("rx dataBytes     : "));
          Serial.println(oraoRx.dataBytes());
          Serial.print(F("max state reached: "));
          Serial.println(cassetteDecoder.debugMaxStateName());
          Serial.print(F("sync hunt enters : "));
          Serial.println(cassetteDecoder.debugSyncEnters());
          Serial.print(F("sync hunt fails  : "));
          Serial.println(cassetteDecoder.debugSyncFails());
          Serial.print(F("sync hunt locks  : "));
          Serial.println(cassetteDecoder.debugSyncLocks());
          Serial.print(F("last shift reg   : 0x"));
          Serial.println(cassetteDecoder.debugLastSyncShift(), HEX);
        }
      }
      break;
    }
    
    if (cassetteDecoder.decodeFinished()) {   
      if (cassetteDecoder.hasError()) {
        okToFile = false;
        switch (cassetteDecoder.lastError()) {
                                                                               
          case DECODE_ERR_PARITY:
            errMsg = "Parity error";
            goto message_error;

          case DECODE_ERR_STOPBIT:
            errMsg = "Stop bit error";
            goto message_error;

          case DECODE_ERR_TIMEOUT:
            errMsg = "Tape timeout";
            goto message_error;

          default:
            errMsg = "Error unknown";
            goto message_error;

message_error:
            centerText(tft, errMsg, 100, 0, WHITE, RED, 2);
            delay(1000);
            cassetteDecoder.clearError();
            break;
        }
      }
    }
  lastActivityTime = millis();  // Initialize activity time
  }
  saveLastMode();
  Serial.println(okToFile);
  if (okToFile) {
    if (oraoMode && oraoRx.type() == 'O') {
      // Object file: write Intel HEX so load address survives round trip.
      writeOraoIntelHex(oraoRx.loadAddr(), oraoRx.dataBytes());
    } else {
      // Async mode, or ORAO 'B' (plain text): existing binary write.
      writeFile();
    }
  }
  if (!okToFile && errMsg && errMsg[0]) {
    centerText(tft, errMsg, 100, 0, WHITE, RED, 2);
    delay(1000);
  }
}

void writeFile() {
  uint32_t a;
  byte v;
  // FILE_WRITE opens an existing file for *append*, which would corrupt a
  // re-save under the same name (now possible when the tape header supplies a
  // fixed filename like TEST.BIN).  Remove any existing file first so a SAVE
  // overwrites cleanly, matching real cassette behaviour.
  if (SD.exists(currentFile.c_str())) SD.remove(currentFile.c_str());
  myFile = SD.open(currentFile, FILE_WRITE);
  if (myFile) {
    centerText(tft, "Writing file", 10, 0, BLUE, CYAN, 2);
    delay(500);
    for (word a = 0; a < ramAddr; a++) {
      v = ram.readByte(a); 
      myFile.write(v);
      lastActivityTime = millis();  // Initialize activity time
    }
    myFile.close();
    if (SERIALDEBUG) { Serial.println(F("done.")); }
    
      tft.fillScreen(BLACK);
      centerText(tft, "Writing completed", 10, 0, BLUE, YELLOW, 2);
      delay(1000);
  } else {
    // if the file didn't open, print an error:
    if (SERIALDEBUG) { Serial.println(F("Error opening file")); }
    centerText(tft, "ERROR", 10, 0, WHITE, RED, 2);
     delay(1000);
  }
}


// ---------------------------------------------------------------------------
// ORAO .TAP -> program bytes.
//
// An ORAO .TAP holds the *demodulated* tape stream.  For a 'B' (BASIC) image
// the relevant part is, per block:
//     [ $FF... leader ][ $7F ] $1B $1B $1B $1B  'B'  <10-char name>  <blk#>
//     <ASCII payload ...>
// Each block's payload is plain ASCII that runs until the next $FF leader, and
// the whole program ends at a $1A EOF.  We scan for the $1B*4 sync, skip the
// type/name/block# header, and copy payload bytes into RAM until $FF (next
// block) or $1A (done) -- exactly the bytes a normal audio receive would yield.
// Fills ramAddr, captures the embedded name into currentFile, returns true on
// success.  ('O'/object images use a different layout and aren't handled here.)
// ---------------------------------------------------------------------------
bool convertOraoTap(File &f) {
  enum TapSt { HUNT, T_TYPE, T_NAME, T_BLK, T_PAYLOAD };
  TapSt   st      = HUNT;
  uint8_t syncRun = 0;
  uint8_t nameIdx = 0;
  char    tapName[11];
  tapName[0] = '\0';
  char    tapType = 0;
  ramAddr = 0;
  bool gotData = false;
  bool done    = false;

  while (f.available() && !done) {
    uint8_t b = (uint8_t)f.read();
    switch (st) {
      case HUNT:                         // look for the 4-byte $1B sync
        if (b == 0x1B) { if (++syncRun >= 4) { syncRun = 0; st = T_TYPE; } }
        else           { syncRun = 0; }
        break;
      case T_TYPE:
        tapType = (char)b;
        if (b != 'B' && b != 'O') { st = HUNT; break; }   // false sync
        nameIdx = 0; st = T_NAME;
        break;
      case T_NAME:
        if (nameIdx < 10) tapName[nameIdx++] = (char)b;
        if (nameIdx >= 10) { tapName[10] = '\0'; st = T_BLK; }
        break;
      case T_BLK:                        // block number -- not needed
        st = T_PAYLOAD;
        break;
      case T_PAYLOAD:
        if (b == 0x1A) {                 // EOF -> program complete
          ram.writeByte((uint16_t)ramAddr++, 0x1A);
          done = true;
        } else if (b == 0xFF) {          // leader tone -> end of this block
          st = HUNT;
        } else {
          ram.writeByte((uint16_t)ramAddr++, b);
          gotData = true;
        }
        break;
    }
  }

  if (!gotData || tapType != 'B') return false;

  String nm = sanitizeTapeName(tapName);
  if (nm.length() > 0) currentFile = currentPath + nm + ".BIN";
  if (SERIALDEBUG) {
    Serial.print(F("TAP name        : ")); Serial.println(tapName);
    Serial.print(F("TAP -> file      : ")); Serial.println(currentFile);
    Serial.print(F("TAP bytes        : ")); Serial.println(ramAddr);
  }
  return true;
}

// Forward declaration -- defined just below; streamOraoTap() uses it above its
// definition, and static functions aren't auto-prototyped by the IDE.
static uint8_t oraoEncoderReader(uint32_t srcIndex, void* ctx);

// Locate the ORAO 'B' (BASIC) protocol row so a converted TAP can be streamed
// as BASIC regardless of which protocol is currently selected in the UI.
int findOraoBasicProtocol() {
  for (uint8_t i = 0; i < cassetteProtocolCount; i++) {
    if (cassetteProtocols[i].framing  == FRAMING_BLOCK_ORAO &&
        cassetteProtocols[i].oraoType == ORAO_TYPE_BASIC) return (int)i;
  }
  return -1;
}

// --- Local helpers used only by streamOraoTap() ---------------------------
//
// streamOraoTap() needs to emit each tape byte as 8 ORAO cycles, back-to-back,
// while *also* reading the next byte from external RAM.  RamExternal::readByte
// uses digitalWrite() and takes ~660us per call -- way longer than a 362us
// bit-0 cycle -- so calling it between bytes stretches every byte's last bit
// past the ORAO's bit-0/bit-1 timing threshold and the receiver can't sync.
//
// Fix: spread the four-transfer SPI read across the *low phase* of the first
// four bit cells of the current byte.  Each SPI byte transfer takes ~165us,
// which fits comfortably inside a 181us bit-0 low half (and even more inside
// a 363us bit-1 low half).  We follow each piece with a fixed delay sized to
// the bit's half-period minus the SPI piece, so cycle timing is deterministic
// -- crucially we do NOT use micros() inside noInterrupts() (the overflow
// counter is stale there and the delta wraps wrong).  By the time the byte
// finishes emitting, the *next* byte is already in hand -- no inter-byte gap.
//
// These helpers replicate RamExternal::spiTransfer / readByte byte-for-byte
// (digitalWrite-based, proven reliable on the user's hardware) so we never
// touch the shared RamExternal code.  They use the same pins, which is safe
// because streamOraoTap is the only thing accessing RAM during its loop.

static uint8_t tapSpiByte(uint8_t d) {
  uint8_t r = 0;
  for (int8_t i = 7; i >= 0; i--) {
    digitalWrite(ramMOSI, (d >> i) & 1);
    digitalWrite(ramCLK, HIGH);
    r <<= 1;
    if (digitalRead(ramMISO)) r |= 1;
    digitalWrite(ramCLK, LOW);
  }
  return r;
}

static uint8_t tapRamReadByte(uint16_t addr) {
  digitalWrite(ramCS, LOW);
  tapSpiByte(0x03);                     // 23K256 READ
  tapSpiByte((addr >> 8) & 0xFF);
  tapSpiByte(addr & 0xFF);
  uint8_t v = tapSpiByte(0x00);
  digitalWrite(ramCS, HIGH);
  return v;
}

// Emit `cur` as 8 ORAO cycles on tapeOut (LSB first, POSITIVE polarity),
// while reading the byte at `na` from external RAM into `*nxt`.  The 4 SPI
// transfers of the read are dropped into the low phase of bit cells 0..3.
//
// We don't use micros() to time the remainder, because micros() is not
// reliable inside noInterrupts(): Timer0's overflow ISR can't fire, so its
// overflow counter goes stale and the next read wraps incorrectly whenever
// TCNT0 rolls over during the SPI piece.  Instead we use *fixed* delays
// computed from a known-good SPI-piece duration -- each bit cell becomes
// fully deterministic, so timing can't drift cell-to-cell.
static void tapEmitByteWithPrefetch(uint8_t cur,
                                    uint16_t na, uint8_t *nxt,
                                    uint16_t half0, uint16_t half1) {
  // Measured time taken by one piece of the SPI read inside the LOW phase
  // (digitalWrite + tapSpiByte at digitalWrite speed on Mega 2560 @ 16MHz).
  // 165us is conservative; small deviations still leave cycle periods well
  // inside the bit-0 / bit-1 windows (362us +-90, 726us +-200).
  const uint16_t SPI_PIECE_US = 165;
  const uint16_t bit0_spi_tail = (half0 > SPI_PIECE_US) ? (half0 - SPI_PIECE_US) : 0;
  const uint16_t bit1_spi_tail = (half1 > SPI_PIECE_US) ? (half1 - SPI_PIECE_US) : 0;

  for (uint8_t b = 0; b < 8; b++) {
    const uint8_t  bit_val  = (cur >> b) & 1;
    const uint16_t half     = bit_val ? half1 : half0;
    const uint16_t spi_tail = bit_val ? bit1_spi_tail : bit0_spi_tail;

    // HIGH phase -- full half-period.
    digitalWrite(tapeOut, HIGH);
    delayMicroseconds(half);
    // LOW phase -- optionally one SPI piece, then a fixed remainder delay.
    digitalWrite(tapeOut, LOW);
    switch (b) {
      case 0: digitalWrite(ramCS, LOW);  tapSpiByte(0x03);
              delayMicroseconds(spi_tail);                       break;
      case 1: tapSpiByte((na >> 8) & 0xFF);
              delayMicroseconds(spi_tail);                       break;
      case 2: tapSpiByte(na & 0xFF);
              delayMicroseconds(spi_tail);                       break;
      case 3: *nxt = tapSpiByte(0x00);   digitalWrite(ramCS, HIGH);
              delayMicroseconds(spi_tail);                       break;
      default: delayMicroseconds(half);                          break;
    }
  }
}

// Stream an ORAO .TAP by re-modulating its tape byte-stream verbatim.
//
// An ORAO emulator .TAP is a faithful image of the *demodulated* tape: a small
// metadata header (its byte length is the little-endian value in bytes 0-1),
// then the tape stream itself -- leader ($FF tone), $7F, sync ($1B), block
// headers and data.  Re-emitting every tape-stream byte as 8 ORAO cycles
// reproduces the original tape exactly, so this one path works for BASIC,
// single-block object, multi-block, and even custom-loader tapes (like Otto
// Motor) without having to understand any block structure.  ORAO 'B' and 'O'
// share the same bit timing, so a single configure() covers both.
void streamOraoTap() {
  if (SERIALDEBUG) { Serial.print(F("TAP: opening ")); Serial.println(currentFile); }

  File f = SD.open(currentFile, FILE_READ);
  if (!f) {
    if (SERIALDEBUG) Serial.println(F("TAP: open FAILED"));
    centerText(tft, "TAP open failed", 100, 0, WHITE, RED, 2);
    delay(1500);
    return;
  }
  if (SERIALDEBUG) { Serial.print(F("TAP: size ")); Serial.println(f.size()); }

  // Find where the tape stream starts.  Emulator TAPs prefix a metadata header
  // whose length sits little-endian in bytes 0-1.  A raw tape image already
  // begins with leader/sync, so don't skip in that case.
  uint8_t b0 = (uint8_t)f.read();
  uint8_t b1 = (uint8_t)f.read();
  uint16_t skip;
  if (b0 == 0xFF || b0 == 0x1B || b0 == 0x7F) {
    skip = 0;
  } else {
    skip = (uint16_t)b0 | ((uint16_t)b1 << 8);
    if (skip < 3 || skip > 4096) skip = 360;     // guard / common default
  }
  if (SERIALDEBUG) { Serial.print(F("TAP: skip header ")); Serial.println(skip); }

  // Load the tape stream into RAM (so transmit runs with no SD access).
  f.seek(skip);
  uint16_t n = 0;
  uint8_t  buf[128];
  bool ok = true;
  tft.fillScreen(BACKGROUND);
  centerText(tft, "Loading TAP", 10, 0, BLUE, CYAN, 2);
  while (true) {
    int got = f.read(buf, sizeof(buf));
    if (got <= 0) break;
    for (int k = 0; k < got; k++) {
      if (n >= 60000) { ok = false; break; }
      ram.writeByte(n++, buf[k]);
    }
    if (!ok) break;
  }
  f.close();
  if (SERIALDEBUG) { Serial.print(F("TAP: loaded ")); Serial.print(n); Serial.println(F(" bytes")); }
  if (!ok)   { centerText(tft, "TAP too big", 100, 0, WHITE, RED, 2); delay(1500); return; }
  if (n == 0){
    if (SERIALDEBUG) Serial.println(F("TAP: tape stream empty"));
    centerText(tft, "Empty TAP", 100, 0, WHITE, RED, 2); delay(1500); return;
  }

  // Configure ORAO timing (B/O identical) and re-modulate byte-for-byte.
  int bi = findOraoObjectProtocol();
  if (bi < 0) bi = findOraoBasicProtocol();
  if (bi < 0) {
    if (SERIALDEBUG) Serial.println(F("TAP: no ORAO protocol available"));
    centerText(tft, "No ORAO mode", 100, 0, WHITE, RED, 2);
    delay(1500);
    return;
  }
  cassetteEncoder.configure(&cassetteProtocols[bi]);
  if (SERIALDEBUG) {
    Serial.print(F("TAP: configured ")); Serial.println(cassetteProtocols[bi].name);
  }

  // Belt-and-braces: re-assert the output pin in case another code path (touch
  // / TFT) shared or reconfigured it since boot.
  pinMode(tapeOut, OUTPUT);
  digitalWrite(tapeOut, LOW);

  tft.fillScreen(BACKGROUND);
  centerText(tft, "Transferring TAP", 10, 0, BLUE, YELLOW, 2);
  {
    char info[24];
    snprintf(info, sizeof(info), "%u bytes", (unsigned)n);
    centerText(tft, info, 50, 0, BLUE, YELLOW, 2);
  }

  // Read the half-periods once -- ORAO bit-0 = 362us (half=181), bit-1 = 726us
  // (half=363).  We drive tapeOut directly to mirror what cassetteEncoder does
  // for ORAO (digitalWrite, positive polarity) but split the work so the next
  // byte's external-RAM read happens during the current byte's bit cells.
  const CassetteParams *pOrao = &cassetteProtocols[bi];
  uint16_t half0 = pOrao->bit0 / 2;
  uint16_t half1 = pOrao->bit1 / 2;

  // Prefetch the very first byte before the timed loop starts.  This is the
  // only "free" read; every subsequent byte gets read concurrently with the
  // emission of the byte before it.
  uint8_t cur = tapRamReadByte(0);
  uint8_t nxt = 0;

  if (SERIALDEBUG) Serial.println(F("TAP: streaming (interleaved prefetch)"));
  noInterrupts();
  for (uint16_t i = 0; i < n; i++) {
    if (i + 1 < n) {
      tapEmitByteWithPrefetch(cur, (uint16_t)(i + 1), &nxt, half0, half1);
      cur = nxt;
    } else {
      // Last byte: nothing left to prefetch, just emit it with plain timing.
      for (uint8_t b = 0; b < 8; b++) {
        uint16_t half = ((cur >> b) & 1) ? half1 : half0;
        digitalWrite(tapeOut, HIGH);
        delayMicroseconds(half);
        digitalWrite(tapeOut, LOW);
        delayMicroseconds(half);
      }
    }
  }
  interrupts();
  if (SERIALDEBUG) Serial.println(F("TAP: done"));

  tft.fillScreen(BACKGROUND);
  centerText(tft, "Transfer complete", 10, 0, BLUE, YELLOW, 2);
  delay(1000);
}

// Locate the ORAO 'O' (OBJECT) protocol row.
int findOraoObjectProtocol() {
  for (uint8_t i = 0; i < cassetteProtocolCount; i++) {
    if (cassetteProtocols[i].framing  == FRAMING_BLOCK_ORAO &&
        cassetteProtocols[i].oraoType == ORAO_TYPE_OBJECT) return (int)i;
  }
  return -1;
}

// Encoder reader callback for ORAO sendOraoFile().  srcIndex runs 0..N-1 where
// N = endAddr - startAddr + 1; we just translate to an absolute RAM address.
static uint8_t oraoEncoderReader(uint32_t srcIndex, void* /*ctx*/) {
  return ram.readByte((uint16_t)(startAddr + srcIndex));
}

// Case-insensitive check that currentName ends with the given extension
// (e.g. ".BAS").  Used to trigger COMX BASIC tokenisation on SAVE.
static bool currentNameHasExt(const char* ext) {
  int nlen = currentName.length();
  int elen = strlen(ext);
  if (nlen < elen) return false;
  for (int i = 0; i < elen; i++) {
    char c = currentName[nlen - elen + i];
    if (c >= 'a' && c <= 'z') c -= 32;
    char e = ext[i];
    if (e >= 'a' && e <= 'z') e -= 32;
    if (c != e) return false;
  }
  return true;
}

void SendData() {

  const CassetteParams *p = &cassetteProtocols[currentProtocol];
  cassetteEncoder.configure(p);
  if (SERIALDEBUG) {
    Serial.print(F("Cassette Mode   : ")); Serial.println(p->name);
    Serial.println("Bit 0           : " + String(p->bit0) + " uS");
    Serial.println("Bit 1           : " + String(p->bit1) + " uS");
    Serial.print(F("Start Bit       : ")); Serial.println(getBitString(p->startBit));
    Serial.print(F("Stop Bit        : ")); Serial.println(getBitString(p->stopBit));
    Serial.print(F("Parity          : ")); Serial.println(getParityString(p->parity));
    Serial.print(F("Endian          : ")); Serial.println(getEndianString(p->bitOrder));
    Serial.print(F("Leader Bit      : ")); Serial.println(getBitString(p->leaderBit));
    Serial.print(F("Leader Count    : ")); Serial.println(p->leaderBits);
    Serial.println("Leader Time     : " + String(p->leaderTime) + " mS");
    Serial.print(F("Trailer         : ")); Serial.println(getBitString(p->trailerBit));
    Serial.println("Trailer Time    : " + String(p->trailerTime) + " mS");
    Serial.print(F("Polarity Mode   : ")); Serial.println(getPolarityString(p->polarity));
    Serial.println(F("Reading data from device......"));
    Serial.println(F("Transferring data to device......"));
  }
  tft.fillScreen(BACKGROUND);
  centerText(tft, "Transferring file", 10, 0, BLUE, YELLOW, 2);
  centerText(tft, "Please wait", 50, 0, BLUE, YELLOW, 2);

  // ---- COMX-35: tokenise BASIC source text into the on-tape image ----------
  // The COMX LOAD routine needs a tokenised image, not raw ASCII.  When we're
  // in COMX mode and the file is BASIC source (.BAS), convert the text that
  // FileLoader put in external RAM [startAddr..endAddr] into the real image and
  // point a LOCAL pair of tx pointers at it.  We must NOT overwrite the global
  // startAddr/endAddr: doing so meant a second send in the same session would
  // re-tokenise the already-tokenised image at 0xC000 (garbage) and the COMX
  // would report error 57.  Keeping the source range in the globals lets the
  // user replay the same file repeatedly.
  uint16_t txStart = startAddr;
  uint16_t txEnd   = endAddr;
  if (p->framing == FRAMING_SYNC_COMX && currentNameHasExt(".BAS")) {
    const uint16_t COMX_IMG_BASE = 0xC000;   // high external-RAM scratch region
    ComxBasic comxBasic(ram);
    uint16_t imgLen = comxBasic.tokeniseInRam(startAddr, endAddr, COMX_IMG_BASE);
    if (imgLen == 0) {
      interrupts();
      if (SERIALDEBUG) {
        Serial.print(F("COMX BASIC tokenise error: "));
        Serial.println(comxBasic.error());
      }
      tft.fillScreen(BACKGROUND);
      centerText(tft, "BASIC token error", 10, 0, WHITE, RED, 2);
      centerText(tft, comxBasic.error(), 50, 0, WHITE, RED, 1);
      delay(2500);
      return;
    }
    txStart = COMX_IMG_BASE;
    txEnd   = COMX_IMG_BASE + imgLen - 1;
    if (SERIALDEBUG) {
      Serial.print(F("COMX BASIC tokenised to image bytes: "));
      Serial.println(imgLen);
    }
  }
  else if (p->framing == FRAMING_SYNC_COMX &&
           (endAddr - startAddr + 1) > 16 &&
           ram.readByte(startAddr + 1) == 0x43 &&   // 'C'
           ram.readByte(startAddr + 2) == 0x4F &&   // 'O'
           ram.readByte(startAddr + 3) == 0x4D &&   // 'M'
           ram.readByte(startAddr + 4) == 0x58) {   // 'X'
    // Emma 02 ".comx" container, detected by its "COMX" magic in RAM (robust --
    // the filename-extension check was unreliable).  Layout of the 15-byte
    // header (per Marcel van Tongeren, Emma 02 author):
    //   byte 0     : .comx type
    //   bytes 1-4  : "COMX"
    //   byte 5     : DEFUS high        <- needed
    //   byte 6     : DEFUS low
    //   bytes 7-8  : end of BASIC
    //   bytes 9-14 : start/end data, end string (not needed)
    //   byte 15+   : program data (RAM image from 0x4400)
    // A genuine PSAVE tape image = 00 11 [nBlocks-1] 00 + program data, where the
    // FIRST program byte must be (DEFUS_high - 0x44) (a PSAVE/PLOAD DEFUS-high
    // fixup that some .comx files already carry and some don't).  Verified
    // byte-for-byte against a matched Diver .comx + genuine PSAVE.
    if (SERIALDEBUG) {
      Serial.print(F("COMX .comx detected, name=")); Serial.println(currentName);
    }
    const uint16_t COMX_HEADER_LEN = 15;
    // Per Marcel van Tongeren: the FIRST program byte (comx[15]) is the number of
    // 0x100 pages reserved below the program -- i.e. (DEFUS_high - 0x44).  A plain
    // BASIC file (DEFUS 0x4400) carries 0x00 here; an ML+BASIC file (DEFUS 0x5400)
    // carries 0x10; etc.  The file already stores the correct value, so we do NOT
    // overwrite it.  The implied DEFUS is 0x4400 + firstByte*0x100.  If that runs
    // past the 64K address space (firstByte > 0xBB) the .comx is not a PSAVE image
    // at all but a COMX DOS/FDC direct-RAM-address save, which can never be loaded
    // with PLOAD -- refuse those rather than send an unloadable tape.
    uint8_t firstByte = ram.readByte(startAddr + COMX_HEADER_LEN);
    if (firstByte > 0xBB) {
      centerText(tft, ".comx not PLOAD-compatible", 200, 0, BLACK, RED, 2);
      if (SERIALDEBUG) {
        Serial.print(F("COMX .comx: firstByte 0x")); Serial.print(firstByte, HEX);
        Serial.println(F(" -> implied DEFUS past 64K (DOS direct-address save), cannot PLOAD. Aborting."));
      }
      return;   // do not transmit an unloadable image
    }
    uint16_t hdrPos = startAddr + COMX_HEADER_LEN - 4;  // 4 header bytes before body
    uint32_t comxImgLen = (uint32_t)(endAddr - hdrPos + 1);
    uint16_t dBlocks = (comxImgLen <= 257)
                       ? 1 : 1 + (uint16_t)((comxImgLen - 257 + 255) / 256);
    uint16_t nBlk = dBlocks + 1;                         // + trailing block
    ram.writeByte(hdrPos + 0, 0x00);
    ram.writeByte(hdrPos + 1, 0x11);
    ram.writeByte(hdrPos + 2, (uint8_t)((nBlk - 1) & 0xFF));
    ram.writeByte(hdrPos + 3, 0x00);
    txStart = hdrPos;
    txEnd   = endAddr;
    if (SERIALDEBUG) {
      Serial.print(F("COMX .comx: firstByte(reserve)=")); Serial.print(firstByte, HEX);
      Serial.print(F(" implied DEFUS 0x")); Serial.print(0x4400 + (uint16_t)firstByte * 0x100, HEX);
      Serial.print(F(", header 00 11 "));   Serial.print((uint8_t)(nBlk - 1), HEX);
      Serial.print(F(" 00, image bytes: ")); Serial.print((uint16_t)(txEnd - txStart + 1));
      Serial.print(F(", blocks: "));         Serial.println(nBlk);
    }
  }

  if (p->framing == FRAMING_BLOCK_ORAO) {
    noInterrupts();
    // ----- ORAO block-mode send -----------------------------------------
    // For 'O' (object) mode the load/end addresses come from FileLoader
    // (Intel HEX preserves them; for binary input they default to 0..size-1).
    // For 'B' (BASIC) mode the addresses are unused -- the file is just text.
    // ORAO header filename (up to 10 chars).  Priority:
    //   1. the name the user typed when saving (saveFilename), else
    //   2. the actual file being sent (currentName), with path + extension
    //      stripped, else
    //   3. the BASEFILE default.
    // sendOraoFile() pads to 10 chars with spaces and truncates beyond 10.
    char oraoName[11];
    {
      String n;
      if (saveFilenameLength > 0) {
        n = String(saveFilename);
      } else {
        n = currentName;                       // e.g. "/PROGS/TEST4.BIN"
        int slash = n.lastIndexOf('/');
        if (slash >= 0) n = n.substring(slash + 1);
        int dot = n.lastIndexOf('.');
        if (dot > 0) n = n.substring(0, dot);  // strip extension
      }
      if (n.length() == 0) n = String(BASEFILE);
      uint8_t i = 0;
      for (; i < 10 && i < (uint8_t)n.length(); i++) oraoName[i] = n[i];
      oraoName[i] = '\0';
    }
    const char* fname = oraoName;
    if (SERIALDEBUG) Serial.print(F("ORAO name       : ")); Serial.println(fname);

    uint32_t total = (uint32_t)endAddr - (uint32_t)startAddr + 1;
    cassetteEncoder.sendOraoFile(fname, total, startAddr, endAddr,
                                 oraoEncoderReader, nullptr);
    interrupts();
  } else {
    // ----- Async-serial send --------------------------------------------
    // IMPORTANT: nothing that blocks may happen between bits here.  The byte
    // hex-dump used to run INSIDE this loop via Serial.print(), which (a) takes
    // hundreds of us to ms per call and (b) can't drain with interrupts off --
    // it stretched the 500/1220us COMX cells arbitrarily and stopped the COMX
    // from ever locking.  We now dump the bytes BEFORE the timed loop (with
    // interrupts still enabled), then emit with zero serial I/O in the loop.
    if (SERIALDEBUG) {
      int c = 0; char hexStr[5];
      for (uint32_t addr = txStart; addr <= txEnd; addr++) {
        sprintf(hexStr, "%02X", ram.readByte(addr));
        Serial.print(F(" ")); Serial.print(hexStr); Serial.print(F(" "));
        if (++c > 16) { c = 0; Serial.println(F(" ")); }
      }
      Serial.println(F(" "));
      Serial.flush();          // make sure the UART is idle before timing starts
    }

    // Pre-read each COMX block/record's FIRST byte here, with interrupts STILL
    // ENABLED.  The bit-banged external-RAM read returns corrupted data (the
    // address low byte, e.g. 0x01 for 0xC101, instead of the real value) for the
    // FIRST byte read after a gap when performed inside noInterrupts() -- this
    // garbled one byte at each block boundary.  We cannot hold the whole image in
    // SRAM (that exhausts the Mega and corrupts the display) and we must keep
    // interrupts OFF across the whole timed send (Timer0 jitter trips the
    // marginal COMX bits).  So we cache just the first byte of every block/record
    // now; the send emits those verbatim.
    //
    // The offset of each "first byte" depends on the image layout, so we detect
    // the layout HERE (interrupts on) too:
    //   RAW image      -> record starts at 0, 257, 513, 769, ...  (256/block)
    //   PRE-BLOCKED BIN -> record starts at 0, 257, 514, 771, ... (257/record;
    //                      a saved .BIN or PSAVE capture already has seq bytes)
    const uint8_t COMX_MAX_BLOCKS = 40;          // 40*257 ~= 10 KB image max
    static uint8_t comxFirstByte[COMX_MAX_BLOCKS];
    bool comxPreBlocked = false;
    if (p->framing == FRAMING_SYNC_COMX) {
      uint32_t imgLenPre = txEnd - txStart + 1;
      // Detect the pre-blocked form: size a multiple of 257, "00 11" header, and
      // a sequence byte (01,02,..) at every 257-byte record boundary.
      if ((imgLenPre % 257) == 0 && imgLenPre >= 257 &&
          ram.readByte(txStart) == 0x00 && ram.readByte(txStart + 1) == 0x11) {
        comxPreBlocked = true;
        uint16_t recs = (uint16_t)(imgLenPre / 257);
        for (uint16_t r = 1; r < recs; r++) {
          if (ram.readByte(txStart + (uint32_t)r * 257) != (uint8_t)r) { comxPreBlocked = false; break; }
        }
      }
      for (uint8_t b = 0; b < COMX_MAX_BLOCKS; b++) {
        uint32_t off;
        if (comxPreBlocked) off = (uint32_t)b * 257;              // record boundary
        else                off = (b == 0) ? 0 : (257 + (uint32_t)(b - 1) * 256);
        comxFirstByte[b] = (off < imgLenPre) ? ram.readByte(txStart + off) : 0x00;
      }
    }


    if (SERIALDEBUG && p->framing == FRAMING_SYNC_COMX) {
      // ---- DIAGNOSTIC (prints only, changes no send logic) -----------------
      // Read the block-boundary byte (image offset 256, address txStart+256)
      // several different ways and report what the external RAM returns, so we
      // can see directly why it has been emitted as 0x00 instead of its real
      // value.  txStart is 0xC000, so offset 256 is address 0xC100.
      uint16_t bAddr = txStart + 256;                 // 0xC100 for a 2-block image
      uint8_t  rStandalone = ram.readByte(bAddr);     // fresh, isolated read
      uint8_t  rAfterPrev  = (ram.readByte(bAddr - 1), ram.readByte(bAddr)); // after 0xC0FF
      uint8_t  rTwice      = (ram.readByte(bAddr), ram.readByte(bAddr));     // read twice
      Serial.print(F("DIAG boundary addr=0x")); Serial.print(bAddr, HEX);
      Serial.print(F(" standalone=")); Serial.print(rStandalone, HEX);
      Serial.print(F(" afterPrev="));  Serial.print(rAfterPrev, HEX);
      Serial.print(F(" twice="));      Serial.print(rTwice, HEX);
      Serial.print(F(" (img[256] should be 0x38 for the HELLO test program)"));
      Serial.println();
    }

    noInterrupts();
    if (p->framing != FRAMING_SYNC_COMX) {
      // ----- Generic async send (VIP / ELF II / HUG 1802 / KCS) -----------
      // EXACT v3a behavior: a single leader followed by one continuous stream
      // of bytes (start/data/parity/stop framing handled inside sendByte()).
      // These protocols are NOT block-structured -- they must NOT get the COMX
      // 256-byte block + inter-block leader treatment below.
      cassetteEncoder.sendLeader();
      for (uint32_t addr = startAddr; addr <= endAddr; addr++) {
        cassetteEncoder.sendByte(ram.readByte(addr));
      }
      cassetteEncoder.sendTrailer();
      interrupts();
      saveLastMode();
      if (SERIALDEBUG) {
        Serial.println(F(" "));
        Serial.println(F("Transfer complete."));
      }
      tft.fillScreen(BLACK);
      centerText(tft, "Transfer complete", 10, 0, BLUE, YELLOW, 2);
      delay(1000);
      return;
    }
    // COMX-35 BASIC PSAVE playback (see detailed format note below).
    {
      // COMX BASIC PSAVE format -- CONFIRMED by decoding a genuine COMX save
      // (Test99.wav) of 10 PRINT"HELLO"/20 GOTO 10 in full:
      //   The save is the program RAM region streamed as 256-byte BLOCKS with a
      //   ~3907-cell bit0 re-sync leader between blocks (NO silence, NO 00 00
      //   header -- the data is the raw image, block 1 starting with its own
      //   00 11 01...).  Even this tiny program produced TWO 256-byte blocks
      //   (512 bytes total): block 1 = program + RAM tail, block 2 = more RAM
      //   (mostly zero).  Sending only one block made the COMX wait for the
      //   second block's leader/data and report error 57 at the END of the load.
      //   Layout: [~20s leader][256B block][~3907-cell leader][256B block]...
      //   We pad the image up to a whole number of 256-byte blocks (>=2, since
      //   the COMX always writes at least the full 512-byte program region).
      // ROM-confirmed block structure: the COMX PLOAD routine reads and STORES
      // exactly 256 bytes per block (R10 counts 0x40FF down to high byte 0x3F =
      // 0x100 = 256), then reads ONE more tape byte that it does NOT store -- a
      // trailer/sync byte that the genuine tape carries (making 257 bytes per
      // block on tape).  We were sending 257 *data* bytes per block, so the COMX
      // stored only our first 256 and DISCARDED our 257th, dropping image byte
      // 256, 513, ... -- everything after the first boundary shifted by one and
      // garbled from the first line of block 2.  Sending 256 DATA bytes plus 1
      // (discarded) trailer byte per block keeps the stored image contiguous.
      const uint16_t COMX_DATA       = 256;   // DATA bytes per block (plus a
                                              // leading sequence byte = 257 on tape)
      const uint8_t  COMX_MIN_BLOCKS = 2;     // at least 1 data + 1 trailing block

      // Trailing-block toggle.  A genuine COMX save writes ONE extra block after
      // the program data (TEST210: a 301-byte program produced 3 blocks = 2 data
      // + 1 trailing).  Set to 1 to include it (matches genuine), 0 to omit it
      // for testing whether the loader actually requires it.
      const uint8_t  COMX_TRAILING_BLOCK = 1;

      uint32_t imgLen  = txEnd - txStart + 1;

      // preBlocked was determined during the interrupts-on pre-read above, using
      // the same test (size % 257, "00 11" header, sequence bytes at boundaries).
      bool preBlocked = comxPreBlocked;

      // block 0 carries 257 image bytes; each later block carries 256.
      uint16_t dataBlocks;
      if (imgLen <= 257) dataBlocks = 1;
      else               dataBlocks = 1 + (uint16_t)((imgLen - 257 + 255) / 256);
      uint16_t nBlocks = dataBlocks + (COMX_TRAILING_BLOCK ? 1 : 0);
      if (nBlocks < COMX_MIN_BLOCKS) nBlocks = COMX_MIN_BLOCKS;

      if (SERIALDEBUG) {
        Serial.print(F("COMX v59 blk: img[0]="));
        Serial.print(ram.readByte(txStart), HEX);
        Serial.print(F(" img[1]=")); Serial.print(ram.readByte(txStart + 1), HEX);
        Serial.print(F("  imgLen=")); Serial.print(imgLen);
        Serial.print(F(" preBlocked=")); Serial.print(preBlocked ? 1 : 0);
        Serial.print(F(" blocks=")); Serial.print(preBlocked ? (uint16_t)(imgLen/257) : nBlocks);
        Serial.print(F(" trailing=")); Serial.println(COMX_TRAILING_BLOCK);
      }

      if (preBlocked) {
        // Stream the stored 257-byte records verbatim: initial leader before the
        // first, an inter-block gap+leader before each subsequent one.  The
        // sequence bytes are already the first byte of records 1..N, so we do
        // NOT add our own.  Reads happen inside noInterrupts; a throwaway warm-up
        // read before each record absorbs the first-read-after-gap corruption.
        uint16_t recs = (uint16_t)(imgLen / 257);
        for (uint16_t r = 0; r < recs; r++) {
          if (r == 0) {
            cassetteEncoder.sendSilence(200);
            cassetteEncoder.sendLeader();
          } else {
            cassetteEncoder.sendSilence(185);
            const uint16_t COMX_LEAD_INTER_TOTAL = 3944;
            for (uint16_t i = 0; i < COMX_LEAD_INTER_TOTAL; i++) cassetteEncoder.pulseBit(0);
          }
          uint32_t recBase = txStart + (uint32_t)r * 257;
          (void)ram.readByte(recBase);                  // warm-up read (discarded)
          uint8_t firstB = comxFirstByte[r < COMX_MAX_BLOCKS ? r : 0];
          for (uint16_t i = 0; i < 257; i++) {
            uint8_t b = (i == 0 && r < COMX_MAX_BLOCKS) ? firstB
                                                        : ram.readByte(recBase + i);
            cassetteEncoder.sendByte(b);
          }
        }
      } else {

      // Verified block format (genuine TEST210, a program spanning blocks):
      //   block 0        = image[0..256]                         (257 bytes)
      //   block N (N>=1)  = [seq=N] + image[257+(N-1)*256 .. +255] (1+256)
      // plus one TRAILING block after the data (its image offsets are past the
      // program, so it comes out as [seq]+padding).  Genuine block 1 began with
      // 0x01 and block 2 with 0x02, confirming the sequence prefix and the extra
      // trailing block that the loader needs to see the program end.
      cassetteEncoder.sendSilence(200);
      cassetteEncoder.sendLeader();                       // ~20s initial leader
      // Verified block format (genuine TEST210, a program spanning blocks):
      //   block 0        = image[0..256]                         (257 bytes)
      //   block N (N>=1)  = [seq=N] + image[257+(N-1)*256 .. +255] (1+256)
      // plus one TRAILING block after the data.  Interrupts stay OFF for the
      // whole send (set once, above); the per-block external-RAM read below runs
      // inside that noInterrupts region during the block gap, so it never toggles
      // interrupts and never runs between data cells.
      for (uint16_t blk = 0; blk < nBlocks; blk++) {
        if (blk > 0) {
          // Inter-block gap: ~185 ms silence then a ~3944-cell re-sync leader.
          cassetteEncoder.sendSilence(185);
          const uint16_t COMX_LEAD_INTER_TOTAL = 3944;
          for (uint16_t i = 0; i < COMX_LEAD_INTER_TOTAL; i++) cassetteEncoder.pulseBit(0);
        }
        uint32_t imgLenLocal = txEnd - txStart + 1;
        uint32_t base;
        uint16_t nData;
        if (blk == 0) { base = 0;                              nData = 257; }
        else          { base = 257 + (uint32_t)(blk - 1) * 256; nData = 256; }

        if (blk != 0) cassetteEncoder.sendByte((uint8_t)blk);  // sequence byte N

        // The FIRST external-RAM read after the leader/gap returns garbage (the
        // address low byte) inside noInterrupts().  Do one throwaway read to
        // absorb that, so the real reads below are clean.  Byte 0 additionally
        // comes from the interrupts-on pre-read cache as belt-and-suspenders.
        (void)ram.readByte(txStart + base);                    // warm-up (discarded)

        for (uint16_t i = 0; i < nData; i++) {
          uint8_t b;
          if (i == 0 && blk < COMX_MAX_BLOCKS) {
            b = comxFirstByte[blk];              // pre-read cache (interrupts-on)
          } else {
            uint32_t off = base + i;
            b = (off < imgLenLocal) ? ram.readByte(txStart + off) : 0x00;
          }
          cassetteEncoder.sendByte(b);
        }
      }
      }
    }
    cassetteEncoder.sendTrailer();
    interrupts();
    if (SERIALDEBUG) {
      // Build-verification banner: if you do NOT see this line after a reflash,
      // the IDE did not recompile the updated firmware (stale build).
      Serial.print(F("COMX send done. timing-cal v3 overhead="));
      Serial.print(ENC_CAL_OVERHEAD_US);
      Serial.print(F("us/half"));
      Serial.print(F("  bit0=")); Serial.print(p->bit0);
      Serial.print(F("us bit1=")); Serial.println(p->bit1);
    }
  }

  saveLastMode();
  if (SERIALDEBUG) {
    Serial.println(F(" "));
    Serial.println(F("Transfer complete."));
  }
  tft.fillScreen(BLACK);
  centerText(tft, "Transfer complete", 10, 0, BLUE, YELLOW, 2);
  delay(1000);
}
void showScreenSaver(int hangTime) {
  tft.fillScreen(BLACK);
  tft.drawBitmap(0, 0, cosmac, 240, 320, FOREGROUND);
  /*Special messaging*/
  centerText(tft, MESSAGE5, 245, 0, BLUE, BLACK, 2);
  centerText(tft, MESSAGE6, 265, 0, BLUE, BLACK, 2);

  if (hangTime > 0) delay(hangTime);
}

void activateScreenSaver() {
  screensaverActive = true;
  tft.fillScreen(BLACK);  // Clear the screen
  if (SERIALDEBUG) { Serial.println(F("Screen saver activated")); }
}

void deactivateScreenSaver() {
  screensaverActive = false;
  tft.fillScreen(BLACK);        // Clear the screensaver content
  lastActivityTime = millis();  // Reset activity timer
  if (SERIALDEBUG) { Serial.println(F("Screen saver de-activated")); }
}

void ResetMode(int full) {
  saveFilename[FILENAME_SIZE] = "";
  saveFilenameLength = 0;
  if (full == 1) {
    currentName = "";
    currentPath = "/";
    currentIndex = 0;
  }
  currentFile = "";
  actionFlag = 0;
  keyboardEntry = 0;
}

void loop() {

  unsigned long currentTime = millis();
  // Check for inactivity
  if (!screensaverActive && (currentTime - lastActivityTime >= INACTIVITY_THRESHOLD)) {
    activateScreenSaver();
    showScreenSaver(0);
  } else {
    /* Check button press*/
    if (debounceButton(0)) {
      pressed = "Up";
    } else if (debounceButton(1)) {
      pressed = "Down";
    } else if (debounceButton(2)) {
      pressed = "Yes";
      if (currentFile != "" && actionFlag == 1) {
        pressed = "Play";
      }
    } else if (debounceButton(3)) {
      pressed = "No";
    } else {
      pressed = "*";
    }

    if (SERIALDEBUG) {
      if (pressed != "*") { Serial.print(F("Button ")); Serial.println(pressed); }
    }

    TSPoint pc = ts.getPoint();
    // Restore pin states (shared pins with TFT)
    pinMode(YP, OUTPUT);
    pinMode(XM, OUTPUT);
    if (pc.z > MINPRESSURE && pc.z < MAXPRESSURE) {
      touched = 1;
    } else {
      touched = 0;
    }
    if (touched == 1 || pressed != "*") {
      if (screensaverActive) {
        deactivateScreenSaver();
        displayFiles(1);
      } else {
        lastActivityTime = millis();  // Reset activity timer
        // Map touch coordinates to screen coordinates
        int16_t x = map(pc.x, TS_MINX, TS_MAXX, 0, tft.width());
        int16_t y = map(pc.y, TS_MINY, TS_MAXY, 0, tft.height());
        numAreas = numValidButtons[actionFlag];
        for (int i = 0; i < numAreas; i++) {
          if (x >= screenButtons[actionFlag][i].xMin && x <= screenButtons[actionFlag][i].xMax && y >= screenButtons[actionFlag][i].yMin && y <= screenButtons[actionFlag][i].yMax) {
            Serial.println(screenButtons[actionFlag][i].name);
            pressed = screenButtons[actionFlag][i].name;
            if (pressed == "Play" && actionFlag == 0) { pressed = "Record"; }
            break;
          }
        }
        if (SERIALDEBUG) {
          Serial.print(F("Button: ")); Serial.println(pressed);
          Serial.print(F("Touched: ")); Serial.println(touched);
        }

        if (keyboardEntry == 1) {
          for (int row = 0; row < 7; row++) {
            for (int col = 0; col < 6; col++) {
              int xk = BUTTON_START_X + col * (BUTTON_WIDTH + BUTTON_SPACING);
              int yk = BUTTON_START_Y + row * (BUTTON_HEIGHT + BUTTON_SPACING);
              if (x >= xk && x <= xk + BUTTON_WIDTH && y >= yk && y <= yk + BUTTON_HEIGHT) {
                char key = keys[row][col];
                if (SERIALDEBUG) { Serial.println(String("Character : " + key)); }

                if (key == '*') {
                  if (saveFilenameLength == 0) {
                    currentFile = getUniqueFileName();
                  } else {
                    currentFile = currentPath + saveFilename + ".BIN";
                  }
                  keyboardEntry = 2;
                  actionFlag = 2;
                  displayFileToSaveInfo();
                  drawButtons();
                  if (SERIALDEBUG) {
                    Serial.print(F("saveFilename entered: "));
                    Serial.println(currentFile);
                  }
                  saveFilename[0] = '\0';
                  saveFilenameLength = 0;
                } else if (key == '@') {
                  if (saveFilenameLength > 0 || saveFilenameLength == 0) {
                    saveFilenameLength--;
                    saveFilename[saveFilenameLength] = '\0';
                    if (saveFilenameLength < 0) {
                      saveFilename[0] = '\0';
                      saveFilenameLength = 0;
                    }
                    updatesaveFilenameDisplay();
                  }
                }

                else if (saveFilenameLength == (FILENAME_SIZE - 1) || saveFilenameLength > (FILENAME_SIZE - 1)) {
                  continue;
                }

                else if (saveFilenameLength < (FILENAME_SIZE - 1)) {  // Add character if not at limit
                  saveFilename[saveFilenameLength++] = key;
                  saveFilename[saveFilenameLength] = '\0';
                  updatesaveFilenameDisplay();
                }
                lastActivityTime = millis();  // Initialize activity time
                delay(200);  // Debounce
              }
            }
          }
        } else {
          /* Play */
          if (pressed == "Play" && currentFile != "" && actionFlag == 1) {
            getFile(startAddr, endAddr, fileSize, fileExt);
            displayInfo(startAddr, endAddr, fileSize, fileExt);
            actionFlag = 2;
            drawButtons();
          }
          /* Record */
          else if (pressed == "Record" && currentFile == "" && actionFlag == 0 && keyboardEntry == 0) {
            keyboardEntry = 1;
            if (SERIALDEBUG) { Serial.println(F("Keyboard Entry")); }
            tft.fillScreen(BLACK);
            drawKeyboard();
          }
          /* Up */
          else if (pressed == "Up") {
            if (SERIALDEBUG) { Serial.println(F("Up")); }
            if (fileList[currentIndex] == "..") {
              navigateToSelection(1);
            } else {
              moveSelection(-1);
            }
          }
          /* Down */
          else if (pressed == "Down") {
            moveSelection(1);
            if (SERIALDEBUG) { Serial.println(F("Down")); }
          }

          /* Previous page */
          else if (pressed == "Prev") {
            if (SERIALDEBUG) { Serial.println(F("Prev page")); }
            if (fileList[currentIndex] == "..") {
              navigateToSelection(1);
            } else {
              moveSelection(-ITEMS_PER_PAGE);
            }
          }
          /* Next page */
          else if (pressed == "Next") {
            if (SERIALDEBUG) { Serial.println(F("Next page")); }
            moveSelection(ITEMS_PER_PAGE);
          }
          /* No option*/
          else if (pressed == "No") {
            if (SERIALDEBUG) {
              Serial.println(currentFile);
              Serial.println(F("No"));
            }
            ResetMode(0);
            loadDirectory(currentPath);
            displayFiles(1);
          }
          /* Yes option*/
          else if (pressed == "Yes") {
            if (SERIALDEBUG) {
              Serial.println(currentFile);
              Serial.println(F("Yes"));
            }
            if (keyboardEntry == 2) {
              if (SERIALDEBUG) { Serial.println(currentFile); }
              tft.fillScreen(BACKGROUND);
              centerText(tft, "Reading....", 10, 0, BLUE, CYAN, 2);
              centerText(tft, "Please wait", 50, 0, BLUE, CYAN, 2);
              ReadData();
              ResetMode(0);
              keyboardEntry = 0;
              actionFlag = 0;
              loadDirectory(currentPath);
              displayFiles(1);
            } else if (currentFile != "") {
              if (currentFile.endsWith(".TAP") || currentFile.endsWith(".tap")) {
                // ORAO tape image: re-modulate the tape stream straight to the
                // ORAO, reproducing the original tape (any block layout).
                streamOraoTap();
              } else {
                SendData();
              }
              keyboardEntry = 0;
              actionFlag = 0;
              ResetMode(0);
              loadDirectory(currentPath);
              displayFiles(1);
            } else {
              if (fileList[currentIndex] == ".." || fileList[currentIndex].endsWith("/")) {
                navigateToSelection(1);
              } else {
                currentFile = currentPath + fileList[currentIndex];
                currentName = fileList[currentIndex];
                actionFlag = 1;
                navigateToSelection(1);
              }
            }
          } else if (pressed == "Type") {
            nextProtocol();
            const CassetteParams *p = cassetteDecoder.getParams();
            if (p) {
              positionText(tft, p->name, 42, 10, 12, WHITE, BLUE, TEXTSIZE);
              if (SERIALDEBUG) { Serial.println(p->name); }
            }
          }

          /* Select item */
          else if (y > Y_OFFSET && y < (Y_OFFSET + CHAR_HEIGHT * ITEMS_PER_PAGE)) {
            int selectedItem = ((y - Y_OFFSET) / CHAR_HEIGHT) + displayStart;
            if (selectedItem >= 0 && selectedItem < fileCount) {
              currentIndex = selectedItem;
              if (fileList[currentIndex] == "" || fileList[currentIndex] == ".." || fileList[currentIndex].endsWith("/")) {
                currentFile = "";
                currentName = "";
                actionFlag = 0;
              } else {
                currentFile = currentPath + fileList[currentIndex];
                currentName = fileList[currentIndex];
                actionFlag = 1;
              }
              navigateToSelection(1);
              if (SERIALDEBUG) {
                Serial.print(F("Selected : ")); Serial.println(currentFile);
                Serial.println(pressed);
              }
            }
          }
          delay(200); /* Debounce delay*/
        }
      }
    }
  }
}
