#ifndef CASSETTE_ENCODER_H
#define CASSETTE_ENCODER_H

#include <Arduino.h>
#include "CassetteParams.h"

// ---------------------------------------------------------------------------
// Output timing calibration
// ---------------------------------------------------------------------------
// On this board, each emitted half-cycle runs LONGER than the requested
// delayMicroseconds() value by a roughly fixed amount -- the per-half overhead
// of the writeHigh()/writeLow() calls and loop.  Measured on a real unit with
// the COMX-35 self-check (identity calibration): requesting 250us/610us halves
// produced 279us/641us actual, i.e. a fixed ~27us per-half overhead with a
// scale of ~1.0.  So the correction is simply to SUBTRACT that overhead from
// each half-period delay:
//
//     requested_delay = target_half - ENC_CAL_OVERHEAD_US
//
// This is the single timing tuning knob.  Use the COMX timing self-check (runs
// at boot with SERIALDEBUG on): if bit0 still reads > 500us, raise this; if
// < 500us, lower it.  Each 1us here changes the full cell by ~2us.  Set to 0
// for no correction (raw delayMicroseconds).
#ifndef ENC_CAL_OVERHEAD_US
#define ENC_CAL_OVERHEAD_US 10
#endif

// ---------------------------------------------------------------------------
// Software amplitude/energy reduction (single pulse per half-cycle)
// ---------------------------------------------------------------------------
// A plain Mega digital pin (e.g. A9) can only output 0V or 5V -- it cannot make
// a lower PEAK voltage.  (Lowering the actual peak needs a resistor divider on
// the wire; firmware can't do it.)  What this DOES control is how much of each
// half-cycle the pin is driven, i.e. the pulse WIDTH / average energy, while
// keeping exactly ONE clean edge per half-cycle so the tone FREQUENCY stays
// correct.
//
// ENC_PWM_DUTY_PCT = percent of each half-cycle the pin is driven active.
//   100 = solid (original full-width square wave)
//    50 = active for half of each half-cycle, idle the rest (clean edges,
//         observed to give a clean leader on real hardware)
//   low values (e.g. 12) make a very NARROW pulse -- "mostly off" -- which can
//   be too thin for the input to track.  Higher = wider/stronger pulse.
//
// This does NOT change the 5V peak.  If the input saturates on peak regardless
// of width, a resistor divider on the output wire is required; see
// COMX35_STATUS.md.  ENC_PWM_ENABLE 0 = solid full-width 5V (original).
// NOTE: applies to COMX only (gated in sendBit); other protocols are unaffected.
#ifndef ENC_PWM_ENABLE
#define ENC_PWM_ENABLE   0         // 1 = single-pulse width control; 0 = solid full-width
#endif
#ifndef ENC_PWM_DUTY_PCT
#define ENC_PWM_DUTY_PCT 100        // percent of each half-cycle driven active (1..100)
#endif
// Edge-rate shaping: synthesise a soft rising/falling edge over this many us so
// an AC-coupled input sees a smaller spike (0 = hard edges, off).  Try 20-40 if
// the input saturates on the fast 5V edge even with the pot.  Test polarity
// FIRST with this at 0 to isolate one variable at a time.
#ifndef ENC_EDGE_RAMP_US
#define ENC_EDGE_RAMP_US 0
#endif

// ---- Encoder error reporting ----
enum EncodeError {
    ENCODE_OK = 0,
    ENCODE_ERR_NO_PARAMS,
    ENCODE_ERR_INVALID_PARAMS,
    ENCODE_ERR_ABORTED,
    ENCODE_ERR_UNKNOWN
};

class CassetteEncoder {
public:
    explicit CassetteEncoder(uint8_t outPin);

    void begin();
    void configure(const CassetteParams* p);
    void setParams(const CassetteParams* p);
    void reset();

    // Async-serial send path (unchanged for FRAMING_ASYNC entries).
    // For FRAMING_BLOCK_ORAO entries, sendByte() emits 8 raw data bits with
    // no start/parity/stop bits.  In ORAO mode you typically don't call
    // sendByte() / sendLeader() / sendTrailer() directly -- use sendOraoFile()
    // below, which handles per-block leaders and 256-byte block assembly.
    void sendLeader();
    void sendByte(uint8_t b);
    void sendTrailer();

    // ---- ORAO block-mode send (only valid when params->framing == FRAMING_BLOCK_ORAO)
    //
    // Sends a complete ORAO file as one or more 256-byte blocks, each preceded
    // by its own leader.  The byte source is a callback so the encoder stays
    // decoupled from RAM/SD/whatever the caller is reading from.
    //
    //   filename       : up to 10 ASCII chars, space-padded; nullptr -> all spaces.
    //   totalDataBytes : number of bytes the reader callback will be asked to
    //                    return (NOT counting address bytes or EOF marker).
    //                    For BASIC mode this is the source size; for OBJECT mode
    //                    this is the program size (endAddr - loadAddr + 1).
    //   loadAddr,
    //   endAddr        : used only when oraoType == ORAO_TYPE_OBJECT, written
    //                    into the first 4 payload bytes of the first block.
    //   reader, ctx    : reader(srcIndex, ctx) is called with srcIndex = 0..N-1
    //                    where N == totalDataBytes; the byte returned is sent
    //                    next on tape.
    //
    typedef uint8_t (*OraoByteReader)(uint32_t srcIndex, void* ctx);

    void sendOraoFile(const char* filename,
                      uint32_t totalDataBytes,
                      uint16_t loadAddr,
                      uint16_t endAddr,
                      OraoByteReader reader,
                      void* readerCtx);

    // CMS compatibility (used for UI test pulse)
    void pulseBit(uint8_t bit) { sendBit(bit); }

    // Hold the output idle (no transitions = silence to the audio input) for
    // `ms` milliseconds.  The genuine COMX tape has ~180ms of silence before
    // each inter-block leader; the machine uses it to detect the block boundary
    // and reset byte framing.  Emitting it is required for multi-block loads.
    void sendSilence(uint16_t ms);

    // Error handling
    EncodeError lastError() const { return _lastError; }
    bool hasError() const { return _lastError != ENCODE_OK; }
    void clearError() { _lastError = ENCODE_OK; }
    void abort() { _lastError = ENCODE_ERR_ABORTED; }

private:
    void sendBit(uint8_t bit);
    void sendByteRaw(uint8_t b);   // 8 raw data bits, no framing (used by ORAO)
    void writeHigh();
    void writeLow();
    void holdHigh(uint16_t us);   // high phase: software-PWM (reduced amplitude) or solid

    uint8_t _pin;
    const CassetteParams* _p = nullptr;

    // Raw port output register + bit mask for _pin, resolved in the constructor.
    // Used by holdHigh() for fast direct-register toggling when software-PWM
    // amplitude reduction is enabled.
    volatile uint8_t* _portReg = nullptr;
    uint8_t _portBit = 0;

    uint16_t _half0_us = 0;
    uint16_t _half1_us = 0;

    EncodeError _lastError = ENCODE_OK;
};

#endif
