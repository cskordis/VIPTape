/////////////////////////////////////////////////////////////////
/*             Costas Skordis July 2025                        */
/*                                                             */
/*          Configure your screen settings here                */
/*    Modify lines appropriate to your device                  */
/*                                                             */
/*                                                             */
/////////////////////////////////////////////////////////////////

#define TITLE           "VIPTAPE"             // Title
#define VERSION         "CMS v0.1"            // Version 
#define SCREENDEBUG     0                     // Debug message enabled/disabled
#define DISPLAY_SPLASH  1                     // Splash screen 0 - disabled, 1 - enabled
#define DISPLAY_TITLE   1                     // Splash screen 0 - disabled, 1 - enabled
#define SERIAL_BAUD     9600
#define SERIALDEBUG     1                     // Serial enabled/disabled
#define ORIENTATION     0                     // Portrait
#define NAVICON         1                     // Display navigation symbols, Disabled - 0, Buttons - 1
#define SD_CS           10                    // SD card chip select pin

#define BASEFILE        "FILE"                // Default base name for unspecified file


/* Ram SPI */
#define ramCS   27
#define ramMISO 26
#define ramCLK  25
#define ramMOSI 24

#define tapeOut A9
#define tapeIn  A8

#define AP  LOW
#define NAP HIGH

/* Ram Test*/
#define RAM      1
#define RAMTEST  2                            // 0 - Disabled, 1 - Enabled, 2 - Enabled with status
#define RAMSTART 0

/* Touchscreen pins (adjust based on your shield) */
#define XP 8
#define YP A3
#define XM A2
#define YM 9

/* Touch screen calibrated co-ordinates - adjust accordingly after running calibration */
#define TS_MINX 933
#define TS_MAXX 90
#define TS_MINY 72
#define TS_MAXY 919

#define MINPRESSURE 2
#define MAXPRESSURE 1000

#define TEXTSIZE    2
#define TEXTSIZE1   1
#define TEXTSIZE2   2
#define TEXTSIZE3   3

#define MAX_ARRAY     128
#define MAX_FILECOUNT 128

#define TEXT_SIZE       2
#define TOP_DISP        30
#define ITEMS_PER_PAGE  12
#define CHAR_HEIGHT     (8 * TEXT_SIZE + 2)
#define CHAR_WIDTH      8
#define Y_OFFSET        50    

#define INACTIVITY_THRESHOLD 300000  // 5 minutes in milliseconds

/* Assign human-readable names to some common 16-bit color values: */
#define BLACK         0x0000
#define BLUE          0x001F
#define RED           0xF800
#define GREEN         0x07E0
#define CYAN          0x07FF
#define MAGENTA       0xF81F
#define YELLOW        0xFFE0
#define WHITE         0xFFFF
#define GRAY          0x8410
#define NAVY          0x0080
#define DARKBLUE      0x008B
#define MEDIUMBLUE    0x00CD
#define DARKGREEN     0x6400
#define TEAL          0x8080
#define DARKCYAN      0x8B8B
#define DEEPSKYBLUE   0xBFFF
#define DARKTURQUOISE 0xCED1

#define BACKGROUND BLUE                  // Background color
#define FOREGROUND WHITE                 // Foreground color
#define DIRECTORY  WHITE                 // Directory text color
#define HILIGHT    YELLOW                // Highlight text color 
#define ALERT      RED                   // Alert color


/* Physical buttons */
#define BUTTONS      4 
#define BUTTON_NO    22
#define BUTTON_YES   30
#define BUTTON_DOWN  36
#define BUTTON_UP    44

/* Keyboard Button dimensions and spacing */
#define BUTTON_WIDTH  35
#define BUTTON_HEIGHT 30
#define BUTTON_SPACING 2
#define BUTTON_START_X 10
#define BUTTON_START_Y 55



