
#ifndef Utility_H
#define Utility_H

#include <MCUFRIEND_kbv.h>
#include <string.h>

/* Function to center text with padding */
void centerText(MCUFRIEND_kbv &tft, char* text, int y, int padding, uint16_t textColor, uint16_t bgColor, uint8_t textSize) {

  if (!textSize) {textSize=1;} 
  int cw = 6 * textSize;          /* character width in pixels */
  int textLength = strlen(text) ; /* text length*/
  int width;
  if (tft.getRotation()==0||tft.getRotation()==2) {width = tft.width() / cw;}
  else {width= tft.height() / cw;}
 
  if (padding==0){
    padding = (width - textLength) / 2;
  }
  String padded = "";
  String repeatedString = " ";

  for (int i = 0; i < padding; i++) {
    padded += repeatedString; 
  }
  
  String paddedText = padded + text + padded;
  if ((width - textLength) % 2 == 1) {paddedText += " ";} /* If totalLength is odd, adjust padding to ensure exact length*/
  tft.setTextSize(textSize);
  tft.setTextColor(textColor, bgColor);
  tft.setCursor(0, y);
  tft.print(paddedText);
}
#endif