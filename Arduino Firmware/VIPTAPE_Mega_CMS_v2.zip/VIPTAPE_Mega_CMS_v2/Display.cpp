#include "Display.h"

// Define the global TFT object here (only once)
MCUFRIEND_kbv tft = MCUFRIEND_kbv();
