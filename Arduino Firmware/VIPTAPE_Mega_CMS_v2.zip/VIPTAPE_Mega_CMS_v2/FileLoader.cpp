#include "FileLoader.h"

FileLoader::FileLoader(RamExternal &ram)
  : _ram(ram) {}

FileType FileLoader::detectFileType(File &file) {
  file.seek(0);
  bool hasColonStart = false;
  bool allHexAscii = true;
  uint8_t buf[256];
  int bytesRead = file.read(buf, sizeof(buf));
  for (int i = 0; i < bytesRead; i++) {
    uint8_t c = buf[i];
    if (c == ':' && (i == 0 || buf[i - 1] == '\n')) hasColonStart = true;
    if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f') || c == '\n' || c == '\r' || c == ' ')) allHexAscii = false;
  }
  file.seek(0);
  if (hasColonStart) return FILE_INTEL_HEX;
  if (allHexAscii) return FILE_ASCII_HEX;
  return FILE_BINARY;
}

bool FileLoader::verifyIntelHexLine(String &line) {
  if (line.length() < 11 || line.charAt(0) != ':') return false;
  uint8_t byteCount = strtoul(line.substring(1, 3).c_str(), nullptr, 16);
  uint16_t address = strtoul(line.substring(3, 7).c_str(), nullptr, 16);
  uint8_t recordType = strtoul(line.substring(7, 9).c_str(), nullptr, 16);

  uint8_t sum = byteCount + ((address >> 8) & 0xFF) + (address & 0xFF) + recordType;
  for (uint8_t i = 0; i < byteCount; i++) {
    uint8_t val = strtoul(line.substring(9 + i * 2, 11 + i * 2).c_str(), nullptr, 16);
    sum += val;
  }

  uint8_t checksum = strtoul(line.substring(9 + byteCount * 2, 11 + byteCount * 2).c_str(), nullptr, 16);
  return ((sum + checksum) & 0xFF) == 0;
}

// ------------------ Load Functions --------------------

void FileLoader::loadIntelHex(File &file, uint16_t &startAddr, uint16_t &endAddr) {
  startAddr = 0xFFFF;
  endAddr = 0;
  file.seek(0);
  String line;
  uint32_t fileSize = file.size();
  uint32_t processed = 0;
  while (file.available()) {
    char c = file.read();
    processed++;
    if (c == '\r') continue;
    if (c == '\n') {
      if (line.length() > 0) {
        if (!verifyIntelHexLine(line)) {
          Serial.println("Invalid Intel HEX line: " + line);
          line = "";
          continue;
        }
        uint8_t byteCount = strtoul(line.substring(1, 3).c_str(), nullptr, 16);
        uint16_t address = strtoul(line.substring(3, 7).c_str(), nullptr, 16);
        uint8_t recordType = strtoul(line.substring(7, 9).c_str(), nullptr, 16);

        if (recordType == 0x00) {  // Data record
          for (uint8_t i = 0; i < byteCount; i++) {
            uint8_t val = strtoul(line.substring(9 + i * 2, 11 + i * 2).c_str(), nullptr, 16);
            _ram.writeByte(address + i, val);
            if (address + i < startAddr) startAddr = address + i;
            if (address + i > endAddr) endAddr = address + i;
          }
        }
        line = "";
      }
    } else line += c;
  }
}

void FileLoader::loadAsciiHex(File &file, uint16_t &startAddr, uint16_t &endAddr)
{
    startAddr = 0xFFFF;
    endAddr = 0;

    file.seek(0);

    uint16_t addr = 0;
    int hiNibble = -1;

    while (file.available()) {
        int c = file.read();
        int val;
        if (c >= '0' && c <= '9') val = c - '0';
        else if (c >= 'A' && c <= 'F') val = c - ('A' - 10);
        else if (c >= 'a' && c <= 'f') val = c - ('a' - 10);
        else
            continue;   // skip non-hex characters
        if (hiNibble < 0) {
            // save first nibble
            hiNibble = val;
        } else {
            // form full byte
            uint8_t byteVal = (hiNibble << 4) | val;
            hiNibble = -1;
            _ram.writeByte(addr, byteVal);
            if (addr < startAddr) startAddr = addr;
            if (addr > endAddr)   endAddr   = addr;
            addr++;
        }
    }

    // If file ended on a half-byte, ignore the last nibble
}

void FileLoader::loadBinary(File &file, uint16_t &startAddr, uint16_t &endAddr) {
  startAddr = 0;
  file.seek(0);
  uint32_t fileSize = file.size();
  uint32_t processed = 0;
  for (uint16_t addr = 0; file.available(); addr++) {
    uint8_t val = file.read();
    _ram.writeByte(addr, val);
    processed++;
   }
  endAddr = processed - 1;
}

// ------------------ Master Load Function --------------------

void FileLoader::loadFile(File &file, uint16_t &startAddr, uint16_t &endAddr,unsigned long &fileSize,String &fileType) {
  
  fileSize = file.size();
  FileType type = detectFileType(file);
  if (type == FILE_ASCII_HEX) {fileType="A";loadAsciiHex(file, startAddr, endAddr);}
  else if (type == FILE_BINARY) {fileType="B";loadBinary(file, startAddr, endAddr);}
  else if (type == FILE_INTEL_HEX) {fileType="H";loadIntelHex(file, startAddr, endAddr);}
  else {fileType="U";}
}
