#include "FileAnalyzer.h"

// Helpers
void FileAnalyzer::trimTrailing(String& s) {
  while (s.length() > 0) {
    char last = s.charAt(s.length() - 1);
    if (last == '\r' || last == '\n' || last == ' ' || last == '\t') {
      s = s.substring(0, s.length() - 1);
    } else {
      break;
    }
  }
}

bool FileAnalyzer::isValidHex(const String& hexStr) {
  for (int i = 0; i < hexStr.length(); i++) {
    char c = hexStr.charAt(i);
    if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f'))) return false;
  }
  return true;
}

uint8_t FileAnalyzer::hexToByte(const String& hexStr) {
  return (uint8_t)strtol(hexStr.c_str(), NULL, 16);
}

// analyzeFileStreaming
FileAnalysis FileAnalyzer::analyzeFileStreaming(File& file) {
  FileAnalysis result = {"Unknown", 0, 0, 0, 0};
  
  file.seek(0);
  int firstByte = file.peek();
  bool possibleIntelHex = (firstByte == ':');
  
  if (possibleIntelHex) {
    FileAnalysis hexResult = parseIntelHexAnalysis(file);
    if (hexResult.format == "Intel Hex") return hexResult;
  }
  
  file.seek(0);
  FileAnalysis asciiResult = parseAsciiHexStreaming(file);
  if (asciiResult.format == "ASCII Hex") return asciiResult;
  
  result.dataLength = file.size();
  result.format = "Binary";
  result.numPages = result.dataLength / 256;
  result.startAddr = 0;
  result.endAddr = result.dataLength - 1;
  return result;
}

// extractData
size_t FileAnalyzer::extractData(File& file, uint8_t* buffer, size_t bufferSize) {
  if (bufferSize == UINT_MAX) bufferSize = 65536;  // Default cap

  FileAnalysis analysis = analyzeFileStreaming(file);
  if (analysis.format == "Unknown") return 0;
  
  // Clear buffer if provided
  if (buffer && bufferSize > 0) {
    memset(buffer, 0xFF, bufferSize);
  }
  
  Serial.print("Format: "); Serial.println(analysis.format);
  
  size_t filled = 0;
  file.seek(0);
  if (analysis.format == "Intel Hex") {
    uint32_t minAddr = 0, maxAddr = 0;
    filled = parseIntelHexExtraction(file, buffer, bufferSize, minAddr, maxAddr);
    analysis.startAddr = minAddr;
    analysis.endAddr = maxAddr;
  } else if (analysis.format == "ASCII Hex") {
    filled = extractAsciiHexData(file, buffer, bufferSize);
  } else if (analysis.format == "Binary") {
    filled = extractBinaryData(file, buffer, bufferSize);
  }
  Serial.println("extractData filled bytes: " + String(filled));
  return filled;
}

// parseIntelHexAnalysis (analysis)
FileAnalysis FileAnalyzer::parseIntelHexAnalysis(File& file) {
  uint32_t minAddr = UINT32_MAX;
  uint32_t maxAddr = 0;
  size_t hexDataLen = 0;
  uint32_t currentBaseAddr = 0;
  uint32_t currentExpectedAddr = 0;
  bool eofFound = false;
  bool isValid = true;
  bool firstData = true;
  
  char lineBuffer[BUFFER_SIZE + 1];
  int lineLen = 0;
  while (!eofFound && isValid && file.available()) {
    int c = file.read();
    if (c == -1) break;
    
    if (c == '\n' || c == '\r') {
      if (lineLen > 0) {
        lineBuffer[lineLen] = '\0';
        String line(lineBuffer);
        trimTrailing(line);
        
        if (line.length() > 0 && line.charAt(0) == ':') {
          if (!parseIntelHexRecord(line, hexDataLen, minAddr, maxAddr, currentBaseAddr, eofFound, currentExpectedAddr, firstData, nullptr, 0, hexDataLen)) {  // Pass null buffer for analysis
            isValid = false;
          }
        }
        lineLen = 0;
      }
      if (c == '\r' && file.peek() == '\n') {
        file.read();
      }
    } else if (c != ' ' && c != '\t') {
      if (lineLen < BUFFER_SIZE) {
        lineBuffer[lineLen++] = (char)c;
      } else {
        isValid = false;
        break;
      }
    }
  }
  
  if (lineLen > 0) {
    lineBuffer[lineLen] = '\0';
    String line(lineBuffer);
    trimTrailing(line);
    if (line.length() > 0 && line.charAt(0) == ':') {
      parseIntelHexRecord(line, hexDataLen, minAddr, maxAddr, currentBaseAddr, eofFound, currentExpectedAddr, firstData, nullptr, 0, hexDataLen);
    }
  }
  
  if (isValid && hexDataLen > 0 && eofFound) {
    FileAnalysis result = {"Intel Hex", hexDataLen, hexDataLen / 256, (minAddr != UINT32_MAX) ? minAddr : 0, maxAddr};
    return result;
  }
  
  return {"Unknown", 0, 0, 0, 0};
}

// parseIntelHexExtraction (extraction to buffer)
size_t FileAnalyzer::parseIntelHexExtraction(File& file, uint8_t* buffer, size_t bufferSize, uint32_t& minAddr, uint32_t& maxAddr) {
  minAddr = UINT32_MAX;
  maxAddr = 0;
  size_t hexDataLen = 0;
  uint32_t currentBaseAddr = 0;
  uint32_t currentExpectedAddr = 0;
  bool eofFound = false;
  bool isValid = true;
  bool firstData = true;
  size_t bufferOffset = 0;
  
  char lineBuffer[BUFFER_SIZE + 1];
  int lineLen = 0;
  while (!eofFound && isValid && file.available()) {
    int c = file.read();
    if (c == -1) break;
    
    if (c == '\n' || c == '\r') {
      if (lineLen > 0) {
        lineBuffer[lineLen] = '\0';
        String line(lineBuffer);
        trimTrailing(line);
        
        if (line.length() > 0 && line.charAt(0) == ':') {
          if (!parseIntelHexRecord(line, hexDataLen, minAddr, maxAddr, currentBaseAddr, eofFound, currentExpectedAddr, firstData, buffer, bufferSize, bufferOffset)) {
            isValid = false;
          }
        }
        lineLen = 0;
      }
      if (c == '\r' && file.peek() == '\n') {
        file.read();
      }
    } else if (c != ' ' && c != '\t') {
      if (lineLen < BUFFER_SIZE) {
        lineBuffer[lineLen++] = (char)c;
      } else {
        isValid = false;
        break;
      }
    }
  }
  
  if (lineLen > 0) {
    lineBuffer[lineLen] = '\0';
    String line(lineBuffer);
    trimTrailing(line);
    if (line.length() > 0 && line.charAt(0) == ':') {
      parseIntelHexRecord(line, hexDataLen, minAddr, maxAddr, currentBaseAddr, eofFound, currentExpectedAddr, firstData, buffer, bufferSize, bufferOffset);
    }
  }
  
  Serial.println("EXTRACT SUMMARY: isValid=" + String(isValid ? "TRUE" : "FALSE") + 
                  ", total_bytes=" + String(hexDataLen) + 
                  ", eof=" + String(eofFound ? "TRUE" : "FALSE") + 
                  ", addr_range=0x" + String(minAddr, HEX) + "-0x" + String(maxAddr, HEX));
  if (!isValid) Serial.println("Likely cause: Bad hex chars, length, or checksum in your file.");

  
  if (isValid && hexDataLen > 0 && eofFound) {
    size_t paddedSize = (maxAddr - minAddr + 1UL > bufferSize) ? bufferSize : (maxAddr - minAddr + 1UL);
    return paddedSize;
  }
  
  return 0;
}

// parseIntelHexRecord (updated for buffer)
bool FileAnalyzer::parseIntelHexRecord(const String& record, size_t& hexDataLen, uint32_t& minAddr, uint32_t& maxAddr, uint32_t& currentBaseAddr, bool& eofFound, uint32_t& currentExpectedAddr, bool& firstData, uint8_t* buffer, size_t bufferSize, size_t& bufferOffset) {
  if (record.length() < 9 || (record.length() - 1) % 2 != 0) return false;
  
  String byteCountStr = record.substring(1, 3);
  if (!isValidHex(byteCountStr)) return false;
  uint8_t byteCount = hexToByte(byteCountStr);
  
  String addrStr = record.substring(3, 7);
  if (!isValidHex(addrStr)) return false;
  uint16_t addr = (hexToByte(addrStr.substring(0, 2)) << 8) | hexToByte(addrStr.substring(2, 4));
  
  String typeStr = record.substring(7, 9);
  if (!isValidHex(typeStr)) return false;
  uint8_t type = hexToByte(typeStr);
  
  int dataHexLen = byteCount * 2;
  if (record.length() < 9 + dataHexLen + 2) return false;
  
  String dataStr = record.substring(9, 9 + dataHexLen);
  if (!isValidHex(dataStr)) return false;
  
  String checksumStr = record.substring(9 + dataHexLen);
  if (!isValidHex(checksumStr)) return false;
  
  uint8_t sum = byteCount + (addr >> 8) + (addr & 0xFF) + type;
  for (int i = 0; i < dataHexLen; i += 2) {
    String byteStr = dataStr.substring(i, i + 2);
    sum += hexToByte(byteStr);
  }
  uint8_t checksum = hexToByte(checksumStr);
  sum += checksum;
  if (sum % 256 != 0) {
    Serial.println("*** CHECKSUM FAIL: Expected 0, got " + String(sum % 256) + " for line '" + record + "'");
    return false;
  }
  
  uint32_t fullAddr = currentBaseAddr + addr;
  if (type == 0) { // Data
    hexDataLen += byteCount;
    if (fullAddr < minAddr) minAddr = fullAddr;
    if (fullAddr + byteCount - 1 > maxAddr) maxAddr = fullAddr + byteCount - 1;
    
    if (firstData) {
      currentExpectedAddr = fullAddr;
      firstData = false;
    }
    
    // Gap fill (if buffer provided)
    if (buffer && bufferSize > 0) {
      uint32_t gapStart = currentExpectedAddr;
      uint32_t gapEnd = fullAddr - 1;
      if (gapStart <= gapEnd) {
        size_t gapBytes = gapEnd - gapStart + 1;
        size_t relGapStart = (gapStart - minAddr);  // Linear offset into buffer
        size_t gapBufferStart = relGapStart;
        if (gapBufferStart + gapBytes <= bufferSize) {
          memset(buffer + gapBufferStart, 0xFF, gapBytes);
          bufferOffset = max(bufferOffset, gapBufferStart + gapBytes);
        }
      }
    }
    
    // Copy data (if buffer provided)
    if (buffer && bufferSize > 0) {
      size_t relOffset = (fullAddr - minAddr);  // Linear offset into buffer
      if (relOffset + byteCount <= bufferSize) {
        for (int i = 0; i < byteCount; i++) {
          uint8_t byte = hexToByte(dataStr.substring(2 * i, 2 * i + 2));
          buffer[relOffset + i] = byte;
        }
        bufferOffset = max(bufferOffset, relOffset + byteCount);
      } else {
        // Buffer overflow - truncate
        size_t spaceLeft = bufferSize - relOffset;
        for (int i = 0; i < spaceLeft; i++) {
          uint8_t byte = hexToByte(dataStr.substring(2 * i, 2 * i + 2));
          buffer[relOffset + i] = byte;
        }
        bufferOffset = bufferSize;
        return false;  // Signal partial extraction
      }
    }
    
    currentExpectedAddr = fullAddr + byteCount;
  } else if (type == 1) { // EOF
    eofFound = true;
  } else if (type == 2 && byteCount == 2) { // Extended Segment Address
    uint16_t seg = (hexToByte(dataStr.substring(0, 2)) << 8) | hexToByte(dataStr.substring(2, 4));
    currentBaseAddr = (uint32_t)seg << 4;
  } else if (type == 4 && byteCount == 2) { // Extended Linear Address
    uint16_t upper = (hexToByte(dataStr.substring(0, 2)) << 8) | hexToByte(dataStr.substring(2, 4));
    currentBaseAddr = (uint32_t)upper << 16;
  } else if (type == 3 && byteCount == 4) { // Start Segment Address
    // Ignore
  } else if (type == 5 && byteCount == 4) { // Start Linear Address
    // Ignore
  }
  
  return true;
}

// extractAsciiHexData
size_t FileAnalyzer::extractAsciiHexData(File& file, uint8_t* buffer, size_t bufferSize) {
  file.seek(0);
  size_t filled = 0;
  String pair = "";
  uint8_t byte;
  while (file.available() && filled < bufferSize) {
    int c = file.read();
    if (c == -1) break;
    char ch = (char)c;
    if ((ch >= '0' && ch <= '9') || (ch >= 'A' && ch <= 'F') || (ch >= 'a' && ch <= 'f')) {
      pair += ch;
      if (pair.length() == 2) {
        byte = hexToByte(pair);
        if (buffer) buffer[filled] = byte;
        filled++;
        pair = "";
      }
    }
  }
  return filled;
}

// extractBinaryData
size_t FileAnalyzer::extractBinaryData(File& file, uint8_t* buffer, size_t bufferSize) {
  file.seek(0);
  size_t filled = 0;
  uint8_t tempBuf[256];
  while (file.available() && filled < bufferSize) {
    size_t chunk = file.read(tempBuf, min(256UL, bufferSize - filled));
    if (chunk == 0) break;
    if (buffer) {
      memcpy(buffer + filled, tempBuf, chunk);
    }
    filled += chunk;
  }
  return filled;
}

// parseAsciiHexStreaming
FileAnalysis FileAnalyzer::parseAsciiHexStreaming(File& file) {
  FileAnalysis result = {"Unknown", 0, 0, 0, 0};
  size_t hexCharCount = 0;
  bool isValid = true;
  
  file.seek(0);
  while (file.available() && isValid) {
    int c = file.read();
    if (c == -1) break;
    char ch = (char)c;
    if ((ch >= '0' && ch <= '9') || (ch >= 'A' && ch <= 'F') || (ch >= 'a' && ch <= 'f')) {
      hexCharCount++;
    } else if (ch != ' ' && ch != '\r' && ch != '\n' && ch != '\t') {
      isValid = false;
      break;
    }
  }
  
  if (isValid && (hexCharCount % 2 == 0) && hexCharCount > 0) {
    result.format = "ASCII Hex";
    result.dataLength = hexCharCount / 2;
    result.numPages = result.dataLength / 256;
    result.startAddr = 0;
    result.endAddr = result.dataLength - 1;
    return result;
  }
  
  return result;
}

// dumpFromBuffer (debug)
void FileAnalyzer::dumpFromBuffer(uint8_t* buffer, size_t len) {
  Serial.println("=== Buffer Dump ===");
  for (size_t i = 0; i < len; i += 16) {
    size_t chunk = min(16UL, len - i);
    Serial.print("0x"); Serial.print(i, HEX); Serial.print(": ");
    for (size_t j = 0; j < chunk; j++) {
      Serial.print("0x"); if (buffer[i + j] < 0x10) Serial.print("0");
      Serial.print(buffer[i + j], HEX); Serial.print(" ");
    }
    Serial.println();
  }
  Serial.println("=== End ===");
}