// v72 - force recompile
#pragma once
#include <Arduino.h>

enum BitOrder {
  MSB_FIRST,
  LSB_FIRST
};

enum ParityMode {
  PARITY_NONE,
  PARITY_ODD,
  PARITY_EVEN
};

enum PolarityMode {
  POLARITY_NEGATIVE,
  POLARITY_POSITIVE
};

// ---- Framing mode -------------------------------------------------------
//
// FRAMING_ASYNC      : classic UART-style framing (start bit / data / parity / stop bits).
//                      This is the original behaviour and the default for every
//                      existing protocol entry, since unspecified trailing fields
//                      in a brace-initialiser default to zero.
//
// FRAMING_BLOCK_ORAO : ORAO 6502 cassette framing.
//                      No byte-level framing at all -- bytes are 8 raw data bits
//                      back-to-back.  Framing is at the block level: a long leader
//                      precedes a 256-byte block of (4x $1B sync, 1 type byte,
//                      10-byte filename, 1 block-number byte, 240 byte payload).
//                      Multi-block files send the same filename in each block with
//                      an incrementing block number, each preceded by its own leader.
//
// FRAMING_SYNC_COMX  : COMX-35 (CDP1802) cassette framing.
//                      Bit-synchronous, NOT UART-async.  After the leader locks,
//                      data is read as fixed 10-cycle cells.  Within each cell:
//                        cell[0]   : lead framing cycle (value varies; ignored)
//                        cell[1..8]: 8 data bits, LSB-first
//                        cell[9]   : trail framing cycle (value varies; ignored)
//                      Phase is established once at the leader-to-data boundary
//                      and maintained by counting cells -- there is NO per-byte
//                      start-bit resync (the framing cycles are not fixed 1/0,
//                      so a start-bit hunt would mis-sync).  Verified against
//                      real COMX SAVE captures (Raider/Diver/CrossFire).
// FRAMING_ASYNC_KCS  : Kansas City Standard. Each logical bit is a BURST of
//                      multiple same-frequency cycles: '0' = bit0_cycle cycles
//                      of f0 (1200 Hz), '1' = bit1_cycle cycles of f1 (2400 Hz).
//                      Both bursts are the same wall-clock duration so they
//                      cannot be distinguished by period alone -- cycle counting
//                      is required.  Once a full burst is counted, the resulting
//                      logical bit feeds the same UART framing (start / 8 data
//                      LSB-first / stop) as FRAMING_ASYNC.
enum FramingMode {
  FRAMING_ASYNC      = 0,
  FRAMING_BLOCK_ORAO = 1,
  FRAMING_SYNC_COMX  = 2,
  FRAMING_ASYNC_KCS  = 3
};

// ---- ORAO block type byte ----------------------------------------------
//
// Only meaningful when framing == FRAMING_BLOCK_ORAO.  The byte is written into
// every block at offset 4 and tells the receiver how to interpret the payload.
//
//   ORAO_TYPE_BASIC  ('B') : payload is BASIC source as LIST would emit it,
//                            terminated by $1A (Ctrl-Z) and space-padded to 240.
//   ORAO_TYPE_OBJECT ('O') : the first 4 bytes of the FIRST block's payload are
//                            load_lo, load_hi, end_lo, end_hi.  The remaining
//                            payload bytes (across all blocks) are the program
//                            bytes from load_addr to end_addr inclusive,
//                            space-padded in the final block.
//
enum OraoType {
  ORAO_TYPE_NONE   = 0,
  ORAO_TYPE_BASIC  = 0x42,    // 'B'
  ORAO_TYPE_OBJECT = 0x4F     // 'O'
};


struct CassetteParams {
  const char* name;
  uint16_t bit0;
  uint16_t bit0_min;
  uint16_t bit0_max;

  uint16_t bit1;
  uint16_t bit1_min;
  uint16_t bit1_max;

  uint8_t  leaderBit;
  uint16_t leaderBits;
  uint16_t leaderTime;

  uint8_t  startBit;

  BitOrder   bitOrder;
  ParityMode parity;

  uint32_t interByteTimeout_us;

  uint8_t  stopBit;
  uint8_t  stopBits;

  uint8_t  trailerBit;
  uint16_t trailerTime;

  uint16_t bit0_cycle;
  uint16_t bit1_cycle;

  PolarityMode polarity;

  // ---- New fields (added at end so existing brace-initializers stay valid) ----
  // Existing entries default these to FRAMING_ASYNC / ORAO_TYPE_NONE via zero-init.
  FramingMode framing;
  OraoType    oraoType;
};

// ---- Note on the TRS-80 PC-1 -----------------------------------------------
//
// An earlier revision added a `dataBits` field here so the PC-1 could use a
// 4-bit frame.  That has been REVERTED, and deliberately: the PC-1's frame is
// an ordinary 8-data-bit UART frame (start 0, 8 data LSB-first, stop 1), which
// is what the CE-122 service manual documents.  What is special is only the
// PAYLOAD -- the machine uses just the low nibble and pads the high nibble
// with ones, so every byte on tape is 0xF0 | nibble.
//
// Both descriptions produce the IDENTICAL bit sequence on the wire:
//     8 data + 1 stop  ->  0 n0 n1 n2 n3  1 1 1 1  1     (10 cells)
//     4 data + 5 stop  ->  0 n0 n1 n2 n3  1 1 1 1 1      (10 cells)
// but only the first matches the documented framing, and it needs no change to
// this struct or to the encoder/decoder at all.  Confirmed on both captures:
// 38 of 39 frames read 0xFx with 8-bit framing (the one exception is a sampling
// artefact across the inter-record gap) and every stop bit is 1.
//
// The nibble packing therefore belongs in the PC-1 file path, not in the
// framing core: emit 0xF0 | high_nibble then 0xF0 | low_nibble per data byte.
