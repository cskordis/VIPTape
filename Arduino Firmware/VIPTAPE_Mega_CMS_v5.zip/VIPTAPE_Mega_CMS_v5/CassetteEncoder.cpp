#include "CassetteEncoder.h"

// Defensive fallbacks: if an out-of-date CassetteEncoder.h is present (e.g. a
// header/cpp version mismatch after copying files between sketch folders),
// supply safe defaults so the build can't fail on an undefined macro.  When the
// up-to-date header is used, its #ifndef-guarded values take precedence and
// these are skipped.
#ifndef ENC_PWM_ENABLE
#define ENC_PWM_ENABLE   0
#endif
#ifndef ENC_PWM_DUTY_PCT
#define ENC_PWM_DUTY_PCT 50
#endif
#ifndef ENC_CAL_OVERHEAD_US
#define ENC_CAL_OVERHEAD_US 10
#endif
#ifndef ENC_CAL_OVERHEAD_US_PC1
#define ENC_CAL_OVERHEAD_US_PC1 10
#endif
#ifndef ENC_EDGE_RAMP_US
#define ENC_EDGE_RAMP_US 0
#endif


CassetteEncoder::CassetteEncoder(uint8_t outPin)
: _pin(outPin)
{
    pinMode(_pin, OUTPUT);
    digitalWrite(_pin, LOW);
    // Resolve the raw port output register + bit mask for this pin so holdHigh()
    // can toggle it with direct register writes (~0.1us) instead of digitalWrite
    // (~4.5us).  Works for any pin, including analog pins used as digital out
    // (e.g. A9 = PK1 on the Mega 2560).
    _portReg = portOutputRegister(digitalPinToPort(_pin));
    _portBit = digitalPinToBitMask(_pin);
}

void CassetteEncoder::setParams(const CassetteParams* p) {
  _p = p;
}


void CassetteEncoder::configure(const CassetteParams* p)
{
    _p = p;
    _lastError = ENCODE_OK;

    if (!_p) {
        _lastError = ENCODE_ERR_NO_PARAMS;
        return;
    }

    _half0_us = p->bit0 / 2;
    _half1_us = p->bit1 / 2;

    if (_half0_us == 0 || _half1_us == 0 ||
        p->bit0_cycle == 0 || p->bit1_cycle == 0) {
        _lastError = ENCODE_ERR_INVALID_PARAMS;
    }
}

void CassetteEncoder::reset()
{
    digitalWrite(_pin, LOW);
    clearError();
}

void CassetteEncoder::sendLeader()
{
    if (_lastError != ENCODE_OK || !_p) return;

    if (_p->leaderBit == 0 || _p->leaderBit == 1) {
        // uint32_t counter: leaderTime can be large (COMX needs ~49000 cells
        // for its ~23s leader, near the uint16_t ceiling).  A uint16_t loop
        // counter could never exceed leaderTime if they were equal-width, so
        // widen the counter to be safe against future longer leaders.
        for (uint32_t i = 0; i < (uint32_t)_p->leaderTime; i++) {
            sendBit(_p->leaderBit);
        }
    }
}

void CassetteEncoder::sendByte(uint8_t b)
{
    if (_lastError != ENCODE_OK || !_p) return;

    // ORAO block framing: no start/parity/stop bits, just 8 raw data bits.
    if (_p->framing == FRAMING_BLOCK_ORAO) {
        sendByteRaw(b);
        return;
    }

    // COMX-35 bit-synchronous framing: each byte is a 10-cell frame --
    //   start cell (always 1) + 8 data bits (LSB-first) + 1 trailing framing
    //   cell.  On a real COMX the trailing cell's value is don't-care (the
    //   decoder ignores it); we emit a 0 so that, with the next frame's start
    //   cell (1), there is always a 1->0->1 transition the receiver can lock
    //   its per-frame resync onto.  No parity, no separate stop-bit loop.
    if (_p->framing == FRAMING_SYNC_COMX) {
        sendBit(1);                          // start cell
        for (uint8_t i = 0; i < 8; i++) {    // 8 data bits, LSB-first
            sendBit((b >> i) & 1);
        }
        sendBit(0);                          // trailing framing cell
        return;
    }

    uint8_t ones = 0;

    // Start bit
    if (_p->startBit == 0 || _p->startBit == 1) {
        sendBit(_p->startBit);
    }
    // Data bit
    if (_p->bitOrder == LSB_FIRST) {
        for (uint8_t i = 0; i < 8; i++) {
            uint8_t bit = (b >> i) & 1;
            if (bit) ones++;
            sendBit(bit);
        }
    } else {
        for (int8_t i = 7; i >= 0; i--) {
            uint8_t bit = (b >> i) & 1;
            if (bit) ones++;
            sendBit(bit);
        }
    }

    // Parity
    if (_p->parity != PARITY_NONE) {
        uint8_t parity = ones & 1;
        if (_p->parity == PARITY_ODD) {parity = !parity;}  // even = invert odd result
        sendBit(parity);
    }

    // Stop bits
    // NOTE: the Serial.println below is restored from v3a.  It is not (only)
    // debug output -- its per-byte execution time forms part of the inter-byte
    // timing that the VIP / HUG 1802 / ELF II / KCS loaders were validated
    // against.  Removing it in v4 shortened that timing and broke those
    // protocols on real hardware, so it is restored verbatim to guarantee the
    // exact v3a behavior.
    //
    // TRIED AND REVERTED: replacing this with a fixed delayMicroseconds(80),
    // calibrated from the isolated-call (buffer-empty) timing measured on
    // real hardware (76-88us). That undershot whatever the real inter-byte
    // timing needs to be -- real transfers apparently land closer to the
    // back-to-back-measured average (614us, with occasional multi-ms
    // stalls), not the buffer-empty floor. Swapping to 80us reintroduced the
    // instant "all 8s" crash. Do not retry this exact value without new
    // measurements; if revisiting, measure timing during an ACTUAL transfer
    // (not an isolated test loop) to get a realistic calibration target.
    for (uint8_t i = 0; i < _p->stopBits; i++) {
        Serial.println(_p->stopBits);
        sendBit(_p->stopBit);
    }
}

void CassetteEncoder::sendByteRaw(uint8_t b)
{
    // ORAO is LSB-first; honour _p->bitOrder anyway for symmetry/future use.
    if (!_p || _p->bitOrder == LSB_FIRST) {
        for (uint8_t i = 0; i < 8; i++) {
            sendBit((b >> i) & 1);
        }
    } else {
        for (int8_t i = 7; i >= 0; i--) {
            sendBit((b >> i) & 1);
        }
    }
}

void CassetteEncoder::sendTrailer()
{
    if (_lastError != ENCODE_OK || !_p) return;

    if (_p->trailerBit == 0 || _p->trailerBit == 1) {
        for (uint16_t i = 0; i < _p->trailerTime; i++) {
            sendBit(_p->trailerBit);
        }
    }
}

// Emit `cycles` cycles of the tone for `bit`, overriding the protocol's normal
// bit0_cycle / bit1_cycle count.
//
// Needed by the TRS-80 PC-1, whose stop element is NOT a full bit cell.  A PC-1
// frame is start + 8 data bits + a mark burst of only ~6 cycles of 4 kHz
// (1.50 ms) rather than the 8 cycles (2.00 ms) a whole cell would take.
//
// This was measured, not assumed.  Comparing a generated tape against the real
// capture run-for-run: the space runs matched EXACTLY (8/16/24/32/40 half-cycles,
// same counts), while every mark run was 2-3 cycles too long --
//     real  74/76, 90/92, 106/108, 120/122, 138   half-cycles
//     ours  80,    96,     112,     128,     144
// Shortening the stop to 6 cycles reproduces the real distribution
// (76, 92, 108, 124, 140), each sitting mid-cluster of the machine's own jitter.
void CassetteEncoder::sendToneCycles(uint8_t bit, uint16_t cycles)
{
    if (_lastError != ENCODE_OK || !_p || cycles == 0) return;
    sendBitCycles(bit, cycles);
}

void CassetteEncoder::sendBit(uint8_t bit)
{
    sendBitCycles(bit, (bit == 0) ? _p->bit0_cycle : _p->bit1_cycle);
}

void CassetteEncoder::sendBitCycles(uint8_t bit, uint16_t cycles)
{
    uint16_t half   = (bit == 0) ? _half0_us : _half1_us;

    // Both the timing-overhead correction and the software-PWM amplitude
    // reduction are COMX-specific tuning.  Apply them ONLY for the COMX framing
    // so every other protocol (VIP, ELF II, KCS, ORAO, ...) behaves EXACTLY as
    // before -- same full-amplitude output and same raw delayMicroseconds(half)
    // timing.  This keeps the COMX work fully isolated.
    const bool isComx = (_p->framing == FRAMING_SYNC_COMX);

    // The TRS-80 PC-1 needs the SAME overhead correction as the COMX, and needs
    // it more.  Its 4 kHz mark half-cycle is 125us -- the shortest this project
    // emits anywhere -- so the fixed per-half cost of the port write plus loop
    // (measured at ~10-27us on this board via the COMX self-check) is 8-20% of
    // it.  Uncorrected, every bit cell stretches by the same proportion: the
    // tone still decodes, but a 2.16ms cell against the machine's fixed 2.00ms
    // sampling window drifts most of a bit across a 10-cell frame, so the frame
    // is misread even though every individual tone is correct.  That is exactly
    // an ERROR 5 (data/checksum) immediately after the leader locks.
    //
    // Identified by parameters rather than by name: the PC-1 is the only
    // FRAMING_ASYNC_KCS entry with a sub-300us bit1 period (ET-3400 is 416us).
    //
    // CAREFUL -- this is the same shape as the trap that once made six sites
    // read FRAMING_ASYNC_KCS as "ET-3400".  THREE machines now share this
    // framing: ET-3400 (bit1 416us), PC-1 (232us) and PC-2 (400us).  The <300
    // test still selects only the PC-1, so it is correct today, but it is a
    // heuristic standing in for identity.  The PC-2 falls through to d = half
    // (no correction) ON PURPOSE: that equals the PC-1's own calibrated
    // ENC_CAL_OVERHEAD_US_PC1 of 0, and at a 200us half the board's ~7us
    // overhead is 3.5% rather than the 2.8% that mattered on the PC-1.
    // If a PC-2 tape ever loads at the wrong speed, give it its own constant
    // here -- do NOT widen this test, or the PC-2 will start stealing the
    // PC-1's correction.
    const bool isPc1 = (_p->framing == FRAMING_ASYNC_KCS && _p->bit1 < 300);

    // Timing correction: subtract the measured per-half output overhead so the
    // emitted half-period equals `half`.
    // Each protocol uses ITS OWN overhead constant.  The COMX value is
    // calibrated and working -- it must not move when the PC-1 is tuned.
    uint16_t d = half;
    if (isComx) {
        d = (half > ENC_CAL_OVERHEAD_US)
              ? (uint16_t)(half - ENC_CAL_OVERHEAD_US)
              : 1;
    } else if (isPc1) {
        d = (half > ENC_CAL_OVERHEAD_US_PC1)
              ? (uint16_t)(half - ENC_CAL_OVERHEAD_US_PC1)
              : 1;
    }

    // Duty-cycle asymmetry (COMX only).  A genuine COMX save is NOT a 50/50
    // square: measured against the real Test99 save, the POSITIVE (EF4-high)
    // half of every cell is ~23us SHORTER than the negative half, for both
    // bit0 (181us hi / 227us lo) and bit1 (499us hi / 544us lo) -- a constant
    // ~23us skew, independent of cell length.  EMMA02 and the COMX read EF4 as
    // (input > 0), so this skew shifts the zero-crossing the ROM times against.
    // A symmetric 50/50 cell (which we emitted before) loaded the whole program
    // but tripped TAPE READ ERROR on the marginal bits.  Apply the same skew to
    // the two halves, keeping the full period (dHi + dLo) equal to 2*d.
    uint16_t dHi = d, dLo = d;
    if (isComx) {
        const uint16_t DUTY_SKEW_US = 0;    // symmetric cells (skew shifted bit framing -> corruptions; reverted)
        if (d > DUTY_SKEW_US + 1) {
            dHi = (uint16_t)(d - DUTY_SKEW_US);
            dLo = (uint16_t)(d + DUTY_SKEW_US);
        }
    }

    for (uint16_t i = 0; i < cycles; i++) {
        if (isComx) {
            // COMX: emit one cell using DIRECT port-register writes, with the
            // genuine duty skew (positive half shorter than negative half).
            if (_portReg) {
                const bool activeHigh = (_p->polarity == POLARITY_POSITIVE);
                volatile uint8_t* reg = _portReg;
                const uint8_t setMask = _portBit;
                const uint8_t clrMask = (uint8_t)~_portBit;
                // HIGH (positive) half -- shorter
                if (activeHigh) *reg |= setMask; else *reg &= clrMask;
                delayMicroseconds(dHi);
                // LOW (negative) half -- longer
                if (activeHigh) *reg &= clrMask; else *reg |= setMask;
                delayMicroseconds(dLo);
            } else {
                // Fallback if the port register wasn't resolved.
                writeHigh(); delayMicroseconds(dHi);
                writeLow();  delayMicroseconds(dLo);
            }
        } else {
            writeHigh();          // all other protocols: original full-amplitude high
            delayMicroseconds(d);
            writeLow();
            delayMicroseconds(d);
        }
    }
}

// Emit the "high" phase for `us` microseconds at REDUCED average level, while
// keeping the leader/tone FREQUENCY clean.
//
// Earlier this fast-chopped the half-cycle into many ~10us pulses (a ~100kHz
// carrier) and relied on the COMX input to low-pass it.  On real hardware that
// made the leader frequency read "all over the place" unless duty was high --
// the COMX input tracks EDGES, it does not average a 100kHz carrier, so the
// extra edges corrupted the apparent tone.
//
// New scheme: ONE pulse per half-cycle.  We drive the pin active for
// (us * ENC_PWM_DUTY_PCT/100) microseconds, then idle (low) for the remainder
// of the half.  That produces exactly ONE active edge per half-cycle, at the
// correct 408/1043us spacing -> the tone frequency stays clean -- while the
// shorter active time lowers the average level the input sees.  ENC_PWM_DUTY_PCT
// now means "fraction of each half-cycle the pin is driven active" (1..100).
//
// Direct port-register writes (not digitalWrite) keep the edge crisp.
//
// EDGE-RATE SHAPING (ENC_EDGE_RAMP_US > 0): a cassette AUDIO input is normally
// AC-COUPLED (a series capacitor), so its comparator responds to the EDGE
// (dV/dt), not the steady level.  A digital pin's edge is ~nanoseconds -> a huge
// spike through the cap that saturates the stage (this is why the input pot has
// no effect at 5V).  A real tape's edges are gentle, so their spikes are small.
// To mimic that, we SYNTHESISE a slow edge: ramp a fast PWM from 0->100% duty
// over ENC_EDGE_RAMP_US at the rising transition (and 100->0 at the falling
// one).  The coupling cap integrates this into a soft edge, producing a much
// smaller spike at the comparator -- without any hardware.  Set
// ENC_EDGE_RAMP_US 0 to disable (hard edges).
void CassetteEncoder::holdHigh(uint16_t us)
{
#if ENC_PWM_ENABLE
    const bool activeHigh = (_p->polarity == POLARITY_POSITIVE);

    // active time within this half-cycle (one clean pulse)
    uint16_t act = (uint16_t)(((uint32_t)us * ENC_PWM_DUTY_PCT) / 100);
    if (act < 1) act = 1;
    if (act > us) act = us;
    uint16_t idle = (uint16_t)(us - act);

    if (_portReg) {
        volatile uint8_t* reg = _portReg;
        const uint8_t setMask = _portBit;
        const uint8_t clrMask = (uint8_t)~_portBit;
        #define DRIVE_ACTIVE() do { if (activeHigh) *reg |= setMask; else *reg &= clrMask; } while(0)
        #define DRIVE_IDLE()   do { if (activeHigh) *reg &= clrMask; else *reg |= setMask; } while(0)

#if ENC_EDGE_RAMP_US > 0
        // --- rising edge: ramp duty 0 -> 100% over ramp window ---
        const uint16_t ramp = (ENC_EDGE_RAMP_US < act/2) ? ENC_EDGE_RAMP_US : (act/2);
        const uint8_t  STEP = 2;          // PWM sub-period in us (fast carrier)
        uint16_t t = 0;
        while (t < ramp) {
            // duty rises with t: hi_us = STEP * t / ramp
            uint8_t hi = (uint8_t)(((uint32_t)STEP * t) / ramp);
            uint8_t lo = (STEP > hi) ? (STEP - hi) : 0;
            if (hi) { DRIVE_ACTIVE(); delayMicroseconds(hi); }
            if (lo) { DRIVE_IDLE();   delayMicroseconds(lo); }
            t += STEP;
        }
        // --- solid active for the middle ---
        DRIVE_ACTIVE();
        uint16_t mid = (act > 2*ramp) ? (act - 2*ramp) : 0;
        if (mid) delayMicroseconds(mid);
        // --- falling edge: ramp duty 100 -> 0% ---
        t = 0;
        while (t < ramp) {
            uint8_t hi = (uint8_t)(((uint32_t)STEP * (ramp - t)) / ramp);
            uint8_t lo = (STEP > hi) ? (STEP - hi) : 0;
            if (hi) { DRIVE_ACTIVE(); delayMicroseconds(hi); }
            if (lo) { DRIVE_IDLE();   delayMicroseconds(lo); }
            t += STEP;
        }
        DRIVE_IDLE();
        if (idle) delayMicroseconds(idle);
#else
        // hard-edge single pulse (no ramp)
        DRIVE_ACTIVE();
        delayMicroseconds(act);
        DRIVE_IDLE();
        if (idle) delayMicroseconds(idle);
#endif
        #undef DRIVE_ACTIVE
        #undef DRIVE_IDLE
        return;
    }
    // Fallback: solid high for the whole half (full 5V) if port not resolved.
    writeHigh();
    delayMicroseconds(us);
#else
    writeHigh();
    delayMicroseconds(us);
#endif
}


void CassetteEncoder::writeHigh()
{
    // Was digitalWrite() (~4.5us, and its exact timing can be perturbed by
    // other interrupts firing mid-call, e.g. Timer0). Switched to a direct
    // port-register write (~0.1us, effectively atomic) -- the same fix
    // already proven for the COMX path (see constructor comment / line 265).
    // This runs on every single bit edge for every protocol, so removing
    // this jitter source here is a much bigger lever than anything in the
    // stop-bit padding we were previously focused on.
    const bool activeHigh = (_p->polarity == POLARITY_POSITIVE);
    if (activeHigh) *_portReg |= _portBit;
    else            *_portReg &= (uint8_t)~_portBit;
}

void CassetteEncoder::writeLow()
{
    const bool activeHigh = (_p->polarity == POLARITY_POSITIVE);
    if (activeHigh) *_portReg &= (uint8_t)~_portBit;
    else            *_portReg |= _portBit;
}

void CassetteEncoder::sendSilence(uint16_t ms)
{
    // Hold the pin at its idle level with NO transitions -> the audio input
    // sees silence (no tone).  Uses writeLow() so the resting level matches the
    // configured polarity.  delay() is fine here (timing isn't bit-critical).
    writeLow();
    for (uint16_t i = 0; i < ms; i++) delayMicroseconds(1000);
}


// ---------------------------------------------------------------------------
// ORAO block-mode high-level send
// ---------------------------------------------------------------------------
//
// Two on-tape formats are produced, matching what the original Orao 2007 and
// Eagle Extended BASIC ROMs emit on SAVE:
//
//   'B' (BASIC source) -- multi-block with sync per block
//
//     Each 256-byte block:
//       offset 0..3   : sync $1B $1B $1B $1B
//       offset 4      : type byte ('B' = $42)
//       offset 5..14  : filename, ASCII, padded to 10 bytes with $20
//       offset 15     : block number (0, 1, 2, ...)
//       offset 16..255: 240 bytes of payload (source bytes; final byte is
//                       $1A EOF, then $20 padding to 240).
//     Each block is preceded by its own leader and a single 0-bit transition.
//
//   'O' (Object / memory image) -- header block + raw data block
//
//     Block 0 (256 bytes, with sync header) is the file *metadata*:
//       offset 0..3   : sync $1B $1B $1B $1B
//       offset 4      : type byte ('O' = $4F)
//       offset 5..14  : filename
//       offset 15     : block number = 0
//       offset 16..17 : load address (lo, hi)
//       offset 18..19 : length helper (lo, hi).  This is FE_orig / FF_orig
//                       which in the SAVE code becomes the on-tape FE/FF
//                       AFTER `INC FE` / `INC FF`.  We choose them so that
//                         (FE_orig + 1) + 256 * FF_orig == totalDataBytes
//       offset 20..255: $20 padding
//
//     After block 0 is sent, a NEW leader+transition is emitted, followed by
//     the on-tape 2-byte length header (FE_orig+1, FF_orig+1) and the raw
//     program bytes.  No sync $1B is emitted for the data block.

void CassetteEncoder::sendOraoFile(const char* filename,
                                   uint32_t totalDataBytes,
                                   uint16_t loadAddr,
                                   uint16_t endAddr,
                                   OraoByteReader reader,
                                   void* readerCtx)
{
    if (_lastError != ENCODE_OK || !_p) {
        _lastError = ENCODE_ERR_NO_PARAMS;
        return;
    }
    if (_p->framing != FRAMING_BLOCK_ORAO || !reader) {
        _lastError = ENCODE_ERR_INVALID_PARAMS;
        return;
    }

    // Build a 10-byte space-padded filename buffer once.
    char fnPadded[10];
    {
        bool exhausted = false;
        for (uint8_t i = 0; i < 10; i++) {
            if (exhausted || filename == nullptr || filename[i] == '\0') {
                fnPadded[i] = ' ';
                exhausted = true;
            } else {
                fnPadded[i] = filename[i];
            }
        }
    }

    const bool isObject = (_p->oraoType == ORAO_TYPE_OBJECT);
    const uint8_t typeByte = isObject ? (uint8_t)ORAO_TYPE_OBJECT
                                      : (uint8_t)ORAO_TYPE_BASIC;

    // 256-byte SRAM scratch buffer used for the header block (and for 'B'
    // mode for every block).  See the build-then-stream rationale below.
    uint8_t blockBuf[256];

    // ===========================================================================
    // 'O' files: emit header block, then the raw data block.
    // ===========================================================================
    if (isObject) {
        // Compute FE_orig / FF_orig such that
        //   (FE_orig + 1) + 256 * FF_orig == totalDataBytes
        // For totalDataBytes >= 1: FF_orig = (N-1) >> 8, FE_orig = (N-1) & 0xFF.
        // (For N == 0 we still emit a header block but no data.)
        uint8_t feOrig = 0, ffOrig = 0;
        if (totalDataBytes > 0) {
            uint32_t nMinus = totalDataBytes - 1;
            feOrig = (uint8_t)(nMinus & 0xFF);
            ffOrig = (uint8_t)((nMinus >> 8) & 0xFF);
        }

        // ---- Build the 256-byte header block in SRAM --------------------------
        blockBuf[0] = 0x1B;  blockBuf[1] = 0x1B;
        blockBuf[2] = 0x1B;  blockBuf[3] = 0x1B;
        blockBuf[4] = typeByte;
        for (uint8_t i = 0; i < 10; i++) blockBuf[5 + i] = (uint8_t)fnPadded[i];
        blockBuf[15] = 0x00;                                   // block# = 0
        blockBuf[16] = (uint8_t)( loadAddr        & 0xFF);     // load_lo
        blockBuf[17] = (uint8_t)((loadAddr >> 8 ) & 0xFF);     // load_hi
        blockBuf[18] = feOrig;                                 // length helper lo
        blockBuf[19] = ffOrig;                                 // length helper hi
        for (uint16_t i = 20; i < 256; i++) blockBuf[i] = 0x20; // $20 padding

        // ---- Send the header block ------------------------------------------
        sendLeader();
        sendBit(0);                              // leader-to-data transition
        for (uint16_t i = 0; i < 256; i++) sendByteRaw(blockBuf[i]);

        if (_lastError == ENCODE_ERR_ABORTED) return;

        // ---- Send the raw data block ----------------------------------------
        // Format: leader + 0-bit transition + (FE_orig+1) + (FF_orig+1) + N bytes.
        // Note that on real hardware the SAVE code does `INC FE` / `INC FF`
        // (8-bit wraps), so we mirror that here.
        sendLeader();
        sendBit(0);
        sendByteRaw((uint8_t)(feOrig + 1));      // FE_tape
        sendByteRaw((uint8_t)(ffOrig + 1));      // FF_tape
        for (uint32_t i = 0; i < totalDataBytes; i++) {
            if (_lastError == ENCODE_ERR_ABORTED) return;
            sendByteRaw(reader(i, readerCtx));
        }
        // One trailing bit so the decoder can finish the last byte's cycle.
        // Without it the receiver is always one byte short on data blocks.
        sendBit(_p->leaderBit);
        return;
    }

    // ===========================================================================
    // 'B' files: classic multi-block-with-sync, payload is source + $1A + $20 pad.
    // ===========================================================================
    const uint32_t logical   = totalDataBytes + 1;             // +1 for $1A EOF
    uint32_t blockCount = (logical + 239) / 240;
    if (blockCount == 0) blockCount = 1;

    uint32_t srcIndex   = 0;
    uint32_t logicalPos = 0;

    for (uint32_t blk = 0; blk < blockCount; blk++) {
        if (_lastError == ENCODE_ERR_ABORTED) return;

        // Phase 1: build the block in SRAM.
        blockBuf[0] = 0x1B;  blockBuf[1] = 0x1B;
        blockBuf[2] = 0x1B;  blockBuf[3] = 0x1B;
        blockBuf[4] = typeByte;
        for (uint8_t i = 0; i < 10; i++) blockBuf[5 + i] = (uint8_t)fnPadded[i];
        blockBuf[15] = (uint8_t)(blk & 0xFF);

        for (uint16_t i = 0; i < 240; i++) {
            uint8_t b = 0x20;
            if (logicalPos < logical) {
                if (logicalPos == totalDataBytes) {
                    b = 0x1A;                                  // EOF marker
                } else {
                    b = reader(srcIndex, readerCtx);
                    srcIndex++;
                }
            }
            blockBuf[16 + i] = b;
            logicalPos++;
        }

        // Phase 2: transmit (no slow calls here).
        sendLeader();
        sendBit(0);
        for (uint16_t i = 0; i < 256; i++) sendByteRaw(blockBuf[i]);
    }
}
