#pragma once
#include <Arduino.h>
#include "CassetteParams.h"


enum DecodeError {
    DECODE_OK = 0,
    DECODE_ERR_PARITY,
    DECODE_ERR_STOPBIT,
    DECODE_ERR_TIMEOUT,
    DECODE_ERR_FRAMING,
    DECODE_ERR_UNKNOWN
};


class CassetteDecoder {
public:
  CassetteDecoder(uint8_t pin); 
  CassetteDecoder(uint8_t pin, const CassetteParams* params);
  void begin(Stream& s);
  void setParams(const CassetteParams* p);
  const CassetteParams* getParams() const { return _p; }
  void reset();
  void setOutput(Stream* s) { _out = s; }
  bool isDone() const { return _done; }


  // Feed a half-cycle (edge-to-edge) period in microseconds.
  void feedPeriod(uint32_t us);
  // Byte retrieval (non-blocking)
  bool available() const { return _byteReady; }
  uint8_t read();

  void poll();
  bool decodeFinished() const;
  void clearDecodeFinished();
  DecodeError lastError() const { return _lastError; }
  bool hasError() const { return _lastError != DECODE_OK; }
  void clearError() { _lastError = DECODE_OK; }

  // ---- Diagnostics (printed to Serial when the error fires) ------------------
  // These let you see exactly where the decoder bailed: which state was active,
  // how many leader bits were counted, how many sync bytes matched, how many
  // bytes had been emitted, and the cycle counts.  Helpful to localize a real
  // hardware failure (audio level / edge timing / etc) when the simulation
  // works but the Arduino doesn't.
  uint8_t  debugState() const         { return (uint8_t)_state; }
  const char* debugStateName() const {
      switch (_state) {
          case WAIT_LEADER:     return "WAIT_LEADER";
          case WAIT_START:      return "WAIT_START";
          case READ_DATA:       return "READ_DATA";
          case READ_PARITY:     return "READ_PARITY";
          case READ_STOP:       return "READ_STOP";
          case ORAO_HUNT_SYNC:  return "ORAO_HUNT_SYNC";
          case ORAO_READ_BLOCK: return "ORAO_READ_BLOCK";
          case ORAO_READ_RAW:   return "ORAO_READ_RAW";
          case COMX_READ_DATA:  return "COMX_READ_DATA";
          case COMX_READ_FRAME: return "COMX_READ_FRAME";
      }
      return "?";
  }
  uint16_t debugLeaderCount() const   { return _leaderCount;     }
  uint8_t  debugSyncMatch() const     { return _syncMatch;       }
  uint16_t debugBlockBytesRead() const{ return _blockBytesRead;  }
  uint8_t  debugBitCount() const      { return _bitCount;        }
  uint32_t debugUsSinceLastEdge() const {
      // Atomic 32-bit read; see note in poll() for why this matters.
      noInterrupts();
      uint32_t le = _lastEdge;
      interrupts();
      if (le == 0) return 0;
      return (uint32_t)(micros() - le);
  }
  bool     debugAnyByteEmitted() const { return _anyByteEmitted; }

  // ---- Live counters for hardware diagnosis -------------------------------
  // None of these affect decoding -- they're free-running tallies that the
  // main loop can poll and print every ~1s during a LOAD.  When real
  // hardware "just sits waiting" they tell us *why*: no edges arriving,
  // edges arriving but cycle timing wrong, or all classifying correctly but
  // sync never matching.
  uint32_t debugEdgesSeen() const     { return _diagEdges;       }
  uint32_t debugFullCycles() const    { return _diagFullCycles;  }
  uint32_t debugBit0Count() const     { return _diagBit0;        }
  uint32_t debugBit1Count() const     { return _diagBit1;        }
  uint32_t debugOutOfRange() const    { return _diagOutOfRange;  }
  uint32_t debugLastCycleUs() const   { return _diagLastCycleUs; }
  uint32_t debugMinCycleUs() const    { return _diagMinCycleUs == 0xFFFFFFFFUL ? 0 : _diagMinCycleUs; }
  uint32_t debugMaxCycleUs() const    { return _diagMaxCycleUs;  }
  uint32_t debugBytesEmitted() const  { return _diagBytesOut;    }

  // Counts ISR-side edge losses because the period queue was full.  Should
  // remain 0 in a healthy system.  Anything > 0 means main-loop processing
  // is too slow somewhere -- likely the RAM write or Serial.print.  See
  // also debugQueueHighWater() for the worst-case fill level observed.
  uint16_t debugQueueDrops() const    { return _diagQueueDrops;  }
  uint8_t  debugQueueHighWater() const{ return _diagQueueHighWater; }

  // Sticky state-transition counters.  Read these AFTER a load attempt to see
  // what actually happened, especially when 1-second snapshots only ever show
  // WAIT_LEADER -- these reveal if state advanced briefly between snapshots.
  uint8_t  debugMaxState() const      { return _diagMaxState;    }
  const char* debugMaxStateName() const {
      switch ((State)_diagMaxState) {
          case WAIT_LEADER:     return "WAIT_LEADER";
          case WAIT_START:      return "WAIT_START";
          case READ_DATA:       return "READ_DATA";
          case READ_PARITY:     return "READ_PARITY";
          case READ_STOP:       return "READ_STOP";
          case ORAO_HUNT_SYNC:  return "ORAO_HUNT_SYNC";
          case ORAO_READ_BLOCK: return "ORAO_READ_BLOCK";
          case ORAO_READ_RAW:   return "ORAO_READ_RAW";
          case COMX_READ_DATA:  return "COMX_READ_DATA";
          case COMX_READ_FRAME: return "COMX_READ_FRAME";
      }
      return "?";
  }
  uint16_t debugSyncEnters() const    { return _diagSyncEnters;     }
  uint16_t debugSyncFails() const     { return _diagSyncFails;      }
  uint16_t debugSyncLocks() const     { return _diagSyncLocks;      }
  uint32_t debugLastSyncShift() const { return _diagLastSyncShift;  }
  void     debugReset() {
      _diagEdges = 0; _diagFullCycles = 0;
      _diagBit0 = 0; _diagBit1 = 0; _diagOutOfRange = 0;
      _diagLastCycleUs = 0;
      _diagMinCycleUs = 0xFFFFFFFFUL;
      _diagMaxCycleUs = 0;
      _diagBytesOut = 0;
      _diagMaxState = 0;
      _diagSyncEnters = 0;
      _diagSyncFails = 0;
      _diagSyncLocks = 0;
      _diagLastSyncShift = 0;
  }

  // ---- ORAO block-mode hint --------------------------------------------------
  // Real Orao 'O' (object) files use a two-stage tape format:
  //   1.  256-byte HEADER block with sync $1B*4 + type + filename + blknum +
  //       load_lo/hi + length-helper_lo/hi + $20 padding.
  //   2.  Per-block leader + transition + 2-byte length-on-tape + N raw bytes
  //       (NO sync, NO block-size limit -- the count is stamped on the tape).
  // OraoReceive calls setOraoNextBlockMode(ORAO_NEXT_RAW) after consuming the
  // 'O' header so that the decoder knows the next leader-end transition should
  // jump straight into raw byte assembly instead of hunting for $1B sync.
  // After the raw block is consumed the field reverts to ORAO_NEXT_SYNC so a
  // subsequent file in the same session is handled in the normal way.
  enum OraoNextBlock {
    ORAO_NEXT_SYNC = 0,   // expect $1B sync (default; what 'B' files always do)
    ORAO_NEXT_RAW  = 1    // skip sync hunt, emit bytes raw until silence
  };
  void setOraoNextBlockMode(OraoNextBlock m) { _oraoNextBlock = m; }


private:
  static CassetteDecoder* instance;
  static void isrThunk();

  // Attach the edge interrupt in the mode the current protocol needs:
  //   FRAMING_BLOCK_ORAO -> RISING  (one full cycle per IRQ; immune to the
  //                                  half-cycle phase offset that scrambled
  //                                  multi-block ORAO captures)
  //   FRAMING_ASYNC      -> CHANGE  (both edges) + half-cycle pairing in
  //                                  handlePeriod(), exactly as the async
  //                                  protocols (VIP/ELF II/KCS/DREAM) were
  //                                  originally validated.
  // Called from begin() and whenever setParams() changes the protocol.
  void applyInterruptMode();

  void handlePeriod(uint32_t us);
  void kcsFeedBit(uint8_t bit);   // one logical bit -> UART state machine
  bool periodToBit(uint32_t fullCycle, uint8_t& bit);
  void emitByte();
  bool _done;
  const CassetteParams* _p;
  uint8_t _pin;
  Stream* _out;

  volatile uint32_t _lastEdge;

  // ---- Period ring buffer (replaces single-slot _pendingPeriod) -------------
  // The ISR pushes one half-period (edge-to-edge delta) per edge.  The main
  // loop drains AS MANY as are queued each poll().  This is the critical fix
  // for SAVE-direction corruption: the SPI-RAM write inside OraoReceive's
  // F_PAYLOAD path takes ~520us with bit-banged digitalWrite, during which
  // 2-3 edges fire and used to be lost (depth-1 queue overwrote itself).  At
  // 32 slots and ORAO half-period ~181us minimum, the buffer absorbs up to
  // ~5.8 ms of main-loop blocking before any period is dropped.  Size MUST
  // remain a power of two so the mask-modulo works.
  //
  // ---- RESIZED FOR THE TRS-80 PC-1 (save-direction fix) --------------------
  // The PC-1's 4 kHz mark tone fires the CHANGE interrupt every 125us, i.e.
  // ~8000 edges/second -- more than twice the edge rate of any other protocol
  // here.  At 32 slots the queue absorbed only ~3 ms of main-loop blocking,
  // and ReadData()'s once-per-second PC-1 diagnostic line was ~150 characters
  // = ~13 ms of blocking Serial at 115200.  Every save therefore lost ~70
  // periods per second; each loss breaks the mark burst count mid-frame and
  // slips the framing by one bit, which is the junk-nibble symptom.
  //
  // Measured in simulation (tools/pc1_rx_sim.py) with drain-all enabled:
  //     32 slots ->  3 ms of blocking tolerated
  //     64       ->  7 ms
  //    128       -> 15 ms   <-- chosen; the diagnostic line is also shortened
  //    256       -> 31 ms       to ~55 chars (~4.8 ms) for ~3x margin
  //
  // ---- 16-BIT SLOTS ARE ONLY SAFE BECAUSE THE ISR CLAMPS.  IT REALLY DOES. -
  // This was narrowed from uint32_t to uint16_t to save 256 bytes, justified by
  // a comment claiming "the ISR clamps each period to 60000us before storing".
  // THAT CLAMP WAS NOT WRITTEN.  isrThunk() assigned a uint32_t delta straight
  // into the 16-bit slot, so every gap over 65535us WRAPPED -- 66000us became
  // 464us, inside the data window of VIP, COMX-35 and HUG1802, and was decoded
  // as a real bit.  The PC-1 and PC-2 have short uniform gaps and never showed
  // it, so it shipped while those were the machines under test.
  //
  // The clamp now exists, in isrThunk(), and it is what makes this type legal.
  // If you touch either, touch both -- and go and READ isrThunk() rather than
  // trusting this comment, because trusting a comment exactly like this one is
  // what caused the bug.
  //
  // 128 x 2 = 256 bytes.  This board runs at 76% SRAM with ~1.9 KB free, so
  // the 256 bytes the 32-bit version would cost is worth avoiding -- but only
  // with the clamp in place, never by truncation.
  // Size MUST remain a power of two so the mask-modulo works.
  static const uint8_t PERIOD_QUEUE_SIZE = 128;
  static const uint8_t PERIOD_QUEUE_MASK = PERIOD_QUEUE_SIZE - 1;
  volatile uint16_t _periodQueue[PERIOD_QUEUE_SIZE];
  volatile uint8_t  _qHead;            // ISR writes here (next free slot)
  volatile uint8_t  _qTail;            // main loop reads here (oldest entry)
  volatile uint16_t _diagQueueDrops;   // edges discarded because queue was full
  uint8_t           _diagQueueHighWater; // largest occupancy ever observed

  // True when poll() should drain the WHOLE queue rather than one entry per
  // call.  Set once in setParams(); see the drain site in poll() for why this
  // is protocol-scoped rather than framing-scoped.
  bool     _fastDrain;

  // True for the TRS-80 PC-1: emit after FOUR data bits and resynchronise on
  // the next space run, instead of clocking in eight.  See the emit site in
  // handlePeriod() for why this is the only framing that is safe here.
  bool     _nibbleFrame;

public:
  // ---- Run-length trace (PC-1 bring-up instrument) -------------------------
  // Records the raw tone structure -- alternating runs of mark and space, in
  // HALF-CYCLES -- with no framing assumptions layered on top.  Filled during
  // capture (two stores per tone change, no Serial), printed afterwards, so it
  // costs nothing in the timing-critical path.
  //
  // This is the measurement that settles frame structure arguments:  divide a
  // run by 16 for mark cells or by 8 for space cells.  A frame should read as
  // a space run of 8..40 halves (start bit + any leading zero data bits) then
  // a mark run whose length is the rest of the frame.
  // ---- PC-1 BRING-UP DIAGNOSTICS: REMOVED TO RECLAIM SRAM -----------------
  // A 96-entry run trace and a 24-bucket half-period histogram used to live
  // here: 240 bytes of permanently-resident SRAM on a board that compiles at
  // 76% with ~1.9 KB free for stack and heap.  They existed to characterise
  // the PC-1's tone structure during bring-up; that work is finished and its
  // conclusions are written down in the comments and in PC1_RECORD_FORMAT.md.
  // They were only ever read inside SERIALDEBUG blocks in ReadData().
  //
  // 240 bytes is not a rounding error at this headroom -- it is more than the
  // stack frame of the deepest function in the sketch.  If a future machine
  // needs the same analysis, restore them together with their print block,
  // take the measurement, and remove them again.
private:

  uint32_t _waitStartTime;
  uint8_t _startQual;
  uint8_t _cycle0Count;
  uint8_t _cycle1Count;
  uint8_t  _bitCount;
  uint8_t  _byte;
  uint8_t  _parity;
  uint16_t _leaderCount;
  uint8_t  _stopCount;
  uint8_t  _counter;

  // ---- ORAO block-mode state ----
  uint8_t  _syncMatch;        // running count of consecutive $1B sync bytes seen
  uint16_t _blockBytesRead;   // post-sync bytes emitted for current block (0..251)
  OraoNextBlock _oraoNextBlock = ORAO_NEXT_SYNC;  // controls next leader-end action

  // ORAO_HUNT_SYNC uses a 32-bit sliding window to find 4×$1B regardless of
  // which bit position the decoder happened to enter sync hunt at.  This is
  // far more robust against single-bit misclassifications in real audio than
  // byte-aligned hunting, which fails completely if even one bit is wrong.
  uint32_t _syncShift;        // running shift register, 32 most recent bits
  uint16_t _syncHuntBits;     // total bits shifted in this hunt (timeout guard)

  // handlePeriod() pairs successive half-periods into full cycles.  These
  // were function-level statics historically; making them members lets
  // reset() clear them so a second LOAD attempt starts clean.
  uint32_t _halfAccum;
  bool     _haveHalf;

  // Set to true the first time emitByte() runs.  Until then the silence
  // timeout in poll() does NOT fire -- otherwise a noisy audio startup that
  // briefly advances the state out of WAIT_LEADER (without ever producing a
  // valid byte) followed by genuine audio can be aborted before sync is even
  // attempted.  Cleared by reset().
  bool     _anyByteEmitted;

  // ---- Diagnostic counters (see debug*() accessors above) -----------------
  volatile uint32_t _diagEdges;       // incremented in ISR every edge seen
  uint32_t _diagFullCycles;           // incremented when handlePeriod assembles a full cycle
  uint32_t _diagBit0;                 // periodToBit() classified as 0
  uint32_t _diagBit1;                 // periodToBit() classified as 1
  uint32_t _diagOutOfRange;           // periodToBit() rejected
  uint32_t _diagLastCycleUs;          // most recent full-cycle period in us
  uint32_t _diagMinCycleUs;           // running min observed
  uint32_t _diagMaxCycleUs;           // running max observed
  uint32_t _diagBytesOut;             // bytes emitByte() has produced

  // ---- Sticky state-transition counters (set once, never cleared mid-run) -
  // These survive across the WAIT_LEADER <-> ORAO_HUNT_SYNC bounce that
  // happens too fast for the 1-second poll to catch.  After a load attempt
  // ends, these tell us whether sync hunting was ever attempted, how many
  // times we tried, and what the last shift register looked like.
  uint8_t  _diagMaxState;             // highest _state value ever seen
  uint16_t _diagSyncEnters;           // count of WAIT_LEADER -> ORAO_HUNT_SYNC
  uint16_t _diagSyncFails;            // count of ORAO_HUNT_SYNC -> WAIT_LEADER (timeout)
  uint16_t _diagSyncLocks;            // count of ORAO_HUNT_SYNC -> ORAO_READ_BLOCK
  uint32_t _diagLastSyncShift;        // shift register at most recent fail

  bool _decodeFinished = false;
  DecodeError _lastError = DECODE_OK;

  volatile bool _byteReady = false;
  volatile uint8_t _lastByte = 0;


  enum State {
    WAIT_LEADER,
    WAIT_START,
    READ_DATA,
    READ_PARITY,
    READ_STOP,
    // ORAO block-mode states
    ORAO_HUNT_SYNC,    // assembling bits looking for the four $1B sync bytes
    ORAO_READ_BLOCK,   // reading the 252 post-sync bytes (type+name+blk#+payload)
    ORAO_READ_RAW,     // emitting bytes raw with no block-size limit (data block of an 'O' file)
    // COMX-35 bit-synchronous states (FRAMING_SYNC_COMX)
    COMX_READ_DATA,    // reading the 8 LSB-first data bits of the current 10-cell frame
    COMX_READ_FRAME    // consuming the single trailing framing cell (value ignored)
  } _state;
 
};
