// v75 - PC-1 save-direction fixes (period queue depth, drain policy)
#include "CassetteDecoder.h"
#include <string.h>   // strcmp(), used once in setParams()

// COMX PSAVE writes the program RAM region as fixed-size blocks on tape, each
// preceded by a re-sync leader.  Measured from genuine saves: 257 bytes/block.
// The receive decoder uses this to detect a block boundary and skip the
// inter-block leader instead of capturing its cells as data.
static const uint16_t COMX_BLOCK_BYTES = 257;


CassetteDecoder* CassetteDecoder::instance = nullptr;

CassetteDecoder::CassetteDecoder(uint8_t pin)
: _pin(pin),
  _p(nullptr),
  _fastDrain(false)
{
}

CassetteDecoder::CassetteDecoder(uint8_t pin, const CassetteParams* params)
  : _p(params),
    _pin(pin),
    _out(nullptr),
    _lastEdge(0),
    _qHead(0),
    _qTail(0),
    _diagQueueDrops(0),
    _diagQueueHighWater(0),
    _fastDrain(params && (params->framing == FRAMING_BLOCK_ORAO ||
                          strcmp(params->name, "TRS-80 PC-1") == 0 ||
                          strcmp(params->name, "TRS-80 PC-2") == 0)),
    _waitStartTime(0),
    _startQual(0),
    _state(WAIT_LEADER),
    _bitCount(0),
    _byte(0),
    _parity(0),
    _leaderCount(0),
    _stopCount(0),
    _cycle0Count(0),
    _cycle1Count(0),
    _done(false),
    _counter(0),
    _syncMatch(0),
    _blockBytesRead(0) {
}

void CassetteDecoder::begin(Stream& s) {
  _out = &s;
  instance = this;
  pinMode(_pin, INPUT);
  // Interrupt edge mode depends on the protocol's framing -- see
  // applyInterruptMode().  ORAO uses RISING (full-cycle, phase-immune);
  // async protocols use CHANGE + half-cycle pairing as originally validated.
  applyInterruptMode();
  clearDecodeFinished();
  if (_out) _out->println(String(_p->name) + F(" CASSETTE DECODER READY"));
}

void CassetteDecoder::applyInterruptMode() {
  // Choose the edge mode for the active protocol.  Default to CHANGE when no
  // params are set yet (matches the async path, which is the safe default).
  int mode = (_p && _p->framing == FRAMING_BLOCK_ORAO) ? RISING : CHANGE;

  detachInterrupt(digitalPinToInterrupt(_pin));

  // Clear edge/pairing/queue state so the new mode starts from a clean phase.
  noInterrupts();
  _lastEdge   = 0;
  _haveHalf   = false;
  _halfAccum  = 0;
  _qHead      = 0;
  _qTail      = 0;
  interrupts();

  // Only arm the interrupt once begin() has registered this instance for the
  // ISR; otherwise an early edge could dereference a null instance.
  if (instance == this) {
    attachInterrupt(digitalPinToInterrupt(_pin), isrThunk, mode);
  }
}

void CassetteDecoder::setParams(const CassetteParams* params) {
  _p = params;
  // Decide the poll() drain policy ONCE, here, so the per-period hot path stays
  // branch-cheap and no strcmp ever runs inside poll().
  //
  // ORAO has always drained the whole queue.  The TRS-80 PC-1 now does too: at
  // a 125us half-period the one-per-poll policy requires the main loop to
  // complete an iteration in under 125us FOREVER, with no ability to catch up
  // after any blocking call.  Simulation (tools/pc1_rx_sim.py) shows that
  // policy decoding correctly at a 100us loop period and failing outright at
  // 150us, while drain-all decodes correctly at every loop period tested.
  //
  // Deliberately keyed on the protocol NAME, not on framing: the ET-3400 shares
  // FRAMING_ASYNC_KCS and was validated with one-period-per-poll, and an
  // earlier attempt to drain the whole queue on the async path regressed it
  // (see the comment at the drain site in poll()).  This keeps every existing
  // protocol bit-for-bit identical and changes only the PC-1.
  // ---- CAPABILITY FLAGS, NOT MACHINE IDENTITY ----------------------------
  // This project's most expensive architectural lesson, recorded in the
  // handoff: six places once used `framing == FRAMING_ASYNC_KCS` to mean "this
  // is the ET-3400", and adding a second KCS-framed machine broke all six at
  // once.  So these are named for what they DO, and any machine with that
  // property gets them.  Adding a third nibble-framed Sharp is one line here,
  // not an audit of every call site.
  const bool isPc1 = (params && strcmp(params->name, "TRS-80 PC-1") == 0);
  const bool isPc2 = (params && strcmp(params->name, "TRS-80 PC-2") == 0);

  _fastDrain = (params &&
                (params->framing == FRAMING_BLOCK_ORAO || isPc1 || isPc2));

  // Nibble framing: emit after FOUR data bits and resynchronise on the next
  // space run, and round each tone run to the nearest whole bit cell.  Shared
  // by the PC-1211 and the PC-1500 -- both send a byte as two nibbles, each
  // with its own stop bits, over equal-duration 4-vs-8-cycle FSK.  Only the
  // frequencies differ, and those live in the CassetteParams row.
  _nibbleFrame = (isPc1 || isPc2);
  reset();
  // Protocol may have changed framing (e.g. async <-> ORAO), so re-arm the
  // interrupt in the correct edge mode.  No-op before begin() registers us.
  applyInterruptMode();
}

void CassetteDecoder::feedPeriod(uint32_t us) {
  handlePeriod(us);
}

uint8_t CassetteDecoder::read() {
  _byteReady = false;
  return _lastByte;
}

void CassetteDecoder::reset() {
  _state = WAIT_LEADER;
  _leaderCount = 0;
  _startQual = 0;
  _bitCount = 0;
  _byte = 0;
  _parity = 0;
  _stopCount = 0;
  _waitStartTime = 0;
  _decodeFinished = false;
  _byteReady = false;
  _done = false;
  _counter = 0;
  _syncMatch = 0;
  _blockBytesRead = 0;
  _oraoNextBlock = ORAO_NEXT_SYNC;
  _syncShift = 0;
  _syncHuntBits = 0;
  _halfAccum = 0;
  _haveHalf  = false;
  _anyByteEmitted = false;
  // Diagnostic counters
  _diagEdges = 0;
  _diagFullCycles = 0;
  _diagBit0 = 0;
  _diagBit1 = 0;
  _diagOutOfRange = 0;
  _diagLastCycleUs = 0;
  _diagMinCycleUs = 0xFFFFFFFFUL;
  _diagMaxCycleUs = 0;
  _diagBytesOut = 0;
  _diagMaxState = 0;
  _diagSyncEnters = 0;
  _diagSyncFails = 0;
  _diagSyncLocks = 0;
  _diagLastSyncShift = 0;
  // Clear ISR-shared state too -- otherwise a second LOAD attempt inherits
  // _lastEdge from the previous run, which makes isDone() fire instantly.
  noInterrupts();
  _lastEdge = 0;
  _qHead = 0;
  _qTail = 0;
  _diagQueueDrops = 0;
  _diagQueueHighWater = 0;
  interrupts();
  clearError();
}


void CassetteDecoder::isrThunk() {
  uint32_t now = micros();
  // Counter incremented unconditionally so it tallies even the very first
  // edge before _lastEdge is initialized.  ~1 extra cycle in the ISR.
  instance->_diagEdges++;
  if (instance->_lastEdge == 0) {
    instance->_lastEdge = now;
    return;
  }
  uint32_t delta = now - instance->_lastEdge;
  instance->_lastEdge = now;
  // ---- CLAMP, DO NOT TRUNCATE.  THIS FIXES A REAL REGRESSION. ------------
  // The queue slot is 16 bits.  A previous revision assigned this 32-bit delta
  // straight in, so every gap over 65535us WRAPPED: 66000us became 464us,
  // which sits inside the data window of VIP, COMX-35 and HUG1802 and was
  // decoded as a genuine bit.  A comment claimed a clamp existed here.  It did
  // not.  It does now.
  //
  // Clamping is safe where truncating was not: 60000us is far outside every
  // protocol's accept window (the widest is 1350us), so a long gap stays
  // recognisably long instead of masquerading as data.  End of tape is
  // detected from _lastEdge by the silence timeout, never from queue contents,
  // so flattening the exact length of a long gap costs nothing.
  const uint16_t stored = (delta > 60000UL) ? (uint16_t)60000U : (uint16_t)delta;
  // Push into the ring buffer.  If full, drop the oldest-pending behaviour
  // would corrupt bit phase; instead drop THIS period and record the loss.
  // 32-slot buffer handles ~5.8 ms of main-loop blocking before this trips.
  uint8_t h = instance->_qHead;
  uint8_t next = (uint8_t)((h + 1) & PERIOD_QUEUE_MASK);
  if (next != instance->_qTail) {
    instance->_periodQueue[h] = stored;
    instance->_qHead = next;
  } else {
    // Queue full -- bit phase will be corrupted from here.  Count it so the
    // main loop can surface the failure mode after the load attempt.
    instance->_diagQueueDrops++;
  }
}

bool CassetteDecoder::decodeFinished() const {
  return _decodeFinished;
}

void CassetteDecoder::clearDecodeFinished() {
  _decodeFinished = false;
}

void CassetteDecoder::poll() {
  // Silence timeout: 1500ms with no edges => assume the tape ended.
  // This is gated on TWO conditions to avoid spurious aborts on real audio:
  //   1.  We're past WAIT_LEADER  (i.e. some edges have been processed)
  //   2.  AND we've actually emitted at least one byte to the consumer.
  // Without (2), a noisy audio startup (phone-jack pop, ALC settling, etc.)
  // can briefly advance the state out of WAIT_LEADER before any real data
  // arrives; if the audio then dips for 1.5s before the real signal kicks
  // in, the load is aborted before a single byte was decoded.  Once any
  // byte has been emitted we know the signal pipeline is working, so a
  // subsequent 1.5s silence really does mean end-of-tape.
  //
  // Read _lastEdge atomically -- on AVR, 32-bit accesses are NOT atomic
  // (four separate byte loads), so without protection the ISR can update
  // the variable mid-read.  A torn read can produce a value much greater
  // than the current micros(), which makes the unsigned subtraction below
  // underflow to ~2^32 (= 4300 seconds), instantly tripping the timeout
  // and setting _done even though edges are arriving continuously.
  uint32_t lastEdgeSnapshot;
  noInterrupts();
  lastEdgeSnapshot = _lastEdge;
  interrupts();
  if (lastEdgeSnapshot != 0 && _state != WAIT_LEADER && _anyByteEmitted) {
      if ((micros() - lastEdgeSnapshot) > 1500000UL) {
          _done = true;
          return;
      }
  }

  // Drain ALL queued periods, not just one.  This is the SAVE-direction fix.
  // The ISR pushes one period per edge; if we processed only one per poll()
  // call, then any main-loop blocking (e.g. the 520us bit-banged SPI write
  // in RamExternal::writeByte) would let the queue grow indefinitely OR --
  // with the old single-slot variable -- silently lose periods, scrambling
  // bit phase from the first byte where a RAM write fires.
  //
  // _qHead is read once into a local; new ISR pushes after this point will
  // be picked up on the NEXT poll() call.  The slot read does not need the
  // interrupt mask because: (a) ISR only writes at _qHead which is always
  // ahead of _qTail when the queue is non-empty, (b) on AVR an 8-bit index
  // load is atomic, and (c) the queue is never overwritten in-place.
  uint8_t headSnap = _qHead;
  // Track high-water mark for diagnostics (lossless; never resets within a run).
  uint8_t occ = (uint8_t)((headSnap - _qTail) & PERIOD_QUEUE_MASK);
  if (occ > _diagQueueHighWater) _diagQueueHighWater = occ;

  if (_fastDrain) {
    // ORAO and the TRS-80 PC-1: drain ALL queued periods each poll.
    // ORAO: SPI-RAM writes (~520us) block long enough that several edges queue;
    //       draining all prevents lost periods / scrambled phase.
    // KCS:  each logical bit = 4-8 ISR events (4 cycles@1200Hz or 8@2400Hz),
    //       all arriving within one 3.33ms bit period.  With one-period-per-poll,
    //       an external RAM write can block long enough that events queue faster
    //       than they drain, causing phase slip and stop-bit errors on every byte.
    //       Draining the full queue each poll keeps cycle counting in phase.
    while (_qTail != headSnap) {
      uint32_t p = (uint32_t)_periodQueue[_qTail];
      _qTail = (uint8_t)((_qTail + 1) & PERIOD_QUEUE_MASK);
      handlePeriod(p);
    }
  } else {
    // Async (VIP / ELF II / KCS / DREAM): process AT MOST ONE period per poll,
    // exactly as the original decoder did.  These protocols were validated with
    // one-period-per-poll + half-cycle pairing.  Draining the whole queue in a
    // single poll() (added for ORAO) -- combined with the per-byte Serial print
    // in emitByte() running mid-drain -- regressed them, so the async path keeps
    // the original one-at-a-time cadence.  The 32-slot ring buffer still gives
    // far more cushion than the original single slot.
    if (_qTail != headSnap) {
      uint32_t p = (uint32_t)_periodQueue[_qTail];
      _qTail = (uint8_t)((_qTail + 1) & PERIOD_QUEUE_MASK);
      handlePeriod(p);
    }
  }
}

bool CassetteDecoder::periodToBit(uint32_t fullCycle, uint8_t& bit) {

  if (fullCycle >= _p->bit1_min && fullCycle <= _p->bit1_max) {
    bit = 1;
    _diagBit1++;
    return true;
  }
  if (fullCycle >= _p->bit0_min && fullCycle <= _p->bit0_max) {
    bit = 0;
    _diagBit0++;
    return true;
  }
  _diagOutOfRange++;
  return false;
}

// ---------------------------------------------------------------------------
// Feed ONE logical bit into the async UART state machine.
//
// Extracted from handlePeriod()'s KCS branch so it can be called more than once
// per half-period: the PC-1's round-to-nearest-cell rule (see handlePeriod)
// flushes a leftover run as a bit at the moment the tone changes, and then the
// current half-period may itself complete a second bit.  Behaviour for every
// existing protocol is unchanged -- this is the same switch, moved.
// ---------------------------------------------------------------------------
void CassetteDecoder::kcsFeedBit(uint8_t bit) {
  switch (_state) {
    case WAIT_LEADER:
      if (bit == _p->leaderBit) {
        if (_leaderCount < 0xFFFF) _leaderCount++;
        if (_leaderCount >= _p->leaderBits) {
          _state = WAIT_START; _startQual = 0;
          _cycle0Count = 0; _cycle1Count = 0;  // flush any partial burst
        }
      } else { _leaderCount = 0; }
      break;
    case WAIT_START:
      if (_startQual == 1 && _p->interByteTimeout_us > 0 &&
          (micros() - _waitStartTime) > _p->interByteTimeout_us) {
        _decodeFinished = true; _lastError = DECODE_ERR_TIMEOUT;
        _state = WAIT_LEADER; _leaderCount = 0; _startQual = 0;
        _waitStartTime = micros(); break;
      }
      if (bit == _p->startBit) {
        _state = READ_DATA; _bitCount = 0; _byte = 0; _parity = 0;
      }
      break;
    case READ_DATA:
      _byte |= (bit << _bitCount); _parity ^= bit; _bitCount++;

      // ---- TRS-80 PC-1: FOUR data bits, then resync on the next space ----
      // The PC-1 frame carries a nibble.  Clocking in eight bits and calling
      // the last four "the high nibble" only works if at least four WHOLE
      // mark cells follow every frame -- and that is not a property of the
      // machine, it is a property of one recording.  The reference WAVs have
      // a 4.57-cell mark tail so it happened to hold there; on real hardware
      // here the tail is shorter, the decoder runs into the NEXT frame's
      // start bit while still clocking "data", and the framing slips one bit
      // per frame.  That is the 7C 3C 1E 0F 78 rotation seen in the capture:
      // not a tone problem (oor was ~0 and drp was 0 throughout) but a frame
      // structure problem.
      //
      // Measured in tools/pc1_rx_sim.py by sweeping the mark tail length:
      //     tail >= 4.00 cells   8-bit frame OK      4-bit frame OK
      //     tail  = 3.74 cells   8-bit frame SLIPS   4-bit frame OK
      //     tail  = 0.25 cells   8-bit frame SLIPS   4-bit frame OK
      // Reading four bits and then waiting for the next space run makes the
      // tail length irrelevant by construction, which matters because
      // PC1_FINDINGS.md records that tail as DATA-DEPENDENT jitter (frame
      // period wanders 19.28-21.55 ms), i.e. not a constant to rely on.
      //
      // The high nibble is set to ones so everything downstream -- the
      // nibble packer in ReadData(), the .TAP layout, the checksum -- sees
      // exactly the 0xF0|nibble byte it saw before.  Nothing above this line
      // changes.
      if (_nibbleFrame && _bitCount == 4) {
        _byte |= 0xF0;
        emitByte();
        _state = WAIT_START; _startQual = 1; _waitStartTime = micros();
        // Flush the partial burst: the mark tail must not leak cycles into
        // the next frame's start-bit classification.
        _cycle0Count = 0; _cycle1Count = 0;
        break;
      }

      if (_bitCount == 8) {
        emitByte();
        // ---- stopBits == 0 means DO NOT VERIFY A STOP BIT ----------------
        // The TRS-80 PC-1's stop is a SHORT mark burst -- ~6 cycles of 4 kHz
        // (1.50 ms) against the 8 cycles a full bit cell needs.  The burst
        // counter below fires a logical '1' only at bit1_cycle*2 = 16 half-
        // cycles, so a 6-cycle stop NEVER completes a '1'.  The next thing
        // the decoder sees is the following frame's start-bit space, i.e. a
        // '0' where a stop was expected -> "STOP BIT ERROR" on every single
        // frame, and the framing slips one bit at a time.  That is exactly
        // the observed failure: captured bytes read 7C, 3E, 0F ... which are
        // the expected F8 shifted right by 1, 2, 3 bits.
        //
        // With stopBits == 0 there is nothing to verify, so return straight
        // to the start-bit hunt and FLUSH the partial burst so the short stop
        // cannot leak cycles into the next frame's classification.
        if (_p->stopBits == 0) {
          _state = WAIT_START; _startQual = 1; _waitStartTime = micros();
          _cycle0Count = 0; _cycle1Count = 0;
        } else {
          _state = READ_STOP; _stopCount = 0;
        }
      }
      break;
    case READ_STOP:
      if (bit == _p->stopBit) {
        if (++_stopCount >= _p->stopBits) {
          _state = WAIT_START; _startQual = 1; _waitStartTime = micros();
        }
      } else {
        if (_out) _out->println(F("STOP BIT ERROR"));
        _state = WAIT_START; _startQual = 1; _waitStartTime = micros();
      }
      break;
    default: break;
  }
}

void CassetteDecoder::handlePeriod(uint32_t us) {
  uint32_t fullCycle;

  if (_p && _p->framing == FRAMING_BLOCK_ORAO) {
    // ORAO: RISING interrupt -- `us` is already one full cycle. No pairing.
    fullCycle = us;
  } else if (_p && _p->framing == FRAMING_ASYNC_KCS) {
    // KCS: classify each HALF-PERIOD individually, bypassing full-cycle pairing.
    // Cross-frequency boundary pairs (last 2400Hz half + first 1200Hz half)
    // average ~623us, outside both the 1200Hz (700-1050) and 2400Hz (350-520)
    // full-cycle windows.  The self-aligning pairer slides on these and shifts
    // pairing phase by 1 half-cycle = 1 bit, producing stop-bit errors on
    // every single byte.  Working directly with half-periods eliminates this.
    //
    // Half-period windows (half of full-cycle windows):
    //   2400Hz half: bit1_min/2 .. bit1_max/2  (e.g. 150 .. 260 us)
    //   1200Hz half: bit0_min/2 .. bit0_max/2  (e.g. 300 .. 525 us)
    //
    // Bit counts: logical '0' = 4 cycles x 2 halves = 8 half-periods of 1200Hz
    //             logical '1' = 8 cycles x 2 halves = 16 half-periods of 2400Hz
    uint32_t h1_min = _p->bit1_min / 2, h1_max = _p->bit1_max / 2;
    uint32_t h0_min = _p->bit0_min / 2, h0_max = _p->bit0_max / 2;
    uint8_t b0thr = (uint8_t)(_p->bit0_cycle * 2);   // 4 cycles * 2 = 8
    uint8_t b1thr = (uint8_t)(_p->bit1_cycle * 2);   // 8 cycles * 2 = 16

    // Histogram EVERY half-period, in-range or not, in 25us buckets.  This is
    // the instrument that answers "are the accept windows right?" -- the live
    // us= field only ever shows periods that were ACCEPTED, so it is blind to
    // exactly the samples that matter when oor is climbing.  Printed after the
    // capture, so it costs two instructions here and no Serial time.
    // Gated on leader lock for the same reason as the run trace below: an
    // ungated histogram is dominated by the idle line before the machine ever
    // transmits.  The first hardware histogram showed ~60000 samples under
    // 100us and a smeared space peak -- almost all of it the idle input, which
    // is exactly the reading that talked an earlier build into widening the
    // accept windows and hanging the reader.  Measure the SIGNAL.
    // (histogram removed -- see the SRAM note in CassetteDecoder.h)

    uint8_t xbit;
    if (us >= h1_min && us <= h1_max) {
      // ---- ROUND EACH RUN TO THE NEAREST WHOLE BIT CELL --------------------
      // Counting halves and firing at a fixed threshold means a run that is
      // even ONE half-period short silently yields one bit too few.  On the
      // PC-1 that is not hypothetical: a hardware capture decoded every frame
      // as 0xF8 where 0xF0 was sent and 0xFC where 0xF8 was sent, i.e. one
      // spurious 1 at the top of every nibble.  Reproduced exactly in
      // tools/pc1_rx_sim.py by dropping a single half-period at each tone
      // transition -- the space run for nibble 0 is 5 cells = 40 halves, and
      // at 39 it fires only 4 bits, so the missing data bit gets taken from
      // the mark tail instead.
      //
      // Fix: when the tone CHANGES, a leftover of at least half a cell is a
      // cell that really happened, so emit it.  Equivalent to rounding the run
      // length to the nearest whole number of cells instead of truncating it,
      // which is the standard way to demodulate run-length FSK and tolerates
      // +/- half a cell of edge loss or edge noise per run.  Clean input has a
      // leftover of 0 and is completely unaffected.
      // NOT applied in WAIT_LEADER, on purpose: rounding up makes bits fire
      // more readily, and during leader hunt that only helps line noise
      // accumulate the 128 consecutive '1's needed to lock.  A build without
      // this guard could lock a leader on an idle input.  Rounding is only
      // needed once framing matters, i.e. from the start-bit hunt onwards.
      if (_nibbleFrame && _state != WAIT_LEADER &&
          _cycle0Count && (uint8_t)(_cycle0Count * 2) >= b0thr) {
        _cycle0Count = 0; kcsFeedBit(0);
      }
      xbit = 1; ++_cycle1Count; _cycle0Count = 0; _diagBit1++;
    } else if (us >= h0_min && us <= h0_max) {
      if (_nibbleFrame && _state != WAIT_LEADER &&
          _cycle1Count && (uint8_t)(_cycle1Count * 2) >= b1thr) {
        _cycle1Count = 0; kcsFeedBit(1);
      }
      xbit = 0; ++_cycle0Count; _cycle1Count = 0; _diagBit0++;
    } else {
      _cycle0Count = 0; _cycle1Count = 0; _diagOutOfRange++; return;
    }

    // ---- Run-length trace: record the raw tone structure, no framing -------
    // Gated on leader lock ON PURPOSE.  The first version of this recorded from
    // the very first classified half-period, which on a board with an idle
    // tapeIn means the 96-entry buffer fills with line noise before the machine
    // ever transmits, and the trace shows runs of 1-4 halves that say nothing
    // about the tape.  Recording only once the leader has locked puts the
    // buffer where the data is.
    // (run trace removed -- see the SRAM note in CassetteDecoder.h)
    _diagFullCycles++;
    _diagLastCycleUs = us * 2;   // report as approximate full-cycle for diagnostics
    if (us*2 < _diagMinCycleUs) _diagMinCycleUs = us*2;
    if (us*2 > _diagMaxCycleUs) _diagMaxCycleUs = us*2;

    uint8_t bit;
    // Fire logical bit at 8 halves (0-bit) or 16 halves (1-bit), using >= to
    // tolerate the occasional half that's one count short at burst boundaries.
    if (_cycle0Count >= b0thr) {
      bit = 0; _cycle0Count = 0; _cycle1Count = 0;
    } else if (_cycle1Count >= b1thr) {
      bit = 1; _cycle0Count = 0; _cycle1Count = 0;
    } else {
      return;
    }
    kcsFeedBit(bit);
    return;   // KCS handled; skip the full-cycle path below

  } else {
    // Async (VIP/ELF II/DREAM): the CHANGE interrupt delivers half-cycles.
    // Pair two halves into one full cycle, but SELF-ALIGN to the bit-cycle
    // boundary: a stored half + the current half is accepted only if it forms a
    // valid bit period; if it does not, the stored half was a leftover (we were
    // pairing across a bit boundary), so slide the window by one half-cycle and
    // retry on the next edge.  This locks onto the correct pairing phase by
    // itself instead of permanently fusing half of one bit with half of the
    // next -- the cause of the systematic misframe (random bytes + constant
    // PARITY ERROR) seen on real input even though the leader locked fine.
    if (!_haveHalf) {
      _halfAccum = us;
      _haveHalf  = true;
      return;
    }
    uint32_t cand = _halfAccum + us;
    uint8_t  probe;
    if (periodToBit(cand, probe)) {
      fullCycle = cand;       // valid full cycle on this phase -> accept it
      _haveHalf = false;
    } else {
      _halfAccum = us;        // not valid -> slide one half-cycle and keep
      return;                 // waiting (_haveHalf stays true) to re-align
    }
  }

  // Diagnostic tallies for the full cycle.
  _diagFullCycles++;
  _diagLastCycleUs = fullCycle;
  if (fullCycle < _diagMinCycleUs) _diagMinCycleUs = fullCycle;
  if (fullCycle > _diagMaxCycleUs) _diagMaxCycleUs = fullCycle;

  uint8_t bit;
  uint8_t xbit;
 
  if (!periodToBit(fullCycle, xbit)) {
    if (_state == READ_DATA && _startQual == 1) {
      // A single out-of-range cycle while reading data bytes USED to abort the
      // whole capture (back to WAIT_LEADER).  Mid-stream there is no new leader
      // to re-lock on, so one stray/jittery cycle after the first byte ended
      // the entire read -- the "read ends too soon / only 1 byte" symptom.
      // The first byte was already forgiving (it just drops the bad cycle), so
      // make every byte behave the same: drop this cycle and keep reading.
      // Genuine end-of-data is detected by the silence timeout (no edges) and
      // the inter-byte timeout in WAIT_START, not by a single bad cycle.
      return;
    }
    else if (_state == ORAO_HUNT_SYNC) {
      // During sync hunt, a single out-of-range cycle is *not* fatal.
      // Real-tape audio routinely produces a few jitter cycles per second
      // and falling back to WAIT_LEADER here means we'll never re-acquire
      // (the data block bits don't form a long-enough leader to satisfy
      // _leaderCount >= leaderBits).  Just drop the bad cycle and keep
      // the existing shift register so good bits before and after still
      // line up in the sliding-window match.
      return;
    }
    else if (_state == ORAO_READ_BLOCK || _state == ORAO_READ_RAW) {
      // Inside a block, an oor cycle USED TO bail out with _done = true on the
      // theory it would signal end-of-tape.  Real-hardware traces show
      // ~20-25% oor rate in the data block of phone-played audio, so a single
      // oor cycle hits within the first 1-2 bytes -- which means the load
      // ends before any meaningful data is emitted.  End-of-block is already
      // detected by byte count (252 in ORAO_READ_BLOCK, expected length in
      // OraoReceive's F_RAW_DATA state for ORAO_READ_RAW), and genuine
      // end-of-tape is handled by the silence-timeout in poll() (no edges for
      // 1.5s).  So inside a block we just drop the bad cycle and keep going,
      // accepting that we'll lose ONE bit and the byte it lands in.  This is
      // far less destructive than aborting the whole load.
      return;
    }
    else {return;}
  }

  if (xbit == 0) {
    ++_cycle0Count;
    _cycle1Count = 0;
  }
  if (xbit == 1) {
    ++_cycle1Count;
    _cycle0Count = 0;
  }

  // For KCS (FRAMING_ASYNC_KCS), use >= so that an occasional extra cycle at a
  // burst boundary doesn't prevent the bit from firing.  Other protocols keep
  // exact == matching.
  bool kcs = (_p->framing == FRAMING_ASYNC_KCS);
  if (_p->bit0_cycle > 0 && (kcs ? _cycle0Count >= _p->bit0_cycle
                                  : _cycle0Count == _p->bit0_cycle)) {
    bit = 0;
  } else if (_p->bit1_cycle > 0 && (kcs ? _cycle1Count >= _p->bit1_cycle
                                         : _cycle1Count == _p->bit1_cycle)) {
    bit = 1;
  } else {
    return;
  }
  _cycle0Count = 0;
  _cycle1Count = 0;

 switch (_state) {
    case WAIT_LEADER:
      if (bit == _p->leaderBit) {
        if (_leaderCount < 0xFFFF) _leaderCount++;
        // Async: lock onto leader as soon as the threshold is reached.
        // ORAO  : stay in WAIT_LEADER -- transition happens on the FIRST
        //         non-leader bit (which is bit 2 of the first $1B sync byte).
        // COMX  : also stay in WAIT_LEADER and transition on the first
        //         non-leader bit, which is the '1' start bit of the first
        //         10-cell frame (see the FRAMING_SYNC_COMX branch below).
        if (_p->framing != FRAMING_BLOCK_ORAO &&
            _p->framing != FRAMING_SYNC_COMX &&
            _leaderCount >= _p->leaderBits) {
          _state = WAIT_START;
          _startQual = 0;
        }
      } else {
        // Non-leader bit
        if (_p->framing == FRAMING_SYNC_COMX &&
            _leaderCount >= _p->leaderBits) {
          // COMX-35 leader-to-data transition.  The leader is a long run of
          // bit-0 cells; the first bit-1 we see is the START cell of the first
          // 10-cell frame.  A COMX frame is: start(1) + 8 data (LSB) + 1 framing
          // cell (value varies, ignored).  We've just consumed the start cell,
          // so begin assembling the 8 data bits.
          _byte     = 0;
          _bitCount = 0;
          _blockBytesRead = 0;
          _state    = COMX_READ_DATA;
          if (COMX_READ_DATA > _diagMaxState) _diagMaxState = COMX_READ_DATA;
        } else if (_p->framing == FRAMING_BLOCK_ORAO &&
            _leaderCount >= _p->leaderBits) {
          // ORAO leader-to-data transition.  The bit we just received is the
          // single 0-bit transition marker that the original Orao 2007 ROM
          // SAVE emits between the leader's last 1 and the first data bit.
          // We CONSUME this bit (don't store it) and start byte assembly fresh.
          _byte     = 0;
          _bitCount = 0;
          _syncMatch = 0;
          if (_oraoNextBlock == ORAO_NEXT_RAW) {
            // Real Orao 'O' format: data block has NO sync, just length+data.
            // OraoReceive sets this after consuming the 'O' header block.
            _state = ORAO_READ_RAW;
            _oraoNextBlock = ORAO_NEXT_SYNC;   // reset to default for any next file
            if (ORAO_READ_RAW > _diagMaxState) _diagMaxState = ORAO_READ_RAW;
          } else {
            _state = ORAO_HUNT_SYNC;
            _syncShift = 0;
            _syncHuntBits = 0;
            _diagSyncEnters++;
            if (ORAO_HUNT_SYNC > _diagMaxState) _diagMaxState = ORAO_HUNT_SYNC;
          }
        } else {
          _leaderCount = 0;
        }
      }
      break;

    // ---- COMX-35 bit-synchronous data assembly ----------------------------
    // 10-cell frame: start(1) + 8 data bits (LSB-first) + 1 framing cell.
    // The start cell was consumed by the WAIT_LEADER transition (first frame)
    // or by COMX_READ_FRAME (subsequent frames).  Here we collect the 8 data
    // bits, then move to COMX_READ_FRAME to swallow the trailing framing cell.
    case COMX_READ_DATA:
      _byte |= (bit << _bitCount);   // LSB-first, matching the ROM's SHRC builder
      _bitCount++;
      if (_bitCount == 8) {
        emitByte();
        _blockBytesRead++;
        // COMX PSAVE writes the program region as 257-byte BLOCKS separated by
        // ~180ms silence + a re-sync leader (and a block marker).  Without
        // boundary handling the decoder ran straight into that inter-block
        // region and captured the marker/leader cells as data -- corrupting the
        // byte at the 257-byte boundary (e.g. CE 0D became 00 01).  At the end
        // of a block, go back to leader hunt so the inter-block leader is
        // skipped exactly like the initial leader, and block 2 starts clean.
        if (_blockBytesRead >= COMX_BLOCK_BYTES) {
          _blockBytesRead = 0;
          _state       = WAIT_LEADER;
          _leaderCount = 0;
        } else {
          _state = COMX_READ_FRAME;
        }
      }
      break;

    // Consume the single trailing framing cell, then resync on the next start.
    // The framing cell's value is NOT fixed (verified across real captures), so
    // we do not test it -- we just consume one cell and hunt for the next
    // start bit (a '1').  Hunting for the '1' rather than blindly taking the
    // next cell as the start gives per-frame resync: if tape jitter dropped or
    // inserted a half-cycle, we re-lock on the next genuine start cell instead
    // of accumulating phase error (the failure mode that scrambled bytes when
    // this was tried as fixed-stride or as plain UART-async framing).
    case COMX_READ_FRAME:
      // `bit` here is the framing cell -- ignore its value.  The NEXT bit after
      // this is the start cell of the following frame, handled by re-using
      // WAIT_START-style hunting: switch to a tiny hunt that waits for '1'.
      _state     = WAIT_START;
      _startQual = 1;            // mark "mid-stream" so silence timeout can arm
      _waitStartTime = micros();
      break;

    case WAIT_START:
      if (_startQual == 1 && _p->interByteTimeout_us > 0 && (micros() - _waitStartTime) > _p->interByteTimeout_us) {
        _decodeFinished = true;
        _lastError = DECODE_ERR_TIMEOUT;
        _state = WAIT_LEADER;
        _leaderCount = 0;
        _startQual = 0;
        _waitStartTime = micros();
        break;
      }
      
      if (_p->framing == FRAMING_SYNC_COMX) {
        // COMX: the start cell is always '1'.  Hunt for it (ignore '0' framing
        // cells / stray bits); when found, begin the next 10-cell frame's data.
        if (bit == 1) {
          _state    = COMX_READ_DATA;
          _bitCount = 0;
          _byte     = 0;
        }
        break;
      }

      if (bit == _p->startBit) {
        _state = READ_DATA;
        _bitCount = 0;
        _byte = 0;
        _parity = 0;
      }
      break;

    case READ_DATA:
      if (_p->bitOrder == LSB_FIRST) {
        _byte |= (bit << _bitCount);
      } else {
        _byte = (_byte << 1) | bit;
      }
      _parity ^= bit;
      _bitCount++;
      if (_bitCount == 8) {
           if (_p->parity != PARITY_NONE) {
          _state = READ_PARITY;
        } else {
          emitByte();
          goto after_byte;
        }
      }
      break;

    case READ_PARITY:
      // Parity is advisory.  A mismatch logs a warning but does NOT discard the
      // capture: aborting to WAIT_LEADER on a single bad parity bit threw away
      // every byte read so far (the "read ends too soon after a few good bytes"
      // symptom -- e.g. VIP reading F8 FF 3E FF then PARITY ERROR and stopping).
      // Emit the byte and stay synced to the stream so one glitch costs at most
      // one suspect byte instead of the whole file.
      if (_out) {
        bool parityBad = (_p->parity == PARITY_ODD)  ? (((_parity ^ bit) & 1) != 1)
                       : (_p->parity == PARITY_EVEN) ? (((_parity ^ bit) & 1) != 0)
                       : false;
        if (parityBad) _out->println(F("PARITY ERROR"));
      }
      emitByte();
      goto after_byte;

after_byte:
      if (_p->stopBits > 0) {
        _state = READ_STOP;
        _stopCount = 0;
      } else {
        _state = WAIT_START;
        _startQual = 1;
        _waitStartTime = micros();
      }
      break;

    case READ_STOP:
      if (bit == _p->stopBit) {
        if (++_stopCount >= _p->stopBits) {
          _state = WAIT_START;
          _startQual = 1;
          _waitStartTime = micros();
          // Byte was already signalled by emitByte() in the after_byte path
          // before entering READ_STOP.  Setting _byteReady again here makes a
          // polling consumer read the same byte twice (every byte duplicated
          // for stopBits>0 protocols such as DREAM 6800).  So leave it alone.
        }
      } else {
        // Stop-bit mismatch is advisory too -- don't discard the capture.
        // Log it, but treat the byte boundary as done and continue reading the
        // next byte (stay synced) instead of aborting back to WAIT_LEADER.
        if (_out) _out->println(F("STOP BIT ERROR"));
        _state = WAIT_START;
        _startQual = 1;
        _waitStartTime = micros();
      }
      break;

    // -------- ORAO block-mode --------

    case ORAO_HUNT_SYNC:
      // Bit-shift register sync hunt.  We slide a 32-bit window over the
      // incoming bit stream and trigger when it matches 4×$1B in
      // little-endian-on-tape order.
      //
      // $1B = 0001 1011, sent LSB-first: bits in time order are 1,1,0,1,1,0,0,0.
      // Shifting each bit into LSB and pushing previous bits left, after 8
      // bits the register holds 0xD8 (the bit-reversed byte).  After 32
      // bits of sync, register == 0xD8D8D8D8.
      //
      // This handles the common real-hardware failure mode: a single
      // misclassified bit anywhere in or just before the sync sequence
      // would otherwise make the byte-aligned hunt see a non-$1B and abort.
      // With sliding hunt we recover within a few bits and lock cleanly.
      _syncShift = (_syncShift << 1) | (uint32_t)(bit & 1);
      _syncHuntBits++;
      if (_syncShift == 0xD8D8D8D8UL) {
        // Sync locked.  Byte-align here: next bit starts the type byte.
        _byte = 0;
        _bitCount = 0;
        _syncMatch = 4;
        _state = ORAO_READ_BLOCK;
        _blockBytesRead = 0;
        _diagSyncLocks++;
        if (ORAO_READ_BLOCK > _diagMaxState) _diagMaxState = ORAO_READ_BLOCK;
      } else if (_syncHuntBits > 96) {
        // Tried too long without finding sync (4×$1B = 32 bits, allow up to
        // 96 = some leader noise + sync + a bit of slack).  Bail to leader.
        _diagLastSyncShift = _syncShift;
        _diagSyncFails++;
        _state = WAIT_LEADER;
        _leaderCount = 0;
        _syncMatch = 0;
        _byte = 0;
        _bitCount = 0;
      }
      break;

    case ORAO_READ_BLOCK:
      // Same bit-to-byte assembly as ORAO_HUNT_SYNC, but every completed byte
      // is emitted to the consumer.  After 252 bytes the block is done and we
      // go back to leader hunt to wait for the next block (or end-of-tape).
      if (bit) _byte |= (uint8_t)(1 << _bitCount);
      _bitCount++;
      if (_bitCount == 8) {
        emitByte();
        _byte = 0;
        _bitCount = 0;
        _blockBytesRead++;
        if (_blockBytesRead >= 252) {
          _state = WAIT_LEADER;
          _leaderCount = 0;
          _syncMatch = 0;
        }
      }
      break;

    case ORAO_READ_RAW:
      // Real Orao 'O' data block: no sync, no fixed block size.  Every 8 bits
      // becomes a byte that's emitted to OraoReceive.  The receiver decides
      // when the file is complete based on the on-tape length header (the
      // first two bytes) and ends the session by stopping consumption (or by
      // letting the silence-timeout fire when the tape runs out).
      if (bit) _byte |= (uint8_t)(1 << _bitCount);
      _bitCount++;
      if (_bitCount == 8) {
        emitByte();
        _byte = 0;
        _bitCount = 0;
      }
      break;
  }
}

void CassetteDecoder::emitByte() {
  _lastByte = _byte;
  _byteReady = true;
  _anyByteEmitted = true;
  _diagBytesOut++;

  // Optional debug print.  During an ORAO block read this prints ~300us
  // of UART per byte (3-4 chars at 115200), which combined with the SPI
  // RAM write inside OraoReceive::feed would blow past one half-period of
  // headroom (~181us for bit-0).  The ring-buffer fix in poll() now
  // absorbs that latency safely, but we still skip the print inside ORAO
  // block states to leave maximum margin -- the per-byte stream isn't
  // useful diagnostic info anyway; the sticky counters in debug*() are.
  if (_out && _state != ORAO_READ_BLOCK && _state != ORAO_READ_RAW) {
    if (_byte < 0x10) _out->print('0');
    _out->print(_byte, HEX);
    _out->print(" ");
    if (_counter++ == 16 ) {_out->println(); _counter = 0;}
  }
}
