/*
Main Code by Josh Bensadon, with the help of some Libraries. :)
The regular Adafruit "TouchScreen.h" library only works on AVRs
Different mcufriend shields have Touchscreen on different pins and rotation.
Run the TouchScreen_Calibr_native sketch for calibration of your shield and substitute values in SystemConfig.h
Added Cassette protocol for VIP, ELF II and HEC/ETI660

User interface by Costas Skordis July 2025

All files can be found at https://github.com/cskordis/VIPTape.git
 

Version 0.5 - Refactored for new user interface and made code more modularized
Version 1.0  - Release new user interface with bug fixes to UI screen
Version 2.0  - Add logic to cater for KCS300, KCS1200, ELF II, HEC/ETI-660 and VIP cassette protocols
			       - Modularized functions
             - 0 = big endian (MSB-first), 1 = little endian (LSB-first)
             - Polarity, 0 = Low to High (Rising), 1 = High to Low ()
             - Refactored more to improve functionality and expandability. CassetteProtocols hold the definition of the cassette interfaces
             - Decoding and Encoding are done in seperate modules.
             - Removal of unused variables and arrays.
             - must be used on VIPTAPE PCB version 2 and above that uses D18 for the input pin with updated LM358 op amp / comparator circuit
             - save last mode type to SD to set up the modetype on reboot
Version 3.0  - Add logic to cater for ORAO cassette protocols            
Version 3.0a - Add logic if Yes button is depressed at boot up will toggle the SERIALDEBUG flag
Version 4.0a - Add COMX 35 protocol
Version 4.0b - Add ET3400 protocol
Version 4.0c - Save current folder and default to it at startup
Version 5.0  - Add TRS80 Pocket Computer PC1 and PC2 protocols
*/
#include <Adafruit_GFX.h>
#include <TouchScreen.h>
#include <SD.h>
#include <SPI.h>
#include <stdint.h>
#include "SplashImage.h"
#include "SystemConfig.h"
#include "Utility.h"
#include "RamExternal.h"
#include "FileLoader.h"
#include "Display.h"
#include "CassetteParams.h"
#include "CassetteProtocols.h"
#include "CassetteDecoder.h"
#include "CassetteEncoder.h"
#include "ComxBasic.h"
#include "Pc1Basic.h"
#include "Pc2Basic.h"
#include "TinyBasConvert.h"
#include "OraoReceive.h"

uint8_t currentProtocol = DEFAULT_MODE;
uint8_t lastProtocol = DEFAULT_MODE;
CassetteEncoder cassetteEncoder(tapeOut);
CassetteDecoder cassetteDecoder(tapeIn, &cassetteProtocols[currentProtocol]);

unsigned long highStartUs = 0;
bool lastLevel = LOW;
uint32_t lastByteTime = 0;

/* Initialize TouchScreen */
TouchScreen ts = TouchScreen(XP, YP, XM, YM, 300);

// Button objects
Adafruit_GFX_Button up_btn, down_btn, next_btn, prev_btn, yes_btn, no_btn, play_btn, rec_btn;

// Setup external ram
RamExternal ram(ramCS, ramMOSI, ramMISO, ramCLK);
uint32_t ramAddr = 0;

FileLoader loader(ram);

/* File system variables */
File root;
File myFile;

// Global variables for touch coordinates
String currentFile = "";
String currentName = "";
String currentPath = "/";
int fileCount = 0;
int currentIndex = 0;
int displayStart = 0;
int actionFlag = 0;          // Flag to drive current Record or Play logic. 0 - Record or 1 - Play or 2 - Yes/No
String fileList[MAX_ARRAY];  // Array to store file/directory names
char fileName[16];

/*File and SRAM attributes*/
uint16_t startAddr = 0;
uint16_t endAddr = 0;
String fileExt = "";
unsigned long fileSize = 0;

// Runtime debug flag.  Backs the SERIALDEBUG name used everywhere via the
// extern declaration in SystemConfig.h.  Starts at SERIALDEBUG_BOOT_DEFAULT
// and is set to 1 in setup() if BUTTON_YES is held during boot, so a
// debug session can be toggled on without reflashing.
//   0 - disabled, 1 - enabled, 2 - verbose
uint8_t SERIALDEBUG = SERIALDEBUG_BOOT_DEFAULT;

long pages = 0;  // Number of 255 byte pages

/* Screen saver variables*/
unsigned long lastActivityTime = 0;  // Timestamp of the last user activity
bool screensaverActive = false;      // Flag to indicate screensaver state
int hangTime = 0;                    // default hangtime for displays

// Keyboard layout (simplified: A-Z, 0-9, _, ., *)
const char keys[7][6] = {
  { 'A', 'B', 'C', 'D', 'E', 'F' },
  { 'G', 'H', 'I', 'J', 'K', 'L' },
  { 'M', 'N', 'O', 'P', 'Q', 'R' },
  { 'S', 'T', 'U', 'V', 'W', 'X' },
  { 'Y', 'Z', '0', '1', '2', '3' },
  { '4', '5', '6', '7', '8', '9' },
  { '_', '.', ' ', '@', ' ', '*' }
};

int keyboardEntry = 0;
// saveFilename storage
char saveFilename[FILENAME_SIZE] = "";  // Max characters + null terminator
int saveFilenameLength = 0;

/* Buttons */
String pressed;
int touched;
// Structure to hold button state for debouncing
struct ButtonState {
  int currentState;                // Current state of the button
  int lastState;                   // Previous state of the button
  unsigned long lastDebounceTime;  // Last time the button was toggled
};

ButtonState buttonStates[BUTTONS];                                           // Array to store state for each button
const unsigned long debounceDelay = 50;                                      // Debounce time in milliseconds
const int buttonPins[] = { BUTTON_UP, BUTTON_DOWN, BUTTON_YES, BUTTON_NO };  // Array of button pins
const int numButtons = BUTTONS;                                              // Number of buttons

int selectedItem = 0;  // Currently selected item index
int currentPage = 0;   // Current page number
unsigned long lastDebounceTime = 0;

// Define touch areas (for 240x320 portrait orientation)
int numAreas;

struct ButtonCoords {
  uint16_t xMin, xMax, yMin, yMax;
  const char *name;
};

const uint8_t numValidButtons[NUM_SCREENS] = { 6, 6, 2 };

ButtonCoords screenButtons[NUM_SCREENS][NUM_BUTTONS] = {
  {
    { 0, 40, 0, 40, "Up" },
    { 45, 195, 0, 40, "Type" },
    { 200, 240, 0, 40, "Down" },
    { 0, 40, 270, 310, "Prev" },
    { 200, 240, 270, 310, "Next" },
    { 100, 140, 270, 310, "Record" },
  },
  {
    { 0, 40, 0, 40, "Up" },
    { 45, 195, 0, 40, "Type" },
    { 200, 240, 0, 40, "Down" },
    { 0, 40, 270, 310, "Prev" },
    { 200, 240, 270, 310, "Next" },
    { 100, 140, 270, 310, "Play" },
  },
  {
    { 0, 40, 270, 310, "Yes" },
    { 200, 240, 270, 310, "No" },
  },
};


bool getLastPath() {
  currentPath = "/"; // default / safe value

  File f = SD.open("_DIR.CFG", FILE_READ);
  if (!f) return false;

  f.seek(0);

  if (!f.available()) {   // empty file
    f.close();
    return false;
  }

  String v = f.readStringUntil('\n');
  f.close();
  v.trim();

  if (SERIALDEBUG) {
    Serial.print(F("Read path "));
    Serial.println(v);
  }

  if (v.length() > 0 && v.startsWith("/")) {
    // Confirm the saved directory still actually exists on this card --
    // if it was removed/renamed since last time, fall back to "/" rather
    // than getting stuck trying to browse a path that's no longer there.
    if (v == "/" || SD.exists(v)) {
      currentPath = v;
      return true;
    }
  }

  // invalid/stale path in file
  return false;
}

bool saveLastPath() {
  static String lastSavedPath = "";
  if (lastSavedPath == currentPath) { return true; }
  SD.remove("_DIR.CFG");
  File f = SD.open("_DIR.CFG", FILE_WRITE);
  if (!f) {
    if (SERIALDEBUG) Serial.println(F("Open failed"));
    return false;
  }

  f.seek(0);
  f.println(currentPath);
  f.close();

  lastSavedPath = currentPath;
  return true;
}

bool getLastMode() {
  lastProtocol = DEFAULT_MODE; // default / safe value

  File f = SD.open("_PRO.CFG", FILE_READ);
  if (!f) return false;

  f.seek(0);

  if (!f.available()) {   // empty file
    f.close();
    return false;
  }

  long v = f.parseInt();  // parse as long to avoid uint8 wrap issues
  f.close();

  if (SERIALDEBUG) {
    Serial.print(F("Read protocol "));
    Serial.println(v);
  }

  if (v >= 0 && v < cassetteProtocolCount) {
    currentProtocol = (uint8_t)v;
    lastProtocol    = (uint8_t)v;
    return true;
  }

  // invalid number in file
  return false;
}

bool saveLastMode() {
  if ((int)lastProtocol == (int)currentProtocol) {return true;}
  SD.remove("_PRO.CFG");
  File f = SD.open("_PRO.CFG", FILE_WRITE);
  if (!f) {
    if (SERIALDEBUG) Serial.println(F("Open failed"));
    return false;
  }

  f.seek(0);
  f.println((int)currentProtocol); 
  f.close();

  if (SERIALDEBUG) {
     Serial.println();
     Serial.println(F("Protocol saved "));
     Serial.println((int)currentProtocol);
     }
  return true;
}

// ------------------------------------------------------------------
// PROTOCOL SELECTION
// ------------------------------------------------------------------

void nextProtocol() {
  currentProtocol++;
  if (currentProtocol >= cassetteProtocolCount)
    currentProtocol = 0;

  applyProtocol();
}

void prevProtocol() {
  if (currentProtocol == 0)
    currentProtocol = cassetteProtocolCount - 1;
  else
    currentProtocol--;

  applyProtocol();
}

void applyProtocol() {
  const CassetteParams *p = &cassetteProtocols[currentProtocol];
  cassetteDecoder.setParams(p);
  cassetteEncoder.setParams(p);
  cassetteDecoder.reset();
}

bool eraseRam(uint32_t sizeBytes) {
  const uint32_t step = sizeBytes / 10;  // 10% progress
  uint32_t nextMark = step;
  uint8_t pct = 0;

  if (SERIALDEBUG) {
    Serial.println(F("Erasing AND TESTING external ram with 0xFF"));
    Serial.println(F("Press 'NO' button to abort"));
  }
  tft.setTextColor(YELLOW, BACKGROUND);
  tft.setCursor(0, tft.height() - 120);
  tft.println("Clearing RAM");
  tft.setCursor(tft.width() - 20, tft.height() - 120);
  tft.print("%");
  for (uint32_t addr = 0; addr < sizeBytes; addr++) {
    ram.writeByte((uint16_t)addr, 0x00);
    uint8_t v = ram.readByte((uint16_t)addr);
    if (v != 0x00) {
      if (SERIALDEBUG) {
        Serial.print(F("SRAM ERROR at 0x"));
        Serial.print(addr, HEX);
        Serial.print(F(" read "));
        Serial.println(v, HEX);
      }
      char addrStr[5];
      sprintf(addrStr, "%04X", addr);
      tft.setCursor(tft.width(), tft.height() - 100);
      tft.setTextColor(BLACK, RED);
      tft.print(String("Error at ") + addrStr);
      tft.setTextColor(FOREGROUND, BACKGROUND);
      delay(1000);
      return false;
    }
    if (digitalRead(BUTTON_NO) == LOW) {
      if (SERIALDEBUG) { Serial.println(F("SRAM erase/test CANCELED")); }
      centerText(tft, "Cancelled", tft.height() - 100, 0, RED, BLACK, 2);
      delay(1000);
      return false;
    }
    if (addr >= nextMark && pct < 100) {
      pct += 10;
      nextMark += step;
      if (SERIALDEBUG) {
        Serial.print(F("Clearing RAM "));
        Serial.print(pct);
        Serial.println(F("%"));
      }
      tft.setCursor(tft.width() - 55, tft.height() - 120);
      tft.print(pct);
      delay(5);
    }
  }
  if (SERIALDEBUG) { Serial.println(F("SRAM erase + test PASSED (100%)")); }
  tft.setCursor(tft.width() - 30, tft.height() - 120);
  tft.setTextColor(WHITE, GREEN);
  tft.print("OK");
  return true;
}

void setup() {

  // Boot-time debug override: if BUTTON_YES is held during reset/power-on,
  // force SERIALDEBUG = true regardless of SERIALDEBUG_BOOT_DEFAULT.  This is
  // the very first thing setup() does so we can decide whether to bring up
  // Serial below.  pinMode + a brief settle delay are enough; INPUT_PULLUP
  // gives HIGH when idle, LOW when the button is grounded.
  pinMode(BUTTON_YES, INPUT_PULLUP);
  delay(20);                                   // let the internal pull-up settle
  if (digitalRead(BUTTON_YES) == LOW) {
    if (SERIALDEBUG > 0) {SERIALDEBUG=0;}
    else {SERIALDEBUG=1;}
  }
  /*Initialize Serrial if flagged to start*/
  if (SERIALDEBUG) {
    Serial.begin(SERIAL_BAUD);
    delay(1000);
    Serial.println(F(""));
    Serial.println(F("Starting....."));
  }

  /* Initialize TFT */
  tft.reset();
  tft.begin(tft.readID());
  tft.setRotation(0);  // Portrait orientation
  tft.fillScreen(BLACK);
  tft.setTextColor(WHITE);
  tft.setTextSize(TEXTSIZE);

   // Start decoder
  cassetteDecoder.begin(Serial);

  /* Initialize external ram */
  ram.begin();
  ramAddr = 0;
  /* Initialize SD card */
  if (!SD.begin(SD_CS)) {
    tft.setTextColor(RED);
    tft.setCursor(10, 10);
    tft.println("SD Card Init Failed");
    while (1);
  }
  /* get last saved protocol*/
  getLastMode();
  applyProtocol();

  // Initialize SPI
  SPI.begin();
  delay(500);
  pinMode(SS, OUTPUT);

  // Initialize external 23LC512 SRAM (used by the "decode to SRAM" path)
  /*Set up modes*/

  pinMode(BUTTON_YES, INPUT_PULLUP);
  pinMode(BUTTON_NO, INPUT_PULLUP);
  pinMode(BUTTON_UP, INPUT_PULLUP);
  pinMode(BUTTON_DOWN, INPUT_PULLUP);

  pinMode(tapeOut, OUTPUT);
  cassetteEncoder.pulseBit(0);

  // --- COMX timing self-check -------------------------------------------
  // The COMX needs bit-0 ~500us and bit-1 ~1220us full-cycle on the WIRE.
  // delayMicroseconds() + loop overhead vary per board, so here we MEASURE
  // what VIPTAPE actually emits for the COMX protocol and print it, so the
  // ENC_CAL_* constants in CassetteEncoder.h can be trimmed to hit target.
  // Runs only with SERIALDEBUG on; emits a brief burst on tapeOut.
  if (SERIALDEBUG && currentProtocol==7) {
    int comxIdx = -1;
    for (uint8_t i = 0; i < cassetteProtocolCount; i++) {
      if (cassetteProtocols[i].framing == FRAMING_SYNC_COMX) { comxIdx = i; break; }
    }
    if (comxIdx >= 0) {
      cassetteEncoder.configure(&cassetteProtocols[comxIdx]);
      const uint16_t N = 200;
      // Measure with interrupts ENABLED (micros() needs Timer0; it freezes
      // under noInterrupts()).  delayMicroseconds() is a busy-wait so timing
      // stays accurate either way; we're only timing the loop, not driving
      // the COMX.
      unsigned long t0 = micros();
      for (uint16_t i = 0; i < N; i++) cassetteEncoder.pulseBit(0);
      unsigned long t1 = micros();
      for (uint16_t i = 0; i < N; i++) cassetteEncoder.pulseBit(1);
      unsigned long t2 = micros();
      float c0 = (float)(t1 - t0) / N;
      float c1 = (float)(t2 - t1) / N;
      Serial.println(F("--- COMX timing self-check ---"));
      Serial.print(F("bit0 cell measured: ")); Serial.print(c0,1);
      Serial.println(F(" us  (target 408)"));
      Serial.print(F("bit1 cell measured: ")); Serial.print(c1,1);
      Serial.println(F(" us  (target 1043)"));
      Serial.print(F("cal overhead=")); Serial.print(ENC_CAL_OVERHEAD_US);
      Serial.println(F("us/half"));

      // Validity gate: only act on a sane reading (bit1 must be the longer
      // tone; both in plausible range).  Prevents a glitched measurement from
      // emitting a bogus correction.
      bool sane = (c0 > 50.0f && c0 < 5000.0f &&
                   c1 > 50.0f && c1 < 8000.0f &&
                   c1 > c0 * 1.5f);
      if (!sane) {
        Serial.println(F("MEASUREMENT INVALID - ignoring."));
      } else if (c0 < 395.0f || c0 > 425.0f) {
        // Each 1us of ENC_CAL_OVERHEAD_US changes the bit0 CELL by ~2us/half.
        // To move c0 toward the ~455us target:
        long suggest = (long)ENC_CAL_OVERHEAD_US + (long)((c0 - 408.0f) / 2.0f + 0.5f);
        if (suggest < 0)  suggest = 0;
        if (suggest > 120) suggest = 120;
        Serial.print(F("suggest ENC_CAL_OVERHEAD_US=")); Serial.println(suggest);
      } else {
        Serial.println(F("bit0 within target window - timing looks good."));
      }
      Serial.println(F("------------------------------"));
      digitalWrite(tapeOut, LOW);
    }
  }

  pinMode(tapeIn, INPUT);
  digitalWrite(tapeIn, HIGH);

  for (int i = 0; i < numButtons; i++) {
    pinMode(buttonPins[i], INPUT_PULLUP);  // Button pins with internal pull-up
    // Initialize button states
    buttonStates[i].currentState = HIGH;
    buttonStates[i].lastState = HIGH;
    buttonStates[i].lastDebounceTime = 0;
  }
  

  /* Navigation buttons*/
  up_btn.initButton(&tft, tft.width() - 218, tft.height() - 300, 40, 40, WHITE, CYAN, BLACK, "Up", 2);
  down_btn.initButton(&tft, tft.width() - 28, tft.height() - 300, 50, 40, WHITE, CYAN, BLACK, "Down", 2);

  next_btn.initButton(&tft, tft.width() - 28, tft.height() - 22, 50, 40, WHITE, YELLOW, BLACK, "Next", 2);
  prev_btn.initButton(&tft, tft.width() - 212, tft.height() - 22, 50, 40, WHITE, YELLOW, BLACK, "Prev", 2);

  play_btn.initButton(&tft, tft.width() - 115, tft.height() - 22, 60, 40, WHITE, CYAN, BLACK, "Play", 2);
  rec_btn.initButton(&tft, tft.width() - 120, tft.height() - 22, 90, 40, WHITE, RED, BLACK, "Record", 2);

  yes_btn.initButton(&tft, tft.width() - 212, tft.height() - 22, 50, 40, WHITE, CYAN, BLACK, "Yes", 2);
  no_btn.initButton(&tft, tft.width() - 28, tft.height() - 22, 50, 40, WHITE, RED, BLACK, "No", 2);
  
  tft.fillScreen(BACKGROUND);
  if (DISPLAY_TITLE) { displayTitle(1000); }
  if (RAMTEST) {
    eraseRam(RAMSIZE);
    delay(1000);
  }
  if (DISPLAY_SPLASH) { showScreenSaver(1000); }
  ResetMode(1);
  /* restore last saved directory path -- must come AFTER ResetMode(1),
     which unconditionally resets currentPath to "/" */
  getLastPath();
  loadDirectory(currentPath);
  displayFiles(1);
  lastActivityTime = millis();  // Initialize activity time
}

/* Button debounce method to return button pressed*/
bool debounceButton(int index) {
  bool buttonPressed = false;
  int reading = digitalRead(buttonPins[index]);

  // Check if the button state has changed
  if (reading != buttonStates[index].lastState) {
    buttonStates[index].lastDebounceTime = millis();  // Reset debounce timer
  }

  // Check if the button state has been stable for the debounce delay
  if ((millis() - buttonStates[index].lastDebounceTime) > debounceDelay) {
    if (reading != buttonStates[index].currentState) {
      buttonStates[index].currentState = reading;
      // Detect button press (LOW due to INPUT_PULLUP)
      if (buttonStates[index].currentState == LOW) {
        buttonPressed = true;
        lastActivityTime = millis();  // Reset activity timer
      }
    }
  }

  buttonStates[index].lastState = reading;
  return buttonPressed;
}

/* Display file attributes */
void displayInfo(uint16_t startAddr, uint16_t endAddr, uint32_t fileSize, String fileExt) {
  int dotIndex = currentName.lastIndexOf('.');
  String fname;

  if (dotIndex != -1) {
    fname = currentName.substring(0, dotIndex);
  } else {
    fname = currentName;
  }

  tft.fillScreen(BACKGROUND);
  centerText(tft, "File To Be Loaded", 10, 0, BLUE, CYAN, 2);
  centerText(tft, fname.c_str(), 40, 0, WHITE, BACKGROUND, 2);
  tft.setCursor(228, 40);
  tft.print(fileExt);
  if (fileExt == 'H') {
    centerText(tft, "Hex Mode", 55, 0, BLUE, GREEN, 2);
    tft.setTextColor(YELLOW, BLUE);
    if (SERIALDEBUG) { Serial.println(F("Hex Mode")); }
  }
  tft.setCursor(0, 80);
  tft.print("Bytes: ");
  tft.print(fileSize);
  tft.setCursor(0, 100);
  if (currentProtocol == 5 || currentProtocol == 6) {tft.print("Blocks: ");}
  else {tft.print("Pages: ");}
  tft.print((fileSize + 255) / 256);
  if (fileExt != "H") {
    if (currentProtocol == 0 || currentProtocol == 1) {
      startAddr = 0;
      endAddr = fileSize - 1;
    } else if (currentProtocol == 2) {
      startAddr = 1536;
      endAddr = startAddr + endAddr;
    } else if (currentProtocol == 3) {
      startAddr = 512;
      endAddr = startAddr + endAddr;
    } else if (currentProtocol == 5 || currentProtocol == 6) {
      startAddr = 1024;
      endAddr = startAddr + endAddr;
    }
  }
  char hexStart[5];
  char hexEnd[5];
  sprintf(hexStart, "%04X", startAddr);
  sprintf(hexEnd, "%04X", endAddr);
  tft.setCursor(0, 120);
  tft.print("Start Address : " + String(hexStart));
  tft.setCursor(0, 140);
  tft.print("End Address   : " + String(hexEnd));
  centerText(tft, "Proceed?", 160, 0, BLUE, YELLOW, 2);
}


/* Display files and directories of the current page */
void displayFiles(int erase) {
  if (erase == 1) { tft.fillScreen(BACKGROUND); }
  const CassetteParams *p = cassetteDecoder.getParams();
  if (p) {
    centerText(tft, p->name, 10, 0, WHITE, BLUE, TEXTSIZE);
    if (SERIALDEBUG) { Serial.println(p->name); }
  }
  drawButtons(); /*Draw navigation buttons*/

  String dirName = currentPath;
  if (dirName == "/") { dirName = "Root"; }
  tft.setTextColor(WHITE);
  root.rewindDirectory();
  centerText(tft, dirName.c_str(), FILE_DISP, 0, WHITE, BLUE, TEXTSIZE);

  tft.setTextSize(TEXTSIZE);
  if (SERIALDEBUG) {
    Serial.print(F("Directory : ")); Serial.println(dirName);
    Serial.println(F("File List"));
  }

  // Display files
  for (int i = 0; i < ITEMS_PER_PAGE; i++) {
    int fileIndex = displayStart + i;
    if (fileIndex >= fileCount) break;

    // Highlight current selection
    if (fileIndex == currentIndex) {
      tft.fillRect(0, ((i + 1) * CHAR_HEIGHT) + TOP_DISP, tft.width(), CHAR_HEIGHT, YELLOW);
      tft.setTextColor(BLACK);
    } else {
      tft.setTextColor(WHITE);
    }
    tft.setCursor(0, ((i + 1) * CHAR_HEIGHT) + TOP_DISP);
    tft.println(fileList[fileIndex]);
    if (SERIALDEBUG) { Serial.println(fileList[fileIndex]); }
  }
}

/* Display file attributes */
void displayFileToSaveInfo() {
  tft.fillScreen(BACKGROUND);
  centerText(tft, "File To Save", 10, 0, BLUE, CYAN, 2);
  tft.setCursor(0, 30);
  tft.setTextColor(YELLOW, BLUE);
  tft.println(currentFile);
  tft.setCursor(228, 30);
  centerText(tft, "Proceed To Save", 120, 0, BLUE, YELLOW, 2);
}

void displayTitle(int hangTime) {
  tft.fillScreen(BACKGROUND);
  centerText(tft, TITLE, 5, 0, YELLOW, BACKGROUND, 3);
  centerText(tft, VERSION, 40, 0, FOREGROUND, BACKGROUND, 2);
  /*Special messaging*/
  centerText(tft, MESSAGE1, 70, 0, FOREGROUND, BACKGROUND, 2);
  centerText(tft, MESSAGE2, 90, 0, FOREGROUND, BACKGROUND, 2);

  centerText(tft, MESSAGE3, 120, 0, FOREGROUND, BACKGROUND, 2);
  centerText(tft, MESSAGE4, 140, 0, FOREGROUND, BACKGROUND, 2);
  tft.setTextSize(2);

  if (SERIALDEBUG) { Serial.println(VERSION); }
  if (hangTime > 0) { delay(hangTime); }
}

/* Directory methods */
bool fileEntryGreater(const String &a, const String &b);   // forward declaration
void loadDirectory(String path) {
  // Clear previous list
  fileCount = 0;
  for (int i = 0; i < MAX_FILECOUNT; i++) {
    fileList[i] = "";
  }
  // Open directory
  root = SD.open(path);
  if (!root) {
    tft.fillScreen(BACKGROUND);
    tft.setCursor(0, 0);
    tft.println("Failed to open directory!");
    return;
  }
  // If not root, add parent directory option
  if (path != "/") {
    fileList[fileCount] = "..";
    fileCount++;
  }
  // Read directory contents
  while (true) {
    File entry = root.openNextFile();
    if (!entry) break;
    String name = String(entry.name());
    if (name.equalsIgnoreCase("System Volume Information") || name.equalsIgnoreCase("SYSTEM~1")) {
      continue;
    } else if (name.equalsIgnoreCase(".Trashes") || name.equalsIgnoreCase("$RECYCLE.BIN")) {
      continue;
    } else if (name.length() >= 4 && name.substring(name.length() - 4).equalsIgnoreCase(".CFG")) {
      continue;
    } else if (name.charAt(0) == '.')  {
      continue;
    }
    if (fileCount < MAX_FILECOUNT) {
      fileList[fileCount] = String(entry.name());
      if (entry.isDirectory()) {
        fileList[fileCount] += "/";
      }
      fileCount++;
    }
    entry.close();
  }
  root.close();

  /* Sort the list alphabetically (case-insensitive), keeping ".." pinned at the
     top and grouping directories (names ending in '/') before files.  Insertion
     sort -- fileCount is small (<= MAX_FILECOUNT) so this is fast and needs no
     extra memory. */
  {
    // The ".." entry, if present, is always at index 0; leave it there.
    int firstSortable = (fileCount > 0 && fileList[0] == "..") ? 1 : 0;
    for (int i = firstSortable + 1; i < fileCount; i++) {
      String key = fileList[i];
      int j = i - 1;
      while (j >= firstSortable && fileEntryGreater(fileList[j], key)) {
        fileList[j + 1] = fileList[j];
        j--;
      }
      fileList[j + 1] = key;
    }
  }

  /* Reset selection */
  currentIndex = 0;
  displayStart = 0;
}

/* Order comparison for the file browser: directories (trailing '/') come before
   files; within each group, compare names case-insensitively.  Returns true if
   entry 'a' should sort AFTER entry 'b'. */
bool fileEntryGreater(const String &a, const String &b) {
  bool aDir = a.endsWith("/");
  bool bDir = b.endsWith("/");
  if (aDir != bDir) return !aDir;          // a is a file, b a dir -> a is greater
  // Same group: case-insensitive lexical compare.
  int la = a.length(), lb = b.length();
  int n = (la < lb) ? la : lb;
  for (int k = 0; k < n; k++) {
    char ca = a[k], cb = b[k];
    if (ca >= 'a' && ca <= 'z') ca -= 32;
    if (cb >= 'a' && cb <= 'z') cb -= 32;
    if (ca != cb) return ca > cb;
  }
  return la > lb;                           // prefix ties: longer name sorts later
}

void navigateToSelection(int display) {
  // Handle directory navigation
  if (fileList[currentIndex] == "..") {
    // Go up one directory
    int lastSlash = currentPath.lastIndexOf('/', currentPath.length() - 2);
    if (lastSlash >= 0) {
      currentPath = currentPath.substring(0, lastSlash + 1);
      loadDirectory(currentPath);
      saveLastPath();
    }
  } else if (fileList[currentIndex].endsWith("/")) {
    // Enter directory
    currentPath += fileList[currentIndex];
    loadDirectory(currentPath);
    saveLastPath();
  }
  if (display) { displayFiles(1); }
}

void moveSelection(int delta) {
  int newIndex = currentIndex + delta;

  // Constrain index
  if (newIndex < 0) newIndex = 0;
  if (newIndex >= fileCount) newIndex = fileCount - 1;

  // Update display start if needed
  if (newIndex < displayStart) {
    displayStart = newIndex - (newIndex % ITEMS_PER_PAGE);
  }
  if (newIndex >= displayStart + ITEMS_PER_PAGE) {
    displayStart = newIndex - (ITEMS_PER_PAGE - 1);
  }

  // Update selection
  currentIndex = newIndex;
  displayFiles(1);
}

void drawButtons() {
  if (SERIALDEBUG) { Serial.print(F("Action Flag: ")); Serial.println(actionFlag); }
  if (actionFlag == 0) {
    down_btn.drawButton(false);
    next_btn.drawButton(false);
    prev_btn.drawButton(false);
    up_btn.drawButton(false);
    rec_btn.drawButton(false);

  } else if (actionFlag == 1) {
    down_btn.drawButton(false);
    next_btn.drawButton(false);
    prev_btn.drawButton(false);
    up_btn.drawButton(false);
    play_btn.drawButton(false);

  } else if (actionFlag == 2) {
    yes_btn.drawButton(false);
    no_btn.drawButton(false);
  }
}
void drawKeyboard() {
  tft.fillRect(10, 10, tft.width() - 20, 40, GRAY);
  tft.setCursor(15, 25);
  tft.setTextColor(BLACK);
  tft.setTextSize(2);
  tft.print(saveFilename);

  for (int row = 0; row < 7; row++) {
    for (int col = 0; col < 6; col++) {
      int x = BUTTON_START_X + col * (BUTTON_WIDTH + BUTTON_SPACING);
      int y = BUTTON_START_Y + row * (BUTTON_HEIGHT + BUTTON_SPACING);
      tft.fillRect(x, y, BUTTON_WIDTH, BUTTON_HEIGHT, BLUE);
      tft.setCursor(x + 12, y + 10);
      tft.setTextColor(WHITE);
      tft.setTextSize(2);
      if (keys[row][col] == '*') {
        tft.print("OK");
      } else if (keys[row][col] == '@') {
        tft.print("<<");
      } else {
        tft.print(keys[row][col]);
      }
    }
  }
}

void updatesaveFilenameDisplay() {
  // Clear saveFilename area
  tft.fillRect(10, 10, tft.width() - 20, 40, GRAY);
  // Display updated saveFilename
  tft.setCursor(15, 25);
  tft.setTextColor(BLACK);
  tft.setTextSize(2);
  tft.print(saveFilename);
}

String buildBaseName(const String &baseFile, uint32_t number, int totalLen) {
  String result = baseFile;
  if (result.length() > totalLen)
    result = result.substring(0, totalLen);
  int missing = totalLen - result.length();
  if (missing > 0) {
    // Make a padded number wide enough
    char buf[16];
    snprintf(buf, sizeof(buf), "%015lu", (unsigned long)number);
    int bufLen = strlen(buf);
    const char *tail = buf + (bufLen - missing);
    result += tail;  // append just enough digits to reach totalLen
  }
  return result;
}

// Convert a raw 10-byte, space-padded tape-header filename into a safe SD
// filename.  Trailing pad spaces are trimmed, letters are upper-cased, anything
// that isn't A-Z/0-9/_/- becomes '_', and the result is capped at 8 chars so it
// stays friendly to the SD library's 8.3 naming.  Returns "" when the header
// carried no name (all spaces / empty) -- the caller then keeps VIPTAPE's own
// filename, so a nameless SAVE is unaffected.
String sanitizeTapeName(const char* raw) {
  if (raw == nullptr) return String("");
  char buf[11];
  uint8_t n = 0;
  for (uint8_t i = 0; i < 10 && raw[i] != '\0'; i++) buf[n++] = raw[i];
  buf[n] = '\0';
  while (n > 0 && buf[n - 1] == ' ') buf[--n] = '\0';   // trim pad spaces
  String out;
  for (uint8_t i = 0; i < n; i++) {
    char c = buf[i];
    if (c == ' ') continue;                 // drop spaces (Char 4096 -> CHAR4096)
    if (c >= 'a' && c <= 'z') c -= 32;
    bool ok = (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
              c == '_' || c == '-';
    out += ok ? c : '_';
    if (out.length() >= 8) break;
  }
  return out;
}

String getUniqueFileName() {
  uint32_t fileNumber = 0;
  const int TOTAL_LEN = FILENAME_SIZE - 1;
  String fileName;

  while (fileNumber < 100000000UL) {
    String baseName = buildBaseName(BASEFILE, fileNumber, TOTAL_LEN);
    fileName = String(currentPath) + baseName + ".BIN";

    if (!SD.exists(fileName.c_str())) {
      return fileName;
    }
    if (SERIALDEBUG) { Serial.println(fileName); }
    fileNumber++;
  }
  if (SERIALDEBUG) { Serial.println(F("Error: no unique filename available.")); }
  return "";
}

void drawFileSaved() {
  tft.fillScreen(BACKGROUND);
  tft.setCursor(0, 80);
  tft.print("Bytes: ");
  tft.print(ramAddr);
  tft.setCursor(0, 100);
  if (currentProtocol == 5 || currentProtocol == 6) {tft.print("Blocks: ");}
  else {tft.print("Pages: ");}
  tft.print((ramAddr + 255) / 256);
}

/* Get file information*/
void getFile(uint16_t &startAddr, uint16_t &endAddr, unsigned long &fileSize, String &fileExt) {

  if (SERIALDEBUG) { Serial.print(F("Opening file: ")); Serial.println(currentFile); }

  File f = SD.open(currentFile);
  if (!f) {
    centerText(tft, "ERROR Opening File", 200, 0, BLACK, RED, 2);
    if (SERIALDEBUG) { Serial.println(F("ERROR Opening File")); }
    return;
  }
  FileLoader loader(ram);
  loader.loadFile(f, startAddr, endAddr, fileSize, fileExt);
  f.close();
  if (SERIALDEBUG) {
    Serial.println(F("Load complete."));
    Serial.print(F("File type : ")); Serial.println(fileExt);
    Serial.print(F("File size : ")); Serial.println(fileSize);
    Serial.print(F("Start     : 0x"));
    Serial.println(startAddr, HEX);
    Serial.print(F("End       : 0x"));
    Serial.println(endAddr, HEX);
  }
}
/*
========================================================================================================================================
Tape Methods
========================================================================================================================================
*/
// ----------------------------------------------------------------------------
// Helper: write an ORAO 'O' (object) file to SD as Intel HEX so the load
// ----------------------------------------------------------------------------
// ET-3400 KCS SAVE capture arrives in `ram` (addresses 0..ramAddr-1) as the
// raw Motorola S-record ASCII TEXT exactly as transmitted (e.g. "S113000...").
// This decodes that text back into a plain, human-readable .bas file:
//   1. Scan the S1 records covering the system area to find progStart
//      (0x0020-0x0021) and progEnd (0x0024-0x0025).
//   2. Re-scan, this time extracting only the bytes whose address falls in
//      [progStart, progEnd), and run them through the known program-line
//      format ([line# hi][line# lo][ASCII text][0x0D] repeating) to
//      reconstruct each line as "NNNN TEXT".
// This does not touch or replace the existing .s19 file -- it's an
// additional, separate output.
// ----------------------------------------------------------------------------
// Peeks at the captured S-record text to find progStart, WITHOUT writing
// anything -- lets the caller decide exclusively between the .bas-only
// path (real Tiny BASIC program, progStart == 0x0100) and the .s19-only
// path (anything else, e.g. machine code), rather than doing both.
static bool et3400CaptureIsBasicProgram(uint16_t s19Start, uint16_t s19End) {
  uint16_t progStart = 0;
  bool gotHi = false, gotLo = false;
  uint16_t p = s19Start;
  while (p < s19End) {
    if (ram.readByte(p) == 'S' && (uint16_t)(p+1) < s19End && ram.readByte(p+1) == '1') {
      uint8_t count = (s19HexVal(p+2) << 4) | s19HexVal(p+3);
      uint16_t addr = (s19HexVal(p+4) << 12) | (s19HexVal(p+5) << 8) | (s19HexVal(p+6) << 4) | s19HexVal(p+7);
      if (count < 3) { p++; continue; }
      uint8_t nbytes = count - 3;
      uint16_t dataStart = p + 8;
      for (uint8_t i = 0; i < nbytes; i++) {
        uint16_t a = addr + i;
        uint8_t val = (s19HexVal(dataStart + i*2) << 4) | s19HexVal(dataStart + i*2 + 1);
        if (a == 0x20) { progStart = (progStart & 0x00FF) | ((uint16_t)val << 8); gotHi = true; }
        if (a == 0x21) { progStart = (progStart & 0xFF00) | val; gotLo = true; }
      }
      if (gotHi && gotLo) return progStart == 0x0100;
      p = dataStart + nbytes*2 + 2;
      while (p < s19End && (ram.readByte(p) == '\r' || ram.readByte(p) == '\n')) p++;
      continue;
    }
    p++;
  }
  return false;
}

// ----------------------------------------------------------------------------
// Plain ASCII Hex (.TXT/.HEX) -> Motorola S-record image, for sending raw
// machine code to the ET-3400. Unlike TinyBasConvert (which handles Tiny
// BASIC's line format and system area), this just chunks a flat byte buffer
// into 16-byte S1 records at a fixed load address, ending with a real S9 --
// the same S-record wire format validated throughout this project, just
// without any BASIC-specific structure.
//
// ASCII Hex files have no way to specify their own load address (confirmed
// in FileLoader::loadAsciiHex, which always starts at 0) -- so this uses a
// fixed default load address instead. Change ET_TXT_HEX_LOAD_ADDR below if a
// different fixed address is needed.
// ----------------------------------------------------------------------------
static const uint16_t ET_TXT_HEX_LOAD_ADDR = 0x0100;

static void writeS1RecordRaw(uint32_t &dst, uint16_t addr, uint8_t *data, uint8_t len) {
  auto writeHexNib = [&](uint8_t v) {
    ram.writeByte(dst++, (v < 10) ? ('0' + v) : ('A' + v - 10));
  };
  auto writeHex8v = [&](uint8_t v) { writeHexNib(v >> 4); writeHexNib(v & 0xF); };
  uint8_t count = len + 3;
  uint16_t sum = count + (addr >> 8) + (addr & 0xFF);
  for (uint8_t i = 0; i < len; i++) sum += data[i];
  uint8_t chk = (~sum) & 0xFF;
  ram.writeByte(dst++, 'S'); ram.writeByte(dst++, '1');
  writeHex8v(count);
  writeHex8v((addr >> 8) & 0xFF); writeHex8v(addr & 0xFF);
  for (uint8_t i = 0; i < len; i++) writeHex8v(data[i]);
  writeHex8v(chk);
  ram.writeByte(dst++, '\r'); ram.writeByte(dst++, '\n');
}

static uint32_t convertRawBinaryToSRecords(uint16_t srcStart, uint16_t srcEnd,
                                           uint16_t loadAddr, uint32_t dstBase) {
  uint32_t dst = dstBase;
  uint8_t buf[16];
  uint16_t addr = loadAddr;
  uint16_t s = srcStart;
  while (s <= srcEnd) {
    uint8_t n = 0;
    while (n < 16 && s <= srcEnd) { buf[n++] = ram.readByte(s++); }
    writeS1RecordRaw(dst, addr, buf, n);
    addr += n;
  }
  // Real, well-formed S9 terminator (see the S9-restoration notes above --
  // the ET-3400 monitor only checks for literal 'S' then '9', but a
  // well-formed record is safest for any other consumer).
  ram.writeByte(dst++, 'S'); ram.writeByte(dst++, '9');
  ram.writeByte(dst++, '0'); ram.writeByte(dst++, '3');
  ram.writeByte(dst++, '0'); ram.writeByte(dst++, '0');
  ram.writeByte(dst++, '0'); ram.writeByte(dst++, '0');
  ram.writeByte(dst++, 'F'); ram.writeByte(dst++, 'C');
  ram.writeByte(dst++, '\r'); ram.writeByte(dst++, '\n');
  return dst - dstBase;
}


static uint8_t s19HexVal(uint16_t idx) {
  char c = (char)ram.readByte(idx);
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return 0;
}

static void writeBasTextFromS19Capture(uint16_t s19Start, uint16_t s19End, const String &basFilename) {
  // Pass 1: find progStart/progEnd from the system-area S1 records.
  uint16_t progStart = 0, progEnd = 0;
  bool gotStartHi=false, gotStartLo=false, gotEndHi=false, gotEndLo=false;
  {
    uint16_t p = s19Start;
    while (p < s19End) {
      if (ram.readByte(p) == 'S' && (uint16_t)(p+1) < s19End && ram.readByte(p+1) == '1') {
        uint8_t count = (s19HexVal(p+2) << 4) | s19HexVal(p+3);
        uint16_t addr = (s19HexVal(p+4) << 12) | (s19HexVal(p+5) << 8) | (s19HexVal(p+6) << 4) | s19HexVal(p+7);
        if (count < 3) { p++; continue; }
        uint8_t nbytes = count - 3;
        uint16_t dataStart = p + 8;
        for (uint8_t i = 0; i < nbytes; i++) {
          uint16_t a = addr + i;
          uint8_t val = (s19HexVal(dataStart + i*2) << 4) | s19HexVal(dataStart + i*2 + 1);
          if (a == 0x20) { progStart = (progStart & 0x00FF) | ((uint16_t)val << 8); gotStartHi = true; }
          if (a == 0x21) { progStart = (progStart & 0xFF00) | val; gotStartLo = true; }
          if (a == 0x24) { progEnd   = (progEnd   & 0x00FF) | ((uint16_t)val << 8); gotEndHi = true; }
          if (a == 0x25) { progEnd   = (progEnd   & 0xFF00) | val; gotEndLo = true; }
        }
        p = dataStart + nbytes*2 + 2; // skip checksum
        while (p < s19End && (ram.readByte(p) == '\r' || ram.readByte(p) == '\n')) p++;
        continue;
      }
      p++;
    }
  }
  if (!(gotStartHi && gotStartLo && gotEndHi && gotEndLo) || progEnd <= progStart) {
    if (SERIALDEBUG) Serial.println(F("writeBasTextFromS19Capture: couldn't find progStart/progEnd, skipping .bas export"));
    return;
  }
  // Content-based safety check: Tiny BASIC programs always start at
  // 0x0100 (PROG_START, used throughout this project). A genuine
  // machine-code save uses whatever arbitrary address its own program
  // needs (e.g. 0x0001), essentially never exactly 0x0100 -- so this
  // reliably distinguishes a real BASIC capture without depending on
  // what the user happened to name the file.
  if (progStart != 0x0100) {
    if (SERIALDEBUG) Serial.println(F("writeBasTextFromS19Capture: progStart != 0x0100, not a BASIC program, skipping .bas export"));
    return;
  }

  // FILE_WRITE on the Arduino SD library APPENDS to an existing file rather
  // than truncating it -- if a .BAS with this name already existed from a
  // prior save, writing on top of it could leave stale leftover content.
  // Explicitly remove any existing file first so every export starts clean.
  if (SD.exists(basFilename)) SD.remove(basFilename);
  File basFile = SD.open(basFilename, FILE_WRITE);
  if (!basFile) {
    if (SERIALDEBUG) Serial.println(F("writeBasTextFromS19Capture: couldn't open output file"));
    return;
  }

  // Pass 2: extract program-area bytes in address order and decode lines.
  uint8_t lineBuf[80];
  uint8_t lineLen = 0;
  bool haveHi = false, haveLo = false;
  uint16_t curLineNo = 0;

  uint16_t p = s19Start;
  while (p < s19End) {
    if (ram.readByte(p) == 'S' && (uint16_t)(p+1) < s19End && ram.readByte(p+1) == '1') {
      uint8_t count = (s19HexVal(p+2) << 4) | s19HexVal(p+3);
      uint16_t addr = (s19HexVal(p+4) << 12) | (s19HexVal(p+5) << 8) | (s19HexVal(p+6) << 4) | s19HexVal(p+7);
      if (count < 3) { p++; continue; }
      uint8_t nbytes = count - 3;
      uint16_t dataStart = p + 8;
      for (uint8_t i = 0; i < nbytes; i++) {
        uint16_t a = addr + i;
        if (a >= progStart && a < progEnd) {
          uint8_t val = (s19HexVal(dataStart + i*2) << 4) | s19HexVal(dataStart + i*2 + 1);
          if (!haveHi)      { curLineNo = (uint16_t)val << 8; haveHi = true; }
          else if (!haveLo) { curLineNo |= val; haveLo = true; }
          else if (val == 0x0D) {
            // Line number 0 is never valid in Tiny BASIC (explicitly
            // rejected by both the LOAD parser and the interpreter itself).
            // If one shows up here, it means we've read past the real end
            // of the program into stray/padding bytes in the captured
            // system area -- treat this as "no more real content" and stop
            // the export entirely, rather than writing a bogus line.
            if (curLineNo == 0) {
              basFile.close();
              return;
            }
            basFile.print(curLineNo);
            basFile.print(' ');
            for (uint8_t k = 0; k < lineLen; k++) basFile.write(lineBuf[k]);
            basFile.print("\r\n");
            lineLen = 0; haveHi = false; haveLo = false;
          } else {
            if (lineLen < sizeof(lineBuf)) lineBuf[lineLen++] = val;
          }
        }
      }
      p = dataStart + nbytes*2 + 2;
      while (p < s19End && (ram.readByte(p) == '\r' || ram.readByte(p) == '\n')) p++;
      continue;
    }
    p++;
  }
  basFile.close();
  if (SERIALDEBUG) {
    Serial.print(F("Wrote plain-text BASIC listing to "));
    Serial.println(basFilename);
  }
}


// ----------------------------------------------------------------------------
// ORAO files use Intel HEX for their machine-code load address, since that
// address is preserved and the existing FileLoader can re-read it.
// 'B' (BASIC) files use the existing writeFile() path -- they're plain text.
// ----------------------------------------------------------------------------
static void writeOraoIntelHex(uint16_t loadAddr, uint32_t size) {
  // Open with the current filename (the user has already chosen the SD path)
  myFile = SD.open(currentFile, FILE_WRITE);
  if (!myFile) {
    if (SERIALDEBUG) Serial.println(F("Error opening file"));
    centerText(tft, "ERROR", 10, 0, WHITE, RED, 2);
    delay(1000);
    return;
  }
  centerText(tft, "Writing HEX", 10, 0, BLUE, CYAN, 2);
  delay(500);

  static const char hexChars[] = "0123456789ABCDEF";
  uint32_t off = 0;
  while (off < size) {
    uint8_t recLen = (size - off > 16) ? 16 : (uint8_t)(size - off);
    uint16_t addr  = (uint16_t)(loadAddr + off);
    uint8_t  sum   = recLen + (uint8_t)(addr >> 8) + (uint8_t)(addr & 0xFF) + 0x00;

    myFile.write(':');
    myFile.write(hexChars[recLen >> 4]);            myFile.write(hexChars[recLen & 0x0F]);
    myFile.write(hexChars[(addr >> 12) & 0x0F]);    myFile.write(hexChars[(addr >> 8) & 0x0F]);
    myFile.write(hexChars[(addr >> 4)  & 0x0F]);    myFile.write(hexChars[ addr       & 0x0F]);
    myFile.write('0');                              myFile.write('0');   // record type 00 = data

    for (uint8_t i = 0; i < recLen; i++) {
      uint8_t v = ram.readByte((uint16_t)(loadAddr + off + i));
      sum += v;
      myFile.write(hexChars[v >> 4]);  myFile.write(hexChars[v & 0x0F]);
    }
    uint8_t cs = (uint8_t)(-(int8_t)sum);
    myFile.write(hexChars[cs >> 4]);   myFile.write(hexChars[cs & 0x0F]);
    myFile.write('\r');                myFile.write('\n');
    off += recLen;
    lastActivityTime = millis();
  }
  // EOF record
  myFile.print(F(":00000001FF\r\n"));
  myFile.close();

  tft.fillScreen(BLACK);
  centerText(tft, "Writing completed", 10, 0, BLUE, YELLOW, 2);
  delay(1000);
}

// Bytes of SRAM between the top of the heap and the current stack pointer.
// The PC-1 work added a deeper period queue and two diagnostic buffers; if a
// board ever starts behaving strangely after a build, check this FIRST.  Under
// ~400 bytes on a Mega, String operations and the SD/TFT libraries will collide
// with the stack and the symptoms look like anything but memory.
static int freeSram() {
  extern int __heap_start, *__brkval;
  int v;
  return (int)&v - (__brkval == 0 ? (int)&__heap_start : (int)__brkval);
}

void ReadData() {
  ramAddr = 0;
  bool okToFile = false;
  bool pc1WantListing = false;
  const char *errMsg = "";

  // Re-arm the decoder for the protocol we're about to decode.  setParams()
  // does reset() AND re-applies the correct interrupt edge mode (ORAO=RISING,
  // async=CHANGE).  This guarantees a decode can never run with a stale edge
  // mode left over from a previous operation -- a stale RISING mode on an async
  // protocol doubles every measured period out of its accept window, so the
  // leader never locks and only a single stray byte is ever captured.  That is
  // exactly the "async saves only 1 byte" failure; this line prevents it.
  const CassetteParams *p = cassetteDecoder.getParams();
  cassetteDecoder.setParams(p);

  // ---- FUNCTION SCOPE ON PURPOSE ----------------------------------------
  // These are used both inside the async capture loop AND after the
  // done_receiving: label, where the nibble packing and the record-layer
  // handling run.  Declaring them inside the capture loop's else-block put
  // them out of scope for the second half of the function.
  //
  // pc1Rx  = CAPABILITY: frames a byte as two nibbles over 4-vs-8-cycle FSK.
  //          True for the PC-1 and the PC-2; they share the capture loop, the
  //          signal-quality gate and the instruments.
  // isPc1Rec = IDENTITY: has the PC-1211's specific record layout (0x80 marker,
  //          0x5F terminator, nibble-sum checksum).  The PC-1500's record layer
  //          is different and not yet measured.
  const bool pc1Rx    = (strcmp(p->name, "TRS-80 PC-1") == 0 ||
                         strcmp(p->name, "TRS-80 PC-2") == 0);
  const bool isPc1Rec = (strcmp(p->name, "TRS-80 PC-1") == 0);

  bool oraoMode = (p->framing == FRAMING_BLOCK_ORAO);

  if (oraoMode) {
    // -------------------- ORAO 'B' / 'O' framing --------------------
    OraoReceive oraoRx(ram, cassetteDecoder);
    lastByteTime = millis();
    unsigned long startTime = millis();

    while (true) {
      cassetteDecoder.poll();

      if (cassetteDecoder.available()) {
        uint8_t b = cassetteDecoder.read();
        OraoReceive::Status s = oraoRx.feed(b);
        lastByteTime = millis();

        if (s == OraoReceive::OR_DONE) {
          ramAddr = oraoRx.dataBytes();
          // Append the $1A EOF marker so the stored file matches what a real
          // ORAO tape carries (and what loads back cleanly via SendData()).
          ram.writeByte((uint16_t)ramAddr, 0x1A);
          ramAddr++;
          okToFile = true;
          break;
        }
        if (s == OraoReceive::OR_ERROR) {
          errMsg = "Decode error";
          okToFile = false;
          break;
        }
      }

      // No bytes at all after 15 s -> nothing is coming; abort.
      if (oraoRx.dataBytes() == 0 && (millis() - startTime) > 15000UL) {
        errMsg = "No data";
        okToFile = false;
        break;
      }

      // Data started but the tape died mid-file (never saw $1A).  Wait longer
      // than the ~2.3 s inter-block leader gap before giving up, then save
      // what we have so a partial capture isn't lost.
      if (oraoRx.dataBytes() > 0 && (millis() - lastByteTime) > 5000UL) {
        ramAddr = oraoRx.dataBytes();
        ram.writeByte((uint16_t)ramAddr, 0x1A);
        ramAddr++;
        okToFile = true;
        break;
      }

      lastActivityTime = millis();
    }

    // If the SAVE carried a filename in its header (e.g. SAVE"TEST" -> "TEST"),
    // use that as the output file name, overriding whatever VIPTAPE had chosen.
    // A blank/nameless header leaves currentFile untouched (typed name or the
    // auto FILExxxx default).  Only done once we know we'll actually write.
    if (okToFile) {
      String tapeNameStr = sanitizeTapeName(oraoRx.filename());
      if (tapeNameStr.length() > 0) {
        currentFile = currentPath + tapeNameStr + ".BIN";
        if (SERIALDEBUG) Serial.print(F("Tape filename   : ")); Serial.println(currentFile);
      }
    }

    if (errMsg[0] != '\0') {
      centerText(tft, errMsg, 100, 0, WHITE, RED, 2);
      delay(1000);
      cassetteDecoder.clearError();
    }

  } else {
    // -------------------- original async-protocol path (unchanged) --------
    // Wall-clock start of the capture, for the PC-1 no-data escape below.
    // (`startTime` above is scoped to the ORAO branch.)
    unsigned long rxStartTime = millis();
    lastByteTime = millis();
    if (SERIALDEBUG) {
      Serial.print(F("rx start, free SRAM = ")); Serial.println(freeSram());
    }

    // ---- PC-1 SIGNAL-QUALITY GATE ----------------------------------------
    // The reader used to end a capture on a GAP in decoded bytes.  That works
    // only while silence produces no bytes -- and on this board the idle tape
    // input is not silent.  After the tape ends the decoder keeps finding
    // "frames" in line noise, which refreshes the idle timer forever, so the
    // reader sat on "Reading....." and never came back.
    //
    // The discriminator is the out-of-range counter, and the separation is
    // enormous.  Measured on real captures:
    //     genuine PC-1 signal   ~0.1 out-of-range half-periods per frame
    //     idle line noise       ~400 per frame
    // So a frame that arrives with a big oor jump behind it came out of noise,
    // not off the tape.
    //
    // Such frames are still STORED -- never dropped mid-stream, because packing
    // is pairwise and dropping one frame re-pairs every nibble after it.  They
    // simply do not count as evidence of live signal: they do not refresh the
    // idle timer, and the capture is truncated back to the last trustworthy
    // frame at the end.  A wrongly-classified frame therefore costs nothing.
    // (pc1Rx and isPc1Rec are declared at FUNCTION scope near the top of
    //  ReadData -- they are needed again after done_receiving:.)
    // Threshold from the hardware, not a guess.  On the HHHH capture the 20
    // header frames moved oor by TWO counts total (30826 -> 30828, i.e. 0.1 per
    // frame), while the noise frames after the tape moved it by ~680 each.  30
    // sits 300x above real signal and 20x below noise.  The first value tried,
    // 200, was still low enough to admit ~8 noise bytes at the tail because the
    // gap between the last real frame and the first noise frame is smaller than
    // the noise's own per-frame cost.
    const uint32_t PC1_NOISE_OOR = 30;
    uint32_t oorAtLastByte = 0;
    uint32_t lastGoodLen   = 0;
    uint32_t noisyFrames   = 0;

    // ---- PC-2: STOP ON THE RECORD'S OWN LENGTH, NOT ON A CLOCK ------------
    // Every clock-based terminator is a guess about how long a tape might be,
    // and each one that has been wrong here truncated a capture silently.  The
    // PC-1500 does not require the guess: its 42-byte header carries the image
    // length at bytes 36-37, so the exact size of a complete tape is arithmetic
    // and the exact FRAME the tape ends on is known 3 seconds into a capture
    // that may run 9 minutes.
    //
    // Read incrementally from the frames as they arrive.  It must not touch the
    // SPI RAM: a byte read there is ~585 us and the PC-2's mark tone queues an
    // edge every 200 us, so re-scanning even 100 stored frames mid-capture
    // would overrun the 128-slot period queue and scramble bit phase.  All this
    // needs is a 6-frame rolling window to find the sync and 4 nibbles of the
    // length field -- about a dozen bytes of state and a few comparisons per
    // frame, no reads of any kind.
    //
    // If the sync is never seen, or the length is implausible, the target stays
    // 0 and the old timeouts still terminate the capture.  It can only ever end
    // a capture EARLIER than they would, never later, and only at the byte the
    // tape itself says is the last one.
    uint8_t  pc2Win[6]     = {0, 0, 0, 0, 0, 0};
    uint32_t pc2SyncFrm    = 0;      // frame the 10 11 12 signature starts on
    bool     pc2SyncFound  = false;
    uint8_t  pc2LenNib[4]  = {0, 0, 0, 0};
    uint32_t pc2TargetFrm  = 0;      // 0 = unknown, fall back to the timeouts
    const bool pc2Rx       = (pc1Rx && !isPc1Rec);

    while (true) {
      cassetteDecoder.poll();
      if (cassetteDecoder.available()) {
        uint32_t oorNow = cassetteDecoder.debugOutOfRange();
        uint8_t b = cassetteDecoder.read();
        ram.writeByte(ramAddr++, b);
        // ---- THE NOISE GATE IS PC-1 TUNING, NOT A SHARED CAPABILITY -----
        // PC1_NOISE_OOR = 30 out-of-range periods per BYTE was calibrated on
        // the PC-1, whose byte is 2 frames x 10 cells x 2.0 ms = 40 ms.  A PC-2
        // byte is 2 x 11 x 3.2 = 70 ms -- 75% longer, so 75% more chance for
        // stray periods to accumulate against the same fixed threshold.
        //
        // Gated on pc1Rx (the CAPABILITY, true for both machines) this quietly
        // wrecked long PC-2 captures: once frames start being flagged, this
        // stops refreshing lastByteTime, the 8 s idle test fires, and the
        // capture is then TRIMMED BACK to lastGoodLen.  DungeonQuest captured
        // 2430 of 7729 data bytes that way -- every one of them byte-perfect
        // against the real tape, and 68% of the program thrown away.
        //
        // So gate it on isPc1Rec (IDENTITY).  This is the same trap as the one
        // that once made six sites read FRAMING_ASYNC_KCS as "ET-3400", in
        // reverse: a capability flag was right for the framing and wrong for
        // the tuning that rode along with it.  The PC-2 does not need the
        // heuristic anyway -- its record is self-describing, so trailing junk
        // is trimmed by ARITHMETIC after packing (see below).
        if (!isPc1Rec || ramAddr == 1 || (oorNow - oorAtLastByte) <= PC1_NOISE_OOR) {
          lastByteTime = millis();
          lastGoodLen  = ramAddr;
        } else {
          noisyFrames++;
        }
        oorAtLastByte = oorNow;

        // ---- PC-2: learn where the tape ends, from the tape --------------
        // Nibbles arrive LOW FIRST on this machine, so packed byte k is made
        // from frames (2k) and (2k+1) counted from the sync, low nibble first.
        if (pc2Rx && !pc2TargetFrm) {
          const uint32_t f  = ramAddr - 1;          // index of the frame just stored
          const uint8_t  nv = (uint8_t)(b & 0x0F);

          if (!pc2SyncFound) {
            pc2Win[0] = pc2Win[1]; pc2Win[1] = pc2Win[2]; pc2Win[2] = pc2Win[3];
            pc2Win[3] = pc2Win[4]; pc2Win[4] = pc2Win[5]; pc2Win[5] = nv;
            // Bound the hunt.  Past this point a "signature" is a coincidence
            // in noise, not a header, and locking to it would compute a length
            // from the wrong bytes and stop the capture in the wrong place.
            if (f >= 5 && f < 400) {
              const uint8_t s0 = (uint8_t)((pc2Win[1] << 4) | pc2Win[0]);
              const uint8_t s1 = (uint8_t)((pc2Win[3] << 4) | pc2Win[2]);
              const uint8_t s2 = (uint8_t)((pc2Win[5] << 4) | pc2Win[4]);
              if (s0 == 0x10 && s1 == 0x11 && s2 == 0x12) {
                pc2SyncFrm   = f - 5;
                pc2SyncFound = true;
              }
            }
          } else {
            const uint32_t rel = f - pc2SyncFrm;    // frames since the signature
            if (rel >= 72 && rel <= 75) {           // packed bytes 36 and 37
              pc2LenNib[rel - 72] = nv;
              if (rel == 75) {
                const uint8_t  hi = (uint8_t)((pc2LenNib[1] << 4) | pc2LenNib[0]);
                const uint8_t  lo = (uint8_t)((pc2LenNib[3] << 4) | pc2LenNib[2]);
                const uint32_t n  = ((uint32_t)hi << 8) | lo;   // image length
                // Sanity gate.  A PC-1500 tops out at 16 KB of program even
                // fully expanded, so a length outside this range came from a
                // misread header -- leave the target unset and let the
                // timeouts finish the job rather than stop somewhere wrong.
                if (n >= 2 && n <= 32000UL) {
                  const uint32_t data = n + 1;                 // image + the 0xFF
                  const uint32_t want = 42 + data + 2 * (data / 80)
                                      + ((data % 80) ? 2 : 0) + 1;
                  pc2TargetFrm = pc2SyncFrm + 2 * want;
                  if (SERIALDEBUG) {
                    Serial.print(F("PC-2: header says image ")); Serial.print(n);
                    Serial.print(F(" -> tape ")); Serial.print(want);
                    Serial.print(F(" bytes, ending at frame "));
                    Serial.println(pc2TargetFrm);
                  }
                }
              }
            }
          }
        }

        // The tape has delivered every frame its own header accounts for.
        // Stop here: waiting for a timeout adds 8 seconds and risks appending
        // whatever the line does next.
        if (pc2TargetFrm && ramAddr >= pc2TargetFrm) {
          okToFile = true;
          if (SERIALDEBUG) Serial.println(F("PC-2 rx: complete (header length reached)"));
          break;
        }
      }

      if (errMsg[0] != '\0') { okToFile = false; break; }

      // ---- TRS-80 PC-1 fixes to this loop ---------------------------------
      // (1) END-OF-TAPE THRESHOLD.  The 2000ms below ends the capture after a
      //     gap in decoded bytes.  A genuine PC-1 tape has 3.65 SECOND mark
      //     gaps between its 90-byte blocks (measured), during which no byte
      //     decodes -- so 2000ms cuts the capture off at the FIRST block
      //     boundary.  The PC-1 needs a threshold comfortably above 3.65 s.
      // (2) NO-DATA ESCAPE.  The condition below requires ramAddr > 0, so if
      //     nothing ever decodes this loop spins FOREVER -- the display sits on
      //     "Reading....." and never reaches the diagnostics or the file write.
      //     That is exactly the observed hang.  Give it a hard escape.
      // 8 s, not 5 s.  The measured inter-block mark gap is 3.65 s and the
      // header gap 0.44 s; 5 s left only 1.35 s of margin against the longest
      // thing on the tape.  End-of-tape is now detected by SILENCE (below),
      // which fires in 1.5 s, so this is only a backstop for the case where
      // the PC-1's output line stays noisy after the trailer.
      const unsigned long idleLimit = pc1Rx ? 8000UL : 2000UL;

      if (pc1Rx) {
        // ---- END OF TAPE IS SILENCE, NOT A BYTE GAP -----------------------
        // A PC-1 tape is nearly half mark tone: 4.9 s of leader, a 0.44 s
        // header gap, and a 3.65 s gap every 90 bytes.  Those gaps decode ZERO
        // bytes while still carrying ~8000 edges/second, so a byte-idle timer
        // cannot tell "gap" from "finished" without a threshold longer than
        // the longest gap -- which is what cut captures short at the first
        // block boundary.  The decoder already separates the two cases: its
        // 1.5 s no-EDGE timeout trips only on true silence, which on this
        // machine happens only after the trailer.  Use that as the primary
        // terminator; it ends the capture ~6 s sooner than the backstop and
        // cannot truncate a record mid-tape.
        if (ramAddr > 0 && cassetteDecoder.isDone()) {
          okToFile = true;
          if (SERIALDEBUG) Serial.println(F("PC-1 rx: end of tape (silence)"));
          break;
        }

        static unsigned long lastDiag = 0;
        if (millis() - lastDiag > 2000) {
          lastDiag = millis();
          if (SERIALDEBUG) {
            // ---- KEEP THIS LINE SHORT.  IT IS TIMING-CRITICAL. ------------
            // Serial.print blocks once the 64-byte TX buffer fills, and the
            // PC-1's 4 kHz mark tone queues an edge every 125us.  The old
            // seven-field line was ~150 chars = ~13 ms of blocking, during
            // which ~104 periods arrived; the 32-slot queue held 31 and the
            // rest were dropped.  Each dropped period breaks the mark burst
            // count mid-frame and slips the framing by one bit -- that is the
            // junk-nibble symptom, and it was self-inflicted by this print.
            // The queue is now 128 deep (~15 ms of cover) and this line is
            // ~55 chars (~4.8 ms), a ~3x margin.  If you add a field back,
            // add slots too.  drp= is the canary: it must stay 0.
            Serial.print(F("PC1 b=")); Serial.print(ramAddr);
            Serial.print(F(" oor="));  Serial.print(cassetteDecoder.debugOutOfRange());
            Serial.print(F(" drp="));  Serial.print(cassetteDecoder.debugQueueDrops());
            Serial.print(F(" us="));   Serial.print(cassetteDecoder.debugLastCycleUs());
            Serial.print(' ');         Serial.println(cassetteDecoder.debugStateName());
          }
        }
        // ---- THREE HARD ESCAPES.  A CAPTURE MUST ALWAYS TERMINATE. ---------
        // The idle-gap test below only fires when bytes STOP arriving, so any
        // fault that makes the decoder emit continuously -- noise misread as
        // valid tones, a lost lock, a bad accept window -- refreshes
        // lastByteTime forever and the reader hangs on "Reading.....".  That
        // is not hypothetical: a build with over-wide accept windows did
        // exactly this.  None of the escapes below can be defeated by the
        // signal, so the UI always comes back.

        // (a) nothing decoded at all -> the receive side is not working
        if (ramAddr == 0 && millis() - rxStartTime > 25000UL) {
          okToFile = false;
          errMsg = "PC-1: no data";
          if (SERIALDEBUG) Serial.println(F("PC-1 rx: ABORT - nothing decoded in 25s"));
          break;
        }
        // (b) absolute wall-clock ceiling.
        //
        // ---- THIS IS PER-MACHINE TUNING, NOT A SHARED CAPABILITY ----------
        // 180 s came from the PC-1, whose longest known tape (BLAKJAK) is
        // 132 s.  Gated on pc1Rx (the CAPABILITY, true for both machines) it
        // also applied to the PC-2, where it is far too short and SILENTLY
        // TRUNCATES long captures mid-tape.
        //
        // A PC-2 nibble frame is 11 cells x 3.2 ms = 35.2 ms, so 180 s admits
        // 5114 frames = 2557 bytes.  DungeonQuest's own tape is 7771 bytes =
        // 547 s of signal.  VIPTAPE captured 2472 of it -- 2557 less about 6 s
        // of leader and the operator reaching for ENTER.  That is not an
        // approximate match, it is this test firing, and it explains why all
        // 2430 data bytes it did keep were byte-perfect against the real tape:
        // the decode was never wrong, the clock ran out mid-tape.
        //
        // (This is the THIRD time PC-1 tuning has been found riding on the
        // pc1Rx capability flag.  When adding a constant here, ask which of the
        // two flags it belongs to before writing it down.)
        //
        // The ceiling is only a backstop for a decoder emitting continuously
        // out of noise.  The real terminators are the 1.5 s silence test and
        // the 8 s idle test, and escape (c) bounds a runaway at 60000 frames
        // no matter what, so the PC-2's can afford to be generous: 1500 s
        // covers a 21000-byte tape, larger than a fully expanded PC-1500 holds.
        const unsigned long rxCeiling = isPc1Rec ? 180000UL : 1500000UL;
        if (millis() - rxStartTime > rxCeiling) {
          okToFile = (ramAddr > 0);
          if (SERIALDEBUG) Serial.println(F("PC rx: ABORT - wall-clock ceiling, saving what we have"));
          break;
        }
        // (c) buffer ceiling.  ram.writeByte() takes a uint16_t address, so an
        // unbounded capture WRAPS at 65536 and silently overwrites itself from
        // the start.  Stop well short of that.
        if (ramAddr >= 60000UL) {
          okToFile = true;
          if (SERIALDEBUG) Serial.println(F("PC-1 rx: ABORT - buffer full at 60000 frames"));
          break;
        }
      }

      if (ramAddr > 0 && millis() - lastByteTime > idleLimit) {
        okToFile = true;
        break;
      }

      if (cassetteDecoder.decodeFinished()) {
        if (cassetteDecoder.hasError()) {
          switch (cassetteDecoder.lastError()) {
            case DECODE_ERR_TIMEOUT:
              // For KCS: inter-byte timeout after data = end of tape -> save.
              if (p && p->framing == FRAMING_ASYNC_KCS && strcmp(p->name, "ET-3400") == 0 && ramAddr > 0) {
                okToFile = true;
                cassetteDecoder.clearError();
                goto done_receiving;
              }
              okToFile = false;
              errMsg = "Tape timeout";  goto message_error;
            case DECODE_ERR_PARITY:  okToFile = false; errMsg = "Parity error";   goto message_error;
            case DECODE_ERR_STOPBIT: okToFile = false; errMsg = "Stop bit error"; goto message_error;
            default:                 okToFile = false; errMsg = "Error unknown";  goto message_error;
message_error:
            centerText(tft, errMsg, 100, 0, WHITE, RED, 2);
            delay(1000);
            cassetteDecoder.clearError();
            break;
          }
        }
      }
      lastActivityTime = millis();
    }

    // ---- TRIM TRAILING NOISE ---------------------------------------------
    // Everything after the last trustworthy frame is line noise the decoder
    // found once the tape stopped.  Cut it here rather than letting it reach
    // the file: it would otherwise show up as junk bytes appended to a
    // perfectly good record, and it is what made the reader look hung.
    if (isPc1Rec && lastGoodLen > 0 && lastGoodLen < ramAddr) {
      if (SERIALDEBUG) {
        Serial.print(F("PC-1: trimmed ")); Serial.print(ramAddr - lastGoodLen);
        Serial.print(F(" trailing noise frames (")); Serial.print(noisyFrames);
        Serial.println(F(" flagged)"));
      }
      ramAddr = lastGoodLen;
    }
  }

done_receiving:
  saveLastMode();
  if (SERIALDEBUG) {
    Serial.print(F("ReadData done: okToFile=")); Serial.print(okToFile);
    Serial.print(F(" ramAddr=")); Serial.print(ramAddr);
    Serial.print(F(" protocol=")); Serial.println(p->name);
  }
  // Decide EXCLUSIVELY between the .bas-only path (real Tiny BASIC program)
  // and the .s19-only path (anything else, e.g. machine code) by peeking at
  // content -- progStart == 0x0100 reliably means Tiny BASIC, since that's
  // the fixed program-start address used throughout this project, and a
  // genuine machine-code save uses whatever arbitrary address it needs
  // (e.g. 0x0001 in the reference file). No filename typing required.
  bool isBasicSave = okToFile && p->framing == FRAMING_ASYNC_KCS && strcmp(p->name, "ET-3400") == 0
                     && strcmp(p->name, "ET-3400") == 0
                     && et3400CaptureIsBasicProgram(0, (uint16_t)ramAddr);

  if (isBasicSave) {
    String bf = currentFile;
    int bdot = bf.lastIndexOf('.');
    if (bdot >= 0) bf = bf.substring(0, bdot);
    bf += ".BAS";
    writeBasTextFromS19Capture(0, (uint16_t)ramAddr, bf);
  } else {
    // ET-3400 (KCS) captures arrive as Motorola S-record TEXT. Save it
    // as-is (.s19) so the file can be sent back to the ET-3400 directly --
    // this is the original, proven-working behavior for anything that
    // isn't a real Tiny BASIC program.
    if (okToFile && p->framing == FRAMING_ASYNC_KCS && strcmp(p->name, "ET-3400") == 0) {
      String f = currentFile;
      int dot = f.lastIndexOf('.');
      if (dot >= 0) f = f.substring(0, dot);
      currentFile = f + ".s19";
      if (SERIALDEBUG) {
        Serial.print(F("ET-3400 capture: saving "));
        Serial.print(ramAddr); Serial.print(F(" bytes as "));
        Serial.println(currentFile);
      }
    }
    // ---- TRS-80 PC-1: pack nibble frames back into bytes -----------------
    // NOTE THIS IS ReadData(), THE LIVE CAPTURE FUNCTION.
    //
    // Every PC-1 frame carries ONE nibble in its low 4 bits with the high
    // nibble padded to ones, so `ram` holds 2N bytes of 0xF0|nibble for an
    // N-byte tape stream.  Written out raw that gives a file twice the right
    // size full of 0xF0..0xFF.  Pack pairs back together HIGH NIBBLE FIRST --
    // the same order the send path emits -- then halve the length.  The result
    // is the tape byte stream verbatim, i.e. a .TAP (verified: the decode of
    // BLAKJAK.wav matches BLAKJAK.tap 1573/1573).
    if (okToFile && pc1Rx && ramAddr >= 2) {
      // ---- RUN-LENGTH TRACE ------------------------------------------------
      // Printed AFTER the capture, so it costs nothing in the timing-critical
      // path.  This is the raw tone structure with no framing assumed:
      //   M<n> = n half-cycles of 4 kHz mark   (divide by 16 for bit cells)
      //   S<n> = n half-cycles of 2 kHz space  (divide by  8 for bit cells)
      // A frame should read as one space run of 8..40 halves (start bit plus
      // any leading zero data bits) followed by a mark run that is the rest of
      // the frame.  THE MARK RUN IS THE NUMBER THAT MATTERS: it is the frame
      // tail, and the 8-bit framing this decoder used to apply needed it to be
      // >= 64 halves (4 cells).  If the mark runs here are shorter than that,
      // that is the confirmation for why the old framing slipped.
      // ---- HALF-PERIOD HISTOGRAM -------------------------------------------
      // Every sample the decoder saw, in-range or not, in 25us buckets.  A
      // healthy PC-1 capture is sharply BIMODAL: a spike at the 125us bucket
      // (4 kHz mark) and one at 250us (2 kHz space), with almost nothing in
      // between.  Mass spread across the middle buckets means the input edges
      // are dirty; mass piled just OUTSIDE a window means that window needs
      // widening -- and note the windows are RECEIVE-only, so widening them
      // cannot affect a load.  Never move bit0/bit1 themselves; those are the
      // transmit periods and are hardware-calibrated.
      // The half-period histogram and run trace that used to print here have
      // been removed along with the 240 bytes of SRAM arrays that fed them.
      // See the note in CassetteDecoder.h; restore both together if a future
      // machine needs that measurement.

      // ---- LOCK ONTO THE HEADER RECORD BEFORE PACKING ---------------------
      // Two separate jobs, both solved by the same scan:
      //
      //   1. DISCARD PRE-LOCK JUNK.  A capture can begin with frames decoded
      //      before the decoder has settled (and, on a board with an
      //      unterminated tapeIn, with frames decoded from line noise before
      //      the PC-1 starts driving at all).  Those land ahead of the real
      //      header and shift the whole file.
      //   2. FIX NIBBLE PARITY.  Packing is pairwise, so an ODD number of
      //      junk frames at the head does not merely add junk -- it pairs
      //      every real nibble with the wrong neighbour and destroys the
      //      entire capture.  Locking to the marker fixes alignment as a
      //      side effect.
      //
      // The lock is checksum-verified, not a bare 0x80 search, because 0x80 is
      // a legal data byte: a candidate must have the 0x5F terminator in byte 8
      // AND a byte-9 checksum equal to the 8-bit sum of the record's data
      // nibbles (marker excluded).  That rule is confirmed against both known
      // files -- HI.TAP (80 00 00 00 00 00 95 85 5F -> 2F) and BLAKJAK.tap
      // (80 B5 15 A5 B5 15 C5 25 5F -> 67).
      //
      // NOTE the asymmetry deliberately: junk is only ever stripped from the
      // HEAD.  Frames are never dropped mid-stream, because dropping one there
      // would re-pair every nibble after it -- far more destructive than
      // keeping a corrupt byte.
      uint32_t startNib = 0;
      bool     locked   = false;
      // RECORD LAYER -- PC-1 ONLY.  The 0x80 marker, the 0x5F terminator and
      // the nibble-sum checksum are the PC-1211's header record.  The PC-1500
      // has a different one (five file types, a FF/sum/0x55 footer), which is
      // not yet measured, so a PC-2 capture is packed from frame 0 with no
      // marker hunt.  Do NOT let it search for an 0x80 it will never find and
      // then silently mis-align on a coincidence.
      if (isPc1Rec && ramAddr >= 20) {
        for (uint32_t i = 0; i + 19 < ramAddr; i++) {
          if ((ram.readByte((uint16_t)i) & 0x0F) != 0x08) continue;
          if ((ram.readByte((uint16_t)(i + 1)) & 0x0F) != 0x00) continue;
          uint8_t  n[20];
          for (uint8_t k = 0; k < 20; k++)
            n[k] = (uint8_t)(ram.readByte((uint16_t)(i + k)) & 0x0F);
          if (((n[16] << 4) | n[17]) != 0x5F) continue;      // terminator
          uint8_t sum = 0;
          for (uint8_t k = 2; k < 18; k++) sum = (uint8_t)(sum + n[k]);
          if (sum != (uint8_t)((n[18] << 4) | n[19])) continue;  // checksum
          startNib = i; locked = true; break;
        }
        if (!locked) {
          // No verified header.  Fall back to the first bare 0x80 marker so a
          // capture with a damaged checksum is still usable, and say so.
          for (uint32_t i = 0; i + 1 < ramAddr; i++) {
            if ((ram.readByte((uint16_t)i) & 0x0F) == 0x08 &&
                (ram.readByte((uint16_t)(i + 1)) & 0x0F) == 0x00) {
              startNib = i; break;
            }
          }
        }
      }
      if (SERIALDEBUG) {
        Serial.print(F("PC-1: header "));
        Serial.print(locked ? F("VERIFIED") : F("NOT verified"));
        Serial.print(F(", dropped ")); Serial.print(startNib);
        Serial.println(F(" junk frames"));
      }

      // ---- PC-2: NIBBLE ORDER IS THE OPPOSITE OF THE PC-1 -------------------
      // The PC-1211 sends the HIGH nibble of a byte first.  The PC-1500 sends
      // the LOW nibble first.  Measured, not assumed: the first PC-2 capture
      // packed high-first produced nonsense, and low-first produced
      //     00 0A | 0A | F0 97 | 22 48 45 4C 4C 4F 22 | 0D | FF
      //     line 10 | len 10 | PRINT | "HELLO" | end of line | end of program
      // with the filename "HI" (48 49) readable in the header.  Characters are
      // plain ASCII on this machine, not the PC-1's ASCII+0x10.
      //
      // Also: the capture began with ONE spurious frame, so the frame count was
      // odd and every nibble paired with the wrong neighbour.  For the PC-2 we
      // lock to the header's sync preamble (10 11 12 13 ...) the same way the
      // PC-1 locks to its 0x80 marker -- that fixes alignment and strips
      // pre-lock junk in one step.
      if (!isPc1Rec) {
        for (uint32_t i = 0; i + 5 < ramAddr; i++) {
          uint8_t a = (uint8_t)((ram.readByte((uint16_t)(i + 1)) & 0x0F) << 4)
                    |  (uint8_t)(ram.readByte((uint16_t)i)       & 0x0F);
          uint8_t b = (uint8_t)((ram.readByte((uint16_t)(i + 3)) & 0x0F) << 4)
                    |  (uint8_t)(ram.readByte((uint16_t)(i + 2)) & 0x0F);
          uint8_t c = (uint8_t)((ram.readByte((uint16_t)(i + 5)) & 0x0F) << 4)
                    |  (uint8_t)(ram.readByte((uint16_t)(i + 4)) & 0x0F);
          if (a == 0x10 && b == 0x11 && c == 0x12) { startNib = i; locked = true; break; }
        }
        if (SERIALDEBUG) {
          Serial.print(F("PC-2: sync ")); Serial.print(locked ? F("FOUND") : F("NOT found"));
          Serial.print(F(" at frame ")); Serial.println(startNib);
        }
      }

      uint32_t outLen = 0;
      for (uint32_t i = startNib; i + 1 < ramAddr; i += 2) {
        uint8_t n0 = (uint8_t)(ram.readByte((uint16_t)i)       & 0x0F);
        uint8_t n1 = (uint8_t)(ram.readByte((uint16_t)(i + 1)) & 0x0F);
        // PC-1: first nibble is the HIGH one.  PC-2: first nibble is the LOW one.
        uint8_t v = isPc1Rec ? (uint8_t)((n0 << 4) | n1)
                             : (uint8_t)((n1 << 4) | n0);
        ram.writeByte((uint16_t)outLen, v);
        outLen++;
      }
      if (SERIALDEBUG) {
        Serial.print(F("PC-1: packed ")); Serial.print(ramAddr);
        Serial.print(F(" nibble frames -> ")); Serial.print(outLen);
        Serial.println(F(" bytes"));
      }
      ramAddr = outLen;

      // ---- PC-2: TRIM / REPORT USING THE RECORD'S OWN LENGTH --------------
      // The PC-1500 header carries the image length, so the exact size of a
      // complete tape is arithmetic, not a guess: 42 header bytes + image + the
      // 0xFF, plus a 2-byte checksum per 80 of those, plus one for a partial
      // final block, plus the 0x55.  Anything past that is line noise the
      // decoder found after the tape stopped -- cut it exactly, with no
      // heuristic.  Anything short of it means the capture really did lose
      // data, and saying so here beats discovering it when CLOAD hangs.
      if (!isPc1Rec && outLen >= 44) {
        bool sig = true;
        for (uint8_t i = 0; i < 8; i++)
          if (ram.readByte(i) != (uint8_t)(0x10 + i)) { sig = false; break; }
        if (sig) {
          const uint32_t n    = ((uint32_t)ram.readByte(36) << 8) | ram.readByte(37);
          const uint32_t data = n + 1;
          const uint32_t want = 42 + data + 2 * (data / 80)
                              + ((data % 80) ? 2 : 0) + 1;
          if (outLen > want) {
            if (SERIALDEBUG) {
              Serial.print(F("PC-2: trimming ")); Serial.print(outLen - want);
              Serial.println(F(" trailing noise bytes (header says the tape ends there)"));
            }
            ramAddr = want;
          } else if (outLen < want) {
            if (SERIALDEBUG) {
              Serial.print(F("PC-2 capture SHORT: got ")); Serial.print(outLen);
              Serial.print(F(", header implies ")); Serial.print(want);
              Serial.println(F(" -- this .TAP will hang CLOAD"));
            }
            centerText(tft, "capture SHORT", 150, 0, WHITE, RED, 2);
            { char b[40];
              snprintf(b, sizeof(b), "got %u of %u", (unsigned)outLen, (unsigned)want);
              centerText(tft, b, 175, 0, YELLOW, BLACK, 1); }
            delay(3000);
          }
        }
      }

      String f = currentFile;
      int dot = f.lastIndexOf('.');
      if (dot >= 0) f = f.substring(0, dot);
      currentFile = f + ".TAP";
      if (SERIALDEBUG) { Serial.print(F("PC-1 capture -> ")); Serial.println(currentFile); }
      pc1WantListing = true;
    }
    if (okToFile) writeFile();

    // ---- ALSO WRITE A READABLE .BAS LISTING -------------------------------
    // Reading the PC-1's program format is fully solved (BLAKJAK.tap decodes
    // to a complete 52-line listing with all 1390 bytes accounted for), so a
    // capture can produce human-readable source alongside the .TAP at no cost.
    // The .TAP stays the authoritative artefact -- it is the tape byte stream
    // verbatim and is what CLOADs back.  The .BAS is a convenience view.
    //
    // Deliberately AFTER writeFile(): the packer above rewrote `ram` in place,
    // so the .TAP image is what sits at [0, ramAddr) by this point.
    if (PC1_WRITE_LISTING && okToFile && pc1WantListing) {
      // ---- EXTENSION IS .LST, DELIBERATELY NOT .BAS -----------------------
      // .BAS already means "loadable BASIC source, will be tokenised on send"
      // in this firmware -- for the COMX (FRAMING_SYNC_COMX) and the ET-3400.
      // Writing a PC-1 listing as .BAS put a file in the browser that looks
      // sendable, sits next to working .TAPs, and is not loadable at all,
      // because the PC-1 tokeniser does not exist yet.  Selecting it sent raw
      // ASCII to the machine, which of course failed.
      //
      // .LST says what it is: a listing, for reading, not for loading.  The
      // .TAP remains the only loadable PC-1 artefact.  SendData() also refuses
      // to transmit a non-.TAP in PC-1 mode -- see the guard there.
      String bf = currentFile;
      int d = bf.lastIndexOf('.');
      if (d >= 0) bf = bf.substring(0, d);
      bf += ".LST";
      Pc1Basic pc1b(ram);
      uint16_t n = pc1b.writeListing(ramAddr, bf);
      if (SERIALDEBUG) {
        if (n) {
          Serial.print(F("PC-1: listing -> ")); Serial.print(bf);
          Serial.print(F(" (")); Serial.print(n); Serial.print(F(" lines"));
          if (pc1b.unknownBytes()) {
            // Escapes in the listing mean the character/token table is
            // incomplete.  Say so -- do not let it look like a clean decode.
            Serial.print(F(", ")); Serial.print(pc1b.unknownBytes());
            Serial.print(F(" UNKNOWN bytes shown as {XX}"));
          }
          Serial.println(F(")"));
        } else {
          Serial.println(F("PC-1: no listing (not a program record)"));
        }
      }
    }
  }
}

void writeFile() {
  uint32_t a;
  byte v;
  // FILE_WRITE opens an existing file for *append*, which would corrupt a
  // re-save under the same name (now possible when the tape header supplies a
  // fixed filename like TEST.BIN).  Remove any existing file first so a SAVE
  // overwrites cleanly, matching real cassette behaviour.
  if (SD.exists(currentFile.c_str())) SD.remove(currentFile.c_str());
  myFile = SD.open(currentFile, FILE_WRITE);
  if (myFile) {
    centerText(tft, "Writing file", 10, 0, BLUE, CYAN, 2);
    delay(500);
    for (word a = 0; a < ramAddr; a++) {
      v = ram.readByte(a); 
      myFile.write(v);
      lastActivityTime = millis();  // Initialize activity time
    }
    myFile.close();
    if (SERIALDEBUG) { Serial.println(F("done.")); }
    
      tft.fillScreen(BLACK);
      centerText(tft, "Writing completed", 10, 0, BLUE, YELLOW, 2);
      delay(1000);
  } else {
    // if the file didn't open, print an error:
    if (SERIALDEBUG) { Serial.println(F("Error opening file")); }
    centerText(tft, "ERROR", 10, 0, WHITE, RED, 2);
     delay(1000);
  }
}


// ---------------------------------------------------------------------------
// ORAO .TAP -> program bytes.
//
// An ORAO .TAP holds the *demodulated* tape stream.  For a 'B' (BASIC) image
// the relevant part is, per block:
//     [ $FF... leader ][ $7F ] $1B $1B $1B $1B  'B'  <10-char name>  <blk#>
//     <ASCII payload ...>
// Each block's payload is plain ASCII that runs until the next $FF leader, and
// the whole program ends at a $1A EOF.  We scan for the $1B*4 sync, skip the
// type/name/block# header, and copy payload bytes into RAM until $FF (next
// block) or $1A (done) -- exactly the bytes a normal audio receive would yield.
// Fills ramAddr, captures the embedded name into currentFile, returns true on
// success.  ('O'/object images use a different layout and aren't handled here.)
// ---------------------------------------------------------------------------
bool convertOraoTap(File &f) {
  enum TapSt { HUNT, T_TYPE, T_NAME, T_BLK, T_PAYLOAD };
  TapSt   st      = HUNT;
  uint8_t syncRun = 0;
  uint8_t nameIdx = 0;
  char    tapName[11];
  tapName[0] = '\0';
  char    tapType = 0;
  ramAddr = 0;
  bool gotData = false;
  bool done    = false;

  while (f.available() && !done) {
    uint8_t b = (uint8_t)f.read();
    switch (st) {
      case HUNT:                         // look for the 4-byte $1B sync
        if (b == 0x1B) { if (++syncRun >= 4) { syncRun = 0; st = T_TYPE; } }
        else           { syncRun = 0; }
        break;
      case T_TYPE:
        tapType = (char)b;
        if (b != 'B' && b != 'O') { st = HUNT; break; }   // false sync
        nameIdx = 0; st = T_NAME;
        break;
      case T_NAME:
        if (nameIdx < 10) tapName[nameIdx++] = (char)b;
        if (nameIdx >= 10) { tapName[10] = '\0'; st = T_BLK; }
        break;
      case T_BLK:                        // block number -- not needed
        st = T_PAYLOAD;
        break;
      case T_PAYLOAD:
        if (b == 0x1A) {                 // EOF -> program complete
          ram.writeByte((uint16_t)ramAddr++, 0x1A);
          done = true;
        } else if (b == 0xFF) {          // leader tone -> end of this block
          st = HUNT;
        } else {
          ram.writeByte((uint16_t)ramAddr++, b);
          gotData = true;
        }
        break;
    }
  }

  if (!gotData || tapType != 'B') return false;

  String nm = sanitizeTapeName(tapName);
  if (nm.length() > 0) currentFile = currentPath + nm + ".BIN";
  if (SERIALDEBUG) {
    Serial.print(F("TAP name        : ")); Serial.println(tapName);
    Serial.print(F("TAP -> file      : ")); Serial.println(currentFile);
    Serial.print(F("TAP bytes        : ")); Serial.println(ramAddr);
  }
  return true;
}

// Forward declaration -- defined just below; streamOraoTap() uses it above its
// definition, and static functions aren't auto-prototyped by the IDE.
static uint8_t oraoEncoderReader(uint32_t srcIndex, void* ctx);

// Locate the ORAO 'B' (BASIC) protocol row so a converted TAP can be streamed
// as BASIC regardless of which protocol is currently selected in the UI.
int findOraoBasicProtocol() {
  for (uint8_t i = 0; i < cassetteProtocolCount; i++) {
    if (cassetteProtocols[i].framing  == FRAMING_BLOCK_ORAO &&
        cassetteProtocols[i].oraoType == ORAO_TYPE_BASIC) return (int)i;
  }
  return -1;
}

// --- Local helpers used only by streamOraoTap() ---------------------------
//
// streamOraoTap() needs to emit each tape byte as 8 ORAO cycles, back-to-back,
// while *also* reading the next byte from external RAM.  RamExternal::readByte
// uses digitalWrite() and takes ~660us per call -- way longer than a 362us
// bit-0 cycle -- so calling it between bytes stretches every byte's last bit
// past the ORAO's bit-0/bit-1 timing threshold and the receiver can't sync.
//
// Fix: spread the four-transfer SPI read across the *low phase* of the first
// four bit cells of the current byte.  Each SPI byte transfer takes ~165us,
// which fits comfortably inside a 181us bit-0 low half (and even more inside
// a 363us bit-1 low half).  We follow each piece with a fixed delay sized to
// the bit's half-period minus the SPI piece, so cycle timing is deterministic
// -- crucially we do NOT use micros() inside noInterrupts() (the overflow
// counter is stale there and the delta wraps wrong).  By the time the byte
// finishes emitting, the *next* byte is already in hand -- no inter-byte gap.
//
// These helpers replicate RamExternal::spiTransfer / readByte byte-for-byte
// (digitalWrite-based, proven reliable on the user's hardware) so we never
// touch the shared RamExternal code.  They use the same pins, which is safe
// because streamOraoTap is the only thing accessing RAM during its loop.

static uint8_t tapSpiByte(uint8_t d) {
  uint8_t r = 0;
  for (int8_t i = 7; i >= 0; i--) {
    digitalWrite(ramMOSI, (d >> i) & 1);
    digitalWrite(ramCLK, HIGH);
    r <<= 1;
    if (digitalRead(ramMISO)) r |= 1;
    digitalWrite(ramCLK, LOW);
  }
  return r;
}

static uint8_t tapRamReadByte(uint16_t addr) {
  digitalWrite(ramCS, LOW);
  tapSpiByte(0x03);                     // 23K256 READ
  tapSpiByte((addr >> 8) & 0xFF);
  tapSpiByte(addr & 0xFF);
  uint8_t v = tapSpiByte(0x00);
  digitalWrite(ramCS, HIGH);
  return v;
}

// Emit `cur` as 8 ORAO cycles on tapeOut (LSB first, POSITIVE polarity),
// while reading the byte at `na` from external RAM into `*nxt`.  The 4 SPI
// transfers of the read are dropped into the low phase of bit cells 0..3.
//
// We don't use micros() to time the remainder, because micros() is not
// reliable inside noInterrupts(): Timer0's overflow ISR can't fire, so its
// overflow counter goes stale and the next read wraps incorrectly whenever
// TCNT0 rolls over during the SPI piece.  Instead we use *fixed* delays
// computed from a known-good SPI-piece duration -- each bit cell becomes
// fully deterministic, so timing can't drift cell-to-cell.
static void tapEmitByteWithPrefetch(uint8_t cur,
                                    uint16_t na, uint8_t *nxt,
                                    uint16_t half0, uint16_t half1) {
  // Measured time taken by one piece of the SPI read inside the LOW phase
  // (digitalWrite + tapSpiByte at digitalWrite speed on Mega 2560 @ 16MHz).
  // 165us is conservative; small deviations still leave cycle periods well
  // inside the bit-0 / bit-1 windows (362us +-90, 726us +-200).
  const uint16_t SPI_PIECE_US = 165;
  const uint16_t bit0_spi_tail = (half0 > SPI_PIECE_US) ? (half0 - SPI_PIECE_US) : 0;
  const uint16_t bit1_spi_tail = (half1 > SPI_PIECE_US) ? (half1 - SPI_PIECE_US) : 0;

  for (uint8_t b = 0; b < 8; b++) {
    const uint8_t  bit_val  = (cur >> b) & 1;
    const uint16_t half     = bit_val ? half1 : half0;
    const uint16_t spi_tail = bit_val ? bit1_spi_tail : bit0_spi_tail;

    // HIGH phase -- full half-period.
    digitalWrite(tapeOut, HIGH);
    delayMicroseconds(half);
    // LOW phase -- optionally one SPI piece, then a fixed remainder delay.
    digitalWrite(tapeOut, LOW);
    switch (b) {
      case 0: digitalWrite(ramCS, LOW);  tapSpiByte(0x03);
              delayMicroseconds(spi_tail);                       break;
      case 1: tapSpiByte((na >> 8) & 0xFF);
              delayMicroseconds(spi_tail);                       break;
      case 2: tapSpiByte(na & 0xFF);
              delayMicroseconds(spi_tail);                       break;
      case 3: *nxt = tapSpiByte(0x00);   digitalWrite(ramCS, HIGH);
              delayMicroseconds(spi_tail);                       break;
      default: delayMicroseconds(half);                          break;
    }
  }
}

// Stream an ORAO .TAP by re-modulating its tape byte-stream verbatim.
//
// An ORAO emulator .TAP is a faithful image of the *demodulated* tape: a small
// metadata header (its byte length is the little-endian value in bytes 0-1),
// then the tape stream itself -- leader ($FF tone), $7F, sync ($1B), block
// headers and data.  Re-emitting every tape-stream byte as 8 ORAO cycles
// reproduces the original tape exactly, so this one path works for BASIC,
// single-block object, multi-block, and even custom-loader tapes (like Otto
// Motor) without having to understand any block structure.  ORAO 'B' and 'O'
// share the same bit timing, so a single configure() covers both.
void streamOraoTap() {
  if (SERIALDEBUG) { Serial.print(F("TAP: opening ")); Serial.println(currentFile); }

  File f = SD.open(currentFile, FILE_READ);
  if (!f) {
    if (SERIALDEBUG) Serial.println(F("TAP: open FAILED"));
    centerText(tft, "TAP open failed", 100, 0, WHITE, RED, 2);
    delay(1500);
    return;
  }
  if (SERIALDEBUG) { Serial.print(F("TAP: size ")); Serial.println(f.size()); }

  // Find where the tape stream starts.  Emulator TAPs prefix a metadata header
  // whose length sits little-endian in bytes 0-1.  A raw tape image already
  // begins with leader/sync, so don't skip in that case.
  uint8_t b0 = (uint8_t)f.read();
  uint8_t b1 = (uint8_t)f.read();
  uint16_t skip;
  if (b0 == 0xFF || b0 == 0x1B || b0 == 0x7F) {
    skip = 0;
  } else {
    skip = (uint16_t)b0 | ((uint16_t)b1 << 8);
    if (skip < 3 || skip > 4096) skip = 360;     // guard / common default
  }
  if (SERIALDEBUG) { Serial.print(F("TAP: skip header ")); Serial.println(skip); }

  // Load the tape stream into RAM (so transmit runs with no SD access).
  f.seek(skip);
  uint16_t n = 0;
  uint8_t  buf[128];
  bool ok = true;
  tft.fillScreen(BACKGROUND);
  centerText(tft, "Loading TAP", 10, 0, BLUE, CYAN, 2);
  while (true) {
    int got = f.read(buf, sizeof(buf));
    if (got <= 0) break;
    for (int k = 0; k < got; k++) {
      if (n >= 60000) { ok = false; break; }
      ram.writeByte(n++, buf[k]);
    }
    if (!ok) break;
  }
  f.close();
  if (SERIALDEBUG) { Serial.print(F("TAP: loaded ")); Serial.print(n); Serial.println(F(" bytes")); }
  if (!ok)   { centerText(tft, "TAP too big", 100, 0, WHITE, RED, 2); delay(1500); return; }
  if (n == 0){
    if (SERIALDEBUG) Serial.println(F("TAP: tape stream empty"));
    centerText(tft, "Empty TAP", 100, 0, WHITE, RED, 2); delay(1500); return;
  }

  // Configure ORAO timing (B/O identical) and re-modulate byte-for-byte.
  int bi = findOraoObjectProtocol();
  if (bi < 0) bi = findOraoBasicProtocol();
  if (bi < 0) {
    if (SERIALDEBUG) Serial.println(F("TAP: no ORAO protocol available"));
    centerText(tft, "No ORAO mode", 100, 0, WHITE, RED, 2);
    delay(1500);
    return;
  }
  cassetteEncoder.configure(&cassetteProtocols[bi]);
  if (SERIALDEBUG) {
    Serial.print(F("TAP: configured ")); Serial.println(cassetteProtocols[bi].name);
  }

  // Belt-and-braces: re-assert the output pin in case another code path (touch
  // / TFT) shared or reconfigured it since boot.
  pinMode(tapeOut, OUTPUT);
  digitalWrite(tapeOut, LOW);

  tft.fillScreen(BACKGROUND);
  centerText(tft, "Transferring TAP", 10, 0, BLUE, YELLOW, 2);
  {
    char info[24];
    snprintf(info, sizeof(info), "%u bytes", (unsigned)n);
    centerText(tft, info, 50, 0, BLUE, YELLOW, 2);
  }

  // Read the half-periods once -- ORAO bit-0 = 362us (half=181), bit-1 = 726us
  // (half=363).  We drive tapeOut directly to mirror what cassetteEncoder does
  // for ORAO (digitalWrite, positive polarity) but split the work so the next
  // byte's external-RAM read happens during the current byte's bit cells.
  const CassetteParams *pOrao = &cassetteProtocols[bi];
  uint16_t half0 = pOrao->bit0 / 2;
  uint16_t half1 = pOrao->bit1 / 2;

  // Prefetch the very first byte before the timed loop starts.  This is the
  // only "free" read; every subsequent byte gets read concurrently with the
  // emission of the byte before it.
  uint8_t cur = tapRamReadByte(0);
  uint8_t nxt = 0;

  if (SERIALDEBUG) Serial.println(F("TAP: streaming (interleaved prefetch)"));
  noInterrupts();
  for (uint16_t i = 0; i < n; i++) {
    if (i + 1 < n) {
      tapEmitByteWithPrefetch(cur, (uint16_t)(i + 1), &nxt, half0, half1);
      cur = nxt;
    } else {
      // Last byte: nothing left to prefetch, just emit it with plain timing.
      for (uint8_t b = 0; b < 8; b++) {
        uint16_t half = ((cur >> b) & 1) ? half1 : half0;
        digitalWrite(tapeOut, HIGH);
        delayMicroseconds(half);
        digitalWrite(tapeOut, LOW);
        delayMicroseconds(half);
      }
    }
  }
  interrupts();
  if (SERIALDEBUG) Serial.println(F("TAP: done"));

  tft.fillScreen(BACKGROUND);
  centerText(tft, "Transfer complete", 10, 0, BLUE, YELLOW, 2);
  delay(1000);
}

// Locate the ORAO 'O' (OBJECT) protocol row.
int findOraoObjectProtocol() {
  for (uint8_t i = 0; i < cassetteProtocolCount; i++) {
    if (cassetteProtocols[i].framing  == FRAMING_BLOCK_ORAO &&
        cassetteProtocols[i].oraoType == ORAO_TYPE_OBJECT) return (int)i;
  }
  return -1;
}

// Encoder reader callback for ORAO sendOraoFile().  srcIndex runs 0..N-1 where
// N = endAddr - startAddr + 1; we just translate to an absolute RAM address.
static uint8_t oraoEncoderReader(uint32_t srcIndex, void* /*ctx*/) {
  return ram.readByte((uint16_t)(startAddr + srcIndex));
}

// Case-insensitive check that currentName ends with the given extension
// (e.g. ".BAS").  Used to trigger COMX BASIC tokenisation on SAVE.
static bool currentNameHasExt(const char* ext) {
  int nlen = currentName.length();
  int elen = strlen(ext);
  if (nlen < elen) return false;
  for (int i = 0; i < elen; i++) {
    char c = currentName[nlen - elen + i];
    if (c >= 'a' && c <= 'z') c -= 32;
    char e = ext[i];
    if (e >= 'a' && e <= 'z') e -= 32;
    if (c != e) return false;
  }
  return true;
}

void SendData() {

  const CassetteParams *p = &cassetteProtocols[currentProtocol];

  // ---- PC-1: ONLY .TAP IS LOADABLE ---------------------------------------
  // The PC-1 has no tokeniser yet, so the only thing that can be sent to it is
  // the verbatim tape byte stream in a .TAP.  Anything else -- notably the .LST
  // listing written alongside every capture -- is human-readable text, and
  // transmitting it sends ASCII where the machine expects an 0x80 header
  // record, so CLOAD sits there forever.  Refuse it here with a clear message
  // instead of letting the user watch a load that can never complete.
  // ---- PC-2 ACCEPTS .TAP AND .BAS -----------------------------------------
  // .TAP is the tape byte stream verbatim.  .BAS is source text, tokenised on
  // send by Pc2Basic into the same stream (header, block checksums, footer and
  // all).  Anything else is refused: sending raw ASCII where the machine wants
  // a 42-byte header record leaves CLOAD waiting forever, and that is an
  // afternoon of debugging a load that was never going to work.
  if (strcmp(p->name, "TRS-80 PC-2") == 0 &&
      !currentNameHasExt(".TAP") && !currentNameHasExt(".BAS")) {
    if (SERIALDEBUG) {
      Serial.print(F("PC-2 send REFUSED: ")); Serial.println(currentFile);
      Serial.println(F("  PC-2 accepts .TAP (tape image) or .BAS (source, tokenised on send)"));
    }
    tft.fillScreen(BLACK);
    centerText(tft, "PC-2: .TAP or .BAS", 80, 0, WHITE, RED, 2);
    delay(2500);
    return;
  }
  if (strcmp(p->name, "TRS-80 PC-1") == 0 &&
      !currentNameHasExt(".TAP") && !currentNameHasExt(".BAS")) {
    if (SERIALDEBUG) {
      Serial.print(F("PC-1 send REFUSED: ")); Serial.println(currentFile);
      Serial.println(F("  PC-1 accepts .TAP (tape image) or .BAS (source, tokenised on send)"));
    }
    tft.fillScreen(BLACK);
    centerText(tft, "PC-1: .TAP or .BAS", 80, 0, WHITE, RED, 2);
    centerText(tft, ".LST is a listing, not loadable", 110, 0, YELLOW, BLACK, 1);
    delay(2500);
    return;
  }

  cassetteEncoder.configure(p);
  if (SERIALDEBUG) {
    Serial.print(F("Cassette Mode   : ")); Serial.println(p->name);
    Serial.println("Bit 0           : " + String(p->bit0) + " uS");
    Serial.println("Bit 1           : " + String(p->bit1) + " uS");
    Serial.print(F("Start Bit       : ")); Serial.println(getBitString(p->startBit));
    Serial.print(F("Stop Bit        : ")); Serial.println(getBitString(p->stopBit));
    Serial.print(F("Parity          : ")); Serial.println(getParityString(p->parity));
    Serial.print(F("Endian          : ")); Serial.println(getEndianString(p->bitOrder));
    Serial.print(F("Leader Bit      : ")); Serial.println(getBitString(p->leaderBit));
    Serial.print(F("Leader Count    : ")); Serial.println(p->leaderBits);
    Serial.println("Leader Time     : " + String(p->leaderTime) + " mS");
    Serial.print(F("Trailer         : ")); Serial.println(getBitString(p->trailerBit));
    Serial.println("Trailer Time    : " + String(p->trailerTime) + " mS");
    Serial.print(F("Polarity Mode   : ")); Serial.println(getPolarityString(p->polarity));
    Serial.println(F("Reading data from device......"));
    Serial.println(F("Transferring data to device......"));
  }
  tft.fillScreen(BACKGROUND);
  centerText(tft, "Transferring file", 10, 0, BLUE, YELLOW, 2);
  centerText(tft, "Please wait", 50, 0, BLUE, YELLOW, 2);

  // ---- COMX-35: tokenise BASIC source text into the on-tape image ----------
  // The COMX LOAD routine needs a tokenised image, not raw ASCII.  When we're
  // in COMX mode and the file is BASIC source (.BAS), convert the text that
  // FileLoader put in external RAM [startAddr..endAddr] into the real image and
  // point a LOCAL pair of tx pointers at it.  We must NOT overwrite the global
  // startAddr/endAddr: doing so meant a second send in the same session would
  // re-tokenise the already-tokenised image at 0xC000 (garbage) and the COMX
  // would report error 57.  Keeping the source range in the globals lets the
  // user replay the same file repeatedly.
  uint16_t txStart = startAddr;
  uint16_t txEnd   = endAddr;
  if (p->framing == FRAMING_SYNC_COMX && currentNameHasExt(".BAS")) {
    const uint16_t COMX_IMG_BASE = 0xC000;   // high external-RAM scratch region
    ComxBasic comxBasic(ram);
    uint16_t imgLen = comxBasic.tokeniseInRam(startAddr, endAddr, COMX_IMG_BASE);
    if (imgLen == 0) {
      interrupts();
      if (SERIALDEBUG) {
        Serial.print(F("COMX BASIC tokenise error: "));
        Serial.println(comxBasic.error());
      }
      tft.fillScreen(BACKGROUND);
      centerText(tft, "BASIC token error", 10, 0, WHITE, RED, 2);
      centerText(tft, comxBasic.error(), 50, 0, WHITE, RED, 1);
      delay(2500);
      return;
    }
    txStart = COMX_IMG_BASE;
    txEnd   = COMX_IMG_BASE + imgLen - 1;
    if (SERIALDEBUG) {
      Serial.print(F("COMX BASIC tokenised to image bytes: "));
      Serial.println(imgLen);
    }
  }
  // ---- TRS-80 PC-1: tokenise BASIC source text into the .TAP image ---------
  // Same shape as the COMX branch above and for the same reason: the machine
  // needs the tape byte stream, and raw ASCII leaves CLOAD waiting forever.
  //
  // The CSAVE name comes from the FILENAME (up to 7 characters), so PROG.BAS
  // arrives on the PC-1 as PROG.  That is the only sane source for it -- the
  // name lives in the header record, not in the program text.
  //
  // Tokenised into a high scratch region, NOT over the source, so the same file
  // can be sent repeatedly in one session (the COMX path learned that the hard
  // way: re-tokenising an already-tokenised image produced garbage).
  else if (strcmp(p->name, "TRS-80 PC-1") == 0 && currentNameHasExt(".BAS")) {
    const uint16_t PC1_IMG_BASE = 0xC000;
    char csName[8];
    {
      String bn = currentFile;
      int sl = bn.lastIndexOf('/');  if (sl >= 0) bn = bn.substring(sl + 1);
      int dt = bn.lastIndexOf('.');  if (dt >= 0) bn = bn.substring(0, dt);
      bn.toUpperCase();
      uint8_t k = 0;
      for (uint8_t i = 0; i < bn.length() && k < 7; i++) csName[k++] = bn[i];
      csName[k] = '\0';
    }
    Pc1Basic pc1b(ram);
    uint32_t imgLen = pc1b.tokeniseInRam(startAddr, endAddr, PC1_IMG_BASE, csName);
    if (imgLen == 0) {
      interrupts();
      if (SERIALDEBUG) {
        Serial.print(F("PC-1 BASIC tokenise error: ")); Serial.println(pc1b.error());
      }
      tft.fillScreen(BACKGROUND);
      centerText(tft, "BASIC token error", 10, 0, WHITE, RED, 2);
      centerText(tft, pc1b.error(), 50, 0, WHITE, RED, 1);
      delay(2500);
      return;
    }
    txStart = PC1_IMG_BASE;
    txEnd   = (uint16_t)(PC1_IMG_BASE + imgLen - 1);
    if (SERIALDEBUG) {
      Serial.print(F("PC-1 BASIC tokenised: ")); Serial.print(imgLen);
      Serial.print(F(" bytes, CSAVE name \"")); Serial.print(csName);
      Serial.println(F("\""));
    }
  }
  // ---- TRS-80 PC-2 .BAS -> tape image -------------------------------------
  // Same shape as the PC-1 path above, and for the same reason: tokenise into
  // a HIGH scratch region rather than over the source, so the same file can be
  // sent twice in one session.  Note what tokeniseInRam returns here is the
  // WHOLE tape stream -- 42-byte header, image, block checksums, FF/sum/0x55 --
  // so the sender below treats it exactly like a .TAP and needs no special
  // case.  The CSAVE name comes from the filename, up to 16 characters, which
  // is the only sane source for it: the name lives in the header, not in the
  // program text.
  else if (strcmp(p->name, "TRS-80 PC-2") == 0 && currentNameHasExt(".BAS")) {
    const uint16_t PC2_IMG_BASE = 0xC000;
    char csName[17];
    {
      String bn = currentFile;
      int sl = bn.lastIndexOf('/');  if (sl >= 0) bn = bn.substring(sl + 1);
      int dt = bn.lastIndexOf('.');  if (dt >= 0) bn = bn.substring(0, dt);
      bn.toUpperCase();
      uint8_t k = 0;
      for (uint16_t i = 0; i < bn.length() && k < 16; i++) csName[k++] = bn[i];
      csName[k] = '\0';
    }
    Pc2Basic pc2b(ram);
    uint32_t imgLen = pc2b.tokeniseInRam(startAddr, endAddr, PC2_IMG_BASE, csName);
    if (imgLen == 0) {
      interrupts();
      if (SERIALDEBUG) {
        Serial.print(F("PC-2 BASIC tokenise error: ")); Serial.println(pc2b.error());
      }
      tft.fillScreen(BACKGROUND);
      centerText(tft, "BASIC token error", 10, 0, WHITE, RED, 2);
      centerText(tft, pc2b.error(), 50, 0, WHITE, RED, 1);
      delay(2500);
      return;
    }
    txStart = PC2_IMG_BASE;
    txEnd   = (uint16_t)(PC2_IMG_BASE + imgLen - 1);
    if (SERIALDEBUG) {
      Serial.print(F("PC-2 BASIC tokenised: ")); Serial.print(imgLen);
      Serial.print(F(" tape bytes, CSAVE name \"")); Serial.print(csName);
      Serial.println(F("\""));
    }
  }
  // ---- CHECK A PC-2 .TAP BEFORE SPENDING TWO MINUTES SENDING IT -----------
  // A .TAP goes out verbatim, so a damaged one is only discovered by watching
  // the PC-2 -- and a SHORT tape does not error, it HANGS, because CLOAD waits
  // for bytes that never arrive.  That is indistinguishable from a dozen other
  // faults from the outside, and it cost this project a lot of bench time.
  //
  // validateTap() redoes the arithmetic the machine itself does: header
  // checksum, the length the header implies, every 80-byte block checksum, and
  // the 0x55.  A file that fails here cannot load, so refuse it and say why
  // rather than transmit for two minutes and leave the machine hanging.
  //
  // EXCEPTION: short by exactly the 0x55.  The capture path can lose the final
  // frame (HI.TAP did, and still loaded) and the sender puts the terminator
  // back, so that one is a note, not a refusal.
  else if (strcmp(p->name, "TRS-80 PC-2") == 0 && currentNameHasExt(".TAP")) {
    Pc2Basic pc2v(ram);
    uint32_t want = 0;
    const char *bad = pc2v.validateTap((uint32_t)(endAddr - startAddr + 1), &want);
    const bool repairable = (bad && strstr(bad, "0x55") != nullptr);
    if (SERIALDEBUG) {
      Serial.print(F("PC-2 .TAP check: ")); Serial.print(endAddr - startAddr + 1);
      Serial.print(F(" bytes on card, header implies ")); Serial.print(want);
      Serial.print(F(" -- ")); Serial.println(bad ? bad : "OK");
    }
    if (bad && !repairable) {
      tft.fillScreen(BACKGROUND);
      centerText(tft, "PC-2 .TAP damaged", 10, 0, WHITE, RED, 2);
      centerText(tft, bad, 50, 0, YELLOW, BLACK, 1);
      { char b[40];
        snprintf(b, sizeof(b), "have %u, need %u",
                 (unsigned)(endAddr - startAddr + 1), (unsigned)want);
        centerText(tft, b, 70, 0, WHITE, BLACK, 1); }
      centerText(tft, "not sent - it would hang CLOAD", 95, 0, WHITE, BLACK, 1);
      delay(4000);
      return;
    }
  }
  /* ET-3400 ONLY: the PC-1 shares FRAMING_ASYNC_KCS but must NOT get
     the ET-3400 file conversions (S-records / Tiny BASIC). */
  else if (p->framing == FRAMING_ASYNC_KCS && strcmp(p->name, "ET-3400") == 0 && (currentNameHasExt(".TXT") || currentNameHasExt(".HEX"))) {
    // Plain ASCII Hex file (e.g. "CC DD EE FF") -> S-record image for the
    // ET-3400. No BASIC structure involved, just raw bytes chunked into
    // S1 records at a fixed load address (ASCII Hex has no way to specify
    // its own address -- see ET_TXT_HEX_LOAD_ADDR above).
    const uint32_t ET_DST_BASE = 0x8000UL;
    uint32_t imgLen = convertRawBinaryToSRecords(startAddr, endAddr, ET_TXT_HEX_LOAD_ADDR, ET_DST_BASE);
    txStart = (uint16_t)(ET_DST_BASE & 0xFFFF);
    txEnd   = (uint16_t)((ET_DST_BASE + imgLen - 1) & 0xFFFF);
    if (SERIALDEBUG) {
      Serial.print(F("ET-3400 ASCII Hex -> S-record bytes: ")); Serial.println(imgLen);
      Serial.print(F("Load address: 0x")); Serial.println(ET_TXT_HEX_LOAD_ADDR, HEX);
    }
  }
  else if (p->framing == FRAMING_ASYNC_KCS && strcmp(p->name, "ET-3400") == 0 && currentNameHasExt(".BAS")) {
    // ETA-3400 Tiny BASIC: convert plain source text to a KCS-loadable S-record
    // image.  Tiny BASIC stores source verbatim (no tokenisation) as lines of
    // [lineno_hi][lineno_lo][text][0x0D] from address 0x0100, wrapped in a 256-
    // byte system area.  The resulting S-record ASCII text is sent byte-for-byte
    // over KCS -- exactly what the ET-3400 LOAD command expects.
    const uint32_t ET_DST_BASE = 0x8000UL;   // scratch area in external RAM
    TinyBasConvert tbc(ram);
    uint32_t imgLen = tbc.convert(startAddr, endAddr, ET_DST_BASE);
    if (imgLen == 0) {
      interrupts();
      if (SERIALDEBUG) {
        Serial.print(F("ET-3400 BAS convert error: "));
        Serial.println(tbc.error());
      }
      tft.fillScreen(BACKGROUND);
      centerText(tft, "BASIC convert error", 10, 0, WHITE, RED, 2);
      centerText(tft, tbc.error() ? tbc.error() : "unknown", 50, 0, WHITE, RED, 1);
      delay(2500);
      return;
    }
    txStart = (uint16_t)(ET_DST_BASE & 0xFFFF);
    txEnd   = (uint16_t)((ET_DST_BASE + imgLen - 1) & 0xFFFF);
    if (SERIALDEBUG) {
      Serial.print(F("ET-3400 BAS -> S-record bytes: ")); Serial.println(imgLen);
    }
  }
  else if (p->framing == FRAMING_SYNC_COMX &&
           (endAddr - startAddr + 1) > 16 &&
           ram.readByte(startAddr + 1) == 0x43 &&   // 'C'
           ram.readByte(startAddr + 2) == 0x4F &&   // 'O'
           ram.readByte(startAddr + 3) == 0x4D &&   // 'M'
           ram.readByte(startAddr + 4) == 0x58) {   // 'X'
    // Emma 02 ".comx" container, detected by its "COMX" magic in RAM (robust --
    // the filename-extension check was unreliable).  Layout of the 15-byte
    // header (per Marcel van Tongeren, Emma 02 author):
    //   byte 0     : .comx type
    //   bytes 1-4  : "COMX"
    //   byte 5     : DEFUS high        <- needed
    //   byte 6     : DEFUS low
    //   bytes 7-8  : end of BASIC
    //   bytes 9-14 : start/end data, end string (not needed)
    //   byte 15+   : program data (RAM image from 0x4400)
    // A genuine PSAVE tape image = 00 11 [nBlocks-1] 00 + program data, where the
    // FIRST program byte must be (DEFUS_high - 0x44) (a PSAVE/PLOAD DEFUS-high
    // fixup that some .comx files already carry and some don't).  Verified
    // byte-for-byte against a matched Diver .comx + genuine PSAVE.
    if (SERIALDEBUG) {
      Serial.print(F("COMX .comx detected, name=")); Serial.println(currentName);
    }
    const uint16_t COMX_HEADER_LEN = 15;
    // Per Marcel van Tongeren: the FIRST program byte (comx[15]) is the number of
    // 0x100 pages reserved below the program -- i.e. (DEFUS_high - 0x44).  A plain
    // BASIC file (DEFUS 0x4400) carries 0x00 here; an ML+BASIC file (DEFUS 0x5400)
    // carries 0x10; etc.  The file already stores the correct value, so we do NOT
    // overwrite it.  The implied DEFUS is 0x4400 + firstByte*0x100.  If that runs
    // past the 64K address space (firstByte > 0xBB) the .comx is not a PSAVE image
    // at all but a COMX DOS/FDC direct-RAM-address save, which can never be loaded
    // with PLOAD -- refuse those rather than send an unloadable tape.
    uint8_t firstByte = ram.readByte(startAddr + COMX_HEADER_LEN);
    if (firstByte > 0xBB) {
      centerText(tft, ".comx not PLOAD-compatible", 200, 0, BLACK, RED, 2);
      if (SERIALDEBUG) {
        Serial.print(F("COMX .comx: firstByte 0x")); Serial.print(firstByte, HEX);
        Serial.println(F(" -> implied DEFUS past 64K (DOS direct-address save), cannot PLOAD. Aborting."));
      }
      return;   // do not transmit an unloadable image
    }
    uint16_t hdrPos = startAddr + COMX_HEADER_LEN - 4;  // 4 header bytes before body
    uint32_t comxImgLen = (uint32_t)(endAddr - hdrPos + 1);
    uint16_t dBlocks = (comxImgLen <= 257)
                       ? 1 : 1 + (uint16_t)((comxImgLen - 257 + 255) / 256);
    uint16_t nBlk = dBlocks + 1;                         // + trailing block
    ram.writeByte(hdrPos + 0, 0x00);
    ram.writeByte(hdrPos + 1, 0x11);
    ram.writeByte(hdrPos + 2, (uint8_t)((nBlk - 1) & 0xFF));
    ram.writeByte(hdrPos + 3, 0x00);
    txStart = hdrPos;
    txEnd   = endAddr;
    if (SERIALDEBUG) {
      Serial.print(F("COMX .comx: firstByte(reserve)=")); Serial.print(firstByte, HEX);
      Serial.print(F(" implied DEFUS 0x")); Serial.print(0x4400 + (uint16_t)firstByte * 0x100, HEX);
      Serial.print(F(", header 00 11 "));   Serial.print((uint8_t)(nBlk - 1), HEX);
      Serial.print(F(" 00, image bytes: ")); Serial.print((uint16_t)(txEnd - txStart + 1));
      Serial.print(F(", blocks: "));         Serial.println(nBlk);
    }
  }

  if (p->framing == FRAMING_BLOCK_ORAO) {
    noInterrupts();
    // ----- ORAO block-mode send -----------------------------------------
    // For 'O' (object) mode the load/end addresses come from FileLoader
    // (Intel HEX preserves them; for binary input they default to 0..size-1).
    // For 'B' (BASIC) mode the addresses are unused -- the file is just text.
    // ORAO header filename (up to 10 chars).  Priority:
    //   1. the name the user typed when saving (saveFilename), else
    //   2. the actual file being sent (currentName), with path + extension
    //      stripped, else
    //   3. the BASEFILE default.
    // sendOraoFile() pads to 10 chars with spaces and truncates beyond 10.
    char oraoName[11];
    {
      String n;
      if (saveFilenameLength > 0) {
        n = String(saveFilename);
      } else {
        n = currentName;                       // e.g. "/PROGS/TEST4.BIN"
        int slash = n.lastIndexOf('/');
        if (slash >= 0) n = n.substring(slash + 1);
        int dot = n.lastIndexOf('.');
        if (dot > 0) n = n.substring(0, dot);  // strip extension
      }
      if (n.length() == 0) n = String(BASEFILE);
      uint8_t i = 0;
      for (; i < 10 && i < (uint8_t)n.length(); i++) oraoName[i] = n[i];
      oraoName[i] = '\0';
    }
    const char* fname = oraoName;
    if (SERIALDEBUG) Serial.print(F("ORAO name       : ")); Serial.println(fname);

    uint32_t total = (uint32_t)endAddr - (uint32_t)startAddr + 1;
    cassetteEncoder.sendOraoFile(fname, total, startAddr, endAddr,
                                 oraoEncoderReader, nullptr);
    interrupts();
  } else {
    // ----- Async-serial send --------------------------------------------
    // IMPORTANT: nothing that blocks may happen between bits here.  The byte
    // hex-dump used to run INSIDE this loop via Serial.print(), which (a) takes
    // hundreds of us to ms per call and (b) can't drain with interrupts off --
    // it stretched the 500/1220us COMX cells arbitrarily and stopped the COMX
    // from ever locking.  We now dump the bytes BEFORE the timed loop (with
    // interrupts still enabled), then emit with zero serial I/O in the loop.
    if (SERIALDEBUG) {
      int c = 0; char hexStr[5];
      for (uint32_t addr = txStart; addr <= txEnd; addr++) {
        sprintf(hexStr, "%02X", ram.readByte(addr));
        Serial.print(F(" ")); Serial.print(hexStr); Serial.print(F(" "));
        if (++c > 16) { c = 0; Serial.println(F(" ")); }
      }
      Serial.println(F(" "));
      Serial.flush();          // make sure the UART is idle before timing starts
    }

    // Pre-read each COMX block/record's FIRST byte here, with interrupts STILL
    // ENABLED.  The bit-banged external-RAM read returns corrupted data (the
    // address low byte, e.g. 0x01 for 0xC101, instead of the real value) for the
    // FIRST byte read after a gap when performed inside noInterrupts() -- this
    // garbled one byte at each block boundary.  We cannot hold the whole image in
    // SRAM (that exhausts the Mega and corrupts the display) and we must keep
    // interrupts OFF across the whole timed send (Timer0 jitter trips the
    // marginal COMX bits).  So we cache just the first byte of every block/record
    // now; the send emits those verbatim.
    //
    // The offset of each "first byte" depends on the image layout, so we detect
    // the layout HERE (interrupts on) too:
    //   RAW image      -> record starts at 0, 257, 513, 769, ...  (256/block)
    //   PRE-BLOCKED BIN -> record starts at 0, 257, 514, 771, ... (257/record;
    //                      a saved .BIN or PSAVE capture already has seq bytes)
    const uint8_t COMX_MAX_BLOCKS = 40;          // 40*257 ~= 10 KB image max
    static uint8_t comxFirstByte[COMX_MAX_BLOCKS];
    bool comxPreBlocked = false;
    if (p->framing == FRAMING_SYNC_COMX) {
      uint32_t imgLenPre = txEnd - txStart + 1;
      // Detect the pre-blocked form: size a multiple of 257, "00 11" header, and
      // a sequence byte (01,02,..) at every 257-byte record boundary.
      if ((imgLenPre % 257) == 0 && imgLenPre >= 257 &&
          ram.readByte(txStart) == 0x00 && ram.readByte(txStart + 1) == 0x11) {
        comxPreBlocked = true;
        uint16_t recs = (uint16_t)(imgLenPre / 257);
        for (uint16_t r = 1; r < recs; r++) {
          if (ram.readByte(txStart + (uint32_t)r * 257) != (uint8_t)r) { comxPreBlocked = false; break; }
        }
      }
      for (uint8_t b = 0; b < COMX_MAX_BLOCKS; b++) {
        uint32_t off;
        if (comxPreBlocked) off = (uint32_t)b * 257;              // record boundary
        else                off = (b == 0) ? 0 : (257 + (uint32_t)(b - 1) * 256);
        comxFirstByte[b] = (off < imgLenPre) ? ram.readByte(txStart + off) : 0x00;
      }
    }


    if (SERIALDEBUG && p->framing == FRAMING_SYNC_COMX) {
      // ---- DIAGNOSTIC (prints only, changes no send logic) -----------------
      // Read the block-boundary byte (image offset 256, address txStart+256)
      // several different ways and report what the external RAM returns, so we
      // can see directly why it has been emitted as 0x00 instead of its real
      // value.  txStart is 0xC000, so offset 256 is address 0xC100.
      uint16_t bAddr = txStart + 256;                 // 0xC100 for a 2-block image
      uint8_t  rStandalone = ram.readByte(bAddr);     // fresh, isolated read
      uint8_t  rAfterPrev  = (ram.readByte(bAddr - 1), ram.readByte(bAddr)); // after 0xC0FF
      uint8_t  rTwice      = (ram.readByte(bAddr), ram.readByte(bAddr));     // read twice
      Serial.print(F("DIAG boundary addr=0x")); Serial.print(bAddr, HEX);
      Serial.print(F(" standalone=")); Serial.print(rStandalone, HEX);
      Serial.print(F(" afterPrev="));  Serial.print(rAfterPrev, HEX);
      Serial.print(F(" twice="));      Serial.print(rTwice, HEX);
      Serial.print(F(" (img[256] should be 0x38 for the HELLO test program)"));
      Serial.println();
    }

    noInterrupts();
    if (p->framing != FRAMING_SYNC_COMX) {
      // ----- Generic async send (VIP / ELF II / HUG 1802 / KCS) -----------
      // EXACT v3a behavior: a single leader followed by one continuous stream
      // of bytes (start/data/parity/stop framing handled inside sendByte()).
      // These protocols are NOT block-structured -- they must NOT get the COMX
      // 256-byte block + inter-block leader treatment below.
      // ----- TRS-80 PC-1: nibble payload + short stop + inter-record gap -----
      // The PC-1 differs from every other async protocol here in three ways,
      // all measured against a tape that genuinely loads:
      //   1. each FILE byte goes out as TWO frames, HIGH NIBBLE FIRST, and the
      //      payload is 0xF0 | nibble -- the machine uses only the low nibble
      //      and pads the high one with ones.
      //   2. the stop is NOT a full bit cell.  stopBits is 0 in the table on
      //      purpose; the real stop is 6 cycles of mark (1.50 ms vs a 2.00 ms
      //      cell).  Emitting a whole stop bit makes every mark run 2-3 cycles
      //      too long; emitting none makes each frame 9 cells instead of 9.75,
      //      i.e. ~8% fast with no mark between frames at all.
      //   3. the two records (header, then program) are separated by ~129 mark
      //      bits of gap.  The file carries both records back to back, so the
      //      gap is emitted after the first record.
      // PC1_HEADER_BYTES is the header record length: 1 marker + 8 data + 1
      // checksum.  A file shorter than that is sent as a single record.
      const bool isPc1 = (strcmp(p->name, "TRS-80 PC-1") == 0);
      const bool isPc2 = (strcmp(p->name, "TRS-80 PC-2") == 0);

      // ---- TRS-80 PC-2 (Sharp PC-1500) send ---------------------------------
      // Same 4-vs-8-cycle FSK as the PC-1, so the encoder is reused.  THREE
      // differences, all measured from a real capture rather than assumed:
      //
      //  1. NIBBLE ORDER IS REVERSED.  The PC-1 sends the high nibble first;
      //     the PC-2 sends the LOW nibble first.  Getting this backwards
      //     produces a tape that looks structurally perfect and decodes to
      //     nonsense -- it is what the first PC-2 capture did.
      //  2. THE STOP IS SIX WHOLE BIT CELLS, not the PC-1's short 6-cycle
      //     burst.  sendByte(0xF0|nibble) already emits 4 data bits plus 4 mark
      //     cells, so only 2 more cells are needed: 4 + 2 = 6.
      //  3. NO 3.65 s BLOCK GAPS.  The capture ran continuously, unlike the
      //     PC-1's 3.65 s gap every 90 bytes.  What it DOES have is a short
      //     interim sync -- see (5).
      //  4. THE FILE-TYPE NIBBLE.  The tape opens with a SINGLE LONE NIBBLE
      //     0xA (= IDENT_PC1500) in a frame of its own, before the header.
      //     That is why the raw capture's frame count was odd.  The receiver
      //     deliberately drops it when it locks to "10 11 12", so it is NOT in
      //     the .TAP and MUST be re-created here.  Without it every following
      //     nibble reaches the machine paired with the wrong neighbour and
      //     CLOAD sits forever waiting for a file type it never sees.
      //     THIS WAS THE CLOAD HANG.
      //     Confirmed two independent ways: nibble 0 of the raw 58-byte HI
      //     capture is 0xA, and PocketTools bin2wav emits exactly
      //     WriteQuaterToWav(IDENT_PC1500, 6) before the PC-1500 header.
      //  5. INTERIM SYNC AFTER THE 42-BYTE HEADER.  bin2wav writes
      //     WriteSyncToWav(75) between header and data -- 75 mark cells,
      //     ~240 ms.  It carries no frames, so a capture cannot show it and
      //     the .TAP holds header and data back to back.  Re-created here.
      //
      // The 42-byte header is confirmed by the capture itself, not only by
      // bin2wav: 10 11 12 13 14 15 16 17 | 01 (BASIC image) | 16 name bytes
      // ("HI") | 9 nulls | addr 00C5 | len 000D | entry 0000 | sum 0200 --
      // and 0x0200 is the plain 16-bit sum of the 40 bytes before it.  EXACT.
      if (isPc2) {
        const uint8_t  PC2_EXTRA_STOP_CELLS   = 2;    // 4 from sendByte + 2 = 6
        const uint8_t  PC2_IDENT_NIBBLE       = 0x0A; // IDENT_PC1500
        const uint16_t PC2_HEADER_BYTES       = 42;
        const uint16_t PC2_INTERIM_SYNC_CELLS = 70;   // 224 ms, MEASURED
        const uint8_t  PC2_EOF_BYTE           = 0x55; // EOF_15

        const uint32_t txLen = (txEnd - txStart + 1);


        cassetteEncoder.sendSilence(870);
        cassetteEncoder.sendLeader();

        // (4) the lone file-type nibble, in a frame of its own
        cassetteEncoder.sendByte((uint8_t)(0xF0 | PC2_IDENT_NIBBLE));
        cassetteEncoder.sendToneCycles(1, PC2_EXTRA_STOP_CELLS * p->bit1_cycle);

        uint32_t idx = 0;
        for (uint32_t addr = txStart; addr <= txEnd; addr++, idx++) {
          // ---- GAP BEFORE THE END-OF-FILE BYTE ------------------------------
          // A tape this machine accepts puts 70 mark cells (224 ms) between the
          // last checksum byte and the 0x55, and this was NOT being emitted --
          // the 0x55 followed the data immediately.  Measured, not guessed:
          // a WAV of BOWLING that loads decodes to 31030 cells over 99.30 s
          // (3.200 ms per cell exactly) with mark runs of 625 / 70 / 70 / 70
          // cells at the leader, after byte 42, before the 0x55, and after it.
          //
          // It was left out earlier because HI.TAP loaded without it, which
          // proved only that the machine tolerates its absence sometimes.
          if (idx + 1 == txLen && ram.readByte(txEnd) == PC2_EOF_BYTE) {
            cassetteEncoder.sendToneCycles(1,
                (uint16_t)((uint32_t)PC2_INTERIM_SYNC_CELLS * p->bit1_cycle));
          }
          uint8_t b = ram.readByte(addr);
          // LOW nibble first -- the opposite of the PC-1
          cassetteEncoder.sendByte((uint8_t)(0xF0 | (b & 0x0F)));
          cassetteEncoder.sendToneCycles(1, PC2_EXTRA_STOP_CELLS * p->bit1_cycle);
          cassetteEncoder.sendByte((uint8_t)(0xF0 | (b >> 4)));
          cassetteEncoder.sendToneCycles(1, PC2_EXTRA_STOP_CELLS * p->bit1_cycle);

          // (5) interim sync, once, immediately after the header record
          if (idx + 1 == (uint32_t)PC2_HEADER_BYTES && txLen > PC2_HEADER_BYTES) {
            cassetteEncoder.sendToneCycles(1,
                (uint16_t)((uint32_t)PC2_INTERIM_SYNC_CELLS * p->bit1_cycle));
          }
        }

        // ---- FOOTER REPAIR -------------------------------------------------
        // The file must end 0xFF, sum_hi, sum_lo, 0x55.  Verified on the HI
        // capture: sum = 045F = the 16-bit sum of the 13 program bytes PLUS
        // the 0xFF itself.  The capture path can lose the final frame to the
        // signal-quality truncation -- the HI.TAP we have does exactly that,
        // it stops at ...FF 04 5F.  A .TAP with no 0x55 leaves CLOAD waiting
        // for an end-of-file that never arrives, so put the terminator back.
        // ONLY the terminator is reconstructed; no checksum is ever invented.
        if (txLen > 0 && ram.readByte(txEnd) != PC2_EOF_BYTE) {
          if (SERIALDEBUG)
            Serial.println(F("PC-2: .TAP has no 0x55 EOF -- appending one"));
          // Same 70-cell gap the genuine tape puts before its EOF byte.
          cassetteEncoder.sendToneCycles(1,
              (uint16_t)((uint32_t)PC2_INTERIM_SYNC_CELLS * p->bit1_cycle));
          cassetteEncoder.sendByte((uint8_t)(0xF0 | (PC2_EOF_BYTE & 0x0F)));
          cassetteEncoder.sendToneCycles(1, PC2_EXTRA_STOP_CELLS * p->bit1_cycle);
          cassetteEncoder.sendByte((uint8_t)(0xF0 | (PC2_EOF_BYTE >> 4)));
          cassetteEncoder.sendToneCycles(1, PC2_EXTRA_STOP_CELLS * p->bit1_cycle);
        }

        cassetteEncoder.sendTrailer();
      }
      else if (isPc1) {
        // Gap structure, measured from a GENUINE machine recording
        // (BLAKJAK.wav, 131.9 s, whose byte stream matches BLAKJAK.tap 1573/1573):
        //   header record = 10 bytes, then a 0.44 s mark gap
        //   then the program in 90-BYTE BLOCKS, each followed by a 3.65 s gap
        // There are 18 such gaps in that tape, at byte offsets 10, 100, 190,
        // 280 ... i.e. every 90 bytes after the header.  They dominate the
        // running time: 0.44 + 17 x 3.65 = 62.5 s of the 131.9 s total, against
        // 60.3 s of actual frame data.  Emitting the bytes back-to-back (what
        // this did before) finishes in ~66 s and the PC-1 never leaves CLOAD --
        // it needs those gaps between blocks.
        const uint16_t PC1_HEADER_BYTES = 10;
        // stop length now comes from PC1_STOP_CYCLES in CassetteEncoder.h (measured 4.6 cycles)
        const uint16_t PC1_HDR_GAP_BITS = 220;    // 0.44 s
        const uint16_t PC1_BLOCK_BYTES  = 90;
        const uint16_t PC1_BLK_GAP_BITS = 1823;   // 3.65 s
        // The genuine recording opens with 0.87 s of TRUE SILENCE before the
        // leader tone starts.  VIPTAPE was driving the tone from the first
        // instant.  The COMX path already does this (sendSilence(200) before
        // its leader) because the receiving machine needs a quiet interval to
        // settle its input stage before it will lock onto a leader.
        cassetteEncoder.sendSilence(870);
        cassetteEncoder.sendLeader();
        uint32_t idx = 0;
        for (uint32_t addr = txStart; addr <= txEnd; addr++, idx++) {
          if (idx == PC1_HEADER_BYTES) {                 // after the header record
            for (uint16_t g = 0; g < PC1_HDR_GAP_BITS; g++) cassetteEncoder.pulseBit(1);
          } else if (idx > PC1_HEADER_BYTES &&
                     ((idx - PC1_HEADER_BYTES) % PC1_BLOCK_BYTES) == 0) {
            for (uint16_t g = 0; g < PC1_BLK_GAP_BITS; g++) cassetteEncoder.pulseBit(1);
          }
          uint8_t b = ram.readByte(addr);
          cassetteEncoder.sendByte((uint8_t)(0xF0 | (b >> 4)));
          cassetteEncoder.sendToneCycles(1, PC1_STOP_CYCLES);
          cassetteEncoder.sendByte((uint8_t)(0xF0 | (b & 0x0F)));
          cassetteEncoder.sendToneCycles(1, PC1_STOP_CYCLES);
        }
        cassetteEncoder.sendTrailer();
      } else {
      cassetteEncoder.sendLeader();
      for (uint32_t addr = txStart; addr <= txEnd; addr++) {
        cassetteEncoder.sendByte(ram.readByte(addr));
      }
      cassetteEncoder.sendTrailer();
      }
      interrupts();
      saveLastMode();
      if (SERIALDEBUG) {
        Serial.println(F(" "));
        Serial.println(F("Transfer complete."));
      }
      tft.fillScreen(BLACK);
      centerText(tft, "Transfer complete", 10, 0, BLUE, YELLOW, 2);
      delay(1000);
      return;
    }
    // COMX-35 BASIC PSAVE playback (see detailed format note below).
    {
      // COMX BASIC PSAVE format -- CONFIRMED by decoding a genuine COMX save
      // (Test99.wav) of 10 PRINT"HELLO"/20 GOTO 10 in full:
      //   The save is the program RAM region streamed as 256-byte BLOCKS with a
      //   ~3907-cell bit0 re-sync leader between blocks (NO silence, NO 00 00
      //   header -- the data is the raw image, block 1 starting with its own
      //   00 11 01...).  Even this tiny program produced TWO 256-byte blocks
      //   (512 bytes total): block 1 = program + RAM tail, block 2 = more RAM
      //   (mostly zero).  Sending only one block made the COMX wait for the
      //   second block's leader/data and report error 57 at the END of the load.
      //   Layout: [~20s leader][256B block][~3907-cell leader][256B block]...
      //   We pad the image up to a whole number of 256-byte blocks (>=2, since
      //   the COMX always writes at least the full 512-byte program region).
      // ROM-confirmed block structure: the COMX PLOAD routine reads and STORES
      // exactly 256 bytes per block (R10 counts 0x40FF down to high byte 0x3F =
      // 0x100 = 256), then reads ONE more tape byte that it does NOT store -- a
      // trailer/sync byte that the genuine tape carries (making 257 bytes per
      // block on tape).  We were sending 257 *data* bytes per block, so the COMX
      // stored only our first 256 and DISCARDED our 257th, dropping image byte
      // 256, 513, ... -- everything after the first boundary shifted by one and
      // garbled from the first line of block 2.  Sending 256 DATA bytes plus 1
      // (discarded) trailer byte per block keeps the stored image contiguous.
      const uint16_t COMX_DATA       = 256;   // DATA bytes per block (plus a
                                              // leading sequence byte = 257 on tape)
      const uint8_t  COMX_MIN_BLOCKS = 2;     // at least 1 data + 1 trailing block

      // Trailing-block toggle.  A genuine COMX save writes ONE extra block after
      // the program data (TEST210: a 301-byte program produced 3 blocks = 2 data
      // + 1 trailing).  Set to 1 to include it (matches genuine), 0 to omit it
      // for testing whether the loader actually requires it.
      const uint8_t  COMX_TRAILING_BLOCK = 1;

      uint32_t imgLen  = txEnd - txStart + 1;

      // preBlocked was determined during the interrupts-on pre-read above, using
      // the same test (size % 257, "00 11" header, sequence bytes at boundaries).
      bool preBlocked = comxPreBlocked;

      // block 0 carries 257 image bytes; each later block carries 256.
      uint16_t dataBlocks;
      if (imgLen <= 257) dataBlocks = 1;
      else               dataBlocks = 1 + (uint16_t)((imgLen - 257 + 255) / 256);
      uint16_t nBlocks = dataBlocks + (COMX_TRAILING_BLOCK ? 1 : 0);
      if (nBlocks < COMX_MIN_BLOCKS) nBlocks = COMX_MIN_BLOCKS;

      if (SERIALDEBUG) {
        Serial.print(F("COMX v59 blk: img[0]="));
        Serial.print(ram.readByte(txStart), HEX);
        Serial.print(F(" img[1]=")); Serial.print(ram.readByte(txStart + 1), HEX);
        Serial.print(F("  imgLen=")); Serial.print(imgLen);
        Serial.print(F(" preBlocked=")); Serial.print(preBlocked ? 1 : 0);
        Serial.print(F(" blocks=")); Serial.print(preBlocked ? (uint16_t)(imgLen/257) : nBlocks);
        Serial.print(F(" trailing=")); Serial.println(COMX_TRAILING_BLOCK);
      }

      if (preBlocked) {
        // Stream the stored 257-byte records verbatim: initial leader before the
        // first, an inter-block gap+leader before each subsequent one.  The
        // sequence bytes are already the first byte of records 1..N, so we do
        // NOT add our own.  Reads happen inside noInterrupts; a throwaway warm-up
        // read before each record absorbs the first-read-after-gap corruption.
        uint16_t recs = (uint16_t)(imgLen / 257);
        for (uint16_t r = 0; r < recs; r++) {
          if (r == 0) {
            cassetteEncoder.sendSilence(200);
            cassetteEncoder.sendLeader();
          } else {
            cassetteEncoder.sendSilence(185);
            const uint16_t COMX_LEAD_INTER_TOTAL = 3944;
            for (uint16_t i = 0; i < COMX_LEAD_INTER_TOTAL; i++) cassetteEncoder.pulseBit(0);
          }
          uint32_t recBase = txStart + (uint32_t)r * 257;
          (void)ram.readByte(recBase);                  // warm-up read (discarded)
          uint8_t firstB = comxFirstByte[r < COMX_MAX_BLOCKS ? r : 0];
          for (uint16_t i = 0; i < 257; i++) {
            uint8_t b = (i == 0 && r < COMX_MAX_BLOCKS) ? firstB
                                                        : ram.readByte(recBase + i);
            cassetteEncoder.sendByte(b);
          }
        }
      } else {

      // Verified block format (genuine TEST210, a program spanning blocks):
      //   block 0        = image[0..256]                         (257 bytes)
      //   block N (N>=1)  = [seq=N] + image[257+(N-1)*256 .. +255] (1+256)
      // plus one TRAILING block after the data (its image offsets are past the
      // program, so it comes out as [seq]+padding).  Genuine block 1 began with
      // 0x01 and block 2 with 0x02, confirming the sequence prefix and the extra
      // trailing block that the loader needs to see the program end.
      cassetteEncoder.sendSilence(200);
      cassetteEncoder.sendLeader();                       // ~20s initial leader
      // Verified block format (genuine TEST210, a program spanning blocks):
      //   block 0        = image[0..256]                         (257 bytes)
      //   block N (N>=1)  = [seq=N] + image[257+(N-1)*256 .. +255] (1+256)
      // plus one TRAILING block after the data.  Interrupts stay OFF for the
      // whole send (set once, above); the per-block external-RAM read below runs
      // inside that noInterrupts region during the block gap, so it never toggles
      // interrupts and never runs between data cells.
      for (uint16_t blk = 0; blk < nBlocks; blk++) {
        if (blk > 0) {
          // Inter-block gap: ~185 ms silence then a ~3944-cell re-sync leader.
          cassetteEncoder.sendSilence(185);
          const uint16_t COMX_LEAD_INTER_TOTAL = 3944;
          for (uint16_t i = 0; i < COMX_LEAD_INTER_TOTAL; i++) cassetteEncoder.pulseBit(0);
        }
        uint32_t imgLenLocal = txEnd - txStart + 1;
        uint32_t base;
        uint16_t nData;
        if (blk == 0) { base = 0;                              nData = 257; }
        else          { base = 257 + (uint32_t)(blk - 1) * 256; nData = 256; }

        if (blk != 0) cassetteEncoder.sendByte((uint8_t)blk);  // sequence byte N

        // The FIRST external-RAM read after the leader/gap returns garbage (the
        // address low byte) inside noInterrupts().  Do one throwaway read to
        // absorb that, so the real reads below are clean.  Byte 0 additionally
        // comes from the interrupts-on pre-read cache as belt-and-suspenders.
        (void)ram.readByte(txStart + base);                    // warm-up (discarded)

        for (uint16_t i = 0; i < nData; i++) {
          uint8_t b;
          if (i == 0 && blk < COMX_MAX_BLOCKS) {
            b = comxFirstByte[blk];              // pre-read cache (interrupts-on)
          } else {
            uint32_t off = base + i;
            b = (off < imgLenLocal) ? ram.readByte(txStart + off) : 0x00;
          }
          cassetteEncoder.sendByte(b);
        }
      }
      }
    }
    cassetteEncoder.sendTrailer();
    interrupts();
    if (SERIALDEBUG) {
      // Build-verification banner: if you do NOT see this line after a reflash,
      // the IDE did not recompile the updated firmware (stale build).
      Serial.print(F("COMX send done. timing-cal v3 overhead="));
      Serial.print(ENC_CAL_OVERHEAD_US);
      Serial.print(F("us/half"));
      Serial.print(F("  bit0=")); Serial.print(p->bit0);
      Serial.print(F("us bit1=")); Serial.println(p->bit1);
    }
  }

  saveLastMode();
  if (SERIALDEBUG) {
    Serial.println(F(" "));
    Serial.println(F("Transfer complete."));
  }
  tft.fillScreen(BLACK);
  centerText(tft, "Transfer complete", 10, 0, BLUE, YELLOW, 2);
  delay(1000);
}
void showScreenSaver(int hangTime) {
  tft.fillScreen(BLACK);
  tft.drawBitmap(0, 0, cosmac, 240, 320, FOREGROUND);
  /*Special messaging*/
  centerText(tft, MESSAGE5, 245, 0, BLUE, BLACK, 2);
  centerText(tft, MESSAGE6, 265, 0, BLUE, BLACK, 2);

  if (hangTime > 0) delay(hangTime);
}

void activateScreenSaver() {
  screensaverActive = true;
  tft.fillScreen(BLACK);  // Clear the screen
  if (SERIALDEBUG) { Serial.println(F("Screen saver activated")); }
}

void deactivateScreenSaver() {
  screensaverActive = false;
  tft.fillScreen(BLACK);        // Clear the screensaver content
  lastActivityTime = millis();  // Reset activity timer
  if (SERIALDEBUG) { Serial.println(F("Screen saver de-activated")); }
}

void ResetMode(int full) {
  saveFilename[FILENAME_SIZE] = "";
  saveFilenameLength = 0;
  if (full == 1) {
    currentName = "";
    currentPath = "/";
    currentIndex = 0;
  }
  currentFile = "";
  actionFlag = 0;
  keyboardEntry = 0;
}

void loop() {

  unsigned long currentTime = millis();
  // Check for inactivity
  if (!screensaverActive && (currentTime - lastActivityTime >= INACTIVITY_THRESHOLD)) {
    activateScreenSaver();
    showScreenSaver(0);
  } else {
    /* Check button press*/
    if (debounceButton(0)) {
      pressed = "Up";
    } else if (debounceButton(1)) {
      pressed = "Down";
    } else if (debounceButton(2)) {
      pressed = "Yes";
      if (currentFile != "" && actionFlag == 1) {
        pressed = "Play";
      }
    } else if (debounceButton(3)) {
      pressed = "No";
    } else {
      pressed = "*";
    }

    if (SERIALDEBUG) {
      if (pressed != "*") { Serial.print(F("Button ")); Serial.println(pressed); }
    }

    TSPoint pc = ts.getPoint();
    // Restore pin states (shared pins with TFT)
    pinMode(YP, OUTPUT);
    pinMode(XM, OUTPUT);
    if (pc.z > MINPRESSURE && pc.z < MAXPRESSURE) {
      touched = 1;
    } else {
      touched = 0;
    }
    if (touched == 1 || pressed != "*") {
      if (screensaverActive) {
        deactivateScreenSaver();
        displayFiles(1);
      } else {
        lastActivityTime = millis();  // Reset activity timer
        // Map touch coordinates to screen coordinates
        int16_t x = map(pc.x, TS_MINX, TS_MAXX, 0, tft.width());
        int16_t y = map(pc.y, TS_MINY, TS_MAXY, 0, tft.height());
        numAreas = numValidButtons[actionFlag];
        for (int i = 0; i < numAreas; i++) {
          if (x >= screenButtons[actionFlag][i].xMin && x <= screenButtons[actionFlag][i].xMax && y >= screenButtons[actionFlag][i].yMin && y <= screenButtons[actionFlag][i].yMax) {
            Serial.println(screenButtons[actionFlag][i].name);
            pressed = screenButtons[actionFlag][i].name;
            if (pressed == "Play" && actionFlag == 0) { pressed = "Record"; }
            break;
          }
        }
        if (SERIALDEBUG) {
          Serial.print(F("Button: ")); Serial.println(pressed);
          Serial.print(F("Touched: ")); Serial.println(touched);
        }

        if (keyboardEntry == 1) {
          for (int row = 0; row < 7; row++) {
            for (int col = 0; col < 6; col++) {
              int xk = BUTTON_START_X + col * (BUTTON_WIDTH + BUTTON_SPACING);
              int yk = BUTTON_START_Y + row * (BUTTON_HEIGHT + BUTTON_SPACING);
              if (x >= xk && x <= xk + BUTTON_WIDTH && y >= yk && y <= yk + BUTTON_HEIGHT) {
                char key = keys[row][col];
                if (SERIALDEBUG) { Serial.println(String("Character : " + key)); }

                if (key == '*') {
                  if (saveFilenameLength == 0) {
                    currentFile = getUniqueFileName();
                  } else {
                    currentFile = currentPath + saveFilename + ".BIN";
                  }
                  keyboardEntry = 2;
                  actionFlag = 2;
                  displayFileToSaveInfo();
                  drawButtons();
                  if (SERIALDEBUG) {
                    Serial.print(F("saveFilename entered: "));
                    Serial.println(currentFile);
                  }
                  saveFilename[0] = '\0';
                  saveFilenameLength = 0;
                } else if (key == '@') {
                  if (saveFilenameLength > 0 || saveFilenameLength == 0) {
                    saveFilenameLength--;
                    saveFilename[saveFilenameLength] = '\0';
                    if (saveFilenameLength < 0) {
                      saveFilename[0] = '\0';
                      saveFilenameLength = 0;
                    }
                    updatesaveFilenameDisplay();
                  }
                }

                else if (saveFilenameLength == (FILENAME_SIZE - 1) || saveFilenameLength > (FILENAME_SIZE - 1)) {
                  continue;
                }

                else if (saveFilenameLength < (FILENAME_SIZE - 1)) {  // Add character if not at limit
                  saveFilename[saveFilenameLength++] = key;
                  saveFilename[saveFilenameLength] = '\0';
                  updatesaveFilenameDisplay();
                }
                lastActivityTime = millis();  // Initialize activity time
                delay(200);  // Debounce
              }
            }
          }
        } else {
          /* Play */
          if (pressed == "Play" && currentFile != "" && actionFlag == 1) {
            getFile(startAddr, endAddr, fileSize, fileExt);
            displayInfo(startAddr, endAddr, fileSize, fileExt);
            actionFlag = 2;
            drawButtons();
          }
          /* Record */
          else if (pressed == "Record" && currentFile == "" && actionFlag == 0 && keyboardEntry == 0) {
            keyboardEntry = 1;
            if (SERIALDEBUG) { Serial.println(F("Keyboard Entry")); }
            tft.fillScreen(BLACK);
            drawKeyboard();
          }
          /* Up */
          else if (pressed == "Up") {
            if (SERIALDEBUG) { Serial.println(F("Up")); }
            if (fileList[currentIndex] == "..") {
              navigateToSelection(1);
            } else {
              moveSelection(-1);
            }
          }
          /* Down */
          else if (pressed == "Down") {
            moveSelection(1);
            if (SERIALDEBUG) { Serial.println(F("Down")); }
          }

          /* Previous page */
          else if (pressed == "Prev") {
            if (SERIALDEBUG) { Serial.println(F("Prev page")); }
            if (fileList[currentIndex] == "..") {
              navigateToSelection(1);
            } else {
              moveSelection(-ITEMS_PER_PAGE);
            }
          }
          /* Next page */
          else if (pressed == "Next") {
            if (SERIALDEBUG) { Serial.println(F("Next page")); }
            moveSelection(ITEMS_PER_PAGE);
          }
          /* No option*/
          else if (pressed == "No") {
            if (SERIALDEBUG) {
              Serial.println(currentFile);
              Serial.println(F("No"));
            }
            ResetMode(0);
            loadDirectory(currentPath);
            displayFiles(1);
          }
          /* Yes option*/
          else if (pressed == "Yes") {
            if (SERIALDEBUG) {
              Serial.println(currentFile);
              Serial.println(F("Yes"));
            }
            if (keyboardEntry == 2) {
              if (SERIALDEBUG) { Serial.println(currentFile); }
              tft.fillScreen(BACKGROUND);
              centerText(tft, "Reading....", 10, 0, BLUE, CYAN, 2);
              centerText(tft, "Please wait", 50, 0, BLUE, CYAN, 2);
              ReadData();
              ResetMode(0);
              keyboardEntry = 0;
              actionFlag = 0;
              loadDirectory(currentPath);
              displayFiles(1);
            } else if (currentFile != "") {
              // .TAP dispatch.  streamOraoTap() is ORAO-SPECIFIC: it looks up
              // the ORAO protocol row itself and hard-codes ORAO cycle timing
              // (362us/726us, one cycle per bit, 8 raw bits per byte, no
              // framing).  Routing EVERY .TAP through it ignores the selected
              // protocol entirely -- a TRS-80 PC-1 .TAP came out at roughly
              // 4ms per byte instead of 39ms, i.e. about TEN TIMES too fast.
              // Only send a .TAP that way when ORAO is actually selected;
              // everything else goes through SendData(), which honours the
              // protocol table.
              const CassetteParams *sp = &cassetteProtocols[currentProtocol];
              const bool tapExt = currentFile.endsWith(".TAP") || currentFile.endsWith(".tap");
              if (tapExt && sp->framing == FRAMING_BLOCK_ORAO) {
                // ORAO tape image: re-modulate the tape stream straight to the
                // ORAO, reproducing the original tape (any block layout).
                streamOraoTap();
              } else {
                SendData();
              }
              keyboardEntry = 0;
              actionFlag = 0;
              ResetMode(0);
              loadDirectory(currentPath);
              displayFiles(1);
            } else {
              if (fileList[currentIndex] == ".." || fileList[currentIndex].endsWith("/")) {
                navigateToSelection(1);
              } else {
                currentFile = currentPath + fileList[currentIndex];
                currentName = fileList[currentIndex];
                actionFlag = 1;
                navigateToSelection(1);
              }
            }
          } else if (pressed == "Type") {
            nextProtocol();
            const CassetteParams *p = cassetteDecoder.getParams();
            if (p) {
              positionText(tft, p->name, 42, 10, 12, WHITE, BLUE, TEXTSIZE);
              if (SERIALDEBUG) { Serial.println(p->name); }
            }
          }

          /* Select item */
          else if (y > Y_OFFSET && y < (Y_OFFSET + CHAR_HEIGHT * ITEMS_PER_PAGE)) {
            int selectedItem = ((y - Y_OFFSET) / CHAR_HEIGHT) + displayStart;
            if (selectedItem >= 0 && selectedItem < fileCount) {
              currentIndex = selectedItem;
              if (fileList[currentIndex] == "" || fileList[currentIndex] == ".." || fileList[currentIndex].endsWith("/")) {
                currentFile = "";
                currentName = "";
                actionFlag = 0;
              } else {
                currentFile = currentPath + fileList[currentIndex];
                currentName = fileList[currentIndex];
                actionFlag = 1;
              }
              navigateToSelection(1);
              if (SERIALDEBUG) {
                Serial.print(F("Selected : ")); Serial.println(currentFile);
                Serial.println(pressed);
              }
            }
          }
          delay(200); /* Debounce delay*/
        }
      }
    }
  }
}
