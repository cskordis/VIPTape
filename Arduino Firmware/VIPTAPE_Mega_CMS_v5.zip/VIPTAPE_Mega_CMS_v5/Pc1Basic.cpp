#include "Pc1Basic.h"
#include <SD.h>
#include <avr/pgmspace.h>

// ===========================================================================
// Character table -- PC-1211 internal code for each ASCII character.
// Ported from PocketTools conv_asc2old().  Digits and A-Z are ASCII+0x10; the
// codes below 0x40 are their OWN table and do NOT follow that rule.  Applying
// +0x10 across the board turns '=' into '$' and hides every operator.
// ===========================================================================
struct AscMap { char asc; uint8_t code; };
static const AscMap CHARS[] PROGMEM = {
  {' ', 17}, {'"', 18}, {'?', 19}, {'!', 20}, {'#', 21}, {'%', 22},
  {'$', 24}, {',', 27}, {';', 28}, {':', 29}, {'@', 30}, {'&', 31},
  {'(', 48}, {')', 49}, {'>', 50}, {'<', 51}, {'=', 52}, {'+', 53},
  {'-', 54}, {'*', 55}, {'/', 56}, {'^', 57}, {'.', 74}, {'~', 77},
  {'_', 78},
};
static const uint8_t CHARS_N = sizeof(CHARS) / sizeof(CHARS[0]);

// Multi-character escapes for keys with no ASCII form.  These are the ONLY
// three special characters the PC-1211 has, which is itself a useful check:
// Robert van Engelen's TRS-80 PC-1 collection documents exactly [E], [PI] and
// [SQR], and PocketTools encodes exactly those.
struct EscMap { uint8_t code; const char *text; };
static const char e_pi[]  PROGMEM = "[PI]";
static const char e_sqr[] PROGMEM = "[SQR]";
static const char e_e[]   PROGMEM = "[E]";
static const EscMap ESCAPES[] PROGMEM = {
  {0x19, e_pi}, {0x1A, e_sqr}, {0x4B, e_e},
};
static const uint8_t ESCAPES_N = sizeof(ESCAPES) / sizeof(ESCAPES[0]);

// ===========================================================================
// Keyword tokens -- IDENT_OLD_BAS, PC-1211 subset.
// Longest names FIRST: the scanner takes the first match, so "PRINT" must be
// tried before "P"-anything and ">=" before ">".
// ===========================================================================
struct TokMap { const char *name; uint8_t code; };
static const char t_radian[] PROGMEM="RADIAN"; static const char t_return[] PROGMEM="RETURN";
static const char t_degree[] PROGMEM="DEGREE"; static const char t_setcom[] PROGMEM="SETCOM";
static const char t_aread[]  PROGMEM="AREAD";  static const char t_chain[]  PROGMEM="CHAIN";
static const char t_clear[]  PROGMEM="CLEAR";  static const char t_cload[]  PROGMEM="CLOAD";
static const char t_close[]  PROGMEM="CLOSE";  static const char t_csave[]  PROGMEM="CSAVE";
static const char t_debug[]  PROGMEM="DEBUG";  static const char t_gosub[]  PROGMEM="GOSUB";
static const char t_input[]  PROGMEM="INPUT";  static const char t_pause[]  PROGMEM="PAUSE";
static const char t_print[]  PROGMEM="PRINT";  static const char t_using[]  PROGMEM="USING";
static const char t_beep[]   PROGMEM="BEEP";   static const char t_cont[]   PROGMEM="CONT";
static const char t_goto[]   PROGMEM="GOTO";   static const char t_grad[]   PROGMEM="GRAD";
static const char t_list[]   PROGMEM="LIST";   static const char t_next[]   PROGMEM="NEXT";
static const char t_open[]   PROGMEM="OPEN";   static const char t_step[]   PROGMEM="STEP";
static const char t_stop[]   PROGMEM="STOP";   static const char t_then[]   PROGMEM="THEN";
static const char t_abs[]    PROGMEM="ABS";    static const char t_acs[]    PROGMEM="ACS";
static const char t_asn[]    PROGMEM="ASN";    static const char t_atn[]    PROGMEM="ATN";
static const char t_cos[]    PROGMEM="COS";    static const char t_deg[]    PROGMEM="DEG";
static const char t_dms[]    PROGMEM="DMS";    static const char t_end[]    PROGMEM="END";
static const char t_exp[]    PROGMEM="EXP";    static const char t_for[]    PROGMEM="FOR";
static const char t_int[]    PROGMEM="INT";    static const char t_let[]    PROGMEM="LET";
static const char t_log[]    PROGMEM="LOG";    static const char t_mem[]    PROGMEM="MEM";
static const char t_new[]    PROGMEM="NEW";    static const char t_rem[]    PROGMEM="REM";
static const char t_run[]    PROGMEM="RUN";    static const char t_sgn[]    PROGMEM="SGN";
static const char t_sin[]    PROGMEM="SIN";    static const char t_tan[]    PROGMEM="TAN";
static const char t_ge[]     PROGMEM=">=";     static const char t_le[]     PROGMEM="<=";
static const char t_ne[]     PROGMEM="<>";     static const char t_if[]     PROGMEM="IF";
static const char t_ln[]     PROGMEM="LN";     static const char t_to[]     PROGMEM="TO";

static const TokMap TOKENS[] PROGMEM = {
  {t_radian,0xC3},{t_return,0xDE},{t_degree,0xC4},{t_setcom,0x9B},
  {t_aread,0xDC},{t_chain,0xD9},{t_clear,0xC5},{t_cload,0xB7},{t_close,0x9D},
  {t_csave,0xB6},{t_debug,0xB5},{t_gosub,0xD8},{t_input,0xC2},{t_pause,0xDA},
  {t_print,0xC1},{t_using,0xDD},
  {t_beep,0xDB},{t_cont,0xB4},{t_goto,0xD7},{t_grad,0xC0},{t_list,0xB3},
  {t_next,0xD5},{t_open,0x9C},{t_step,0x91},{t_stop,0xD6},{t_then,0x92},
  {t_abs,0xAA},{t_acs,0xA4},{t_asn,0xA3},{t_atn,0xA5},{t_cos,0xA1},
  {t_deg,0xAC},{t_dms,0xAD},{t_end,0xD4},{t_exp,0xA6},{t_for,0xD1},
  {t_int,0xA9},{t_let,0xD2},{t_log,0xA8},{t_mem,0xB2},{t_new,0xB1},
  {t_rem,0xD3},{t_run,0xB0},{t_sgn,0xAB},{t_sin,0xA0},{t_tan,0xA2},
  {t_ge,0x82},{t_le,0x83},{t_ne,0x84},{t_if,0xD0},{t_ln,0xA7},{t_to,0x90},
};
static const uint8_t TOKENS_N = sizeof(TOKENS) / sizeof(TOKENS[0]);

static const uint8_t EOL_B = 0x00, EOF_B = 0xF0, HDR_END = 0x5F;
static const uint16_t BLK_DATA = 80;   // BLK_OLD:      sum resets every 80 data bytes
static const uint8_t  SUM_EVERY = 8;   // BLK_OLD_SUM:  checksum after every 8

// PocketTools CheckSumB1: end-around carry after the HIGH nibble ONLY.
static uint8_t cksumB1(uint8_t s, uint8_t b) {
  uint16_t t = (uint16_t)s + (uint16_t)((b & 0xF0) >> 4);
  if (t > 0xFF) t = (t + 1) & 0xFF;
  return (uint8_t)((t + (b & 0x0F)) & 0xFF);
}

static uint8_t nibSum(const uint8_t *p, uint8_t n) {
  uint16_t s = 0;
  for (uint8_t i = 0; i < n; i++) s += (p[i] >> 4) + (p[i] & 0x0F);
  return (uint8_t)(s & 0xFF);
}

static uint8_t ascToCode(char c) {
  if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z')) return (uint8_t)c + 16;
  if (c >= 'a' && c <= 'z') return (uint8_t)(c - 32) + 16;   // fold to upper
  for (uint8_t i = 0; i < CHARS_N; i++) {
    AscMap m; memcpy_P(&m, &CHARS[i], sizeof(m));
    if (m.asc == c) return m.code;
  }
  return 0;                                                  // 0 = no encoding
}

void Pc1Basic::appendChar(uint8_t code, String &out) {
  for (uint8_t i = 0; i < ESCAPES_N; i++) {
    EscMap e; memcpy_P(&e, &ESCAPES[i], sizeof(e));
    if (e.code == code) { char b[8]; strncpy_P(b, e.text, 7); b[7] = 0; out += b; return; }
  }
  for (uint8_t i = 0; i < CHARS_N; i++) {
    AscMap m; memcpy_P(&m, &CHARS[i], sizeof(m));
    if (m.code == code) { out += m.asc; return; }
  }
  if (code >= 0x40 && code <= 0x6A) { out += (char)(code - 0x10); return; }
  out += '{';
  const char hex[] = "0123456789ABCDEF";
  out += hex[code >> 4]; out += hex[code & 0x0F];
  out += '}';
  _unknown++;
}

// ---------------------------------------------------------------- header name
String Pc1Basic::headerName() {
  uint8_t nb[14]; uint8_t n = 0;
  for (uint8_t i = 1; i <= 7; i++) {
    uint8_t b = _ram.readByte(i);
    nb[n++] = (uint8_t)(b >> 4); nb[n++] = (uint8_t)(b & 0x0F);
  }
  uint8_t s = 0;
  while (s < n && nb[s] == 0) s++;
  String out;
  for (uint8_t i = n; i > s + 1; i -= 2) {
    uint8_t c = (uint8_t)((nb[i - 1] << 4) | nb[i - 2]);
    if (c >= 0x30 && c <= 0x7F) out += (char)(c - 0x10);
  }
  return out;
}

// ------------------------------------------------------------- emit one byte
void Pc1Basic::emitData(uint8_t b) {
  _ram.writeByte((uint16_t)(_dst + _outLen), b);
  _outLen++;
  _sum = cksumB1(_sum, b);
  _cnt++;
  if ((_cnt % SUM_EVERY) == 0) {
    _ram.writeByte((uint16_t)(_dst + _outLen), _sum);
    _outLen++;
    if (_cnt >= BLK_DATA) { _sum = 0; _cnt = 0; }
  }
  // NOTE: a final incomplete group gets NO checksum -- bin2wav only writes one
  // where (count % BLK_OLD_SUM) == 0.  BLAKJAK proves it: 1390 program bytes =
  // 173 full groups + 6 over, and the file is 1573 bytes, not 1574.
}

// ------------------------------------------------------------------ tokenise
uint32_t Pc1Basic::tokeniseInRam(uint16_t srcStart, uint16_t srcEnd,
                                 uint16_t dstBase, const char *name) {
  _err = ""; _dst = dstBase; _outLen = 0; _sum = 0; _cnt = 0;

  // ---- header record -----------------------------------------------------
  uint8_t nb[14]; uint8_t nn = 0;
  for (uint8_t i = 0; i < 7 && name[i]; i++) {
    uint8_t c = ascToCode(name[i]);
    if (!c) c = 17;
    nb[nn++] = (uint8_t)(c >> 4); nb[nn++] = (uint8_t)(c & 0x0F);
  }
  // reverse the nibble stream, then left-pad with zeros to 14 nibbles
  uint8_t rev[14];
  for (uint8_t i = 0; i < nn; i++) rev[i] = nb[nn - 1 - i];
  uint8_t pad = 14 - nn;
  uint8_t full[14];
  for (uint8_t i = 0; i < pad; i++) full[i] = 0;
  for (uint8_t i = 0; i < nn; i++) full[pad + i] = rev[i];
  uint8_t hdr[9];
  for (uint8_t i = 0; i < 7; i++) hdr[i] = (uint8_t)((full[i * 2] << 4) | full[i * 2 + 1]);
  hdr[7] = HDR_END;
  _ram.writeByte((uint16_t)(_dst + _outLen++), 0x80);
  for (uint8_t i = 0; i < 8; i++) _ram.writeByte((uint16_t)(_dst + _outLen++), hdr[i]);
  _ram.writeByte((uint16_t)(_dst + _outLen++), nibSum(hdr, 8));

  // ---- program lines -----------------------------------------------------
  char line[132];
  uint16_t a = srcStart;
  uint16_t lastLine = 0;
  bool any = false;
  while (a <= srcEnd) {
    uint8_t len = 0;
    while (a <= srcEnd) {
      uint8_t c = _ram.readByte(a++);
      if (c == '\r') continue;
      if (c == '\n') break;
      if (len < sizeof(line) - 1) line[len++] = (char)c;
    }
    line[len] = '\0';
    // trim
    char *t = line;
    while (*t == ' ' || *t == '\t') t++;
    uint8_t tl = strlen(t);
    while (tl && (t[tl - 1] == ' ' || t[tl - 1] == '\t')) t[--tl] = '\0';
    if (!tl) continue;

    // line number
    uint16_t num = 0; uint8_t nd = 0;
    while (t[nd] >= '0' && t[nd] <= '9' && nd < 4) { num = num * 10 + (t[nd] - '0'); nd++; }
    if (!nd) {
      // An un-numbered leading "REM name" is the listing's own title line, not
      // program text -- skip it so a listing feeds straight back in.
      if (!strncasecmp(t, "REM", 3)) continue;
      _err = "line has no number"; return 0;
    }
    if (num < 1 || num > 999) { _err = "line number not 1-999"; return 0; }
    if (any && num <= lastLine) { _err = "line numbers out of order"; return 0; }
    lastLine = num; any = true;
    t += nd;
    while (*t == ' ') t++;                 // the space after the number is not data

    emitData((uint8_t)(0xE0 | (num / 100)));
    emitData((uint8_t)((((num / 10) % 10) << 4) | (num % 10)));

    bool inStr = false;
    while (*t) {
      // escapes work inside and outside strings
      bool done = false;
      if (*t == '[') {
        for (uint8_t i = 0; i < ESCAPES_N; i++) {
          EscMap e; memcpy_P(&e, &ESCAPES[i], sizeof(e));
          char b[8]; strncpy_P(b, e.text, 7); b[7] = 0;
          uint8_t bl = strlen(b);
          if (!strncmp(t, b, bl)) { emitData(e.code); t += bl; done = true; break; }
        }
        if (done) continue;
        _err = "unknown [..] escape"; return 0;
      }
      if (*t == '"') { inStr = !inStr; emitData(18); t++; continue; }
      if (!inStr) {
        // ---- SPACES OUTSIDE A STRING ARE DROPPED --------------------------
        // The old series does not allow spaces between commands.  PocketTools
        // says so ("The older series do not allow spaces between commands, but
        // they are allowed in the PC-E/G series") and all nine reference tapes
        // agree: 495 spaces inside string literals, ZERO outside.
        //
        // Keeping them is not harmless.  A stored space LISTs back normally --
        // the machine shows `PAUSE "TEXT"` either way -- so the program looks
        // perfectly correct and then fails at RUN with a syntax error on that
        // line.  Dropping them here also means `PRINT "A"` and `PRINT"A"` are
        // the same program, so hand-written source can be spaced for
        // readability and indented freely.
        if (*t == ' ' || *t == '\t') { t++; continue; }
        for (uint8_t i = 0; i < TOKENS_N; i++) {
          TokMap m; memcpy_P(&m, &TOKENS[i], sizeof(m));
          char nmb[8]; strncpy_P(nmb, m.name, 7); nmb[7] = 0;
          uint8_t nl = strlen(nmb);
          if (!strncasecmp(t, nmb, nl)) {
            emitData(m.code);
            t += nl;
            // ---- REM swallows the rest of the line ------------------------
            // Everything after REM is COMMENT, and PocketTools copies it out
            // verbatim -- no keyword matching inside it.  Without this,
            // `REM PRINT TOTALS` would emit a real PRINT token in the middle
            // of a comment: it would still LIST as PRINT, so the corruption
            // looks like valid source right up until the machine executes it.
            // delREMspc: the spaces immediately after REM are dropped.
            if (m.code == 0xD3) {
              while (*t == ' ') t++;
              while (*t) {
                uint8_t rc = ascToCode(*t);
                if (!rc) { _err = "bad char in REM"; return 0; }
                emitData(rc); t++;
              }
            }
            done = true; break;
          }
        }
        if (done) continue;
      }
      uint8_t c = ascToCode(*t);
      if (!c) { _err = "character has no PC-1211 code"; return 0; }
      emitData(c); t++;
    }
    emitData(EOL_B);
  }
  if (!any) { _err = "no BASIC lines found"; return 0; }
  emitData(EOF_B);
  return _outLen;
}

// ---------------------------------------------------------------- detokenise
uint16_t Pc1Basic::writeListing(uint32_t tapLen, const String &basFilename) {
  _unknown = 0;
  if (tapLen < 12 || _ram.readByte(0) != 0x80) return 0;
  if (SD.exists(basFilename.c_str())) SD.remove(basFilename.c_str());
  File f = SD.open(basFilename, FILE_WRITE);
  if (!f) return 0;

  String hdr = F("REM ");
  hdr += headerName();
  f.println(hdr);

  uint16_t lines = 0;
  String out; out.reserve(110);
  bool inLine = false;
  uint8_t pend = 0, marker = 0;
  uint16_t bi = 0;
  for (uint32_t i = 10; i < tapLen; i++) {
    if ((bi++ % 9) == 8) continue;                  // checksum byte
    uint8_t b = _ram.readByte((uint16_t)i);
    if (pend) {
      out = String((uint16_t)((marker & 0x0F) * 100 + (b >> 4) * 10 + (b & 0x0F)));
      out += ' '; pend = 0; inLine = true; continue;
    }
    if (b >= 0xE0 && b <= 0xEF) {
      if (inLine) { f.println(out); lines++; }
      marker = b; pend = 1; inLine = false; continue;
    }
    if (b == EOF_B) break;
    if (!inLine) continue;
    if (b == EOL_B) { f.println(out); lines++; out = ""; inLine = false; continue; }
    appendChar(b, out);
  }
  if (inLine) { f.println(out); lines++; }
  f.close();
  return lines;
}
