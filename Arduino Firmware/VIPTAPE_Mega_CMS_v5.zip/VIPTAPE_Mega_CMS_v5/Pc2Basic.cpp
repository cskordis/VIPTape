#include "Pc2Basic.h"
#include <SD.h>
#include <avr/pgmspace.h>

// ===========================================================================
// Keyword tokens -- the base PC-1500 set, 115 entries, two bytes each.
// SORTED LONGEST NAME FIRST.  The scanner takes the first match, so this order
// is what makes PEEK#/PEEK, POKE#/POKE, GCURSOR/LCURSOR/CURSOR and INKEY$/IN
// resolve the way the machine does.  Generated from PocketTools bas2img and
// checked against wav2bin's five detokenise tables; see Pc2Basic.h.
// ===========================================================================
// Anonymous namespace, and a name of its own: Pc1Basic.cpp also has a file-
// scope `TokMap`, with a uint8_t code because the PC-1's tokens are one byte.
// Two different structs sharing a name across translation units is an ODR
// violation, and the Arduino build reports it as a wall of
//     note: type 'uint8_t' should match type 'uint16_t'
// out of stdint.h, which points nowhere near the actual cause.
namespace {
struct Pc2Tok { const char *name; uint16_t code; };
}
static const char k_endselect[] PROGMEM = "ENDSELECT"; static const char k_glcursor[]  PROGMEM = "GLCURSOR";
static const char k_hpcursor[]  PROGMEM = "HPCURSOR"; static const char k_integral[]  PROGMEM = "INTEGRAL";
static const char k_postload[]  PROGMEM = "POSTLOAD"; static const char k_renumber[]  PROGMEM = "RENUMBER";
static const char k_terminal[]  PROGMEM = "TERMINAL"; static const char k_transmit[]  PROGMEM = "TRANSMIT";
static const char k_vpcursor[]  PROGMEM = "VPCURSOR"; static const char k_catalog[]   PROGMEM = "CATALOG";
static const char k_console[]   PROGMEM = "CONSOLE"; static const char k_gcursor[]   PROGMEM = "GCURSOR";
static const char k_hcursor[]   PROGMEM = "HCURSOR"; static const char k_lcursor[]   PROGMEM = "LCURSOR";
static const char k_outstat[]   PROGMEM = "OUTSTAT"; static const char k_program[]   PROGMEM = "PROGRAM";
static const char k_qverify[]   PROGMEM = "QVERIFY"; static const char k_restore[]   PROGMEM = "RESTORE";
static const char k_rinkeys[]   PROGMEM = "RINKEY$"; static const char k_rvsload[]   PROGMEM = "RVSLOAD";
static const char k_vcursor[]   PROGMEM = "VCURSOR"; static const char k_append[]    PROGMEM = "APPEND";
static const char k_change[]    PROGMEM = "CHANGE"; static const char k_cursor[]    PROGMEM = "CURSOR";
static const char k_degree[]    PROGMEM = "DEGREE"; static const char k_gprint[]    PROGMEM = "GPRINT";
static const char k_inkeys[]    PROGMEM = "INKEY$"; static const char k_instat[]    PROGMEM = "INSTAT";
static const char k_lprint[]    PROGMEM = "LPRINT"; static const char k_radian[]    PROGMEM = "RADIAN";
static const char k_random[]    PROGMEM = "RANDOM"; static const char k_return[]    PROGMEM = "RETURN";
static const char k_rights[]    PROGMEM = "RIGHT$"; static const char k_rotate[]    PROGMEM = "ROTATE";
static const char k_search[]    PROGMEM = "SEARCH"; static const char k_select[]    PROGMEM = "SELECT";
static const char k_setcom[]    PROGMEM = "SETCOM"; static const char k_setdev[]    PROGMEM = "SETDEV";
static const char k_spaces[]    PROGMEM = "SPACE$"; static const char k_status[]    PROGMEM = "STATUS";
static const char k_subclr[]    PROGMEM = "SUBCLR"; static const char k_subend[]    PROGMEM = "SUBEND";
static const char k_ttimes[]    PROGMEM = "TTIME$"; static const char k_unlock[]    PROGMEM = "UNLOCK";
static const char k_aread[]     PROGMEM = "AREAD"; static const char k_break[]     PROGMEM = "BREAK";
static const char k_chain[]     PROGMEM = "CHAIN"; static const char k_check[]     PROGMEM = "CHECK";
static const char k_clear[]     PROGMEM = "CLEAR"; static const char k_cload[]     PROGMEM = "CLOAD";
static const char k_color[]     PROGMEM = "COLOR"; static const char k_csave[]     PROGMEM = "CSAVE";
static const char k_csize[]     PROGMEM = "CSIZE"; static const char k_deffn[]     PROGMEM = "DEFFN";
static const char k_endif[]     PROGMEM = "ENDIF"; static const char k_erase[]     PROGMEM = "ERASE";
static const char k_error[]     PROGMEM = "ERROR"; static const char k_gosub[]     PROGMEM = "GOSUB";
static const char k_graph[]     PROGMEM = "GRAPH"; static const char k_input[]     PROGMEM = "INPUT";
static const char k_lefts[]     PROGMEM = "LEFT$"; static const char k_llist[]     PROGMEM = "LLIST";
static const char k_merge[]     PROGMEM = "MERGE"; static const char k_names[]     PROGMEM = "NAME$";
static const char k_pause[]     PROGMEM = "PAUSE"; static const char k_peekh[]     PROGMEM = "PEEK#";
static const char k_plast[]     PROGMEM = "PLAST"; static const char k_plist[]     PROGMEM = "PLIST";
static const char k_point[]     PROGMEM = "POINT"; static const char k_pokeh[]     PROGMEM = "POKE#";
static const char k_print[]     PROGMEM = "PRINT"; static const char k_purge[]     PROGMEM = "PURGE";
static const char k_qload[]     PROGMEM = "QLOAD"; static const char k_qsave[]     PROGMEM = "QSAVE";
static const char k_rline[]     PROGMEM = "RLINE"; static const char k_round[]     PROGMEM = "ROUND";
static const char k_sleep[]     PROGMEM = "SLEEP"; static const char k_sorgn[]     PROGMEM = "SORGN";
static const char k_split[]     PROGMEM = "SPLIT"; static const char k_troff[]     PROGMEM = "TROFF";
static const char k_using[]     PROGMEM = "USING"; static const char k_while[]     PROGMEM = "WHILE";
static const char k_arun[]      PROGMEM = "ARUN"; static const char k_beep[]      PROGMEM = "BEEP";
static const char k_call[]      PROGMEM = "CALL"; static const char k_case[]      PROGMEM = "CASE";
static const char k_chrs[]      PROGMEM = "CHR$"; static const char k_coms[]      PROGMEM = "COM$";
static const char k_cont[]      PROGMEM = "CONT"; static const char k_copy[]      PROGMEM = "COPY";
static const char k_data[]      PROGMEM = "DATA"; static const char k_deek[]      PROGMEM = "DEEK";
static const char k_devs[]      PROGMEM = "DEV$"; static const char k_doke[]      PROGMEM = "DOKE";
static const char k_edit[]      PROGMEM = "EDIT"; static const char k_else[]      PROGMEM = "ELSE";
static const char k_exit[]      PROGMEM = "EXIT"; static const char k_feed[]      PROGMEM = "FEED";
static const char k_find[]      PROGMEM = "FIND"; static const char k_frac[]      PROGMEM = "FRAC";
static const char k_gcls[]      PROGMEM = "GCLS"; static const char k_goto[]      PROGMEM = "GOTO";
static const char k_grad[]      PROGMEM = "GRAD"; static const char k_hexs[]      PROGMEM = "HEX$";
static const char k_inpt[]      PROGMEM = "INPT"; static const char k_keep[]      PROGMEM = "KEEP";
static const char k_line[]      PROGMEM = "LINE"; static const char k_link[]      PROGMEM = "LINK";
static const char k_list[]      PROGMEM = "LIST"; static const char k_lock[]      PROGMEM = "LOCK";
static const char k_loop[]      PROGMEM = "LOOP"; static const char k_mids[]      PROGMEM = "MID$";
static const char k_move[]      PROGMEM = "MOVE"; static const char k_next[]      PROGMEM = "NEXT";
static const char k_peek[]      PROGMEM = "PEEK"; static const char k_poke[]      PROGMEM = "POKE";
static const char k_read[]      PROGMEM = "READ"; static const char k_sort[]      PROGMEM = "SORT";
static const char k_step[]      PROGMEM = "STEP"; static const char k_stop[]      PROGMEM = "STOP";
static const char k_strs[]      PROGMEM = "STR$"; static const char k_test[]      PROGMEM = "TEST";
static const char k_text[]      PROGMEM = "TEXT"; static const char k_then[]      PROGMEM = "THEN";
static const char k_time[]      PROGMEM = "TIME"; static const char k_tron[]      PROGMEM = "TRON";
static const char k_wait[]      PROGMEM = "WAIT"; static const char k_zone[]      PROGMEM = "ZONE";
static const char k_abs[]       PROGMEM = "ABS"; static const char k_acs[]       PROGMEM = "ACS";
static const char k_and[]       PROGMEM = "AND"; static const char k_asc[]       PROGMEM = "ASC";
static const char k_asn[]       PROGMEM = "ASN"; static const char k_atn[]       PROGMEM = "ATN";
static const char k_bye[]       PROGMEM = "BYE"; static const char k_cls[]       PROGMEM = "CLS";
static const char k_cos[]       PROGMEM = "COS"; static const char k_dec[]       PROGMEM = "DEC";
static const char k_deg[]       PROGMEM = "DEG"; static const char k_dim[]       PROGMEM = "DIM";
static const char k_dir[]       PROGMEM = "DIR"; static const char k_dms[]       PROGMEM = "DMS";
static const char k_dte[]       PROGMEM = "DTE"; static const char k_end[]       PROGMEM = "END";
static const char k_erl[]       PROGMEM = "ERL"; static const char k_ern[]       PROGMEM = "ERN";
static const char k_exp[]       PROGMEM = "EXP"; static const char k_fac[]       PROGMEM = "FAC";
static const char k_for[]       PROGMEM = "FOR"; static const char k_gsb[]       PROGMEM = "GSB";
static const char k_ifh[]       PROGMEM = "IF#"; static const char k_int[]       PROGMEM = "INT";
static const char k_key[]       PROGMEM = "KEY"; static const char k_len[]       PROGMEM = "LEN";
static const char k_let[]       PROGMEM = "LET"; static const char k_log[]       PROGMEM = "LOG";
static const char k_mem[]       PROGMEM = "MEM"; static const char k_new[]       PROGMEM = "NEW";
static const char k_not[]       PROGMEM = "NOT"; static const char k_off[]       PROGMEM = "OFF";
static const char k_opn[]       PROGMEM = "OPN"; static const char k_rem[]       PROGMEM = "REM";
static const char k_rmt[]       PROGMEM = "RMT"; static const char k_rnd[]       PROGMEM = "RND";
static const char k_rpu[]       PROGMEM = "RPU"; static const char k_run[]       PROGMEM = "RUN";
static const char k_sgn[]       PROGMEM = "SGN"; static const char k_sin[]       PROGMEM = "SIN";
static const char k_spu[]       PROGMEM = "SPU"; static const char k_sqr[]       PROGMEM = "SQR";
static const char k_sub[]       PROGMEM = "SUB"; static const char k_tab[]       PROGMEM = "TAB";
static const char k_tan[]       PROGMEM = "TAN"; static const char k_val[]       PROGMEM = "VAL";
static const char k_do[]        PROGMEM = "DO"; static const char k_fn[]        PROGMEM = "FN";
static const char k_if[]        PROGMEM = "IF"; static const char k_lf[]        PROGMEM = "LF";
static const char k_ln[]        PROGMEM = "LN"; static const char k_on[]        PROGMEM = "ON";
static const char k_or[]        PROGMEM = "OR"; static const char k_pi[]        PROGMEM = "PI";
static const char k_to[]        PROGMEM = "TO";

static const Pc2Tok TOKENS[] PROGMEM = {
  {k_endselect,0xF0D1}, {k_glcursor,0xE682}, {k_hpcursor,0xF055}, {k_integral,0xF07D},
  {k_postload,0xF0FC}, {k_renumber,0xF0C8}, {k_terminal,0xE883}, {k_transmit,0xE885},
  {k_vpcursor,0xF050}, {k_catalog,0xF0A1}, {k_console,0xF0B1}, {k_gcursor,0xF093},
  {k_hcursor,0xF054}, {k_lcursor,0xE683}, {k_outstat,0xE880}, {k_program,0xF0C7},
  {k_qverify,0xF083}, {k_restore,0xF1A7}, {k_rinkeys,0xE85A}, {k_rvsload,0xF0FB},
  {k_vcursor,0xF056}, {k_append,0xF0C0}, {k_change,0xF0C1}, {k_cursor,0xF084},
  {k_degree,0xF18C}, {k_gprint,0xF09F}, {k_inkeys,0xF15C}, {k_instat,0xE859},
  {k_lprint,0xF0B9}, {k_radian,0xF1AA}, {k_random,0xF1A8}, {k_return,0xF199},
  {k_rights,0xF172}, {k_rotate,0xE685}, {k_search,0xF0A8}, {k_select,0xF0D0},
  {k_setcom,0xE882}, {k_setdev,0xE886}, {k_spaces,0xF061}, {k_status,0xF167},
  {k_subclr,0xF0DA}, {k_subend,0xF0D9}, {k_ttimes,0xF05E}, {k_unlock,0xF1B6},
  {k_aread,0xF180}, {k_break,0xF0B3}, {k_chain,0xF0B2}, {k_check,0xF0A2},
  {k_clear,0xF187}, {k_cload,0xF089}, {k_color,0xF0B5}, {k_csave,0xF095},
  {k_csize,0xE680}, {k_deffn,0xF0D2}, {k_endif,0xF0CD}, {k_erase,0xF0C3},
  {k_error,0xF1B4}, {k_gosub,0xF194}, {k_graph,0xE681}, {k_input,0xF091},
  {k_lefts,0xF17A}, {k_llist,0xF0B8}, {k_merge,0xF08F}, {k_names,0xF07A},
  {k_pause,0xF1A2}, {k_peekh,0xF16E}, {k_plast,0xF0C9}, {k_plist,0xF0C6},
  {k_point,0xF168}, {k_pokeh,0xF1A0}, {k_print,0xF097}, {k_purge,0xE2C1},
  {k_qload,0xF080}, {k_qsave,0xF081}, {k_rline,0xF0BA}, {k_round,0xF07C},
  {k_sleep,0xF0E7}, {k_sorgn,0xE684}, {k_split,0xF0CB}, {k_troff,0xF1B0},
  {k_using,0xF085}, {k_while,0xF0D6}, {k_arun,0xF181}, {k_beep,0xF182},
  {k_call,0xF18A}, {k_case,0xF0D3}, {k_chrs,0xF163}, {k_coms,0xE858},
  {k_cont,0xF183}, {k_copy,0xF0A3}, {k_data,0xF18D}, {k_deek,0xF07B},
  {k_devs,0xE857}, {k_doke,0xF0AB}, {k_edit,0xF0DE}, {k_else,0xF0CF},
  {k_exit,0xF0CE}, {k_feed,0xF0B0}, {k_find,0xF0C4}, {k_frac,0xE360},
  {k_gcls,0xF0E1}, {k_goto,0xF192}, {k_grad,0xF186}, {k_hexs,0xF071},
  {k_inpt,0xF0A6}, {k_keep,0xF0C5}, {k_line,0xF0B7}, {k_link,0xF0CA},
  {k_list,0xF090}, {k_lock,0xF1B5}, {k_loop,0xF0D5}, {k_mids,0xF17B},
  {k_move,0xF0A7}, {k_next,0xF19A}, {k_peek,0xF16F}, {k_poke,0xF1A1},
  {k_read,0xF1A6}, {k_sort,0xF0AA}, {k_step,0xF1AD}, {k_stop,0xF1AC},
  {k_strs,0xF161}, {k_test,0xF0BC}, {k_text,0xE686}, {k_then,0xF1AE},
  {k_time,0xF15B}, {k_tron,0xF1AF}, {k_wait,0xF1B3}, {k_zone,0xF0B4},
  {k_abs,0xF170}, {k_acs,0xF174}, {k_and,0xF150}, {k_asc,0xF160},
  {k_asn,0xF173}, {k_atn,0xF175}, {k_bye,0xF0A0}, {k_cls,0xF088},
  {k_cos,0xF17E}, {k_dec,0xF070}, {k_deg,0xF165}, {k_dim,0xF18B},
  {k_dir,0xF0E0}, {k_dms,0xF166}, {k_dte,0xE884}, {k_end,0xF18E},
  {k_erl,0xF053}, {k_ern,0xF052}, {k_exp,0xF178}, {k_fac,0xF075},
  {k_for,0xF1A5}, {k_gsb,0xF0AF}, {k_ifh,0xF0CC}, {k_int,0xF171},
  {k_key,0xF0E2}, {k_len,0xF164}, {k_let,0xF198}, {k_log,0xF177},
  {k_mem,0xF158}, {k_new,0xF19B}, {k_not,0xF16D}, {k_off,0xF19E},
  {k_opn,0xF19D}, {k_rem,0xF1AB}, {k_rmt,0xE7A9}, {k_rnd,0xF17C},
  {k_rpu,0xF0AC}, {k_run,0xF1A4}, {k_sgn,0xF179}, {k_sin,0xF17D},
  {k_spu,0xF0AD}, {k_sqr,0xF16B}, {k_sub,0xF0D8}, {k_tab,0xF0BB},
  {k_tan,0xF17F}, {k_val,0xF162}, {k_do,0xF0D4}, {k_fn,0xF06F},
  {k_if,0xF196}, {k_lf,0xF0B6}, {k_ln,0xF176}, {k_on,0xF19C},
  {k_or,0xF151}, {k_pi,0xF15D}, {k_to,0xF1B1},
};

static const uint8_t TOKENS_N = sizeof(TOKENS) / sizeof(TOKENS[0]);

static const uint8_t  EOL_B     = 0x0D;   // end of a line record
static const uint8_t  IMG_EOF   = 0xFF;   // BAS_1500_EOF, end of the image
static const uint8_t  TAPE_EOF  = 0x55;   // EOF_15, end of the tape
static const uint16_t REM_TOK   = 0xF1AB;
static const uint16_t BLOCK     = 80;     // BLK_OLD: checksum every 80 bytes
static const uint16_t LOAD_ADDR = 0x00C5; // what the machine itself stores

// Longest source line accepted, characters.  Kept in step with the reference
// tool tools/pc2_basic.py so the two accept exactly the same files.
#define PC2_SRC_LINE_MAX 198

static uint8_t hexVal(char c) {
  if (c >= '0' && c <= '9') return (uint8_t)(c - '0');
  if (c >= 'A' && c <= 'F') return (uint8_t)(c - 'A' + 10);
  if (c >= 'a' && c <= 'f') return (uint8_t)(c - 'a' + 10);
  return 0xFF;
}

// ---------------------------------------------------------------- emitters
void Pc2Basic::emitRaw(uint8_t b) {
  if (_dry) return;
  _ram.writeByte((uint16_t)(_dst + _outLen), b);
  _outLen++;
}

void Pc2Basic::emitData(uint8_t b) {
  emitRaw(b);
  _sum = (uint16_t)(_sum + b);
  _cnt++;
  if (_cnt == BLOCK) {
    emitRaw((uint8_t)(_sum >> 8));
    emitRaw((uint8_t)(_sum & 0xFF));
    _cnt = 0; _sum = 0;
  }
}

void Pc2Basic::emitImage(uint8_t b) {
  if (_dry) { _imgLen++; return; }
  emitData(b);
}

void Pc2Basic::bodyPut(uint8_t b) {
  _bodyLen++;
  if (_bodyEmit) emitImage(b);
}

// --------------------------------------------------------------- tokenise
//
// One source line's body -> _bodyLen (and the tape, when `emit`), 0D included.
bool Pc2Basic::tokeniseBody(const char *t, bool emit) {
  _bodyLen = 0;
  _bodyEmit = emit;
  bool inStr = false;

  while (*t) {
    // The record's length is ONE byte, so 255 is a hard ceiling, not a buffer
    // size.  Stop two short: a token or the closing 0D may still be coming.
    if (_bodyLen > 253) { _err = "line body over 255 bytes"; return false; }

    // ---- {F0C0} and {1A} escapes work everywhere, strings included -------
    if (*t == '{') {
      uint8_t n = 0;
      while (n < 5 && t[1 + n] && t[1 + n] != '}') n++;
      if (t[1 + n] == '}' && (n == 2 || n == 4)) {
        uint32_t v = 0; bool ok = true;
        for (uint8_t i = 0; i < n; i++) {
          uint8_t h = hexVal(t[1 + i]);
          if (h == 0xFF) { ok = false; break; }
          v = (v << 4) | h;
        }
        if (ok) {
          if (n == 4) bodyPut((uint8_t)(v >> 8));
          bodyPut((uint8_t)(v & 0xFF));
          t += n + 2;
          continue;
        }
      }
      _err = "bad {..} escape"; return false;
    }

    if (inStr) {
      if (*t == '"') inStr = false;
      bodyPut((uint8_t)*t);
      t++;
      continue;
    }

    if (*t == '"') { inStr = true; bodyPut(0x22); t++; continue; }

    // ---- SPACES OUTSIDE A STRING ARE NOT STORED --------------------------
    // PocketTools deletes up to del_spc_cnt = 80 consecutive spaces for this
    // series, i.e. every space in any real line, and the machine agrees: the
    // HI capture reads F0 97 22 ... with no space between PRINT and the quote
    // even though LIST prints one.  Dropping them here also means hand-written
    // source can be spaced and indented freely.
    if (*t == ' ' || *t == '\t') { t++; continue; }

    // ---- keyword, greedy, longest first ----------------------------------
    bool hit = false;
    for (uint8_t i = 0; i < TOKENS_N; i++) {
      Pc2Tok m; memcpy_P(&m, &TOKENS[i], sizeof(m));
      char nm[10]; strncpy_P(nm, m.name, 9); nm[9] = 0;
      uint8_t nl = (uint8_t)strlen(nm);
      if (strncasecmp(t, nm, nl) != 0) continue;

      bodyPut((uint8_t)(m.code >> 8));
      bodyPut((uint8_t)(m.code & 0xFF));
      t += nl;

      if (m.code == REM_TOK) {
        // ---- REM swallows the rest of the line ---------------------------
        // Everything after REM is comment and is stored verbatim -- no keyword
        // matching inside it.  Without this, `REM PRINT TOTALS` would put a
        // real PRINT token in the middle of a comment; it would still LIST as
        // PRINT, so the corruption reads as valid source right up until the
        // machine runs it.  delREMspc: the spaces straight after REM go.
        while (*t == ' ' || *t == '\t') t++;
        while (*t) {
          if (_bodyLen > 253) { _err = "line body over 255 bytes"; return false; }
          bodyPut((uint8_t)*t);
          t++;
        }
        bodyPut(EOL_B);
        return true;
      }
      hit = true;
      break;
    }
    if (hit) continue;

    // ---- literal character -----------------------------------------------
    uint8_t c = (uint8_t)*t;
    if (c >= 'a' && c <= 'z') c = (uint8_t)(c - 32);   // variables are upper
    if (c < 0x20 || c >= 0xE0) {
      // 0xE0..0xFF would be read back as a token prefix, and a control code
      // would end the line early.  Refuse rather than emit something the
      // machine will choke on halfway through a load.
      _err = "character cannot be stored"; return false;
    }
    bodyPut(c);
    t++;
  }

  if (inStr) { _err = "unterminated string"; return false; }
  bodyPut(EOL_B);
  return true;
}

// Walk the source once, emitting (or, in a dry run, counting) image bytes.
bool Pc2Basic::runLines(uint16_t srcStart, uint16_t srcEnd) {
  // The PC-1500's own input buffer is 80 characters, so a real program line
  // cannot approach this.  The size is not the point -- OVERFLOWING SILENTLY
  // is.  Dropping the tail of a long line produces a tape that loads happily
  // and runs the wrong program, which is the worst possible failure here, so
  // hitting the limit is an error and not a truncation.
  char line[PC2_SRC_LINE_MAX + 1];
  uint16_t a = srcStart;
  uint32_t lastLine = 0;
  bool any = false;

  while (a <= srcEnd) {
    uint16_t len = 0;
    bool over = false;
    while (a <= srcEnd) {
      uint8_t c = _ram.readByte(a++);
      if (c == '\r') continue;
      if (c == '\n') break;
      if (len < PC2_SRC_LINE_MAX) line[len++] = (char)c; else over = true;
    }
    line[len] = '\0';
    if (over) { _err = "source line too long"; return false; }

    char *t = line;
    while (*t == ' ' || *t == '\t') t++;
    uint16_t tl = (uint16_t)strlen(t);
    while (tl && (t[tl - 1] == ' ' || t[tl - 1] == '\t')) t[--tl] = '\0';
    if (!tl) continue;
    if (*t == '#' || *t == ';') continue;              // source comment

    uint32_t num = 0; uint8_t nd = 0;
    while (t[nd] >= '0' && t[nd] <= '9' && nd < 5) { num = num * 10 + (uint8_t)(t[nd] - '0'); nd++; }
    if (!nd) {
      // An un-numbered leading "REM name" is the listing's own title line, not
      // program text -- skip it so a listing feeds straight back in.
      if (!strncasecmp(t, "REM", 3)) continue;
      _err = "line has no number"; return false;
    }
    // 65279 = 0xFEFF.  A line number whose high byte is 0xFF would be read
    // back as the image terminator, so the machine's own limit is also ours.
    if (num < 1 || num > 65279) { _err = "line number not 1-65279"; return false; }
    if (any && num <= lastLine) { _err = "line numbers out of order"; return false; }
    lastLine = num; any = true;

    t += nd;
    while (*t == ' ') t++;                 // the space after the number is not data

    // Measure the body, then -- only when actually writing -- tokenise it a
    // second time to emit it.  The length byte precedes the body on tape, so
    // one of the two has to happen twice; doing the work twice is cheaper than
    // a 256-byte buffer on a board with 2 KB of headroom.
    if (!tokeniseBody(t, false)) return false;
    if (_bodyLen > 255) { _err = "line body over 255 bytes"; return false; }

    if (_dry) {
      _imgLen += 3UL + _bodyLen;
    } else {
      emitImage((uint8_t)(num >> 8));
      emitImage((uint8_t)(num & 0xFF));
      emitImage((uint8_t)_bodyLen);
      if (!tokeniseBody(t, true)) return false;
    }
  }

  if (!any) { _err = "no BASIC lines found"; return false; }
  return true;
}

uint32_t Pc2Basic::tokeniseInRam(uint16_t srcStart, uint16_t srcEnd,
                                 uint16_t dstBase, const char *name) {
  _err = "";

  // ---- pass 1: how long is the image? ------------------------------------
  // The header carries the image length, and the header comes FIRST on tape,
  // so it cannot be written until the whole program has been measured.  Two
  // passes over the source costs a few thousand SPI reads and needs no second
  // buffer; the alternative -- tokenise to scratch then expand in place -- has
  // to move overlapping regions backwards and is far easier to get wrong.
  _dry = true; _imgLen = 0; _outLen = 0; _sum = 0; _cnt = 0;
  if (!runLines(srcStart, srcEnd)) return 0;
  const uint32_t imgLen = _imgLen;
  if (imgLen == 0) { _err = "empty program"; return 0; }
  if (imgLen > 0xFFFF) { _err = "program over 64K"; return 0; }

  // ---- header ------------------------------------------------------------
  _dry = false; _dst = dstBase; _outLen = 0; _sum = 0; _cnt = 0;
  uint8_t hdr[HEADER_LEN];
  uint8_t k = 0;
  for (uint8_t i = 0; i < 8; i++) hdr[k++] = (uint8_t)(0x10 + i);
  hdr[k++] = 0x01;                                    // BASIC image
  for (uint8_t i = 0; i < 16; i++) {
    char c = name[i];
    if (!c) { for (uint8_t j = i; j < 16; j++) hdr[k++] = 0x00; break; }
    if (c >= 'a' && c <= 'z') c = (char)(c - 32);
    hdr[k++] = (uint8_t)c;
  }
  for (uint8_t i = 0; i < 9; i++) hdr[k++] = 0x00;
  hdr[k++] = (uint8_t)(LOAD_ADDR >> 8);   hdr[k++] = (uint8_t)(LOAD_ADDR & 0xFF);
  hdr[k++] = (uint8_t)(imgLen >> 8);      hdr[k++] = (uint8_t)(imgLen & 0xFF);
  hdr[k++] = 0x00;                        hdr[k++] = 0x00;   // entry address
  uint16_t hs = 0;
  for (uint8_t i = 0; i < 40; i++) hs = (uint16_t)(hs + hdr[i]);
  hdr[k++] = (uint8_t)(hs >> 8);          hdr[k++] = (uint8_t)(hs & 0xFF);
  for (uint8_t i = 0; i < HEADER_LEN; i++) emitRaw(hdr[i]);

  // ---- pass 2: the image, then the footer --------------------------------
  // The 80-byte block counter and the running sum start fresh AFTER the
  // header (bin2wav resets both at the end of WriteHeadTo15Wav), which is why
  // the header is written with emitRaw and not emitData.
  if (!runLines(srcStart, srcEnd)) return 0;
  emitData(IMG_EOF);
  if (_cnt) {                       // partial final block gets its own checksum
    emitRaw((uint8_t)(_sum >> 8));
    emitRaw((uint8_t)(_sum & 0xFF));
  }
  emitRaw(TAPE_EOF);
  return _outLen;
}

// ------------------------------------------------------------- header name
String Pc2Basic::headerName() {
  String out;
  for (uint8_t i = 0; i < 16; i++) {
    uint8_t c = _ram.readByte((uint16_t)(9 + i));
    if (!c) break;
    if (c >= 0x20 && c < 0x7F) out += (char)c;
  }
  return out;
}

// ------------------------------------------------------------ validate .TAP
const char *Pc2Basic::validateTap(uint32_t len, uint32_t *expected) {
  if (expected) *expected = 0;
  if (len < HEADER_LEN + 4) return "too short for a PC-2 tape";

  for (uint8_t i = 0; i < 8; i++)
    if (_ram.readByte(i) != (uint8_t)(0x10 + i)) return "bad header signature";

  uint16_t hs = 0;
  for (uint8_t i = 0; i < 40; i++) hs = (uint16_t)(hs + _ram.readByte(i));
  const uint16_t hstored = (uint16_t)((_ram.readByte(40) << 8) | _ram.readByte(41));
  if (hs != hstored) return "header checksum mismatch";

  // What the header's length field implies for the whole tape.
  const uint32_t n    = ((uint32_t)_ram.readByte(36) << 8) | _ram.readByte(37);
  const uint32_t data = n + 1;                       // image + the 0xFF
  const uint32_t want = HEADER_LEN + data
                      + 2 * (data / BLOCK)           // one checksum per full block
                      + ((data % BLOCK) ? 2 : 0)     // partial final block
                      + 1;                           // the 0x55
  if (expected) *expected = want;
  // A shortfall of exactly one byte is the missing 0x55 and nothing else -- the
  // capture path can lose the final frame, HI.TAP did, and the sender puts the
  // terminator back.  Let it through to the checksum walk so it is reported as
  // "missing 0x55 end mark", which the caller treats as repairable.
  if (len + 1 < want) return "tape is SHORT -- truncated capture";
  if (len > want) return "tape is LONGER than its header says";

  // Every block checksum, exactly as the machine accumulates them.
  uint32_t src = HEADER_LEN, taken = 0;
  uint16_t sum = 0, run = 0;
  while (taken < data) {
    sum = (uint16_t)(sum + _ram.readByte((uint16_t)src));
    src++; taken++; run++;
    if (run == BLOCK) {
      const uint16_t got = (uint16_t)((_ram.readByte((uint16_t)src) << 8)
                                    |  _ram.readByte((uint16_t)(src + 1)));
      if (got != sum) return "block checksum mismatch";
      src += 2; run = 0; sum = 0;
    }
  }
  if (run) {
    const uint16_t got = (uint16_t)((_ram.readByte((uint16_t)src) << 8)
                                  |  _ram.readByte((uint16_t)(src + 1)));
    if (got != sum) return "final checksum mismatch";
    src += 2;
  }
  if (src >= len || _ram.readByte((uint16_t)src) != TAPE_EOF)
    return "missing 0x55 end mark";
  return nullptr;
}

// -------------------------------------------------------------- detokenise
uint16_t Pc2Basic::writeListing(uint32_t tapLen, const String &basFilename) {
  _unknown = 0;
  if (tapLen < HEADER_LEN + 2) return 0;
  for (uint8_t i = 0; i < 8; i++)
    if (_ram.readByte(i) != (uint8_t)(0x10 + i)) return 0;
  if (_ram.readByte(8) != 0x01) return 0;             // not a BASIC image

  const uint32_t imgLen = ((uint32_t)_ram.readByte(36) << 8) | _ram.readByte(37);

  if (SD.exists(basFilename.c_str())) SD.remove(basFilename.c_str());
  File f = SD.open(basFilename, FILE_WRITE);
  if (!f) return 0;
  { String h = F("REM "); h += headerName(); f.println(h); }

  // Walk the data section, stepping over the 2-byte checksum after every 80.
  uint32_t src = HEADER_LEN, taken = 0, run = 0;
  uint8_t  img[3];
  uint16_t lines = 0;
  String   out; out.reserve(140);

  // Small helper inline: pull the next image byte, or return 0xFFFF at the end.
  #define PC2_NEXT(dst)                                              \
    do {                                                             \
      if (taken >= imgLen || src >= tapLen) { dst = -1; break; }     \
      dst = _ram.readByte((uint16_t)src);                            \
      src++; taken++; run++;                                         \
      if (run == 80) { src += 2; run = 0; }                          \
    } while (0)

  for (;;) {
    int b0, b1, b2;
    PC2_NEXT(b0); if (b0 < 0) break;
    PC2_NEXT(b1); if (b1 < 0) break;
    PC2_NEXT(b2); if (b2 < 0) break;
    img[0] = (uint8_t)b0; img[1] = (uint8_t)b1; img[2] = (uint8_t)b2;

    out = String((uint16_t)((img[0] << 8) | img[1]));
    out += ' ';

    uint16_t bl = img[2];
    bool remRest = false;
    uint16_t i = 0;
    while (i < bl) {
      int b; PC2_NEXT(b); if (b < 0) break;
      i++;
      uint8_t v = (uint8_t)b;
      if (i == bl && v == EOL_B) break;               // the record's own 0D

      if (!remRest && v >= 0xE0 && v <= 0xF1 && i < bl) {
        int b2b; PC2_NEXT(b2b); if (b2b < 0) break;
        i++;
        uint16_t tk = (uint16_t)((v << 8) | (uint8_t)b2b);
        bool named = false;
        for (uint8_t j = 0; j < TOKENS_N; j++) {
          Pc2Tok m; memcpy_P(&m, &TOKENS[j], sizeof(m));
          if (m.code != tk) continue;
          char nm[10]; strncpy_P(nm, m.name, 9); nm[9] = 0;
          out += nm;
          // The machine's LIST prints a space after a keyword and stores none;
          // spaces outside strings are dropped when this listing is tokenised
          // again, so it is free readability.  NOT after REM, whose text is
          // stored verbatim and would gain a space it could not lose.
          if (tk == REM_TOK) remRest = true; else out += ' ';
          named = true;
          break;
        }
        if (!named) {
          const char hex[] = "0123456789ABCDEF";
          out += '{';
          out += hex[(tk >> 12) & 0xF]; out += hex[(tk >> 8) & 0xF];
          out += hex[(tk >> 4)  & 0xF]; out += hex[tk & 0xF];
          out += '}';
          _unknown++;
        }
        continue;
      }

      if (v >= 0x20 && v < 0x7F) {
        out += (char)v;
      } else {
        const char hex[] = "0123456789ABCDEF";
        out += '{'; out += hex[v >> 4]; out += hex[v & 0x0F]; out += '}';
      }
    }
    f.println(out);
    lines++;
  }
  #undef PC2_NEXT

  f.close();
  return lines;
}
