#ifndef PC1_BASIC_H
#define PC1_BASIC_H

#include <Arduino.h>
#include <string.h>
#include "RamExternal.h"

// ---------------------------------------------------------------------------
// TRS-80 PC-1 / Sharp PC-1211 BASIC tokeniser and detokeniser
// ---------------------------------------------------------------------------
// Converts BASIC *source text* into the .TAP tape byte stream the PC-1's CLOAD
// expects, and back again.  Raw ASCII will NOT load -- the machine looks for an
// 0x80 header record and nibble-framed data, so sending text leaves CLOAD
// waiting forever.
//
// FORMAT, verified byte-for-byte against NINE real tapes -- BLAKJAK, ACEY,
// BACARAT, BANDIT, CRAPS, MISSILE, NUMGUESS, PSLOT and a re-save (BJ).  Every
// one detokenises to text and tokenises back to a byte-identical file, all
// 1357 checksums included:
//
//   header   80 | 7 name bytes | 5F | checksum            (10 bytes)
//            name = the name's nibble stream REVERSED, left-padded with 0x00
//            checksum = plain 8-bit sum of the record's data nibbles, marker
//            EXCLUDED
//   body     8 data bytes then 1 checksum byte, repeating.  The running sum
//            resets every 80 DATA bytes (= 90 bytes on tape, which is why the
//            tape has a 3.65 s gap every 90 bytes).  A final incomplete group
//            of 1..7 bytes gets NO checksum byte.
//   line     Ex | nn | tokens and characters | 00
//            THE LINE NUMBER IS THREE DIGITS ACROSS TWO BYTES: the marker's LOW
//            NIBBLE is the hundreds digit, the next byte is the other two in
//            BCD.   E0 10 -> 10    E1 02 -> 102    E4 30 -> 430
//   end      F0
//
// Tables come from PocketTools (bas2img / bin2wav, Torsten Muecker):
// conv_asc2old() for characters and the IDENT_OLD_BAS block for keywords, with
// its `pcId < 1210 || 1212 < pcId` guard respected -- that guard is why PI and
// SQR here are the CHARACTERS 0x19 / 0x1A and not the tokens 0xBD / 0x87 that
// later Sharps use.  Confirmed independently on the machine, which LISTs
// X=SQR PI for the bytes 1A 19.
//
// Two things measurement alone had got WRONG, both corrected here:
//   * 0x32 is '>' and 0x33 is '<'.  They were swapped, which made BLAKJAK line
//     92 read IF V<Z ("you don't have $" when the bet is BELOW the bankroll" --
//     nonsense).  It is IF V>Z.
//   * the body checksum applies its end-around carry after the HIGH nibble
//     ONLY, adding the low nibble plain.  Summing a group's 16 nibbles and
//     carrying once is a different function; that is why identical (previous
//     checksum, group sum) pairs appeared to give two different answers, and
//     why no amount of tape data could have revealed the rule.
//
// SCOPE: the full PC-1211 keyword set is supported in BOTH directions.  A
// keyword or character with no PC-1211 encoding makes tokenise fail with a
// clear message rather than emit a guess -- a wrong token hangs the machine, so
// the failure belongs on the bench, not on the tape.
//
// Memory model: source text is already in external SPI RAM at [srcStart..srcEnd]
// (put there by FileLoader).  The .TAP image is written to a DIFFERENT region of
// the same external RAM, so nothing needs to fit in the Mega's SRAM.
// ---------------------------------------------------------------------------

// Write a .LST listing alongside every PC-1 capture?  OFF by default -- a
// capture should produce the .TAP that was asked for and nothing else.
#ifndef PC1_WRITE_LISTING
#define PC1_WRITE_LISTING 0
#endif

class Pc1Basic {
public:
  explicit Pc1Basic(RamExternal &ram) : _ram(ram) {}

  // ---- SEND direction: BASIC text -> .TAP image ---------------------------
  // Reads source text from [srcStart..srcEnd], writes the complete .TAP (header
  // + body + checksums) at dstBase.  `name` is the CSAVE name, up to 7 chars.
  // Returns the image length in bytes, or 0 on error (see error()).
  uint32_t tokeniseInRam(uint16_t srcStart, uint16_t srcEnd,
                         uint16_t dstBase, const char *name);

  // ---- RECEIVE direction: .TAP image -> text listing ----------------------
  // Reads the .TAP at [0, tapLen) and writes a listing to `basFilename`.
  // Returns the number of lines written, or 0 if it was not a program record.
  uint16_t writeListing(uint32_t tapLen, const String &basFilename);

  // Bytes the last listing could not identify; they appear as {XX} escapes.
  uint16_t unknownBytes() const { return _unknown; }
  const char *error() const { return _err; }

  // The header record's NAME field -- what CSAVE"NAME" wrote, up to 7 chars.
  // Distinct from any quoted label at the start of a program line: the label is
  // program text and exists so the line can be started with the DEF key.
  String headerName();

private:
  RamExternal &_ram;
  uint16_t _unknown = 0;
  const char *_err = "";

  // checksum state while emitting
  uint8_t  _sum = 0;
  uint16_t _cnt = 0;
  uint32_t _outLen = 0;
  uint16_t _dst = 0;
  void     emitData(uint8_t b);      // one program byte + checksum bookkeeping

  void appendChar(uint8_t code, String &out);
};

#endif
