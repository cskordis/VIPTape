// v77 - force recompile
#include "CassetteProtocols.h"

// NOTE: Keep the protocol table *only* in this .cpp so the array is complete here.
// This prevents "incomplete type" sizeof errors and avoids multiple-definition issues.
//
// Field order (existing entries):
//   name, bit0, bit0_min, bit0_max, bit1, bit1_min, bit1_max,
//   leaderBit, leaderBits, leaderTime, startBit, bitOrder, parity,
//   interByteTimeout_us, stopBit, stopBits, trailerBit, trailerTime,
//   bit0_cycle, bit1_cycle, polarity
//
// Two extra fields exist after polarity (framing, oraoType).  Existing entries
// don't list them so they default to FRAMING_ASYNC / ORAO_TYPE_NONE.
//
// ORAO timings (full cycle in us) are derived from the Orao 2007 ROM and verified
// against real cassette WAV captures: bit-0 ~362us (~2.76kHz), bit-1 ~726us
// (~1.38kHz).  Min/max bounds are widened to absorb tape speed wobble and clock
// drift.  Discrimination threshold sits roughly at the geometric mean (~540us).

const CassetteParams cassetteProtocols[] = {

  {"VIP", 500, 420, 620, 1250, 1050, 1450, 0, 200, 5000, 1, LSB_FIRST, PARITY_EVEN, 20000, 0, 0, 0, 0, 1, 1, POLARITY_POSITIVE},
  {"ELF II", 833, 600, 1350, 416, 300, 520, 1, 200, 8000, 0, MSB_FIRST, PARITY_ODD, 20000, 0, 0, 0, 0, 1, 1,  POLARITY_NEGATIVE},
  {"HUG 1802", 2000, 1400, 2600, 1000, 200, 1200, 1, 200, 5000, 0, MSB_FIRST, PARITY_ODD, 20000, 0, 0, 0, 0, 1, 1, POLARITY_NEGATIVE},
  {"KCS 300", 833, 600, 1350, 416, 300, 520, 0, 0, 5000, 1, LSB_FIRST, PARITY_EVEN, 20000, 0, 0, 0, 0, 4, 8, POLARITY_POSITIVE},
  {"KCS 1200", 416, 300, 520, 208, 150, 350, 0, 0, 5000, 1, LSB_FIRST, PARITY_EVEN, 20000, 0, 0, 0, 0, 4, 8, POLARITY_POSITIVE},
  {"ORAO B", 362, 280, 540, 726, 540, 950, 1, 32, 2500, 0, LSB_FIRST, PARITY_NONE, 0, 0, 0, 0, 0, 1, 1, POLARITY_POSITIVE, FRAMING_BLOCK_ORAO, ORAO_TYPE_BASIC},
  {"ORAO O", 362, 280, 540, 726, 540, 950, 1, 32, 2500, 0, LSB_FIRST, PARITY_NONE, 0, 0, 0, 0, 0, 1, 1, POLARITY_POSITIVE, FRAMING_BLOCK_ORAO, ORAO_TYPE_OBJECT},

  // ---- COMX-35 (RCA CDP1802, BASIC V1.03 ROM) -----------------------------
  // Verified against three real-machine SAVE captures (Raider/Diver/CrossFire,
  // 22050Hz mono 16-bit).  Physical layer is plain 2-tone FSK, one full cycle
  // per bit (CHANGE-edge half-cycle pairing, same as the async protocols):
  //
  //   bit-0 : ~500us full cycle  (~2000 Hz)   <- also the leader tone
  //   bit-1 : ~1220us full cycle (~820 Hz)
  //
  // Framing is BIT-SYNCHRONOUS (FRAMING_SYNC_COMX), not UART-async.  After the
  // leader (a long run of bit-0 cells) locks, data is read as fixed 10-cycle
  // cells: cell[0] lead framing cycle, cell[1..8] = 8 data bits LSB-first,
  // cell[9] trail framing cycle.  The framing cycles are NOT fixed 1/0 values,
  // so phase is locked once at the leader and maintained by counting cells --
  // a per-byte start-bit hunt (the async path) would mis-sync.  This was
  // confirmed empirically: fixed 10-cell extraction recovers the program image
  // byte-perfect (header 00 11 LL 00, the CDP1802 loader stub, and in-program
  // ASCII strings all decode cleanly), whereas start-bit resync drifts.
  //
  // The two period windows are the only bench-tunable values: if a real load
  // misreads, capture a known-good SAVE, read the two cycle-length peaks, and
  // nudge bit0/bit1 (and their min/max) to match.  Min/max are widened well
  // clear of the ~860us inter-symbol threshold to absorb tape-speed wobble.
  //
  // On-tape program image begins with a 4-byte header: 00 11 LL 00, where LL is
  // a length/page byte; the bytes that follow are the raw CDP1802 program image
  // (COMX 'M' machine-code save).  Header parsing is left to FileAnalyzer.
  //
  // Field notes:
  //   leaderBit  = 0           : leader is the bit-0 (~2kHz) tone.
  //   leaderBits = 256         : decoder lock threshold (~0.13s; real leader is
  //                              ~49000 cells, so lock is effectively instant).
  //   leaderTime = 8000        : leader cells the ENCODER emits on SAVE (~4s).
  //   startBit/stopBit/stopBits/parity : UNUSED in FRAMING_SYNC_COMX (the cell
  //                              counter does the framing); left 0 / NONE.
  //   interByteTimeout_us = 0  : no inter-byte idle; timeout disabled.
  //   bit0_cycle = bit1_cycle = 1 : one full cycle per bit.
  // Tone periods from a GENUINE Diver tape (22050Hz) that decodes BYTE-PERFECT
  // to the known Diver image (00 11 6A 00 ... F8 44 B7 ...):
  //   bit0 = 408us (2450 Hz)    bit1 = 1043us (959 Hz)    ratio 2.556
  // Leader ~49000 cells x 408us = ~20-23s (matches the real tape).
  // NOTE: earlier detours to 500us and 816us came from mis-recorded captures
  // (a ~25%-slow file and a half-speed 44.1kHz file whose periods read 2x).
  // This is the verified value -- VIPTAPE's ORIGINAL uncalibrated output was
  // already ~408us, i.e. essentially correct from the start.
  {"COMX-35", 408, 300, 620, 1043, 760, 1300, 0, 256, 49000, 0, LSB_FIRST, PARITY_NONE, 0, 0, 0, 0, 0, 1, 1, POLARITY_NEGATIVE, FRAMING_SYNC_COMX, ORAO_TYPE_NONE},

  // ---- Heathkit ET-3400 / ETA-3400 (Motorola 6800) ------------------------
  // Cassette uses the Kansas City Standard (KCS) at 300 baud, carrying Motorola
  // S-record TEXT (ASCII).  Verified against a genuine ETA-3400A save
  // (DRUNK_BAS.wav): decoded to 89 S-records, 88/89 checksums valid.
  //
  // KCS physical layer (async UART framing, FRAMING_ASYNC):
  //   '0' bit = 4 cycles of 1200 Hz  -> bit0 = 833us/cycle, bit0_cycle = 4
  //   '1' bit = 8 cycles of 2400 Hz  -> bit1 = 416us/cycle, bit1_cycle = 8
  //   Frame: 1 start bit (0/space), 8 data bits LSB-first, no parity, 2 stop
  //   bits (1/mark).  Idle line = continuous mark (1) tone.
  //
  //   leaderBit  = 1      : leader is the mark (2400 Hz) tone the receiver locks
  //   leaderBits = 128    : decoder mark-lock threshold before hunting start bits
  //   leaderTime = 900    : mark bits the ENCODER emits up front (~3s @300baud)
  //   startBit   = 0      : KCS start bit is a space (0)
  //   parity     = NONE   : KCS/S-records carry no parity
  //   stopBit=1, stopBits=2 : two mark stop bits
  //   bit0_cycle = 4, bit1_cycle = 8 : the KCS cycle counts sendBit() emits.
  {"ET-3400", 833, 600, 1050, 416, 300, 520, 1, 256, 900, 0, LSB_FIRST, PARITY_NONE, 10000000, 1, 1, 1, 0, 4, 8, POLARITY_POSITIVE, FRAMING_ASYNC_KCS, ORAO_TYPE_NONE},
  //{"DREAM 6800", 833, 700, 950, 400, 320, 520, 1, 200, 5000, 0, LSB_FIRST, PARITY_NONE, 50000, 1, 1, 0, 0, 4, 8, POLARITY_POSITIVE},

  // ---- TRS-80 Pocket Computer 1 (Sharp PC-1211, via the CE-121) -----------
  // Derived from two real captures of the same save (hi_44100.wav and
  // hi_22050.wav), which demodulate to identical frame timings and identical
  // data.  Physical layer is 2-tone FSK with EQUAL-DURATION bit cells, so the
  // two symbols cannot be told apart by period alone -- cycle counting is
  // mandatory, exactly as for KCS, which is why this uses FRAMING_ASYNC_KCS.
  //
  //   '0' (space) = 4 cycles of 2 kHz   measured 499.56us/cycle
  //   '1' (mark)  = 8 cycles of 4 kHz   measured 250.38us/cycle
  //   both cells  = 2001.6us            -> 499.6 bit/s
  //
  // Framing is a UART frame carrying a NIBBLE:
  //     start '0' | 4 data bits | >= 4 mark stop bits | ~1.25-1.55ms extra mark
  // Hence dataBits = 4 (the last field).  See CassetteParams.h for how that
  // field stays backward-compatible with every entry above.
  //
  // Frame-to-frame spacing is NOT constant -- it wanders between 19.28ms and
  // 21.55ms with the data, the signature of a ROM bit-banging the tape and
  // doing per-nibble housekeeping with the mark tone still running.  The
  // decoder therefore must resync on every start bit (the async path already
  // does); do NOT free-run a bit clock across frames.
  //
  // Record layout measured on the capture:
  //   mark leader   2457 bit cells (~4.92 s)   <- manual says "about 6 seconds"
  //   header section, 20 nibbles
  //   mark gap       130 bit cells (~0.26 s)
  //   data section,   21 nibbles
  //   mark trailer    42 bit cells (~0.08 s)
  //
  // TONE PERIODS ARE THE ONLY BENCH-TUNABLE VALUES.  Note the 4 kHz mark needs
  // a 125us HALF-cycle -- the shortest this project emits anywhere -- so the
  // ENC_CAL_OVERHEAD_US output correction matters more here than for any other
  // protocol: uncorrected, 10us of per-half overhead drags the mark down to
  // ~3.7 kHz.  Min/max windows are widened well clear of the ~375us
  // inter-symbol threshold to absorb tape-speed wobble.
  //
  // bitOrder LSB_FIRST is CONFIRMED, not assumed.  Above this layer each pair
  // of nibbles forms a byte with the FIRST nibble high, and every record ends
  // with a 2-nibble checksum = 8-bit sum of the record's data nibbles.  That
  // checksum only balances for this combination of bit order and nibble
  // packing, and it balances on both captures, which pins the whole chain.
  // The program record decodes to:
  //   E0 10 C1 12 58 59 12 00 | 3D | F0
  //   type, line 10 (BCD), PRINT, quote, 'H', 'I', quote, EOL, checksum, end
  // i.e.  10 PRINT "HI".  Characters are ASCII + 0x10.
  // Framing is a completely ordinary UART frame -- start 0, 8 data LSB-first,
  // 1 stop, no parity -- exactly as the CE-122 service manual documents:
  //
  //   0 | b0 b1 b2 b3 b4 b5 b6 b7 | 1        10 cells x 2.0016us = 20.0 ms
  //
  // and the measured frame period on the captures is 19.28-21.55 ms.  So NO new
  // framing mode and no new struct field are needed; this row is just numbers.
  //
  // The one thing that IS unusual is the PAYLOAD, and it lives above this layer:
  // the PC-1211 uses only the LOW NIBBLE of each frame and pads the high nibble
  // with ones, so every byte on tape is 0xF0 | nibble, two frames per real data
  // byte, HIGH NIBBLE FIRST.  Confirmed on both captures -- 38 of 39 frames read
  // 0xFx (the one exception is a sampling artefact across the inter-record gap)
  // and every stop bit is 1.  The PC-1 file path does that packing; see
  // PC1_FINDINGS.md.
  //
  // An earlier revision modelled this as a 4-data-bit frame with 5 stop bits.
  // That produces the IDENTICAL bit sequence, but needed a new `dataBits` field
  // threaded through CassetteParams, the encoder and the decoder.  It has been
  // reverted in favour of this description, which matches the documentation and
  // touches nothing outside this table.
  // stopBits = 0 ON PURPOSE.  The PC-1's stop is not a whole bit cell -- it is a
  // mark burst of ~6 cycles of 4 kHz (1.50 ms) against a 2.00 ms cell.  Letting
  // the generic path emit a full stop bit makes every mark run 2-3 cycles too
  // long, which is the ONLY structural difference between a generated tape and a
  // real one (space runs match exactly).  The PC-1 send path emits the short
  // stop itself via CassetteEncoder::sendToneCycles(1, 6) after each frame.
  // HARDWARE-VERIFIED TONE PERIODS.  Measured per-run from a tape that loads,
  // NOT the nominal 4000/2000 Hz -- and note they are not an exact 2:1 ratio:
  //     mark  3990.4 Hz -> 250.6 us      space 1994.2 Hz -> 501.5 us
  // A 98.4%-synthetic rebuild at these values loads on real hardware; the same
  // rebuild at 4000/2000 does not.  0.25% sounds negligible but accumulates to
  // half a bit cell over a few hundred ms.
  //
  // ALSO CRITICAL, and not expressible in this table -- the emitted waveform
  // must land on a ZERO CROSSING at every tone boundary.  A phase discontinuity
  // mid-tone creates a spurious or missing edge and corrupts a bit, which fails
  // a load with no other fault present.  VIPTAPE's square-wave output satisfies
  // this naturally as long as each bit emits whole cycles (bit0_cycle=4,
  // bit1_cycle=8) and the short stop is emitted via sendToneCycles(1, 6).
  // RECEIVE WINDOWS: OUTER BOUNDS ARE VALIDATED -- DO NOT WIDEN THEM.
  // bit0=492 / bit1=232 are the hardware-calibrated TRANSMIT periods and must
  // never move; the min/max pairs are RECEIVE-only and the KCS path halves them.
  //
  // A build that widened these to mark 75-187us / space 188-450us HUNG the
  // reader: the extra span let idle line noise classify as valid tones, the
  // decoder locked a leader on noise and emitted bytes continuously, and since
  // ReadData() ends a capture on a GAP in decoded bytes, the gap never came.
  //
  // The evidence that the original bounds were already right: on a clean
  // hardware capture, oor went 31345 -> 31347 across 24 decoded frames.  Two
  // rejects in two seconds.  The large oor counts in that same log came from
  // the idle line BEFORE and AFTER the tape, not from the signal -- fitting the
  // windows to that was fitting them to noise.
  //
  // The one real defect here was a DEAD ZONE: half-windows of 90-190us and
  // 200-350us left 190-200us belonging to neither.  Closed at the true midpoint
  // of the two tones (125us mark, 250us space -> 187.5us) by moving bit1_max
  // 380 -> 374 and bit0_min 400 -> 376.  Outer bounds untouched.
  {"TRS-80 PC-1", 492, 376, 700, 232, 180, 374, 1, 128, 2456, 0, LSB_FIRST, PARITY_NONE, 0, 1, 0, 1, 42, 4, 8, POLARITY_NEGATIVE, FRAMING_ASYNC_KCS, ORAO_TYPE_NONE},

  // ---- TRS-80 Pocket Computer 2 (Sharp PC-1500, via the CE-150) -----------
  // *** RECEIVE / MEASUREMENT ONLY.  THE TONE VALUES BELOW ARE NOMINAL. ***
  //
  // The PC-1500's physical layer is the SAME FAMILY as the PC-1211 -- this is
  // the whole reason it needs no decoder of its own.  From PocketTools'
  // bit-pattern tables and BASE_FREQ2:
  //
  //                     PC-1 (PC-1211)        PC-2 (PC-1500)
  //   bit 1 (mark)      8 cycles @ 4000 Hz    8 cycles @ 2500 Hz
  //   bit 0 (space)     4 cycles @ 2000 Hz    4 cycles @ 1250 Hz
  //   bit cell          2.00 ms               3.20 ms
  //   byte framing      two nibbles, each with its own stop bits  <- BOTH
  //
  // Same equal-duration 4-vs-8-cycle FSK, same nibble-pair byte framing.  So
  // the KCS half-period path, the round-to-nearest-cell rule, the 128-slot
  // queue and the signal-quality gate all apply unchanged.
  //
  // WHAT IS NOT YET KNOWN: the record layer.  The PC-1500 has five file types
  // (BAS/BIN/RSV/DEF/DAT) and ends with a FF,sum,0x55 footer rather than the
  // PC-1's 0x80 header and checksum groups.  Until that is measured, this row
  // is for CAPTURE ONLY -- SendData() refuses to transmit to a PC-2.
  //
  // CALIBRATION IS MANDATORY BEFORE TRUSTING 800 / 400.  The PC-1's nominal
  // 500/250 measured 9% fast on real hardware and cost days of blind sweeping.
  // Capture a SAVE, read the run-length trace, and set these from the median
  // half-period -- exactly the procedure in PC1_SAVE_FIX.md.  Windows are
  // deliberately wide for now so a mistuned tone still produces a trace.
  //   mark  2500 Hz -> 400 us/cycle      space 1250 Hz -> 800 us/cycle
  //   split at 600 us
  // TONE VALUES MEASURED, not nominal.  From a real PC-2 CSAVE capture,
  // half-period histogram in 25us buckets:
  //     mark   175:27713  200:28046   -> half ~200us -> cycle 400us -> 2500 Hz
  //     space  350:214    375:3900    -> half ~385us -> cycle ~780us -> ~1285 Hz
  // The space is NOT exactly half the mark frequency, the same way the PC-1's
  // measured 4055/2031 Hz was not an exact 2:1.  Use the measured 780.
  //
  // ---- bit0 = 760.  THE SPACE PERIOD IS THE SENSITIVE PARAMETER -----------
  // Three points on this machine, all with the measured leader/gap structure
  // except where noted:
  //     bit0 = 780  -> header read, name shown, ERROR 44 later in the data
  //     bit0 = 800  -> HANGS, name never shown  (also failed in v7)
  // Higher is WORSE, and it fails EARLIER: at 800 the machine cannot even get
  // through the ident frame.  The leader is pure mark tone and CLOAD always
  // responds to it, so the mark is fine; everything breaks at the first SPACE
  // cell, which is the ident frame's start bit.
  //
  // Why the nominal must sit BELOW the target.  Every emitted cycle costs two
  // delayMicroseconds() calls plus loop overhead, so the wire sees roughly
  // period + 10..20us.  Nominal 780 goes out at ~790-800 -- already at the edge
  // of what this machine accepts -- and nominal 800 goes out at ~810-820, past
  // it.  Meanwhile this PC-2's OWN CSAVE measured a space half-period of ~385us
  // (histogram bucket 375, 3900 samples, only 214 in bucket 350), i.e. a period
  // near 770.  To EMIT ~770 the nominal has to be ~760.
  //
  // Do not read the 800 in the BOWLING WAV as a contradiction.  That file is
  // sampled at 5 kHz, so every edge is quantised to a 200us grid and 770 cannot
  // be represented -- it lands on 800.  The WAV proves the machine ACCEPTS 800
  // from a tape recorder; it does not prove 800 is what to emit from a pin
  // whose timing carries a per-cycle overhead.
  //
  // If ERROR 44 persists but the header still reads, the next step is DOWN
  // again (740), not up.  If the name stops appearing, that is too far.
  //
  // ---- the superseded warning, kept for the record ------------------------
  // The argument for 800 is seductive and wrong.  It goes: the framing is
  // equal-duration by definition, so a 4-cycle space must equal an 8-cycle
  // mark, 8 x 400us = 3.200 ms, therefore the space must be 4 x 800us; and
  // PocketTools appears to agree, since bin2wav's 44.1 kHz PC-1500 waveform
  // (bit3_15[]) is 141 samples for BOTH bit values -- 8 cycles of 399.7us and
  // 4 cycles of 799.3us, exactly equal cells.
  //
  // It was tried with the old structure and nothing loaded, which looked like
  // proof.  It was not -- see above.  The histogram measured the machine's own
  // OUTPUT through a comparator; the WAV measures what its INPUT accepts, and
  // those need not be the same number.
  //
  // bit0 is used by nothing but the encoder (_half0_us = bit0 / 2); the decoder
  // classifies on the min/max windows and cycle counts, so this value affects
  // TRANSMIT only.  If it is ever revisited, change it ALONE, keep a known-good
  // small .TAP on the card as the control, and believe the machine over the
  // arithmetic.
  //
  // ---- LEADER AND TRAILER MEASURED FROM A TAPE THE MACHINE ACCEPTS -------
  // leaderTime 625 and trailerTime 70 are not estimates.  A WAV of BOWLING
  // that this PC-2 loads was decoded cell by cell; its total is 31030 cells
  // over 99.30 s, i.e. 3.200 ms per cell exactly, and its structure is:
  //     leader                  625 cells (2.000 s)
  //     ident + 42 header bytes
  //     gap                      70 cells (0.224 s)
  //     data bytes ... to the last checksum byte
  //     gap                      70 cells      <- before the 0x55 EOF
  //     0x55
  //     trailer                  70 cells
  // Previously these were 2456 and 42, copied from the PC-1 and never
  // measured; the gap before the EOF byte was not emitted at all.
  //
  // Frame structure, read directly off the run-length trace:
  //     S8 M16 S24 M96  = start | d0=1 | d1..d3=0 | 6 mark cells  -> nibble 1
  //     S40        M96  = start + 4 zero data bits | 6 mark cells -> nibble 0
  //   frame = 1 space cell + 4 data cells LSB-first + 6 mark cells = 11 cells,
  //   which matches PocketTools' MODE_B22 {6,6} stop-bit entry for the PC-1500.
  {"TRS-80 PC-2", 760, 601, 1100, 400, 260, 599, 1, 128,  625, 0, LSB_FIRST, PARITY_NONE, 0, 1, 0, 1, 70, 4, 8, POLARITY_NEGATIVE, FRAMING_ASYNC_KCS, ORAO_TYPE_NONE}

  };

const uint8_t cassetteProtocolCount = sizeof(cassetteProtocols) / sizeof(cassetteProtocols[0]);
