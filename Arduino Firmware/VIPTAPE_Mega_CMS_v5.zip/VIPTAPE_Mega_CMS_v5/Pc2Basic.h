#ifndef PC2_BASIC_H
#define PC2_BASIC_H

#include <Arduino.h>
#include <string.h>
#include "RamExternal.h"

// ---------------------------------------------------------------------------
// TRS-80 PC-2 / Sharp PC-1500 BASIC tokeniser and detokeniser
// ---------------------------------------------------------------------------
// Converts BASIC source text into the complete .TAP tape byte stream the PC-2's
// CLOAD expects, and back again.  Raw ASCII will NOT load.
//
// This is a DIFFERENT machine from the PC-1, not a variant of it.  Everything
// below differs: two-byte tokens instead of one, plain ASCII instead of
// ASCII+0x10, a 42-byte header instead of a 10-byte one, big-endian line
// numbers with an explicit length byte instead of BCD-in-the-marker, and a
// 16-bit block checksum instead of the PC-1's end-around-carry nibble sum.
// Hence a separate class rather than a flag on Pc1Basic.
//
// TAPE BYTE STREAM (this is exactly what a .TAP file holds; the leading lone
// 0xA file-type nibble is stripped when capturing and re-created by the
// sender, so it is NOT part of the file):
//
//   [0..41]  header, 42 bytes
//              10 11 12 13 14 15 16 17   signature
//              01                        sub-ident, BASIC image
//              16 bytes                  name, ASCII, NUL padded
//              9 bytes                   zero
//              2 bytes                   load address, big-endian (00C5)
//              2 bytes                   image length, big-endian
//              2 bytes                   entry address, big-endian (0000)
//              2 bytes                   plain 16-bit sum of bytes 0..39
//   [42..]   the image, then 0xFF, with a 16-bit checksum (hi,lo) of the
//            preceding 80 bytes inserted after every 80 and the running sum
//            reset each time; a partial final block gets its own checksum
//   last     0x55, end of file
//
// PROGRAM IMAGE -- one record per line:
//
//   <line number, 2 bytes BIG-ENDIAN> <length> <body ...> 0D
//
// `length` counts from the first body byte through the 0D inclusive, so it
// caps a line at 255 bytes.  The image ends after the last 0D; the 0xFF
// belongs to the tape layer, not the image, which is why the header's length
// field on a real capture reads 000D for a 13-byte image followed by FF.
//
// VERIFIED, not assumed.  The header layout and its checksum rule were read
// off the machine's own CSAVE of `10 PRINT"HELLO"` saved as HI: the stored
// sum 0x0200 is the plain 16-bit sum of the 40 bytes before it, exactly.  The
// footer sum 0x045F is the 16-bit sum of the 13 image bytes PLUS the 0xFF.
//
// TOKENS are always TWO bytes.  A byte in 0xE0..0xF1 introduces one; every
// other byte is a literal character.  The 183 tokens were derived EMPIRICALLY:
// `10 <NAME>` was fed to PocketTools bas2img --pc=1500 for every name in
// wav2bin's CodePc1500_E6/E7/E8/F0/F1 detokenise tables, and the byte pair it
// emitted was recorded.
//
// An earlier version scraped the names out of the bas2img SOURCE instead, and
// missed 69 of them -- including CLS and CURSOR, which are ordinary PC-1500
// commands.  That was not harmless: greedy matching turned `CURSOR 0` into the
// characters "CURS" followed by the OR token, giving a program that lists back
// almost convincingly and is wrong.  DO NOT go back to parsing the source --
// use the tool as an oracle.
//
// Two names share code 0xF0C3 in bas2img (ERASE and REPKEY).  REPKEY is
// dropped so the table stays a bijection and a listing round-trips
// unambiguously; wav2bin lists 0xF0C3 as ERASE.
//
// KEYWORD MATCHING IS PER-CHARACTER GREEDY, longest name first.  That is the
// rule the machine's own ROM uses and it has to be, because it is the only one
// that reads the machine's own listing back correctly: LIST prints a space
// after a keyword but never before one, so a genuine listing contains
// `IF A<BTHEN GOTO 100` and the THEN there starts in the middle of "BTHEN".
// The cost is the machine's own restriction -- a variable name that contains a
// keyword gets split, so ORDER becomes OR + DER on a real PC-1500 too.
// ---------------------------------------------------------------------------

// Write a .LST listing alongside every PC-2 capture?  OFF by default, to match
// the PC-1: a capture should produce the .TAP that was asked for, nothing else.
#ifndef PC2_WRITE_LISTING
#define PC2_WRITE_LISTING 0
#endif

class Pc2Basic {
public:
  explicit Pc2Basic(RamExternal &ram) : _ram(ram) {}

  // ---- SEND direction: BASIC text -> complete tape image ------------------
  // Reads source text from [srcStart..srcEnd] and writes the whole tape byte
  // stream (header + image + block checksums + FF/sum/55) at dstBase.
  // `name` is the CSAVE name, up to 16 characters.
  // Returns the image length in bytes, or 0 on error (see error()).
  uint32_t tokeniseInRam(uint16_t srcStart, uint16_t srcEnd,
                         uint16_t dstBase, const char *name);

  // ---- RECEIVE direction: tape image -> text listing ----------------------
  // Reads the .TAP at [0, tapLen) and writes a listing to `basFilename`.
  // Returns the number of lines written, or 0 if it was not a BASIC record.
  uint16_t writeListing(uint32_t tapLen, const String &basFilename);

  // Tokens the last listing could not name; they appear as {F0C0} escapes.
  uint16_t unknownTokens() const { return _unknown; }
  const char *error() const { return _err; }

  // The header's NAME field -- what CSAVE"NAME" wrote, up to 16 chars.
  String headerName();

  // ---- CHECK A .TAP BEFORE SENDING IT -------------------------------------
  // Returns nullptr if the tape at [0,len) is internally consistent, or a short
  // reason if not.  Every check is arithmetic the machine itself performs, so a
  // file that fails here will fail on the PC-2 -- usually by HANGING rather than
  // erroring, because a short tape leaves CLOAD waiting for bytes that never
  // arrive.  A capture that lost its final frames looks exactly like this, and
  // diagnosing it by hand costs an afternoon.
  //
  // On return `expected` holds the length the header implies, so the caller can
  // report "1372 bytes expected, 1361 present".
  const char *validateTap(uint32_t len, uint32_t *expected);

  static const uint16_t HEADER_LEN = 42;

private:
  RamExternal &_ram;
  uint16_t _unknown = 0;
  const char *_err = "";

  // emit state
  bool     _dry    = false;   // pass 1: count image bytes, write nothing
  uint32_t _imgLen = 0;
  uint32_t _outLen = 0;
  uint16_t _dst    = 0;
  uint16_t _sum    = 0;       // 16-bit block sum
  uint16_t _cnt    = 0;       // bytes since the last block checksum

  uint16_t _bodyLen  = 0;     // length of the line body being built
  bool     _bodyEmit = false;  // false: measure only; true: measure and emit

  void emitRaw(uint8_t b);    // straight to RAM, no checksum bookkeeping
  void emitData(uint8_t b);   // one tape data byte + block checksum bookkeeping
  void emitImage(uint8_t b);  // one image byte (counted in pass 1)
  void bodyPut(uint8_t b);    // one line-body byte

  bool runLines(uint16_t srcStart, uint16_t srcEnd);

  // Measures the body into _bodyLen, and emits it too when `emit` is set.
  // NO BUFFER: the length byte has to be written before the body, so the body
  // is simply tokenised twice -- once to measure, once to emit.  A 256-byte
  // static to hold it instead would be 3% of this board's SRAM, which is
  // already 72% spoken for, and a stack overflow on an AVR is silent.
  bool tokeniseBody(const char *t, bool emit);
};

#endif
