#!/usr/bin/env python3
"""
pc1_basic.py -- TRS-80 PC-1 / Sharp PC-1211 BASIC <-> .TAP, both directions.

    python3 pc1_basic.py list  PROG.TAP            -> text listing on stdout
    python3 pc1_basic.py make  PROG.BAS NAME out.TAP
    python3 pc1_basic.py test  *.TAP               -> round-trip every file

Tables are ported from PocketTools (bas2img/bin2wav, Torsten Muecker) --
`conv_asc2old()` for characters and the IDENT_OLD_BAS block for keywords, with
the `pcId < 1210 || 1212 < pcId` guard respected so PC-1211-only encodings are
used.  That guard matters: on the PC-1211, PI and SQR are NOT the tokens 0xBD /
0x87 that later models use, they are the keyboard characters 0x19 / 0x1A.

Two things this fixed that measurement alone had got wrong:
  * 0x32 is '>' and 0x33 is '<'.  I had them swapped.  The source settles it,
    and it repairs the logic: BLAKJAK line 92 reads IF V>Z PRINT "YOU DONT
    HAVE $" -- bet exceeds bankroll -- where '<' made nonsense of it.
  * the body checksum is CheckSumB1(): an end-around carry applied after the
    HIGH nibble only, with the low nibble added plain.  No amount of pooled
    tape data could have revealed that -- summing the 16 nibbles of a group and
    carrying once is a different function, which is why identical (prev, sum)
    pairs appeared to give two different answers.
"""

import sys

# ---- characters: PC-1211 code -> ASCII (from conv_asc2old, inverted) --------
CH2A = {17: " ", 18: '"', 19: "?", 20: "!", 21: "#", 22: "%", 24: "$",
        27: ",", 28: ";", 29: ":", 30: "@", 31: "&",
        48: "(", 49: ")", 50: ">", 51: "<", 52: "=", 53: "+", 54: "-",
        55: "*", 56: "/", 57: "^", 74: ".", 77: "~", 78: "_"}
for c in range(0x30, 0x3A):            # digits
    CH2A[c + 16] = chr(c)
for c in range(0x41, 0x5B):            # A-Z
    CH2A[c + 16] = chr(c)
A2CH = {v: k for k, v in CH2A.items()}
# multi-character escapes for keys that have no ASCII form
SPECIAL = {0x19: "[PI]", 0x1A: "[SQR]", 0x4B: "[E]", 0x4C: "[FUL]", 0x10: "[INS]"}

# ---- keywords: IDENT_OLD_BAS, PC-1211 subset -------------------------------
TOK = {
    ">=": 0x82, "<=": 0x83, "<>": 0x84,
    "AREAD": 0xDC, "ABS": 0xAA, "ACS": 0xA4, "ASN": 0xA3, "ATN": 0xA5,
    "BEEP": 0xDB, "CHAIN": 0xD9, "CLEAR": 0xC5, "CLOAD": 0xB7, "CLOSE": 0x9D,
    "CONT": 0xB4, "COS": 0xA1, "CSAVE": 0xB6, "DEBUG": 0xB5, "DEGREE": 0xC4,
    "DEG": 0xAC, "DMS": 0xAD, "END": 0xD4, "EXP": 0xA6, "FOR": 0xD1,
    "GOSUB": 0xD8, "GOTO": 0xD7, "GRAD": 0xC0, "IF": 0xD0, "INPUT": 0xC2,
    "INT": 0xA9, "LN": 0xA7, "LET": 0xD2, "LIST": 0xB3, "LOG": 0xA8,
    "MEM": 0xB2, "NEXT": 0xD5, "NEW": 0xB1, "OPEN": 0x9C, "PAUSE": 0xDA,
    "PRINT": 0xC1, "RADIAN": 0xC3, "REM": 0xD3, "RETURN": 0xDE, "RUN": 0xB0,
    "SETCOM": 0x9B, "SGN": 0xAB, "SIN": 0xA0, "STEP": 0x91, "STOP": 0xD6,
    "TAN": 0xA2, "THEN": 0x92, "TO": 0x90, "USING": 0xDD,
}
TOK2NAME = {v: k for k, v in TOK.items()}
# longest first so PRINT wins over PI-like prefixes and >= over >
KEYS = sorted(TOK, key=len, reverse=True)

EOL, EOF, HDR_END = 0x00, 0xF0, 0x5F
BLK_DATA = 80        # BLK_OLD: data bytes per block before the sum resets
SUM_EVERY = 8        # BLK_OLD_SUM


def cksum_b1(s, byte):
    """PocketTools CheckSumB1: end-around carry after the HIGH nibble only."""
    t = s + ((byte & 0xF0) >> 4)
    if t > 0xFF:
        t = (t + 1) & 0xFF
    return (t + (byte & 0x0F)) & 0xFF


def nsum(b):
    return sum((x >> 4) + (x & 0x0F) for x in b) & 0xFF


# ------------------------------------------------------------------ header
def enc_name(name):
    nibs = []
    for ch in name.upper()[:7]:
        c = A2CH.get(ch, 17)
        nibs += [c >> 4, c & 0x0F]
    nibs.reverse()
    nibs = [0] * (14 - len(nibs)) + nibs
    return bytes((nibs[i] << 4) | nibs[i + 1] for i in range(0, 14, 2))


def dec_name(h7):
    nb = []
    for b in h7:
        nb += [b >> 4, b & 0x0F]
    s = 0
    while s < len(nb) and nb[s] == 0:
        s += 1
    out = ""
    i = len(nb)
    while i > s + 1:
        out += CH2A.get((nb[i - 1] << 4) | nb[i - 2], "?")
        i -= 2
    return out


# ------------------------------------------------------------- detokenise
def program_bytes(tap):
    """strip the 10-byte header and every checksum byte"""
    body = tap[10:]
    out = bytearray()
    n = 0
    i = 0
    while i < len(body):
        for _ in range(SUM_EVERY):
            if i >= len(body):
                break
            out.append(body[i]); i += 1; n += 1
        i += 1                      # skip the checksum
    return bytes(out)


def listing(tap):
    data = program_bytes(tap)
    lines, i = [], 0
    while i < len(data) - 1:
        if not (0xE0 <= data[i] <= 0xEF):
            i += 1
            continue
        num = (data[i] & 0x0F) * 100 + (data[i + 1] >> 4) * 10 + (data[i + 1] & 0x0F)
        i += 2
        txt = ""
        while i < len(data) and data[i] not in (EOL, EOF):
            b = data[i]
            if b in TOK2NAME:
                txt += TOK2NAME[b]
            elif b in SPECIAL:
                txt += SPECIAL[b]
            elif b in CH2A:
                txt += CH2A[b]
            else:
                txt += "{%02X}" % b
            i += 1
        lines.append("%d %s" % (num, txt))
        if i < len(data) and data[i] == EOF:
            break
        i += 1
    return lines


# --------------------------------------------------------------- tokenise
def tokenise_line(text):
    """one source line (without its number) -> program bytes"""
    out = bytearray()
    i = 0
    n = len(text)
    in_str = False
    while i < n:
        c = text[i]
        if c == '"':
            in_str = not in_str
            out.append(A2CH['"']); i += 1; continue
        if not in_str:
            # Spaces outside a string are DROPPED: the old series does not allow
            # spaces between commands.  All nine reference tapes agree -- 495
            # spaces inside string literals, zero outside.  A stored space LISTs
            # back normally, so the program looks right and fails at RUN.
            if c in " \t":
                i += 1; continue
            if text.startswith("[", i):
                for code, esc in SPECIAL.items():
                    if text.startswith(esc, i):
                        out.append(code); i += len(esc); break
                else:
                    raise ValueError("unknown escape at %r" % text[i:i + 8])
                continue
            up = text[i:].upper()
            for k in KEYS:
                if up.startswith(k):
                    out.append(TOK[k]); i += len(k)
                    if k == "REM":
                        # REM swallows the rest of the line: PocketTools copies
                        # it out verbatim with no keyword matching, and drops
                        # the spaces right after REM (delREMspc).  Otherwise
                        # `REM PRINT TOTALS` hides a real PRINT token inside a
                        # comment -- and it still LISTs as PRINT, so it looks
                        # fine until the machine runs it.
                        while i < n and text[i] == " ":
                            i += 1
                        while i < n:
                            if text[i] not in A2CH:
                                raise ValueError("character %r has no PC-1211 code" % text[i])
                            out.append(A2CH[text[i]]); i += 1
                    break
            else:
                if c in A2CH:
                    out.append(A2CH[c]); i += 1
                else:
                    raise ValueError("character %r has no PC-1211 code" % c)
            continue
        # inside a string literal: characters only, escapes still allowed
        if text.startswith("[", i):
            for code, esc in SPECIAL.items():
                if text.startswith(esc, i):
                    out.append(code); i += len(esc); break
            else:
                raise ValueError("unknown escape at %r" % text[i:i + 8])
            continue
        if c in A2CH:
            out.append(A2CH[c]); i += 1
        else:
            raise ValueError("character %r has no PC-1211 code" % c)
    return bytes(out)


def make_tap(src_lines, name):
    prog = bytearray()
    for raw in src_lines:
        raw = raw.rstrip("\n").rstrip()
        if not raw or raw.lstrip().startswith("'"):
            continue
        t = raw.lstrip()
        num = ""
        while t and t[0].isdigit():
            num += t[0]; t = t[1:]
        if not num:
            # A leading un-numbered "REM NAME" is the listing's own title line,
            # not program text.  Skip it rather than refusing the file, so a
            # listing produced by `list` feeds straight back into `make`.
            if t.upper().startswith("REM"):
                continue
            raise ValueError("line has no line number: %r" % raw)
        ln = int(num)
        if not 1 <= ln <= 999:
            raise ValueError("line number out of range: %d" % ln)
        prog.append(0xE0 | (ln // 100))
        prog.append(((ln // 10) % 10) << 4 | (ln % 10))
        prog += tokenise_line(t.lstrip())
        prog.append(EOL)
    prog.append(EOF)

    tap = bytearray()
    nm = enc_name(name)
    tap.append(0x80); tap += nm; tap.append(HDR_END)
    tap.append(nsum(bytes(nm) + bytes([HDR_END])))

    s = 0; cnt = 0
    for i, b in enumerate(prog):
        tap.append(b)
        s = cksum_b1(s, b); cnt += 1
        if cnt % SUM_EVERY == 0:
            tap.append(s)
            if cnt >= BLK_DATA:
                s = 0; cnt = 0
    # NO trailing checksum for a final incomplete group.  bin2wav writes one
    # only where `count % BLK_OLD_SUM == 0`, so a tail of 1..7 bytes gets none.
    # BLAKJAK proves it: 1390 program bytes = 173 full groups + 6 left over, and
    # the file is 10 + 1390 + 173 = 1573 bytes, not 1574.
    return bytes(tap)


def verify(tap):
    body = tap[10:]
    ok = bad = 0
    s = 0; cnt = 0; i = 0
    while i < len(body):
        for _ in range(SUM_EVERY):
            if i >= len(body):
                break
            s = cksum_b1(s, body[i]); i += 1; cnt += 1
        if i >= len(body):
            break
        ok, bad = (ok + 1, bad) if body[i] == s else (ok, bad + 1)
        i += 1
        if cnt >= BLK_DATA:
            s = 0; cnt = 0
    return ok, bad


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "list":
        tap = open(sys.argv[2], "rb").read()
        print("REM %s" % dec_name(tap[1:8]))
        for l in listing(tap):
            print(l)
    elif cmd == "make":
        src = [l for l in open(sys.argv[2])]
        out = make_tap(src, sys.argv[3])
        open(sys.argv[4], "wb").write(out)
        ok, bad = verify(out)
        print("wrote %s: %d bytes, %d checksums ok, %d bad" % (sys.argv[4], len(out), ok, bad))
    elif cmd == "test":
        allok = True
        for f in sys.argv[2:]:
            tap = open(f, "rb").read()
            ok, bad = verify(tap)
            name = dec_name(tap[1:8])
            try:
                txt = listing(tap)
                rebuilt = make_tap(txt, name)
                same = rebuilt == tap
            except Exception as e:
                same = False; txt = []
                print("   %-14s EXCEPTION %s" % (name, e))
            print("  %-10s %5d bytes  %4d/%-4d cksum  %3d lines  round-trip: %s"
                  % (name, len(tap), ok, ok + bad, len(txt),
                     "BYTE-EXACT" if same else "DIFFERS"))
            allok &= same and bad == 0
        print("\n%s" % ("ALL FILES ROUND-TRIP BYTE-EXACT" if allok else "FAILURES ABOVE"))
    else:
        print(__doc__)
