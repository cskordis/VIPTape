#!/usr/bin/env python3
"""
sim_encoder.py -- replicate CassetteEncoder's send path in software so PC-1
output timing can be checked against the real capture WITHOUT flashing hardware.

This mirrors the firmware exactly:
  sendLeader()  -> leaderTime x sendBit(leaderBit)
  sendByte(b)   -> when dataBits < 8, one frame per nibble, HIGH NIBBLE FIRST;
                   each frame = start bit + dataBits data bits + stopBits stop
  sendBit(v)    -> bitN_cycle full cycles at bitN/2 us per half
  sendTrailer() -> trailerTime x sendBit(trailerBit)

Run it to compare the emitted frame period and total duration against the
measured values from hi_44100.wav, and to prove the emitted stream decodes back
to the original bytes through pc1_tape.py.
"""

import sys
import wave

import numpy as np

# TRS-80 PC-1 row from CassetteProtocols.cpp
PC1 = dict(
    bit0=500, bit1=250,          # full-cycle periods, us
    bit0_cycle=4, bit1_cycle=8,  # cycles per bit
    leaderBit=1, leaderTime=2457,
    startBit=0, stopBit=1, stopBits=5,
    trailerBit=1, trailerTime=42,
    dataBits=4, lsb_first=True,
)

# Measured from the real capture, for comparison
REAL = dict(
    mark_cycle_us=250.38, space_cycle_us=499.56,
    bit_us=2001.6,
    frame_period_min=19276.0, frame_period_max=21545.0,
    leader_s=4.9186, total_s=6.14,
)


class Enc:
    def __init__(self, p, rate=44100):
        self.p = p
        self.rate = rate
        self.parts = []
        self.bits = 0

    def send_bit(self, v):
        p = self.p
        full = p["bit0"] if v == 0 else p["bit1"]
        cycles = p["bit0_cycle"] if v == 0 else p["bit1_cycle"]
        freq = 1e6 / full
        n = int(round(self.rate * cycles / freq))
        t = np.arange(n) / self.rate
        self.parts.append(0.6 * np.sin(2 * np.pi * freq * t))
        self.bits += 1

    def send_leader(self):
        for _ in range(self.p["leaderTime"]):
            self.send_bit(self.p["leaderBit"])

    def send_frame(self, v, nbits):
        p = self.p
        self.send_bit(p["startBit"])
        rng = range(nbits) if p["lsb_first"] else range(nbits - 1, -1, -1)
        for i in rng:
            self.send_bit((v >> i) & 1)
        for _ in range(p["stopBits"]):
            self.send_bit(p["stopBit"])

    def send_byte(self, b):
        n = self.p["dataBits"] or 8
        if n < 8:
            for sh in range(8 - n, -1, -n):        # high group first
                self.send_frame((b >> sh) & ((1 << n) - 1), n)
        else:
            self.send_frame(b, 8)

    def send_trailer(self):
        for _ in range(self.p["trailerTime"]):
            self.send_bit(self.p["trailerBit"])

    def wav(self, path):
        sig = np.concatenate(self.parts)
        pcm = (np.clip(sig, -1, 1) * 32767).astype("<i2")
        with wave.open(path, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(self.rate)
            w.writeframes(pcm.tobytes())
        return len(sig) / self.rate


def frame_period_us(p):
    cells = 1 + (p["dataBits"] or 8) + p["stopBits"]
    bit_us = p["bit0"] * p["bit0_cycle"]
    return cells * bit_us, cells


def main():
    # The program record recovered from hi_44100.wav
    record = bytes([0xE0, 0x10, 0xC1, 0x12, 0x58, 0x59, 0x12, 0x00, 0x3D, 0xF0])

    print("== emitted frame geometry ==")
    for label, stopbits in (("stopBits=4 (first cut)", 4),
                            ("stopBits=5 (fixed)", 5)):
        p = dict(PC1, stopBits=stopbits)
        us, cells = frame_period_us(p)
        print(f"  {label:24s} {cells:2d} cells = {us/1000:6.3f} ms/frame  "
              f"({us*2/1000:6.3f} ms per BYTE)")
    print(f"  real machine measured      "
          f"{REAL['frame_period_min']/1000:.2f}-{REAL['frame_period_max']/1000:.2f}"
          f" ms/frame")

    print("\n== what the first-cut bug did ==")
    p4 = dict(PC1, stopBits=4)
    us4, _ = frame_period_us(p4)
    print(f"  one 4-bit frame per BYTE -> {us4/1000:.2f} ms per byte of content")
    print(f"  correct: two frames per byte -> "
          f"{frame_period_us(PC1)[0]*2/1000:.2f} ms per byte")
    print(f"  ratio {frame_period_us(PC1)[0]*2/us4:.2f}x too fast, "
          f"and every high nibble dropped")

    print("\n== full send simulation (fixed encoder) ==")
    e = Enc(PC1)
    e.send_leader()
    lead_bits = e.bits
    for b in record:
        e.send_byte(b)
    e.send_trailer()
    dur = e.wav("/tmp/sim_pc1.wav")
    print(f"  leader      : {lead_bits} bit cells = "
          f"{lead_bits*2001.6/1e6:.3f} s   (real {REAL['leader_s']:.3f} s)")
    print(f"  data        : {len(record)} bytes -> {len(record)*2} frames")
    print(f"  total       : {dur:.3f} s")

    # decode it back through the analysis tool
    sys.path.insert(0, ".")
    import pc1_tape as P
    runs, _ = P.pc1_tone_runs("/tmp/sim_pc1.wav")
    frames = P.pc1_decode(runs)
    nib = [int(b[::-1], 2) for _, b in frames]
    got = bytes((nib[i] << 4) | nib[i + 1] for i in range(0, len(nib) - 1, 2))
    print(f"\n== round trip through the decoder ==")
    print(f"  frames decoded : {len(frames)} (expected {len(record)*2})")
    print(f"  bytes out      : {' '.join(f'{v:02X}' for v in got)}")
    print(f"  bytes in       : {' '.join(f'{v:02X}' for v in record)}")
    print(f"  MATCH          : {got == record}")
    chk = sum(nib[:16]) & 0xFF
    print(f"  checksum recomputed over first 16 nibbles: {chk:02X} "
          f"(record carries 3D)")
    print(f"  listing        : {P.pc1_listing(list(record[:8]))}")


if __name__ == "__main__":
    main()
