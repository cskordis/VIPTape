#!/usr/bin/env python3
"""
pc1_tape.py -- offline analysis toolkit for TRS-80 Pocket Computer 1 /
Sharp PC-1211 cassette recordings (and, in general, any 2-tone FSK tape).

Purpose
-------
The PC-1 tape format is only partially documented in public sources.  The
CE-121 service manual confirms the physical layer is FSK with

    logical '1' = 4 kHz     logical '0' = 2 kHz

and that a save is laid out as

    ~6 s of all-'1' leader | file header (program name) | blocks of 8 program
    steps each followed by a checksum | gaps of all-'1' | end code

but it does NOT state the cycles-per-bit, the frame structure, the checksum
algorithm, or the end code.  Those have to be recovered from a real capture.

This tool does that recovery.  It is deliberately assumption-light: nothing
below hard-codes "8 cycles per bit" or "one byte = 8 bits".  Every such value
is measured from the audio and reported, so the firmware constants can be
derived from evidence rather than guesswork.

Subcommands
-----------
  analyze  <wav>     Full report: levels, tone periods, cycles-per-bit,
                     bitstream segmentation, frame-structure search, and a
                     byte dump under the best-scoring hypothesis.
  bits     <wav>     Write the raw demodulated bitstream to a text file.
  frames   <wav>     Frame-structure search only, printed in detail.
  synth    <bin>     Synthesise a PC-1 style WAV from a byte file using the
                     current best-guess parameters (round-trip check).
  tapinfo  <file>    Structural guess + hexdump for an unknown .TAP container.
  compare  <a> <b>   Compare two WAVs cycle-by-cycle (real vs synthesised).

Written for the VIPTAPE PC-1 protocol work.  Pure numpy/stdlib.
"""

from __future__ import annotations

import argparse
import sys
import wave
from collections import Counter
from dataclasses import dataclass, field

import numpy as np

# ---------------------------------------------------------------------------
# Working hypothesis for the PC-1 physical layer.
#
# These are STARTING POINTS for the search, not asserted truth.  analyze()
# measures the real values and prints them; whatever it reports wins.
# ---------------------------------------------------------------------------
F_MARK = 4000.0   # '1' tone, Hz   (service manual: data "1" = 4KHz)
F_SPACE = 2000.0  # '0' tone, Hz   (service manual: data "0" = 2KHz)

# Sharp's later pocket machines use equal-duration bits: 8 cycles of the fast
# tone for a '1', 4 cycles of the slow tone for a '0', giving 2 ms/bit = 500
# bit/s.  Plausible for the PC-1211 but unverified -- measured by analyze().
GUESS_CYCLES_MARK = 8
GUESS_CYCLES_SPACE = 4


# ---------------------------------------------------------------------------
# WAV loading
# ---------------------------------------------------------------------------

def load_wav(path: str) -> tuple[np.ndarray, int]:
    """Return (mono float64 samples in -1..1, sample_rate)."""
    with wave.open(path, "rb") as w:
        nch = w.getnchannels()
        width = w.getsampwidth()
        rate = w.getframerate()
        n = w.getnframes()
        raw = w.readframes(n)

    if width == 1:
        # 8-bit WAV is unsigned
        data = np.frombuffer(raw, dtype=np.uint8).astype(np.float64)
        data = (data - 128.0) / 128.0
    elif width == 2:
        data = np.frombuffer(raw, dtype="<i2").astype(np.float64) / 32768.0
    elif width == 3:
        b = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 3).astype(np.int32)
        v = (b[:, 0] | (b[:, 1] << 8) | (b[:, 2] << 16))
        v = np.where(v & 0x800000, v - 0x1000000, v)
        data = v.astype(np.float64) / 8388608.0
    elif width == 4:
        data = np.frombuffer(raw, dtype="<i4").astype(np.float64) / 2147483648.0
    else:
        raise ValueError(f"unsupported sample width {width}")

    if nch > 1:
        data = data.reshape(-1, nch).mean(axis=1)

    return data, rate


def highpass(x: np.ndarray, rate: int, fc: float = 200.0) -> np.ndarray:
    """Single-pole high-pass to strip DC/rumble without needing scipy."""
    import math
    a = math.exp(-2.0 * math.pi * fc / rate)
    y = np.empty_like(x)
    prev_x = 0.0
    prev_y = 0.0
    # vectorised single-pole HP is awkward; loop is fine for tape-length files
    for i, xi in enumerate(x):
        prev_y = a * (prev_y + xi - prev_x)
        prev_x = xi
        y[i] = prev_y
    return y


# ---------------------------------------------------------------------------
# Edge detection
# ---------------------------------------------------------------------------

@dataclass
class Edges:
    times_us: np.ndarray        # crossing times, microseconds
    rising: np.ndarray          # bool, True if this crossing was low->high
    rate: int
    amplitude: float


def find_edges(x: np.ndarray, rate: int, hyst_frac: float = 0.15) -> Edges:
    """
    Hysteresis comparator around zero, with sub-sample linear interpolation.

    hyst_frac is a fraction of the signal's RMS.  Hysteresis matters: a tape
    capture has enough noise that a bare sign() test produces spurious extra
    crossings near the zero line, which would corrupt every period measurement
    downstream.
    """
    rms = float(np.sqrt(np.mean(x * x))) or 1e-9
    h = hyst_frac * rms * np.sqrt(2)

    times = []
    rising = []
    state = 1 if x[0] > 0 else -1
    prev = x[0]
    for i in range(1, len(x)):
        v = x[i]
        if state <= 0 and v > h:
            # interpolate the true zero crossing between i-1 and i
            if v != prev:
                frac = (0.0 - prev) / (v - prev)
            else:
                frac = 0.0
            times.append((i - 1 + frac) * 1e6 / rate)
            rising.append(True)
            state = 1
        elif state >= 0 and v < -h:
            if v != prev:
                frac = (0.0 - prev) / (v - prev)
            else:
                frac = 0.0
            times.append((i - 1 + frac) * 1e6 / rate)
            rising.append(False)
            state = -1
        prev = v

    return Edges(np.array(times), np.array(rising, dtype=bool), rate,
                 float(np.max(np.abs(x))))


def full_cycles(e: Edges) -> tuple[np.ndarray, np.ndarray]:
    """
    Pair successive rising edges into full cycles.

    Returns (start_time_us, period_us).  Using rising-to-rising (rather than
    pairing half-periods) makes the measurement immune to duty-cycle skew,
    which real tape playback always has.
    """
    r = e.times_us[e.rising]
    if len(r) < 2:
        return np.array([]), np.array([])
    return r[:-1], np.diff(r)


# ---------------------------------------------------------------------------
# Tone classification
# ---------------------------------------------------------------------------

def histogram_report(periods: np.ndarray, label: str, bins: int = 120) -> None:
    if len(periods) == 0:
        print(f"  ({label}: none)")
        return
    lo, hi = np.percentile(periods, [0.5, 99.5])
    if hi <= lo:
        hi = lo + 1
    counts, edges = np.histogram(periods, bins=bins, range=(lo, hi))
    peak = counts.max() or 1
    print(f"  {label}: n={len(periods)}  "
          f"min={periods.min():.1f} p1={lo:.1f} med={np.median(periods):.1f} "
          f"p99={hi:.1f} max={periods.max():.1f} us")
    for c, lo_e, hi_e in zip(counts, edges[:-1], edges[1:]):
        if c == 0:
            continue
        bar = "#" * max(1, int(48 * c / peak))
        print(f"    {lo_e:7.1f}-{hi_e:7.1f} us | {c:7d} {bar}")


def find_tone_split(periods: np.ndarray) -> tuple[float, float, float]:
    """
    Two-means split of the cycle-period distribution.

    Returns (fast_us, slow_us, threshold_us).  Seeded from the two extremes
    rather than from the 4 kHz/2 kHz assumption, so a tape running off-speed
    (or a capture at an odd rate) still resolves correctly.
    """
    p = periods[(periods > np.percentile(periods, 0.5)) &
                (periods < np.percentile(periods, 99.5))]
    if len(p) == 0:
        return 0.0, 0.0, 0.0
    lo, hi = p.min(), p.max()
    c_fast, c_slow = lo, hi
    for _ in range(60):
        mid = 0.5 * (c_fast + c_slow)
        fast = p[p <= mid]
        slow = p[p > mid]
        if len(fast) == 0 or len(slow) == 0:
            break
        nf, ns = fast.mean(), slow.mean()
        if abs(nf - c_fast) < 1e-6 and abs(ns - c_slow) < 1e-6:
            c_fast, c_slow = nf, ns
            break
        c_fast, c_slow = nf, ns
    return float(c_fast), float(c_slow), float(0.5 * (c_fast + c_slow))


# ---------------------------------------------------------------------------
# Runs -> bits
# ---------------------------------------------------------------------------

@dataclass
class Run:
    tone: int          # 1 = fast tone, 0 = slow tone
    count: int         # number of cycles in the run
    t_start: float     # us
    t_end: float       # us


def build_runs(starts: np.ndarray, periods: np.ndarray, thresh: float) -> list[Run]:
    tones = (periods < thresh).astype(int)   # fast tone -> 1
    runs: list[Run] = []
    if len(tones) == 0:
        return runs
    cur = tones[0]
    n = 0
    t0 = starts[0]
    for i, t in enumerate(tones):
        if t == cur:
            n += 1
        else:
            runs.append(Run(int(cur), n, float(t0), float(starts[i])))
            cur = t
            n = 1
            t0 = starts[i]
    runs.append(Run(int(cur), n, float(t0),
                    float(starts[-1] + periods[-1])))
    return runs


def infer_cycles_per_bit(runs: list[Run], skip_leader_cycles: int = 200
                         ) -> tuple[int, int, Counter, Counter]:
    """
    Recover cycles-per-bit for each tone from run-length statistics.

    In an FSK-per-bit scheme every run length is an integer multiple of the
    tone's cycles-per-bit, so the greatest common divisor of the common run
    lengths gives it directly.  Leader runs (enormous) are excluded.
    """
    fast = Counter()
    slow = Counter()
    for r in runs:
        if r.count >= skip_leader_cycles:
            continue
        (fast if r.tone == 1 else slow)[r.count] += 1

    def gcd_of_common(c: Counter) -> int:
        import math
        if not c:
            return 0
        total = sum(c.values())
        # ignore rare lengths (edge artefacts) -- keep those covering 98%
        keep = [k for k, v in c.most_common() if v >= max(1, total * 0.005)]
        g = 0
        for k in keep:
            g = math.gcd(g, k)
        return g

    return gcd_of_common(fast), gcd_of_common(slow), fast, slow


def runs_to_bits(runs: list[Run], cyc_fast: int, cyc_slow: int
                 ) -> tuple[str, list[tuple[int, float]]]:
    """
    Convert runs to a bitstream.  Returns (bitstring, [(bit, t_start_us)]).
    """
    bits: list[str] = []
    stamped: list[tuple[int, float]] = []
    for r in runs:
        per_bit = cyc_fast if r.tone == 1 else cyc_slow
        if per_bit <= 0:
            continue
        n = int(round(r.count / per_bit))
        if n <= 0:
            continue
        dt = (r.t_end - r.t_start) / max(n, 1)
        for i in range(n):
            bits.append("1" if r.tone == 1 else "0")
            stamped.append((r.tone, r.t_start + i * dt))
    return "".join(bits), stamped


# ---------------------------------------------------------------------------
# Frame-structure search
# ---------------------------------------------------------------------------

@dataclass
class FrameHypothesis:
    width: int
    phase: int
    constant_mask: list[int]     # -1 = varies, 0/1 = constant value
    score: float
    n_frames: int
    data_positions: list[int] = field(default_factory=list)


def search_frames(bits: str, min_w: int = 6, max_w: int = 20,
                  max_frames: int = 400, agree: float = 0.97
                  ) -> list[FrameHypothesis]:
    """
    Find the frame width by looking for bit positions that hold the same value
    in (almost) every frame -- i.e. start and stop bits.

    A UART-like frame of width W has at least one such position; data at the
    wrong W has essentially none.  Two refinements matter on real captures:

      * `agree` tolerance -- a single corrupted frame in a tape recording must
        not veto an otherwise perfect hypothesis, so a position counts as
        constant when >= `agree` of frames match the majority value.

      * harmonic suppression -- if width W frames cleanly then so do 2W, 3W...
        Only the smallest genuine width is reported, otherwise the aliases
        crowd out the real answer.
    """
    cands: list[FrameHypothesis] = []
    for w in range(min_w, max_w + 1):
        for phase in range(w):
            body = bits[phase:]
            nf = min(len(body) // w, max_frames)
            if nf < 8:
                continue
            arr = np.frombuffer(body[:nf * w].encode(), dtype=np.uint8) - ord("0")
            arr = arr.reshape(nf, w)
            const = []
            n_const = 0
            for c in range(w):
                col = arr[:, c]
                ones = float(col.mean())
                if ones >= agree:
                    const.append(1)
                    n_const += 1
                elif ones <= 1.0 - agree:
                    const.append(0)
                    n_const += 1
                else:
                    const.append(-1)
            if n_const == 0 or n_const > max(2, w // 2):
                continue
            # framing overhead: real UART framing spends a small, fixed part of
            # the frame on start/stop bits
            score = (1.0 - n_const / w) + min(nf, 200) / 1000.0
            data_pos = [i for i, v in enumerate(const) if v == -1]
            cands.append(FrameHypothesis(w, phase, const, score, nf, data_pos))

    # harmonic suppression: drop any width that is a multiple of a smaller
    # width which also produced a valid hypothesis
    widths = sorted({h.width for h in cands})
    base: list[int] = []
    for w in widths:
        if not any(w % b == 0 for b in base):
            base.append(w)
    out = [h for h in cands if h.width in base]
    out.sort(key=lambda h: (h.width, -h.score))
    return out[:12]


def frames_to_bytes(bits: str, h: FrameHypothesis, lsb_first: bool = True
                    ) -> list[int]:
    body = bits[h.phase:]
    nf = len(body) // h.width
    vals = []
    for f in range(nf):
        frame = body[f * h.width:(f + 1) * h.width]
        d = [frame[i] for i in h.data_positions]
        if lsb_first:
            d = d[::-1]
        vals.append(int("".join(d), 2) if d else 0)
    return vals


# ---------------------------------------------------------------------------
# Reporting helpers
# ---------------------------------------------------------------------------

def hexdump(data: bytes, base: int = 0, limit: int | None = None) -> None:
    n = len(data) if limit is None else min(len(data), limit)
    for off in range(0, n, 16):
        chunk = data[off:off + 16]
        hexs = " ".join(f"{b:02X}" for b in chunk)
        text = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        print(f"  {base + off:06X}  {hexs:<47}  |{text}|")
    if limit is not None and len(data) > limit:
        print(f"  ... {len(data) - limit} more bytes")


def nibble_string(data: list[int]) -> str:
    return "".join(f"{v:X}" for v in data)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_analyze(args) -> None:
    print(f"== {args.wav}")
    x, rate = load_wav(args.wav)
    dur = len(x) / rate
    print(f"  sample rate : {rate} Hz")
    print(f"  duration    : {dur:.2f} s  ({len(x)} samples)")
    print(f"  peak level  : {np.max(np.abs(x)):.3f}   rms {np.sqrt(np.mean(x*x)):.4f}")
    dc = float(np.mean(x))
    print(f"  dc offset   : {dc:+.5f}")

    if args.highpass:
        print("  applying 200 Hz high-pass")
        x = highpass(x, rate)

    e = find_edges(x, rate, hyst_frac=args.hysteresis)
    print(f"  edges       : {len(e.times_us)}")
    starts, periods = full_cycles(e)
    print(f"  full cycles : {len(periods)}")
    if len(periods) == 0:
        print("  !! no cycles found -- check levels/hysteresis")
        return

    print("\n-- cycle period distribution --")
    histogram_report(periods, "rising-to-rising")

    fast, slow, thresh = find_tone_split(periods)
    print(f"\n  fast tone : {fast:8.2f} us  = {1e6/fast:8.1f} Hz")
    print(f"  slow tone : {slow:8.2f} us  = {1e6/slow:8.1f} Hz")
    print(f"  threshold : {thresh:8.2f} us")
    print(f"  ratio     : {slow/fast:8.3f}   (2.000 expected for 2k/4k FSK)")

    runs = build_runs(starts, periods, thresh)
    print(f"\n-- runs: {len(runs)} --")
    print("  first 24 runs (tone x count):")
    print("   ", " ".join(f"{r.tone}x{r.count}" for r in runs[:24]))

    big = [r for r in runs if r.count >= 200]
    print(f"\n  long runs (>=200 cycles, i.e. leader/gaps): {len(big)}")
    for r in big[:12]:
        print(f"    tone {r.tone}  {r.count:6d} cycles  "
              f"{r.t_start/1e6:8.3f}s .. {r.t_end/1e6:8.3f}s "
              f"({(r.t_end-r.t_start)/1e6:.3f}s)")

    cf, cs, fastc, slowc = infer_cycles_per_bit(runs)
    print(f"\n-- cycles per bit (gcd of run lengths, leader excluded) --")
    print(f"  fast tone ('1') : {cf}")
    print(f"  slow tone ('0') : {cs}")
    print(f"  fast run lengths: {dict(sorted(fastc.most_common(10)))}")
    print(f"  slow run lengths: {dict(sorted(slowc.most_common(10)))}")
    if cf and cs:
        t1 = cf * fast
        t0 = cs * slow
        print(f"  bit duration    : '1' {t1:.1f} us   '0' {t0:.1f} us")
        if abs(t1 - t0) < 0.1 * max(t1, t0):
            print(f"  -> equal-duration bits, {1e6/t1:.1f} bit/s")
        else:
            print("  -> UNEQUAL bit durations (variable bit rate)")

    cf = args.cycles_mark or cf or GUESS_CYCLES_MARK
    cs = args.cycles_space or cs or GUESS_CYCLES_SPACE
    bits, _ = runs_to_bits(runs, cf, cs)
    print(f"\n-- bitstream: {len(bits)} bits (using {cf}/{cs} cycles per bit) --")

    # Locate the end of the leader: the last long run of 1s near the start.
    lead_end = 0
    m = 0
    for i, ch in enumerate(bits):
        if ch == "1":
            m += 1
        else:
            if m >= 100:
                lead_end = i
                break
            m = 0
    print(f"  leader appears to end at bit {lead_end} "
          f"({lead_end} leading '1' bits)")
    body = bits[lead_end:]
    # Trim the trailing all-'1' run (tape trailer).  Left in place it pollutes
    # the frame-constancy statistics -- every trailer frame reads as all ones,
    # which makes a genuine start bit look non-constant.
    trail = len(body)
    while trail > 0 and body[trail - 1] == "1":
        trail -= 1
    if len(body) - trail >= 20:
        print(f"  trailing all-'1' run of {len(body) - trail} bits trimmed")
        body = body[:trail + 1]
    print(f"  post-leader bits: {len(body)}")
    print("  first 240 post-leader bits:")
    for i in range(0, min(240, len(body)), 60):
        print(f"    {i:5d}  {body[i:i+60]}")

    print("\n-- frame structure search --")
    hyps = search_frames(body)
    if not hyps:
        print("  no consistent frame width found "
              "(format may be block/checksum oriented rather than UART-framed)")
    for h in hyps[:6]:
        mask = "".join("." if v < 0 else str(v) for v in h.constant_mask)
        print(f"  width {h.width:2d} phase {h.phase:2d}  frames {h.n_frames:4d}  "
              f"score {h.score:5.2f}  mask {mask}  data bits {len(h.data_positions)}")

    if hyps:
        h = hyps[0]
        for lsb in (True, False):
            vals = frames_to_bytes(body, h, lsb_first=lsb)
            order = "LSB-first" if lsb else "MSB-first"
            print(f"\n-- decode under best hypothesis, {order} "
                  f"({len(h.data_positions)} data bits/frame) --")
            if len(h.data_positions) <= 4:
                print("  nibbles:", nibble_string(vals[:160]))
            else:
                hexdump(bytes(v & 0xFF for v in vals), limit=args.dump)

    if args.save_bits:
        with open(args.save_bits, "w") as f:
            f.write(bits + "\n")
        print(f"\n  bitstream written to {args.save_bits}")


def cmd_bits(args) -> None:
    x, rate = load_wav(args.wav)
    if args.highpass:
        x = highpass(x, rate)
    e = find_edges(x, rate, hyst_frac=args.hysteresis)
    starts, periods = full_cycles(e)
    _, _, thresh = find_tone_split(periods)
    runs = build_runs(starts, periods, thresh)
    cf, cs, _, _ = infer_cycles_per_bit(runs)
    cf = args.cycles_mark or cf or GUESS_CYCLES_MARK
    cs = args.cycles_space or cs or GUESS_CYCLES_SPACE
    bits, _ = runs_to_bits(runs, cf, cs)
    out = args.out or (args.wav + ".bits")
    with open(out, "w") as f:
        f.write(bits + "\n")
    print(f"{len(bits)} bits -> {out}  (cycles/bit {cf}/{cs})")


def cmd_frames(args) -> None:
    bits = open(args.bits).read().strip()
    lead = 0
    m = 0
    for i, ch in enumerate(bits):
        if ch == "1":
            m += 1
        else:
            if m >= 100:
                lead = i
                break
            m = 0
    body = bits[lead:]
    for h in search_frames(body, args.min_width, args.max_width):
        mask = "".join("." if v < 0 else str(v) for v in h.constant_mask)
        print(f"width {h.width:2d} phase {h.phase:2d} frames {h.n_frames:4d} "
              f"score {h.score:5.2f} mask {mask}")


def synth_wav(data: bytes, path: str, rate: int = 44100,
              cyc_mark: int = GUESS_CYCLES_MARK,
              cyc_space: int = GUESS_CYCLES_SPACE,
              leader_s: float = 6.0,
              frame: str = "raw",
              amplitude: float = 0.6) -> None:
    """
    Synthesise a PC-1 style FSK waveform.  `frame` selects bit framing:
      raw  : 8 data bits per byte, LSB first, no start/stop
      uart : start bit 0, 8 data LSB first, 1 stop bit 1
    """
    import math

    def tone(freq: float, cycles: int) -> np.ndarray:
        n = int(round(rate * cycles / freq))
        t = np.arange(n) / rate
        return amplitude * np.sin(2 * math.pi * freq * t)

    one = tone(F_MARK, cyc_mark)
    zero = tone(F_SPACE, cyc_space)

    parts = [np.tile(one, int(leader_s * F_MARK / cyc_mark))]
    for b in data:
        seq = []
        if frame == "uart":
            seq.append(0)
        for i in range(8):
            seq.append((b >> i) & 1)
        if frame == "uart":
            seq.append(1)
        for bit in seq:
            parts.append(one if bit else zero)
    parts.append(np.tile(one, int(0.5 * F_MARK / cyc_mark)))

    sig = np.concatenate(parts)
    pcm = np.clip(sig, -1, 1)
    pcm = (pcm * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.tobytes())
    print(f"wrote {path}: {len(sig)/rate:.2f}s, {len(data)} bytes, "
          f"frame={frame}, cycles {cyc_mark}/{cyc_space}")


def cmd_synth(args) -> None:
    data = open(args.binfile, "rb").read()
    synth_wav(data, args.out, rate=args.rate,
              cyc_mark=args.cycles_mark or GUESS_CYCLES_MARK,
              cyc_space=args.cycles_space or GUESS_CYCLES_SPACE,
              leader_s=args.leader, frame=args.frame)


# ---------------------------------------------------------------------------
# PC-1 specific decoder, derived from the hi_44100 / hi_22050 captures
# ---------------------------------------------------------------------------
#
# Physical layer (measured):
#   '0' (space) = 4 full cycles of 2 kHz   (499.6 us/cycle)  = 2001.6 us
#   '1' (mark)  = 8 full cycles of 4 kHz   (250.4 us/cycle)  = 2001.6 us
#   -> equal-duration bit cells, 499.6 bit/s
#
# Framing (measured): start bit '0', FOUR data bits, then mark.  Four data bits,
# not eight -- the PC-1211's CPU is a 4-bit part and the tape carries one nibble
# per frame.  Two independent facts pin this down:
#   * the longest run of space tone anywhere in either capture is exactly 5 bit
#     cells = start bit + four zero data bits.  A byte-wide frame would show
#     runs of up to 9.
#   * sampling 8 bits past every start bit gives xxxx1111 in all 41 frames of
#     both captures -- data bits 5..8 are mark in every single frame.
#
# After the four stop/idle mark bits each frame carries a further ~1.25-1.55 ms
# of mark before the next start bit, and the frame-to-frame period wanders
# between 19.3 and 21.5 ms.  That jitter is why this decoder re-synchronises on
# every start bit rather than free-running on a bit clock.

PC1_BIT_US = 2001.6
PC1_SPACE_CYCLE_US = 499.6    # 2 kHz
PC1_MARK_CYCLE_US = 250.4     # 4 kHz
PC1_DATA_BITS = 4


def pc1_tone_runs(path: str, hyst: float = 0.15):
    """Half-cycle run segmentation: [(tone, t_start_us, t_end_us), ...].

    Runs are built from HALF-cycles, not full cycles.  Tone changes on this
    format land on half-cycle boundaries, so full-cycle pairing reports run
    lengths that alternate by one cycle and the structure never resolves.
    """
    x, rate = load_wav(path)
    e = find_edges(x, rate, hyst_frac=hyst)
    t = e.times_us
    half = np.diff(t)
    thresh = 0.5 * (PC1_MARK_CYCLE_US + PC1_SPACE_CYCLE_US) / 2
    cls = (half < thresh).astype(int)      # 1 = mark (4 kHz)

    runs = []
    cur = cls[0]
    st = t[0]
    for i, c in enumerate(cls):
        if c != cur:
            runs.append((int(cur), float(st), float(t[i])))
            cur = c
            st = t[i]
    runs.append((int(cur), float(st), float(t[len(cls)])))
    return runs, rate


def pc1_decode(runs) -> list[tuple[float, str]]:
    """Return [(t_start_us, '0101'), ...] -- one entry per frame."""
    def tone_at(tt: float) -> int:
        for tone, a, b in runs:
            if a <= tt < b:
                return tone
        return 1

    frames = []
    pos = -1e18
    for tone, a, b in runs:
        if tone != 0 or a < pos:
            continue
        if (b - a) < 0.5 * PC1_BIT_US:      # too short to be a start bit
            continue
        bits = "".join(str(tone_at(a + (k + 0.5) * PC1_BIT_US))
                       for k in range(1, PC1_DATA_BITS + 1))
        frames.append((a, bits))
        pos = a + (PC1_DATA_BITS + 0.6) * PC1_BIT_US
    return frames


# ---- record / byte layer --------------------------------------------------
#
# Confirmed against the hi_*.wav captures:
#   * bit order within the frame is LSB-first (standard UART order)
#   * the first nibble of a byte is the HIGH nibble
#   * a record ends with a 2-nibble checksum = 8-bit sum of the record's data
#     nibbles, immediately followed by the end code
#   * characters are ASCII + 0x10 for A-Z and 0-9 ("Sharp code minus sixteen"
#     converts to ASCII, per the PC-1251 internal code table -- the PC-1211
#     captures agree exactly)
#
# Tokens observed so far.  Only entries actually seen on tape are listed: a
# guessed token is what makes the target machine hang, so the detokeniser must
# fail loudly on an unknown code rather than invent a keyword.
PC1_TOKENS = {
    0xC1: "PRINT",
}
PC1_QUOTE = 0x12
PC1_EOL = 0x00
PC1_END = 0xF0


def pc1_char(code: int) -> str:
    """Sharp internal code -> ASCII, for the ranges where the mapping holds."""
    if 0x40 <= code <= 0x49 or 0x51 <= code <= 0x6A:
        return chr(code - 0x10)
    return f"<{code:02X}>"


def pc1_records(nibbles: list[int]) -> list[dict]:
    """
    Split a nibble stream into records by locating the checksum.

    The checksum is the only reliable delimiter -- record lengths vary and the
    end code (0xF0) can also occur as data -- so this scans for a position
    where the two nibbles equal the running sum of everything before them.
    """
    n = len(nibbles)
    # Scan from the END: the real checksum is the last consistent one, leaving
    # only the end code trailing.  A forward scan latches onto trivial early
    # matches inside the header's run of zero nibbles (sum 0 == checksum 00).
    for cs in range(n - 2, 1, -1):
        for marker_nibs in (0, 2):
            start = marker_nibs
            if cs - start < 4 or (cs - start) % 2:
                continue
            total = sum(nibbles[start:cs]) & 0xFF
            if ((nibbles[cs] << 4) | nibbles[cs + 1]) != total:
                continue
            data = nibbles[start:cs]
            return [{
                "marker": nibbles[:marker_nibs],
                "data": [(data[i] << 4) | data[i + 1]
                         for i in range(0, len(data), 2)],
                "checksum": total,
                "trailing": nibbles[cs + 2:],
            }]
    return []


def pc1_listing(data: list[int]) -> str:
    """Render a decoded data record as BASIC source, or flag what is unknown."""
    if not data:
        return ""
    parts = []
    i = 0
    if data[0] == 0xE0:      # record-type byte on the program record
        i = 1
    if i >= len(data):
        return ""
    # line number is BCD
    parts.append(f"{data[i] >> 4}{data[i] & 0xF}".lstrip("0") or "0")
    i += 1
    in_str = False
    while i < len(data):
        b = data[i]
        if b == PC1_QUOTE:
            parts.append('"')
            in_str = not in_str
        elif in_str:
            parts.append(pc1_char(b))
        elif b == PC1_EOL:
            pass
        elif b in PC1_TOKENS:
            parts.append(" " + PC1_TOKENS[b] + " ")
        else:
            parts.append(f"<{b:02X}?>")
        i += 1
    return "".join(parts)


def cmd_pc1(args) -> None:
    runs, rate = pc1_tone_runs(args.wav, hyst=args.hysteresis)
    print(f"== {args.wav}  ({rate} Hz)")

    leaders = [(t, a, b) for t, a, b in runs if t == 1 and (b - a) > 50000]
    print("\n-- leaders / gaps (mark tone > 50 ms) --")
    for t, a, b in leaders:
        print(f"  {a/1000:9.2f} .. {b/1000:9.2f} ms  "
              f"{(b-a)/1000:8.2f} ms = {(b-a)/PC1_BIT_US:8.2f} bit cells")

    frames = pc1_decode(runs)
    print(f"\n-- {len(frames)} frames --")

    # split into sections on any gap much longer than a frame period
    sections: list[list[tuple[float, str]]] = []
    cur: list[tuple[float, str]] = []
    prev = None
    for a, bits in frames:
        if prev is not None and a - prev > 60000:
            sections.append(cur)
            cur = []
        cur.append((a, bits))
        prev = a
    sections.append(cur)

    for si, sec in enumerate(sections):
        msb = "".join(f"{int(b, 2):X}" for _, b in sec)
        lsb = "".join(f"{int(b[::-1], 2):X}" for _, b in sec)
        print(f"\n  section {si}: {len(sec)} nibbles "
              f"({sec[0][0]/1000:.1f} .. {sec[-1][0]/1000:.1f} ms)")
        print(f"    nibbles, MSB-first in frame : {msb}")
        print(f"    nibbles, LSB-first in frame : {lsb}")
        nib = [int(b[::-1], 2) for _, b in sec]        # LSB-first in frame
        recs = pc1_records(nib)
        if not recs:
            print("    !! no checksum-consistent record found")
            continue
        for r in recs:
            mk = "".join(f"{v:X}" for v in r["marker"])
            tr = "".join(f"{v:X}" for v in r["trailing"])
            print(f"    marker   : {mk or '(none)'}")
            print(f"    data     : "
                  + " ".join(f"{v:02X}" for v in r["data"]))
            print(f"    checksum : {r['checksum']:02X}  VERIFIED "
                  f"(8-bit sum of the {len(r['data'])*2} data nibbles)")
            print(f"    trailing : {tr or '(none)'}"
                  + ("   <- F0 = end code" if tr.startswith("F0") else ""))
            listing = pc1_listing(r["data"])
            if listing:
                print(f"    listing  : {listing}")

    if args.frames:
        print("\n-- per-frame detail --")
        prev = None
        for a, bits in frames:
            gap = "" if prev is None else f"{a-prev:9.1f}us"
            print(f"  t={a/1000:9.2f}ms  gap={gap:>11}  data={bits}  "
                  f"msb={int(bits,2):X} lsb={int(bits[::-1],2):X}")
            prev = a


def cmd_tapinfo(args) -> None:
    data = open(args.path, "rb").read()
    print(f"== {args.path}: {len(data)} bytes")
    print("\n-- head --")
    hexdump(data, limit=256)
    print("\n-- tail --")
    tail = data[-128:]
    hexdump(tail, base=len(data) - len(tail))

    printable = sum(1 for b in data if 32 <= b < 127 or b in (9, 10, 13))
    print(f"\n  printable ratio : {printable/len(data):.3f}")
    counts = Counter(data)
    print(f"  distinct bytes  : {len(counts)}")
    print(f"  most common     : "
          f"{[(f'{b:02X}', n) for b, n in counts.most_common(8)]}")
    for magic in (b"TAPEFILE", b"POCKET", b"PC-12", b"COMX", b"SHARP"):
        i = data.find(magic)
        if i >= 0:
            print(f"  magic {magic!r} at offset {i}")
    hi = sum(1 for b in data if b >= 0x80)
    print(f"  high-bit bytes  : {hi} ({hi/len(data):.3f})")


def cmd_compare(args) -> None:
    for path in (args.a, args.b):
        x, rate = load_wav(path)
        e = find_edges(x, rate)
        starts, periods = full_cycles(e)
        fast, slow, thresh = find_tone_split(periods)
        runs = build_runs(starts, periods, thresh)
        cf, cs, _, _ = infer_cycles_per_bit(runs)
        bits, _ = runs_to_bits(runs, cf or 1, cs or 1)
        print(f"{path}: {len(x)/rate:.2f}s fast={fast:.1f}us slow={slow:.1f}us "
              f"cyc={cf}/{cs} bits={len(bits)}")


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp):
        sp.add_argument("--hysteresis", type=float, default=0.15,
                        help="comparator hysteresis as a fraction of RMS")
        sp.add_argument("--highpass", action="store_true",
                        help="apply a 200 Hz high-pass first")
        sp.add_argument("--cycles-mark", type=int, default=0,
                        help="override cycles per '1' bit")
        sp.add_argument("--cycles-space", type=int, default=0,
                        help="override cycles per '0' bit")

    a = sub.add_parser("analyze")
    a.add_argument("wav")
    a.add_argument("--dump", type=int, default=512)
    a.add_argument("--save-bits")
    common(a)
    a.set_defaults(func=cmd_analyze)

    b = sub.add_parser("bits")
    b.add_argument("wav")
    b.add_argument("--out")
    common(b)
    b.set_defaults(func=cmd_bits)

    f = sub.add_parser("frames")
    f.add_argument("bits")
    f.add_argument("--min-width", type=int, default=6)
    f.add_argument("--max-width", type=int, default=20)
    f.set_defaults(func=cmd_frames)

    s = sub.add_parser("synth")
    s.add_argument("binfile")
    s.add_argument("out")
    s.add_argument("--rate", type=int, default=44100)
    s.add_argument("--leader", type=float, default=6.0)
    s.add_argument("--frame", choices=["raw", "uart"], default="raw")
    s.add_argument("--cycles-mark", type=int, default=0)
    s.add_argument("--cycles-space", type=int, default=0)
    s.set_defaults(func=cmd_synth)

    q = sub.add_parser("pc1", help="decode using the derived PC-1 format")
    q.add_argument("wav")
    q.add_argument("--frames", action="store_true",
                   help="print per-frame timing detail")
    q.add_argument("--hysteresis", type=float, default=0.15)
    q.set_defaults(func=cmd_pc1)

    t = sub.add_parser("tapinfo")
    t.add_argument("path")
    t.set_defaults(func=cmd_tapinfo)

    c = sub.add_parser("compare")
    c.add_argument("a")
    c.add_argument("b")
    c.set_defaults(func=cmd_compare)

    args = p.parse_args()
    return args.func(args) or 0


if __name__ == "__main__":
    sys.exit(main())
