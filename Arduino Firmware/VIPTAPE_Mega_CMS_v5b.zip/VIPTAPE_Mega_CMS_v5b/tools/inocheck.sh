#!/bin/sh
# Compile-check the .ino without the Arduino IDE.  Stubs the libraries and
# regenerates the forward declarations the IDE normally inserts for you.
#
# TWO STAGES, and the second exists because the first is not enough:
#   1. host g++ syntax check of EVERY module -- catches scope/typo/signature
#      errors inside a file.
#   2. a real avr-g++ build WITH LINK-TIME OPTIMISATION -- catches what a
#      per-file syntax check structurally cannot: two files that disagree
#      about a type.  The Arduino IDE reports those as a wall of
#          note: type 'uint8_t' should match type 'uint16_t'
#      coming out of stdint.h, which points nowhere near the cause.  That is
#      how a duplicated `struct TokMap` in Pc1Basic.cpp and Pc2Basic.cpp got
#      all the way to the user's build.
set -e
SRC=${1:-/root/work/save4/VIPTAPE_Mega_CMS_v4c}
cd /root/work/inochk
cp "$SRC"/*.h "$SRC"/*.cpp . 2>/dev/null || true
cp "$SRC"/VIPTAPE_Mega_CMS_v4c.ino main.cpp
python3 - <<'PY'
import re
src=open('main.cpp').read()
pat=re.compile(r'^([A-Za-z_][\w:<>,\s\*&]*?)\s+([A-Za-z_]\w*)\s*\(([^;{)]*)\)\s*\{', re.M)
p=[]
for m in pat.finditer(src):
    r,n,a=m.group(1).strip(),m.group(2),m.group(3)
    if n in ('if','for','while','switch','else','return','do','catch'): continue
    if '::' in r or r.endswith('='): continue
    p.append("%s %s(%s);"%(r,n,a))
last=src.rfind('#include'); eol=src.index('\n',last)
open('main2.cpp','w').write(src[:eol+1]+"\n"+"\n".join(sorted(set(p)))+"\n"+src[eol+1:])
PY

MODULES="CassetteDecoder CassetteEncoder CassetteProtocols Pc1Basic Pc2Basic \
         ComxBasic Display FileAnalyzer FileLoader OraoReceive RamExternal \
         TinyBasConvert"

# ---- stage 1: host syntax check, every module ----------------------------
g++ -fsyntax-only -I. -std=gnu++11 -fpermissive -w main2.cpp
for f in $MODULES; do
  [ -f "$f.cpp" ] || continue
  g++ -fsyntax-only -I. -std=gnu++11 -fpermissive -w $f.cpp
done

# ---- stage 2: real AVR build with LTO, then link -------------------------
rm -rf lto && mkdir -p lto
AVRF="-mmcu=atmega2560 -Os -std=gnu++11 -fpermissive -w -flto -I."
for f in main2 $MODULES defs; do
  [ -f "$f.cpp" ] || continue
  avr-g++ $AVRF -c $f.cpp -o lto/$f.o
done
echo 'int main(){return 0;}' > lto/_main.cpp
avr-g++ $AVRF -c lto/_main.cpp -o lto/_main.o
avr-g++ -mmcu=atmega2560 -Os -flto -Wlto-type-mismatch -Wodr \
        -o lto/out.elf lto/*.o 2> lto/link.log || { cat lto/link.log; exit 1; }
if grep -qE 'warning|note' lto/link.log; then
  echo "LTO WARNINGS -- these are what the Arduino IDE will show:"
  cat lto/link.log
  exit 1
fi
avr-size lto/out.elf | tail -1
echo "ALL SOURCES COMPILE AND LINK CLEAN (host syntax + avr-gcc LTO)"
