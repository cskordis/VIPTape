#!/usr/bin/env python3
"""
pc2_wavgen.py -- render a PC-2 .TAP into a WAV using EXACTLY the rules the
VIPTAPE firmware emits, so an independent decoder (PocketTools wav2bin) can
judge our transmission rather than our own decoder judging it.

Mirrors SendData()'s isPc2 branch and CassetteEncoder::sendBitCycles:
  silence 870 ms
  leader        leaderTime(2456) mark cells
  ident         one frame carrying nibble 0xA
  each byte     LOW nibble frame, then HIGH nibble frame
  frame         start bit (1 space cell) + 4 data bits + 6 mark cells
                (sendByte emits 0xF0|nibble = start + 8 data LSB-first,
                 the top 4 of which are ones, then 2 extra mark cells)
  after byte 42 interim sync, 75 mark cells
  trailer       trailerTime(42) mark cells
  mark  = 8 cycles of 400 us   (half 200 us)
  space = 4 cycles of 780 us   (half 390 us)
  POLARITY_NEGATIVE: first half of every cycle is BELOW DC (bitMirroring)
"""
import sys, struct, array

RATE   = 44100
MARK_P, MARK_C = 400e-6, 8
SPC_P,  SPC_C  = 800e-6, 4   # 1250 Hz: 4 x 800us = 8 x 400us = 3.200 ms
LEADER, TRAILER, INTERIM, HEADER_LEN = 2456, 42, 75, 42
AMP = 12000

def cycles(w, period, n, invert):
    half = period / 2.0
    for _ in range(n):
        a = -AMP if invert else AMP
        for h in (a, -a):
            for _ in range(int(round(half * RATE))):
                w.append(h)

def cell(w, bit, invert):
    if bit: cycles(w, MARK_P, MARK_C, invert)
    else:   cycles(w, SPC_P,  SPC_C,  invert)

def frame(w, nib, invert):
    cell(w, 0, invert)                       # start bit
    v = 0xF0 | (nib & 0x0F)
    for i in range(8):                       # 8 data bits, LSB first
        cell(w, (v >> i) & 1, invert)
    for _ in range(2):                       # PC2_EXTRA_STOP_CELLS
        cell(w, 1, invert)

def build(tap, invert=True):
    w = array.array('h')
    w.extend([0] * int(0.870 * RATE))        # sendSilence(870)
    for _ in range(LEADER):  cell(w, 1, invert)
    frame(w, 0x0A, invert)                   # lone file-type nibble
    for i, b in enumerate(tap):
        frame(w, b & 0x0F, invert)
        frame(w, b >> 4,   invert)
        if i + 1 == HEADER_LEN and len(tap) > HEADER_LEN:
            for _ in range(INTERIM): cell(w, 1, invert)
    for _ in range(TRAILER): cell(w, 1, invert)
    return w

def write(path, w):
    d = w.tobytes()
    with open(path, 'wb') as f:
        f.write(b'RIFF' + struct.pack('<I', 36 + len(d)) + b'WAVEfmt ')
        f.write(struct.pack('<IHHIIHH', 16, 1, 1, RATE, RATE * 2, 2, 16))
        f.write(b'data' + struct.pack('<I', len(d)) + d)

if __name__ == '__main__':
    tap = open(sys.argv[1], 'rb').read()
    inv = (len(sys.argv) < 4) or sys.argv[3] != 'noinv'
    w = build(tap, inv)
    write(sys.argv[2], w)
    sys.stderr.write("%s: %d tape bytes -> %s, %.2f s, invert=%s\n"
                     % (sys.argv[1], len(tap), sys.argv[2], len(w) / RATE, inv))
