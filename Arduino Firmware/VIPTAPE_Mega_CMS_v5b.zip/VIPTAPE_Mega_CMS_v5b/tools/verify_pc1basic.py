"""Port of Pc1Basic::writeListing, run against the real files to prove the
firmware detokeniser produces the same listing as the validated Python tool."""
CHARS={0x11:" ",0x12:'"',0x13:"?",0x14:"!",0x18:"$",0x19:"PI",0x1A:"SQR",
       0x1B:",",0x1C:";",0x1D:":",0x30:"(",0x31:")",0x32:"<",0x33:">",
       0x34:"=",0x35:"+",0x36:"-",0x37:"*",0x4A:".",0x4B:"E"}
TOKENS={0xC1:"PRINT ",0xC2:"INPUT ",0xD0:"IF ",0x92:"THEN ",0xD2:"LET ",
        0xD7:"GOTO ",0xD8:"GOSUB ",0xDA:"PAUSE ",0xDE:"RETURN",0xA0:"SIN",
        0xA9:"INT",0x83:"<="}
def listing(tap):
    if len(tap)<12 or tap[0]!=0x80: return [],0
    out=[];cur="";inl=False;pend=0;marker=0;unk=0;bi=0
    for i in range(10,len(tap)):
        if bi%9==8: bi+=1; continue
        bi+=1
        b=tap[i]
        if pend:
            cur="%d "%((marker&0x0F)*100+(b>>4)*10+(b&0x0F)); pend=0; inl=True; continue
        if 0xE0<=b<=0xEF:
            if inl: out.append(cur)
            marker=b; pend=1; inl=False; continue
        if b==0xF0: break
        if not inl: continue
        if b==0x00: out.append(cur); cur=""; inl=False; continue
        if b in TOKENS: cur+=TOKENS[b]
        elif b in CHARS: cur+=CHARS[b]
        elif 0x40<=b<=0x6A: cur+=chr(b-0x10)
        else: cur+="{%02X}"%b; unk+=1
    if inl: out.append(cur)
    return out,unk
if __name__=="__main__":
    for f in ("BLAKJAK.tap","HI.TAP"):
        tap=open("/root/work/package/"+f,"rb").read()
        L,u=listing(tap)
        print("%-12s %2d lines, %d unknown bytes"%(f,len(L),u))
        for l in L[:3]: print("   ",l)
        print()
