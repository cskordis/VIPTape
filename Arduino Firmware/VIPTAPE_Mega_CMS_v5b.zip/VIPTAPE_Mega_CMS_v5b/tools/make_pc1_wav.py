#!/usr/bin/env python3
"""
make_pc1_wav.py -- build a COMPLETE, structurally correct PC-1 tape from a
BASIC line, and verify it against the real capture.

Why this exists
---------------
"Too quick" has several possible causes and they need separating:

  1. the firmware emits the wrong bit timing          -> tones/period wrong
  2. the firmware emits the right timing but too few frames  -> content short
  3. the firmware never emits the header record + inter-record gap at all
  4. the wrong protocol is selected on the device
  5. the file being sent is much shorter than expected

This generates a reference tape with EVERY part present and correct, timed
from the measured capture.  Play it into the PC-1 and CLOAD it:

  * if it loads, the format is proven and the problem is on the VIPTAPE side,
    which narrows it to the firmware send path
  * if it does not load, the format understanding is wrong and no amount of
    firmware work will help

It also prints a full time budget, so "too quick" becomes a number you can
compare against whatever VIPTAPE actually produces.
"""

import argparse
import wave

import numpy as np

# ---- measured from hi_44100.wav / hi_22050.wav ----------------------------
MARK_HZ = 4000.0          # '1'  measured 3994 Hz
SPACE_HZ = 2000.0         # '0'  measured 2002 Hz
MARK_CYCLES = 8           # cycles per '1' bit
SPACE_CYCLES = 4          # cycles per '0' bit
BIT_US = 2001.6           # both cells; 499.6 bit/s

LEADER_BITS = 2457        # 4.92 s
GAP_BITS = 130            # 0.26 s of mark between the two records
TRAILER_BITS = 42         # 0.08 s
STOP_BITS = 0             # the stop is NOT a full bit cell -- see STOP_CYCLES
# MEASURED: the stop element is ~6 cycles of the 4 kHz mark tone (1.50 ms), not
# a full 2.00 ms bit cell.  Emitting a full cell makes every mark run 2-3 cycles
# too long -- the only structural difference between a generated tape and the
# real one, and enough to stop the PC-1 accepting it.
STOP_CYCLES = 6
DATA_BITS = 8             # ordinary UART frame; payload is the LOW nibble only,
                          # high nibble padded with ones -> every byte is 0xF0|n

QUOTE = 0x12
EOL = 0x00
END = 0xF0
PROG_MARKER = 0xE0
HDR_MARKER = 0x80
TOKENS = {"PRINT": 0xC1}


def ch(c: str) -> int:
    """ASCII -> Sharp internal code (ASCII + 0x10 for A-Z and 0-9)."""
    o = ord(c.upper())
    if 0x30 <= o <= 0x39 or 0x41 <= o <= 0x5A:
        return o + 0x10
    raise ValueError(f"no confirmed Sharp code for {c!r}")


def build_program_record(lineno: int, keyword: str, string: str) -> list[int]:
    """`<lineno> PRINT "<string>"` as the on-tape data record."""
    if lineno > 99:
        raise ValueError("line numbers above 99 need the 2-byte BCD form, "
                         "which this capture does not demonstrate")
    body = [PROG_MARKER,
            ((lineno // 10) << 4) | (lineno % 10),   # BCD
            TOKENS[keyword],
            QUOTE] + [ch(c) for c in string] + [QUOTE, EOL]
    return body


def with_checksum(data: list[int]) -> list[int]:
    """Append the 2-nibble checksum: 8-bit sum of the record's data nibbles."""
    nib = []
    for b in data:
        nib += [b >> 4, b & 0xF]
    return data + [sum(nib) & 0xFF]


class Tape:
    def __init__(self, rate=44100, amp=0.6):
        self.rate = rate
        self.amp = amp
        self.parts = []
        self.log = []

    def _tone(self, freq, cycles):
        n = int(round(self.rate * cycles / freq))
        t = np.arange(n) / self.rate
        return self.amp * np.sin(2 * np.pi * freq * t)

    def bit(self, v):
        self.parts.append(self._tone(MARK_HZ, MARK_CYCLES) if v
                          else self._tone(SPACE_HZ, SPACE_CYCLES))

    def stop(self):
        """The short inter-frame mark burst: 6 cycles of 4 kHz, not a full bit."""
        self.parts.append(self._tone(MARK_HZ, STOP_CYCLES))

    def mark_run(self, n, label):
        for _ in range(n):
            self.bit(1)
        self.log.append((label, n * BIT_US / 1e6))

    def frame(self, nib):
        """One UART frame carrying a nibble as 0xF0 | nib."""
        v = 0xF0 | (nib & 0x0F)
        self.bit(0)                                  # start
        for i in range(DATA_BITS):                   # 8 data bits, LSB-first
            self.bit((v >> i) & 1)
        self.stop()                                  # short mark burst

    def record(self, data, label, marker_in_checksum=True):
        """Emit a record: optional marker byte, data bytes, checksum."""
        n0 = len(self.parts)
        for b in data:
            self.frame(b >> 4)                       # high nibble first
            self.frame(b & 0xF)
        dur = sum(len(p) for p in self.parts[n0:]) / self.rate
        self.log.append((label, dur))

    def write(self, path):
        sig = np.concatenate(self.parts)
        pcm = (np.clip(sig, -1, 1) * 32767).astype("<i2")
        with wave.open(path, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(self.rate)
            w.writeframes(pcm.tobytes())
        return len(sig) / self.rate


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="pc1_reference.wav")
    ap.add_argument("--rate", type=int, default=44100)
    ap.add_argument("--line", type=int, default=10)
    ap.add_argument("--string", default="HI")
    ap.add_argument("--leader-bits", type=int, default=LEADER_BITS)
    ap.add_argument("--amp", type=float, default=0.6)
    args = ap.parse_args()

    # Header record: marker 0x80 then 8 bytes then checksum.  The trailing
    # 95 85 5F is reproduced verbatim from the capture -- its meaning is not
    # established, and inventing a value here would be a guess on the one part
    # of the format the capture does not explain.
    hdr_marker = [HDR_MARKER]
    hdr_data = [0x00, 0x00, 0x00, 0x00, 0x00, 0x95, 0x85, 0x5F]
    hdr = hdr_marker + with_checksum(hdr_data)

    prog = with_checksum(build_program_record(args.line, "PRINT", args.string)) \
        + [END]

    print("== records ==")
    print("  header  : " + " ".join(f"{b:02X}" for b in hdr))
    print("  program : " + " ".join(f"{b:02X}" for b in prog))

    t = Tape(rate=args.rate, amp=args.amp)
    t.mark_run(args.leader_bits, "leader")
    t.record(hdr, "header record")
    t.mark_run(GAP_BITS, "inter-record gap")
    t.record(prog, "program record")
    t.mark_run(TRAILER_BITS, "trailer")
    total = t.write(args.out)

    print("\n== time budget ==")
    real = {"leader": 4.919, "header record": 0.374,
            "inter-record gap": 0.260, "program record": 0.402,
            "trailer": 0.084}
    for label, dur in t.log:
        r = real.get(label)
        cmp_ = f"   real capture {r:6.3f} s" if r else ""
        print(f"  {label:18s} {dur:6.3f} s{cmp_}")
    print(f"  {'TOTAL':18s} {total:6.3f} s   real capture  6.140 s")
    print(f"\nwrote {args.out}")

    # verify by decoding it back
    try:
        import pc1_tape as P
        runs, _ = P.pc1_tone_runs(args.out)
        frames = P.pc1_decode(runs)
        nib = [int(b[::-1], 2) for _, b in frames]
        print(f"\n== self-check: decoded {len(frames)} frames ==")
        secs, cur, prev = [], [], None
        for a, b in frames:
            if prev is not None and a - prev > 60000:
                secs.append(cur); cur = []
            cur.append((a, b)); prev = a
        secs.append(cur)
        for i, s in enumerate(secs):
            n = [int(b[::-1], 2) for _, b in s]
            recs = P.pc1_records(n)
            for r in recs:
                print(f"  section {i}: data "
                      + " ".join(f"{v:02X}" for v in r["data"])
                      + f"  checksum {r['checksum']:02X} VERIFIED")
                lst = P.pc1_listing(r["data"])
                if lst:
                    print(f"             listing: {lst}")
    except Exception as e:      # pragma: no cover
        print(f"self-check skipped: {e}")


if __name__ == "__main__":
    main()
