#!/usr/bin/env python3
"""
PC-1 (Sharp PC-1211) CSAVE receive-path simulator.

Ports the live firmware receive path -- the ISR period ring, CassetteDecoder::poll()'s
drain policy, the FRAMING_ASYNC_KCS half-period state machine, and ReadData()'s main
loop with its real per-byte costs -- so the save direction can be exercised without
hardware.

Signal source is a synthesised PC-1 tape built from the measured parameters in
PC1_FINDINGS.md, so a correct receiver must reproduce the input record byte for byte.
"""

import sys

# ---------------------------------------------------------------- protocol row
# {"TRS-80 PC-1", 492, 400, 700, 232, 180, 380, 1, 128, 2456, 0, LSB_FIRST,
#  PARITY_NONE, 0, 1, 0, 1, 42, 4, 8, POLARITY_NEGATIVE, FRAMING_ASYNC_KCS}
class Params:
    bit0 = 492; bit0_min = 400; bit0_max = 700
    bit1 = 232; bit1_min = 180; bit1_max = 380
    leaderBit = 1; leaderBits = 128; leaderTime = 2456
    startBit = 0
    interByteTimeout_us = 0
    stopBit = 1; stopBits = 0
    bit0_cycle = 4; bit1_cycle = 8

P = Params()

# --------------------------------------------------------- measured tape timing
MARK_CYC_US  = 250.38     # 4 kHz mark, full cycle
SPACE_CYC_US = 499.56     # 2 kHz space, full cycle
CELL_US      = 2001.6


def build_tape(records, leader_cells=2457, gap_cells=130, trailer_cells=42,
               jitter=True, pre_noise_ms=0.0):
    """Return a list of half-period durations (us) for a PC-1 CSAVE.

    `records` is a list of byte strings; each is emitted as a section of
    nibble frames, sections separated by a mark gap.
    """
    halves = []

    def mark_cells(n):
        for _ in range(int(round(n * CELL_US / MARK_CYC_US))):
            halves.append(MARK_CYC_US / 2)
            halves.append(MARK_CYC_US / 2)

    def mark_cycles(n):
        for _ in range(int(n)):
            halves.append(MARK_CYC_US / 2)
            halves.append(MARK_CYC_US / 2)

    def cell(bit):
        if bit:
            for _ in range(8):
                halves.append(MARK_CYC_US / 2); halves.append(MARK_CYC_US / 2)
        else:
            for _ in range(4):
                halves.append(SPACE_CYC_US / 2); halves.append(SPACE_CYC_US / 2)

    if pre_noise_ms:
        # Unterminated input before the PC-1 starts driving the line: random-ish
        # edges that land inside neither accept window most of the time.
        import random
        rnd = random.Random(1)
        t = 0.0
        while t < pre_noise_ms * 1000.0:
            d = rnd.choice([90.0, 140.0, 210.0, 300.0, 450.0, 620.0])
            halves.append(d); t += d

    mark_cells(leader_cells)

    # frame period wanders 19.28-21.55 ms; cycle through the measured cluster
    jitters = [19.28, 20.02, 20.76, 21.55] if jitter else [20.02]
    ji = 0

    for si, rec in enumerate(records):
        if si:
            mark_cells(gap_cells)
        nibbles = []
        for b in rec:
            nibbles.append((b >> 4) & 0x0F)
            nibbles.append(b & 0x0F)
        for nib in nibbles:
            frame_us = jitters[ji % len(jitters)] * 1000.0
            ji += 1
            cell(0)                                  # start bit
            for k in range(4):                       # 4 data bits, LSB first
                cell((nib >> k) & 1)
            used = 5 * CELL_US
            trail = frame_us - used
            mark_cycles(max(1, int(round(trail / MARK_CYC_US))))
    mark_cells(trailer_cells)
    return halves


# --------------------------------------------------------------- decoder port
WAIT_LEADER, WAIT_START, READ_DATA, READ_STOP = 0, 1, 2, 4


class Decoder:
    QSIZE = 32

    def __init__(self, drain_all=False, validity_gate=False, qsize=32,
                 nibble_frame=True):
        # nibble_frame mirrors the firmware's _pc1Nibble: emit after 4 data
        # bits and resync on the next space run.  Set False to reproduce the
        # old 8-bit framing, which slips whenever the mark tail is < 4 cells.
        self.nibble_frame = nibble_frame
        self.QSIZE = qsize
        self.q = [0] * qsize
        self.qhead = 0
        self.qtail = 0
        self.drops = 0
        self.highwater = 0
        self.drain_all = drain_all
        self.validity_gate = validity_gate
        self.reset()

    def reset(self):
        self.state = WAIT_LEADER
        self.leaderCount = 0
        self.startQual = 0
        self.bitCount = 0
        self.byte = 0
        self.stopCount = 0
        self.c0 = 0
        self.c1 = 0
        self.byteReady = False
        self.lastByte = 0
        self.oor = 0
        self.stopErrors = 0
        self.rejected = 0

    # ---- ISR
    def isr_push(self, delta):
        nxt = (self.qhead + 1) % self.QSIZE
        if nxt != self.qtail:
            self.q[self.qhead] = delta
            self.qhead = nxt
        else:
            self.drops += 1

    # ---- poll()
    def poll(self):
        head = self.qhead
        occ = (head - self.qtail) % self.QSIZE
        if occ > self.highwater:
            self.highwater = occ
        if self.drain_all:
            while self.qtail != head:
                p = self.q[self.qtail]
                self.qtail = (self.qtail + 1) % self.QSIZE
                self.handle(p)
        else:
            if self.qtail != head:
                p = self.q[self.qtail]
                self.qtail = (self.qtail + 1) % self.QSIZE
                self.handle(p)

    def emit(self):
        b = self.byte
        if self.validity_gate and (b & 0xF0) != 0xF0:
            self.rejected += 1
            return
        self.lastByte = b
        self.byteReady = True

    def handle(self, us):
        h1_min, h1_max = P.bit1_min // 2, P.bit1_max // 2
        h0_min, h0_max = P.bit0_min // 2, P.bit0_max // 2
        if h1_min <= us <= h1_max:
            self.c1 += 1; self.c0 = 0
        elif h0_min <= us <= h0_max:
            self.c0 += 1; self.c1 = 0
        else:
            self.c0 = 0; self.c1 = 0; self.oor += 1
            return

        b0thr = P.bit0_cycle * 2
        b1thr = P.bit1_cycle * 2
        if self.c0 >= b0thr:
            bit = 0; self.c0 = 0; self.c1 = 0
        elif self.c1 >= b1thr:
            bit = 1; self.c0 = 0; self.c1 = 0
        else:
            return

        st = self.state
        if st == WAIT_LEADER:
            if bit == P.leaderBit:
                self.leaderCount += 1
                if self.leaderCount >= P.leaderBits:
                    self.state = WAIT_START; self.startQual = 0
                    self.c0 = 0; self.c1 = 0
            else:
                self.leaderCount = 0
        elif st == WAIT_START:
            if bit == P.startBit:
                self.state = READ_DATA; self.bitCount = 0; self.byte = 0
        elif st == READ_DATA:
            self.byte |= (bit << self.bitCount)
            self.bitCount += 1
            if self.nibble_frame and self.bitCount == 4:
                self.byte |= 0xF0
                self.emit()
                self.state = WAIT_START; self.startQual = 1
                self.c0 = 0; self.c1 = 0
                return
            if self.bitCount == 8:
                self.emit()
                if P.stopBits == 0:
                    self.state = WAIT_START; self.startQual = 1
                    self.c0 = 0; self.c1 = 0
                else:
                    self.state = READ_STOP; self.stopCount = 0
        elif st == READ_STOP:
            if bit == P.stopBit:
                self.stopCount += 1
                if self.stopCount >= P.stopBits:
                    self.state = WAIT_START; self.startQual = 1
            else:
                self.stopErrors += 1
                self.state = WAIT_START; self.startQual = 1


# ------------------------------------------------------------ ReadData() model
def run_capture(halves, drain_all=False, validity_gate=False, qsize=32,
                loop_us=12.0, ram_write_us=520.0, diag_us=13000.0,
                diag_period_us=1_000_000.0, diag=True):
    """Simulate ReadData()'s async loop against the edge stream."""
    dec = Decoder(drain_all=drain_all, validity_gate=validity_gate, qsize=qsize)

    edge_t = []
    t = 0.0
    for h in halves:
        t += h
        edge_t.append(t)
    total = t

    captured = []
    now = 0.0
    ei = 0
    next_diag = diag_period_us

    while now < total + 20000.0:
        # advance one main-loop iteration; ISR fires for every edge in between
        step = loop_us
        end = now + step
        while ei < len(edge_t) and edge_t[ei] <= end:
            prev = edge_t[ei - 1] if ei else 0.0
            dec.isr_push(edge_t[ei] - prev)
            ei += 1
        now = end

        dec.poll()

        if dec.byteReady:
            dec.byteReady = False
            captured.append(dec.lastByte)
            # ram.writeByte() -- bit-banged SPI, blocking
            end = now + ram_write_us
            while ei < len(edge_t) and edge_t[ei] <= end:
                prev = edge_t[ei - 1] if ei else 0.0
                dec.isr_push(edge_t[ei] - prev)
                ei += 1
            now = end

        if diag and now >= next_diag:
            next_diag += diag_period_us
            end = now + diag_us
            while ei < len(edge_t) and edge_t[ei] <= end:
                prev = edge_t[ei - 1] if ei else 0.0
                dec.isr_push(edge_t[ei] - prev)
                ei += 1
            now = end

    return dec, captured


def pack(frames, marker_align=False):
    """ReadData()'s nibble packer."""
    nibs = [f & 0x0F for f in frames]
    start = 0
    if marker_align:
        for i in range(len(nibs) - 1):
            if nibs[i] == 0x8 and nibs[i + 1] == 0x0:
                start = i
                break
    out = bytearray()
    i = start
    while i + 1 < len(nibs):
        out.append((nibs[i] << 4) | nibs[i + 1])
        i += 2
    return bytes(out)


def hexs(b):
    return ' '.join('%02X' % x for x in b)


if __name__ == '__main__':
    HDR = bytes([0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x95, 0x85, 0x5F, 0x2F])
    DAT = bytes([0xE0, 0x10, 0xC1, 0x12, 0x58, 0x59, 0x12, 0x00, 0x3D, 0xF0])
    expect = HDR + DAT

    print('expected  :', hexs(expect))
    tape = build_tape([HDR, DAT], pre_noise_ms=float(sys.argv[1]) if len(sys.argv) > 1 else 0.0)
    print('tape halves: %d  duration %.2f s' % (len(tape), sum(tape) / 1e6))

    for label, kw in [
        ('AS SHIPPED          ', dict(drain_all=False, validity_gate=False, qsize=32)),
        ('drain-all           ', dict(drain_all=True,  validity_gate=False, qsize=32)),
        ('drain-all + gate    ', dict(drain_all=True,  validity_gate=True,  qsize=32)),
    ]:
        dec, frames = run_capture(tape, **kw)
        got = pack(frames, marker_align=kw['validity_gate'])
        ok = 'MATCH' if got == expect else 'MISMATCH'
        print('\n%s frames=%d drops=%d hw=%d oor=%d rejected=%d -> %s'
              % (label, len(frames), dec.drops, dec.highwater, dec.oor,
                 dec.rejected, ok))
        print('  got     :', hexs(got[:24]))
