#!/usr/bin/env python3
"""
pc1_make.py -- generate a PC-1 / PC-1211 cassette WAV that the real machine loads.

VALIDATED on hardware.  A 98.4%-synthetic rebuild of a genuine tape produced by
this method loads with CLOAD"HI".

The rules that actually matter -- all of them learned the hard way, and none of
them stated in the service manual:

  1. 8-BIT UNSIGNED MONO WAV.  Not 16-bit.  A 16-bit file fed to an 8-bit
     player is read as twice as many samples, so it plays at half the duration
     and double the pitch -- "too fast, sounds like a faster baud".
  2. TONES ARE 3990.4 Hz / 1994.2 Hz, not the nominal 4000/2000, and NOT an
     exact 2:1 ratio.  0.25% sounds negligible; over a few hundred ms it
     accumulates to half a bit cell.
  3. PHASE MUST LAND ON ZERO AT EVERY TONE BOUNDARY.  This is the one that cost
     the most time.  Generate each run at a frequency chosen so it contains
     exactly a whole number of half-cycles in its duration; then the waveform
     crosses zero exactly at the boundary and the next run starts clean.  A
     phase discontinuity mid-tone creates a spurious or missing edge and
     corrupts a bit -- enough to fail a load with no other fault present.
  4. A clean synthetic sine is fine.  The machine has no objection to it.

Frame and record structure (checksum-verified against the capture):

  frame  : start 0 | 8 data bits LSB-first | stop = 6 cycles of mark
           payload uses only the LOW nibble; high nibble padded with ones,
           so every byte on tape is 0xF0 | nibble, two frames per data byte,
           HIGH NIBBLE FIRST.
  record : data bytes, then a 2-nibble checksum = 8-bit sum of the record's
           data nibbles.
  tape   : leader (mark) | header record | mark gap | program record | trailer

  program record: E0 <lineBCD> <token> 12 <chars> 12 00 | checksum | F0
  characters    : ASCII + 0x10  ('H' 0x48 -> 0x58)

The header record's internal layout is NOT fully solved -- CLOAD"HI" matching
proves the program name lives in it, but the nibble alignment of that field is
still unresolved.  So by default this tool reuses a known-good header verbatim
from a real tape, which keeps the name as "HI".  Pass --header-hex to override
once the layout is known.
"""

import argparse
import wave

import numpy as np

RATE = 44100
MARK_HZ = 3990.4          # measured, not nominal
SPACE_HZ = 1994.2
MARK_CYCLES = 8           # per '1' bit
SPACE_CYCLES = 4          # per '0' bit
STOP_CYCLES = 6           # the stop is NOT a full bit cell

LEADER_BITS = 2456
GAP_BITS = 129
TRAILER_BITS = 42

QUOTE, EOL, END = 0x12, 0x00, 0xF0
PROG_MARKER = 0xE0
TOKENS = {"PRINT": 0xC1}

# Header record from a genuine tape (name "HI").  Reused verbatim; see docstring.
KNOWN_HEADER = [0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x95, 0x85, 0x5F, 0x2F]


def sharp_code(c):
    o = ord(c.upper())
    if 0x30 <= o <= 0x39 or 0x41 <= o <= 0x5A:
        return o + 0x10
    raise ValueError(f"no confirmed Sharp code for {c!r}")


def checksum(data):
    nib = []
    for b in data:
        nib += [b >> 4, b & 0xF]
    return sum(nib) & 0xFF


class Tape:
    """Emits runs, each phase-exact: whole half-cycles, zero at both ends."""

    def __init__(self, amp=0.62):
        self.parts = []
        self.amp = amp

    def run(self, freq, cycles):
        """One tone run of `cycles` whole cycles -> starts and ends at zero."""
        n = int(round(RATE * cycles / freq))
        # frequency trimmed so exactly `cycles` cycles fit in n samples,
        # guaranteeing the run ends on a zero crossing (rule 3)
        f = cycles * RATE / n
        self.parts.append(self.amp * np.sin(2 * np.pi * f * np.arange(n) / RATE))

    def bit(self, v):
        self.run(MARK_HZ, MARK_CYCLES) if v else self.run(SPACE_HZ, SPACE_CYCLES)

    def mark_bits(self, n):
        for _ in range(n):
            self.bit(1)

    def frame(self, nib):
        v = 0xF0 | (nib & 0xF)
        self.bit(0)
        for i in range(8):
            self.bit((v >> i) & 1)
        self.run(MARK_HZ, STOP_CYCLES)

    def record(self, data):
        for b in data:
            self.frame(b >> 4)
            self.frame(b & 0xF)

    def write(self, path):
        sig = np.concatenate([np.zeros(int(0.0032 * RATE))] + self.parts
                             + [np.zeros(int(0.001 * RATE))])
        pcm = np.clip(np.round(sig * 128.0) + 128.0, 0, 255).astype(np.uint8)
        with wave.open(path, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(1)
            w.setframerate(RATE)
            w.writeframes(pcm.tobytes())
        return len(sig) / RATE


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="pc1_program.wav")
    ap.add_argument("--line", type=int, default=10)
    ap.add_argument("--string", default="HI")
    ap.add_argument("--header-hex", default=None,
                    help="override the header record, e.g. '80 00 ... 2F'")
    ap.add_argument("--amp", type=float, default=0.62)
    args = ap.parse_args()

    if args.line > 99:
        raise SystemExit("line numbers >99 need the 2-byte BCD form, "
                         "which the reference capture does not demonstrate")

    body = [PROG_MARKER,
            ((args.line // 10) << 4) | (args.line % 10),
            TOKENS["PRINT"],
            QUOTE] + [sharp_code(c) for c in args.string] + [QUOTE, EOL]
    prog = body + [checksum(body)] + [END]

    header = ([int(v, 16) for v in args.header_hex.split()]
              if args.header_hex else KNOWN_HEADER)

    print("header  : " + " ".join(f"{b:02X}" for b in header))
    print("program : " + " ".join(f"{b:02X}" for b in prog))
    print(f"listing : {args.line} PRINT \"{args.string.upper()}\"")

    t = Tape(amp=args.amp)
    t.mark_bits(LEADER_BITS)
    t.record(header)
    t.mark_bits(GAP_BITS)
    t.record(prog)
    t.mark_bits(TRAILER_BITS)
    dur = t.write(args.out)
    print(f"\nwrote {args.out}: {dur:.3f} s, 8-bit mono {RATE} Hz")
    print("load with:  CLOAD\"HI\"      (the header carries the name)")


if __name__ == "__main__":
    main()
