#!/usr/bin/env python3
"""
pc2_basic.py -- TRS-80 PC-2 / Sharp PC-1500 BASIC tokeniser and detokeniser.

    python3 pc2_basic.py list   FILE.TAP            -> BASIC listing on stdout
    python3 pc2_basic.py make   FILE.BAS OUT.TAP [NAME]
    python3 pc2_basic.py check  FILE.TAP            -> round-trip self-test

EVERYTHING HERE IS CHECKED AGAINST A REAL MACHINE OR AGAINST PocketTools
SOURCE, NOT ASSUMED.  See claude/PC2_RECORD_FORMAT.md.

TAPE BYTE STREAM (what a .TAP holds; the leading lone 0xA file-type nibble is
stripped on capture and re-created by the sender, so it is NOT in the file):

    [0 .. 41]   header, 42 bytes
                  10 11 12 13 14 15 16 17     signature
                  01                          sub-ident, BASIC image
                  16 bytes                    name, ASCII, NUL padded
                  9 bytes                     zero
                  2 bytes                     load address, big-endian (00C5)
                  2 bytes                     image length, big-endian
                  2 bytes                     entry address, big-endian (0000)
                  2 bytes                     plain 16-bit sum of bytes 0..39
    [42 ..  ]   image bytes, then 0xFF, with a 16-bit checksum (hi,lo) of the
                preceding 80 bytes inserted after every 80, sum reset each time
                a partial final block is followed by its own 16-bit checksum
    last        0x55, end of file

PROGRAM IMAGE -- one record per line:

    <line number, 2 bytes BIG-ENDIAN> <length> <body ...> 0D

`length` counts from the first body byte through the 0D inclusive.  The image
ends after the last 0D; the 0xFF terminator belongs to the tape layer.

TOKENS are always TWO bytes.  A byte in 0xE0..0xF1 outside nothing at all --
strings included -- introduces a token; every other byte is a literal
character in plain ASCII (NOT the PC-1's ASCII+0x10).

The 183 tokens below were derived EMPIRICALLY, by feeding `10 <NAME>` to
PocketTools bas2img --pc=1500 for every name in wav2bin's CodePc1500_E6/E7/
E8/F0/F1 detokenise tables and recording the byte pair it emitted.  An
earlier version scraped the names out of the bas2img SOURCE instead and
missed 69 of them -- including CLS and CURSOR, which are ordinary PC-1500
commands.  Do not go back to parsing the source: use the tool as an oracle.

That miss was not harmless.  Greedy matching turned `CURSOR 0` into the
characters "CURS" followed by the OR token: a program that lists back almost
convincingly and is wrong.

Two names share code 0xF0C3 in bas2img (ERASE and REPKEY).  REPKEY is
dropped so the table stays a bijection; wav2bin lists 0xF0C3 as ERASE.
"""
import sys, os, re

TOKENS = [
    ('ENDSELECT', 0xF0D1), ('GLCURSOR', 0xE682), ('HPCURSOR', 0xF055), ('INTEGRAL', 0xF07D),
    ('POSTLOAD', 0xF0FC), ('RENUMBER', 0xF0C8), ('TERMINAL', 0xE883), ('TRANSMIT', 0xE885),
    ('VPCURSOR', 0xF050), ('CATALOG', 0xF0A1), ('CONSOLE', 0xF0B1), ('GCURSOR', 0xF093),
    ('HCURSOR', 0xF054), ('LCURSOR', 0xE683), ('OUTSTAT', 0xE880), ('PROGRAM', 0xF0C7),
    ('QVERIFY', 0xF083), ('RESTORE', 0xF1A7), ('RINKEY$', 0xE85A), ('RVSLOAD', 0xF0FB),
    ('VCURSOR', 0xF056), ('APPEND', 0xF0C0), ('CHANGE', 0xF0C1), ('CURSOR', 0xF084),
    ('DEGREE', 0xF18C), ('GPRINT', 0xF09F), ('INKEY$', 0xF15C), ('INSTAT', 0xE859),
    ('LPRINT', 0xF0B9), ('RADIAN', 0xF1AA), ('RANDOM', 0xF1A8), ('RETURN', 0xF199),
    ('RIGHT$', 0xF172), ('ROTATE', 0xE685), ('SEARCH', 0xF0A8), ('SELECT', 0xF0D0),
    ('SETCOM', 0xE882), ('SETDEV', 0xE886), ('SPACE$', 0xF061), ('STATUS', 0xF167),
    ('SUBCLR', 0xF0DA), ('SUBEND', 0xF0D9), ('TTIME$', 0xF05E), ('UNLOCK', 0xF1B6),
    ('AREAD', 0xF180), ('BREAK', 0xF0B3), ('CHAIN', 0xF0B2), ('CHECK', 0xF0A2),
    ('CLEAR', 0xF187), ('CLOAD', 0xF089), ('COLOR', 0xF0B5), ('CSAVE', 0xF095),
    ('CSIZE', 0xE680), ('DEFFN', 0xF0D2), ('ENDIF', 0xF0CD), ('ERASE', 0xF0C3),
    ('ERROR', 0xF1B4), ('GOSUB', 0xF194), ('GRAPH', 0xE681), ('INPUT', 0xF091),
    ('LEFT$', 0xF17A), ('LLIST', 0xF0B8), ('MERGE', 0xF08F), ('NAME$', 0xF07A),
    ('PAUSE', 0xF1A2), ('PEEK#', 0xF16E), ('PLAST', 0xF0C9), ('PLIST', 0xF0C6),
    ('POINT', 0xF168), ('POKE#', 0xF1A0), ('PRINT', 0xF097), ('PURGE', 0xE2C1),
    ('QLOAD', 0xF080), ('QSAVE', 0xF081), ('RLINE', 0xF0BA), ('ROUND', 0xF07C),
    ('SLEEP', 0xF0E7), ('SORGN', 0xE684), ('SPLIT', 0xF0CB), ('TROFF', 0xF1B0),
    ('USING', 0xF085), ('WHILE', 0xF0D6), ('ARUN', 0xF181), ('BEEP', 0xF182),
    ('CALL', 0xF18A), ('CASE', 0xF0D3), ('CHR$', 0xF163), ('COM$', 0xE858),
    ('CONT', 0xF183), ('COPY', 0xF0A3), ('DATA', 0xF18D), ('DEEK', 0xF07B),
    ('DEV$', 0xE857), ('DOKE', 0xF0AB), ('EDIT', 0xF0DE), ('ELSE', 0xF0CF),
    ('EXIT', 0xF0CE), ('FEED', 0xF0B0), ('FIND', 0xF0C4), ('FRAC', 0xE360),
    ('GCLS', 0xF0E1), ('GOTO', 0xF192), ('GRAD', 0xF186), ('HEX$', 0xF071),
    ('INPT', 0xF0A6), ('KEEP', 0xF0C5), ('LINE', 0xF0B7), ('LINK', 0xF0CA),
    ('LIST', 0xF090), ('LOCK', 0xF1B5), ('LOOP', 0xF0D5), ('MID$', 0xF17B),
    ('MOVE', 0xF0A7), ('NEXT', 0xF19A), ('PEEK', 0xF16F), ('POKE', 0xF1A1),
    ('READ', 0xF1A6), ('SORT', 0xF0AA), ('STEP', 0xF1AD), ('STOP', 0xF1AC),
    ('STR$', 0xF161), ('TEST', 0xF0BC), ('TEXT', 0xE686), ('THEN', 0xF1AE),
    ('TIME', 0xF15B), ('TRON', 0xF1AF), ('WAIT', 0xF1B3), ('ZONE', 0xF0B4),
    ('ABS', 0xF170), ('ACS', 0xF174), ('AND', 0xF150), ('ASC', 0xF160),
    ('ASN', 0xF173), ('ATN', 0xF175), ('BYE', 0xF0A0), ('CLS', 0xF088),
    ('COS', 0xF17E), ('DEC', 0xF070), ('DEG', 0xF165), ('DIM', 0xF18B),
    ('DIR', 0xF0E0), ('DMS', 0xF166), ('DTE', 0xE884), ('END', 0xF18E),
    ('ERL', 0xF053), ('ERN', 0xF052), ('EXP', 0xF178), ('FAC', 0xF075),
    ('FOR', 0xF1A5), ('GSB', 0xF0AF), ('IF#', 0xF0CC), ('INT', 0xF171),
    ('KEY', 0xF0E2), ('LEN', 0xF164), ('LET', 0xF198), ('LOG', 0xF177),
    ('MEM', 0xF158), ('NEW', 0xF19B), ('NOT', 0xF16D), ('OFF', 0xF19E),
    ('OPN', 0xF19D), ('REM', 0xF1AB), ('RMT', 0xE7A9), ('RND', 0xF17C),
    ('RPU', 0xF0AC), ('RUN', 0xF1A4), ('SGN', 0xF179), ('SIN', 0xF17D),
    ('SPU', 0xF0AD), ('SQR', 0xF16B), ('SUB', 0xF0D8), ('TAB', 0xF0BB),
    ('TAN', 0xF17F), ('VAL', 0xF162), ('DO', 0xF0D4), ('FN', 0xF06F),
    ('IF', 0xF196), ('LF', 0xF0B6), ('LN', 0xF176), ('ON', 0xF19C),
    ('OR', 0xF151), ('PI', 0xF15D), ('TO', 0xF1B1),
]

TOKEN_BY_NAME = dict(TOKENS)
TOKEN_BY_VAL  = {}
for _n, _v in TOKENS:
    TOKEN_BY_VAL.setdefault(_v, _n)

REM_TOKEN   = 0xF1AB
QUOTE       = 0x22
EOL         = 0x0D
IMG_EOF     = 0xFF
TAPE_EOF    = 0x55
HEADER_LEN  = 42
BLOCK       = 80
LOAD_ADDR   = 0x00C5
SRC_LINE_MAX = 198


# ---------------------------------------------------------------- tape layer

def tap_to_image(tap):
    """.TAP bytes -> (name, image).  Strips header, block checksums, footer."""
    if len(tap) < HEADER_LEN + 2:
        raise ValueError("too short to be a PC-2 tape (%d bytes)" % len(tap))
    hdr = tap[:HEADER_LEN]
    if bytes(hdr[0:8]) != bytes(range(0x10, 0x18)):
        raise ValueError("bad header signature %s" % hdr[0:8].hex())
    want = (hdr[40] << 8) | hdr[41]
    got  = sum(hdr[0:40]) & 0xFFFF
    if want != got:
        raise ValueError("header checksum %04X, computed %04X" % (want, got))
    subid = hdr[8]
    if subid != 0x01:
        raise ValueError("sub-ident %02X is not a BASIC image" % subid)
    name = bytes(hdr[9:25]).split(b"\x00")[0].decode("ascii", "replace")
    n    = (hdr[36] << 8) | hdr[37]

    # Walk the data section, dropping a 2-byte checksum after every 80 bytes.
    out, run, i = bytearray(), 0, HEADER_LEN
    while len(out) < n + 1 and i < len(tap):
        out.append(tap[i]); i += 1; run += 1
        if run == BLOCK:
            i += 2          # skip the block checksum
            run = 0
    if len(out) != n + 1 or out[-1] != IMG_EOF:
        raise ValueError("image is %d bytes and ends %02X; header says %d + FF"
                         % (len(out) - 1, out[-1] if out else 0, n))
    return name, bytes(out[:-1])


def image_to_tap(image, name):
    """(image, name) -> full .TAP byte stream, checksums and footer included."""
    nm = name.upper().encode("ascii", "replace")[:16]
    hdr = bytearray(range(0x10, 0x18))
    hdr.append(0x01)
    hdr += nm + b"\x00" * (16 - len(nm))
    hdr += b"\x00" * 9
    hdr += bytes([LOAD_ADDR >> 8, LOAD_ADDR & 0xFF])
    hdr += bytes([len(image) >> 8, len(image) & 0xFF])
    hdr += b"\x00\x00"
    s = sum(hdr) & 0xFFFF
    hdr += bytes([s >> 8, s & 0xFF])
    assert len(hdr) == HEADER_LEN

    out, run, s = bytearray(hdr), 0, 0
    for b in bytes(image) + bytes([IMG_EOF]):
        out.append(b); s = (s + b) & 0xFFFF; run += 1
        if run == BLOCK:
            out += bytes([s >> 8, s & 0xFF]); run = 0; s = 0
    if run:
        out += bytes([s >> 8, s & 0xFF])
    out.append(TAPE_EOF)
    return bytes(out)


# ------------------------------------------------------------- detokenise

def _chr(b):
    return chr(b) if 0x20 <= b < 0x7F else "{%02X}" % b


def detokenise(image):
    """image -> BASIC listing text."""
    lines, p = [], 0
    while p < len(image):
        if p + 3 > len(image):
            raise ValueError("truncated line record at %d" % p)
        num = (image[p] << 8) | image[p + 1]
        ln  = image[p + 2]
        body = image[p + 3:p + 3 + ln]
        if len(body) != ln or body[-1] != EOL:
            raise ValueError("line %d: length %d does not land on a 0D" % (num, ln))
        lines.append("%d %s" % (num, _render(body[:-1])))
        p += 3 + ln
    return "\n".join(lines) + "\n"


def _render(body):
    out, i, rest_is_rem = [], 0, False
    while i < len(body):
        b = body[i]
        if not rest_is_rem and 0xE0 <= b <= 0xF1 and i + 1 < len(body):
            val = (b << 8) | body[i + 1]
            nm = TOKEN_BY_VAL.get(val)
            if nm is None:
                out.append("{%04X}" % val)
            elif val == REM_TOKEN:
                # No cosmetic space after REM: the rest of the line is stored
                # verbatim, and adding one here would not survive the trip back
                # (leading spaces after REM are deleted on tokenise).
                out.append(nm); rest_is_rem = True
            else:
                # The machine's own LIST prints a space after a keyword and
                # stores none.  Spaces outside strings are dropped when this
                # listing is tokenised again, so this is free readability.
                out.append(nm + " ")
            i += 2
            continue
        out.append(_chr(b))
        i += 1
    return "".join(out)


# --------------------------------------------------------------- tokenise

_ESC4 = re.compile(r"\{([0-9A-Fa-f]{4})\}")
_ESC2 = re.compile(r"\{([0-9A-Fa-f]{2})\}")


def tokenise(text, warn=None):
    """BASIC listing text -> image bytes."""
    img = bytearray()
    last = 0
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith(("#", ";")):
            continue
        # Kept in step with Pc2Basic.cpp's PC2_SRC_LINE_MAX so the firmware and
        # this tool accept exactly the same files.  The machine's own input
        # buffer is 80 characters, so no real line comes close.
        if len(line) > SRC_LINE_MAX:
            raise ValueError("source line too long (%d > %d chars): %r"
                             % (len(line), SRC_LINE_MAX, raw[:40]))
        m = re.match(r"\s*(\d+)\s*(.*)$", line)
        if not m:
            raise ValueError("no line number: %r" % raw)
        num = int(m.group(1))
        # 65279 = 0xFEFF.  A line number whose high byte is 0xFF would read
        # back as the image terminator, so the machine's limit is ours too.
        if not 1 <= num <= 65279:
            raise ValueError("line number %d out of range 1..65279" % num)
        # The machine keeps the program as a sorted list; an out-of-order image
        # breaks LIST and every GOTO into it.
        if num <= last:
            raise ValueError("line %d comes after line %d" % (num, last))
        last = num
        body = _tokenise_body(m.group(2), num, warn)
        body.append(EOL)
        if len(body) > 255:
            raise ValueError("line %d is %d bytes; the length field holds 255"
                             % (num, len(body)))
        img += bytes([num >> 8, num & 0xFF, len(body)]) + body
    return bytes(img)


def _tokenise_body(src, num, warn):
    out, i, in_str = bytearray(), 0, False
    n = len(src)
    while i < n:
        c = src[i]

        # {F0C0} / {1A} escapes, everywhere
        m = _ESC4.match(src, i)
        if m:
            v = int(m.group(1), 16)
            out += bytes([v >> 8, v & 0xFF]); i = m.end(); continue
        m = _ESC2.match(src, i)
        if m:
            out.append(int(m.group(1), 16)); i = m.end(); continue

        if in_str:
            out.append(ord(c) & 0xFF)
            if c == '"':
                in_str = False
            i += 1
            continue

        if c == '"':
            out.append(QUOTE); in_str = True; i += 1; continue

        # Spaces outside strings are not stored.  bas2img deletes up to 80
        # consecutive spaces for this series (del_spc_cnt = 80), i.e. all of
        # them in any real line, and the machine itself stores none -- the
        # capture reads F0 97 22 ... with no space between PRINT and the
        # quote, though LIST prints one.
        if c == " " or c == "\t":
            i += 1; continue

        # ---- KEYWORD MATCHING IS PER-CHARACTER GREEDY, LONGEST FIRST ----
        # This is deliberately the same rule the PC-1500's own ROM tokeniser
        # uses, and it has to be, because it is the only rule that reads the
        # machine's OWN listing back correctly.  LIST prints a space AFTER a
        # keyword but not before one, so a real listing contains
        #     IF A<BTHEN GOTO 100
        # and the THEN there starts in the middle of the run "BTHEN".  A
        # word-boundary lookup would store "BTHEN" as five literal characters
        # and silently break the program.
        #
        # The cost is the machine's own restriction: a variable name that
        # CONTAINS a keyword gets split, so a variable called ORDER becomes
        # OR + DER on a real PC-1500 too.  TOKENS is sorted longest-first so
        # PEEK#/PEEK, POKE#/POKE and GCURSOR/CURSOR resolve correctly.
        hit = None
        up = src[i:].upper()
        for name, val in TOKENS:
            if up.startswith(name):
                hit = (name, val); break
        if hit:
            name, val = hit
            out += bytes([val >> 8, val & 0xFF])
            i += len(name)
            if val == REM_TOKEN:
                # Rest of the line is verbatim, minus the spaces that follow
                # REM itself (bas2img: delREMspc = true for this series).
                tail = src[i:]
                tail = tail[len(tail) - len(tail.lstrip(" \t")):]
                for ch in tail:
                    out.append(ord(ch) & 0xFF)
                return out
            continue

        v = ord(c)
        if v > 0xFF or v >= 0xE0:
            if warn:
                warn("line %d: character %r cannot be stored" % (num, c))
            v = ord("?")
        out.append(v)
        i += 1
    if in_str:
        # Refuse, do not warn: the firmware refuses too, and the two tools must
        # accept exactly the same files.  A dangling quote also means every
        # keyword after it was stored as literal text.
        raise ValueError("line %d: unterminated string" % num)
    return out


# ------------------------------------------------------------------- cli

def _die(msg):
    sys.stderr.write("pc2_basic: %s\n" % msg); sys.exit(1)


def main(argv):
    if len(argv) < 3:
        sys.stderr.write(__doc__); return 2
    cmd, path = argv[1], argv[2]
    if cmd == "list":
        name, img = tap_to_image(open(path, "rb").read())
        sys.stdout.write("REM name %s\n" % name)
        sys.stdout.write(detokenise(img))
    elif cmd == "make":
        if len(argv) < 4:
            _die("make needs an output path")
        name = argv[4] if len(argv) > 4 else \
               os.path.splitext(os.path.basename(path))[0].upper()[:16]
        img = tokenise(open(path).read(), warn=lambda m: sys.stderr.write(m + "\n"))
        tap = image_to_tap(img, name)
        open(argv[3], "wb").write(tap)
        sys.stderr.write("%s: %d image bytes -> %s, %d tape bytes, name %s\n"
                         % (path, len(img), argv[3], len(tap), name))
    elif cmd == "check":
        raw = open(path, "rb").read()
        name, img = tap_to_image(raw)
        txt = detokenise(img)
        img2 = tokenise(txt)
        tap2 = image_to_tap(img2, name)
        ok = (img2 == img)
        sys.stdout.write(txt)
        sys.stdout.write("\nimage round trip : %s (%d bytes)\n"
                         % ("EXACT" if ok else "DIFFERS", len(img)))
        if not ok:
            sys.stdout.write("  was %s\n  now %s\n" % (img.hex(), img2.hex()))
        sys.stdout.write("tape  round trip : %s\n"
                         % ("EXACT" if tap2 == raw else
                            "differs (input may be truncated)"))
        return 0 if ok else 1
    else:
        _die("unknown command %r" % cmd)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
