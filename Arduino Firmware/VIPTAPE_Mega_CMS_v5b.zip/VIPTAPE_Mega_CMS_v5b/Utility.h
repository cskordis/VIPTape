
#ifndef Utility_H
#define Utility_H

#include <MCUFRIEND_kbv.h>
#include <string.h>


/*Functions to return*/

const char* getEndianString(int value) {
  switch(value) {
    case 0: return "MSB";
    case 1: return "LSB";
    default: return "";
  }
}
const char* getParityString(int value) {
  switch (value) {
    case 0: return "None";
    case 1: return "Odd";
    case 2: return "Even";
    default: return "-";
  }
}


const char* getBitString(int value) {
  switch (value) {
    case 0: return "0";
    case 1: return "1";
    default: return "-";
  }
}

const char* getPolarityString(int value) {
  switch (value) {
    case 0: return "Negative Polarity";
    case 1: return "Positive Polarity";
    default: return "-";
  }
}
/* Function to center text with padding */
// ---- THIS MUST NOT USE THE HEAP.  IT IS THE ERROR REPORTER. ---------------
// This used to build the padded line out of Arduino Strings:
//
//     String padded = "";
//     for (int i = 0; i < padding; i++) padded += repeatedString;
//     String paddedText = padded + text + padded;
//
// which is three heap allocations plus a reallocation per padding character,
// on every single call -- and centerText is called from roughly fifty sites,
// including every error message.
//
// An Arduino String whose allocation FAILS does not throw and does not warn:
// it silently becomes empty.  So when the heap ran short the banner rendered
// as a couple of stray fragments rather than text, which looked exactly like
// display corruption and sent this investigation after the TFT and the SD
// card.  The observable symptom was "large file -> Transferring screen shows
// two small bars", on every protocol, because the file loader had fragmented
// the heap before this ran.
//
// The heap on this board is what is left of ~1.9 KB after globals, shared with
// the file browser's String list and FileLoader's per-line String churn.  A
// routine whose job is to TELL YOU SOMETHING WENT WRONG must not depend on
// that.  This version formats into a bounded stack buffer: no allocation, no
// failure mode, identical output.
#ifndef CENTER_TEXT_MAX
#define CENTER_TEXT_MAX 64      // 240px / 6px per char at size 1 = 40, plus slack
#endif
void centerText(MCUFRIEND_kbv &tft, char* text, int y, int padding, uint16_t textColor, uint16_t bgColor, uint8_t textSize) {

  if (!textSize) {textSize=1;}
  int cw = 6 * textSize;          /* character width in pixels */
  int textLength = strlen(text) ; /* text length*/
  int width;
  if (tft.getRotation()==0||tft.getRotation()==2) {width = tft.width() / cw;}
  else {width= tft.height() / cw;}

  if (padding==0){
    padding = (width - textLength) / 2;
  }
  if (padding < 0) { padding = 0; }   /* text wider than the screen */

  /* Same layout as before -- leading pad, text, trailing pad, plus one extra
     space when (width - textLength) is odd -- built without allocating. */
  char buf[CENTER_TEXT_MAX];
  int n = 0;
  for (int i = 0; i < padding    && n < CENTER_TEXT_MAX - 1; i++) buf[n++] = ' ';
  for (int i = 0; i < textLength && n < CENTER_TEXT_MAX - 1; i++) buf[n++] = text[i];
  for (int i = 0; i < padding    && n < CENTER_TEXT_MAX - 1; i++) buf[n++] = ' ';
  if (((width - textLength) % 2 == 1) && n < CENTER_TEXT_MAX - 1) buf[n++] = ' ';
  buf[n] = '\0';

  tft.setTextSize(textSize);
  tft.setTextColor(textColor, bgColor);
  tft.setCursor(0, y);
  tft.print(buf);
}


void positionText(MCUFRIEND_kbv &tft, char* text, int x , int y, int width,uint16_t textColor, uint16_t bgColor, uint8_t textSize) {

  if (!textSize) {textSize=1;} 
  int cw = 6 * textSize;          /* character width in pixels */
  int textLength = strlen(text) ; /* text length*/
 
  int padding = (width - textLength) / 2;
  
  String padded = "";
  String repeatedString = " ";

  for (int i = 0; i < padding; i++) {
    padded += repeatedString; 
  }
  
  String paddedText = padded + text + padded;
  if ((width - textLength) % 2 == 1) {paddedText += " ";} /* If totalLength is odd, adjust padding to ensure exact length*/
  
  tft.setTextSize(textSize);
  tft.setTextColor(textColor, bgColor);
  tft.setCursor(x, y);
  tft.print(paddedText);
  }

#endif