/*
  KCSEncoder - simple Kansas City Standard style encoder
  - pinOut: output pin for tapeOut
  - freq0: frequency to use for '0' bit (Hz)
  - freq1: frequency to use for '1' bit (Hz)
  - leaderBit: which logical bit value to output for leader (0 or 1 or -1 disable)
  - startBit: value used for the start bit (0 or 1 or -1 disabled)
  - parityBit: 0 - none, 1 - odd parity, 2 - even parity
  - baud rate: integer. 300 for Dream 6800 or zero to ignore
  - endianess: 0 = little endian (LSB-first), 1 = big endian (MSB-first)
  - trailerBit: value used for the trailer bit (0 or 1 or -1 disabled)
  - polarity: 0 = High to Low, 1 = Low to High
*/

#ifndef KCS_ENCODER_H
#define KCS_ENCODER_H

#include <Arduino.h>

class KCSEncoder {
public:

    KCSEncoder(uint8_t pinOut,
               uint32_t freq0 = 2400,
               uint32_t freq1 = 1200,
               uint8_t leaderBit = 0,
               uint8_t startBit = 1,
               uint8_t endBit = 1,
               uint8_t parityBit = 2,
               uint16_t baudRate = 0,
               uint8_t bitEndian = 0,      // 0 = LSB first, 1 = MSB first
               int8_t trailerBit = -1,     // -1 = no trailer, 0 or 1 = trailer bit
               int8_t polarityMode = 1     // 0 = inverted (LOW to HIGH), 1 = normal (HIGH to LOW)
    ) :
          pin(pinOut),
          f0(freq0),
          f1(freq1),
          leader(leaderBit),
          start(startBit),
          end(endBit),
          parityFlag(parityBit),
          baud(baudRate),
          endian(bitEndian),
          trailer(trailerBit),
          polarityMode(polarityMode)
    {
        
        pinMode(pin, OUTPUT);
        digitalWrite(pin, LOW);
        
        period0 = (1000000UL / f0);
        period1 = (1000000UL / f1);
        half0 = period0/ 2;
        half1 = period1/ 2;

       if (baud>0) {
            tbit = 1000000UL / baud;
            cycles0 = tbit /period0;
            cycles1 = tbit /period1;
            }
        else {cycles0=1;cycles1=1;}
    }

    // Full runtime configuration
    void configure(uint32_t newF0,
                   uint32_t newF1,
                   uint8_t newLeader,
                   uint8_t newStart,
                   uint8_t newEnd,
                   uint8_t newParity,
                   uint16_t newbaud = 1,
                   uint8_t newEndian = 0,
                   int8_t newTrailer = -1,
                   int8_t newPolarityMode = 1)
    {
        f0 = newF0;
        f1 = newF1;
        leader = newLeader;
        start = newStart;
        end = newEnd;
        parityFlag = newParity;
        baud = newbaud;
        endian = newEndian;
        trailer = newTrailer;
        polarityMode = newPolarityMode;
     
        period0 = (1000000UL / f0);
        period1 = (1000000UL / f1);
        half0 = period0/ 2;
        half1 = period1/ 2;
   
        if (baud>0) {
            tbit = 1000000UL / baud;
            cycles0 = tbit /period0;
            cycles1 = tbit /period1;
            }
        else {cycles0=1;cycles1=1;}
    }

    // Pulse bit
    void pulseBit(uint8_t bit)
    {
        sendBitOnce(bit);
    }

    // Send a leader tone (many identical bits)
    void sendLeader(uint32_t count) { 
        if (leader == 0 || leader == 1) {
            if (SERIALDEBUG==2) {
                Serial.print("Sending ");
                Serial.print(count);
                Serial.print(" of leader bits ");
                Serial.println(leader);
            }
            for (uint32_t i = 0; i < count; i++) {
                sendBit(leader);
            }      
         }
    }

    // MAIN: Send byte with start → data bits → parity
    void sendByte(uint8_t data)
    {
        uint8_t ones = 0;
        // Start bit   
        if (start==0||start==1) {
            sendBit(start);
            if (SERIALDEBUG==2) {
                Serial.print(" S");
                Serial.print(start);
                Serial.print(" ");
            }
        }
        // Data bits, endian aware
        if (endian == ENDIAN_LSB) {
            // LSB first
            for (int8_t i = 0; i < 8; i++) {
                uint8_t bit = (data >> i) & 1;
                if (bit) ones++;
                sendBit(bit);
                if (SERIALDEBUG==2) {Serial.print(bit);}
             }
        }
        else {
            // MSB first
            for (int8_t i = 7; i >= 0; i--) {
                uint8_t bit = (data >> i) & 1;
                if (bit) ones++;
                sendBit(bit);
                if (SERIALDEBUG==2) {Serial.print(bit);}
            }
        }
       
        // Parity bit
        if (parityFlag==0||parityFlag==1) {
            uint8_t parity = ones & 1;          // odd parity by default
            if (parityFlag == PARITY_ODD) {parity = !parity;}  // even = invert odd result
            sendBit(parity);
            if (SERIALDEBUG==2) {
                Serial.print(" P");
                Serial.print(parity);
            }
        }
        if (end==0||end==1) {
            sendBit(end);
            if (SERIALDEBUG==2) {
                Serial.print(" E");
                Serial.print(end);
            }
        }
    }

    // Trailer support
    void sendTrailer(uint32_t count)
    {
        if (trailer == 0 || trailer == 1) {
            for (uint32_t i = 0; i < count; i++) {
                sendBit(trailer);
            }
            if (SERIALDEBUG==2) {
                Serial.print("Sending ");
                Serial.print(count);
                Serial.print(" of trailer bits ");
                Serial.println(trailer);
            } 
        }
    }

 private:

    void sendBitOnce(uint8_t bit)
    {
        uint16_t half = (bit == 0) ? half0 : half1;
        if (polarityMode==1) {digitalWrite(pin, HIGH);}
        else {digitalWrite(pin, LOW);}
        delayMicroseconds(half);
        if (polarityMode==1) {digitalWrite(pin, LOW);}
        else {digitalWrite(pin, HIGH);}
        delayMicroseconds(half);
    }

    void sendBit(uint8_t bit)
    {
        cycles = (bit == 0) ? cycles0 : cycles1;
        for (i = 0; i < cycles; i++) {
            sendBitOnce(bit);
        }
    }

    uint8_t pin;
    uint32_t f0, f1;
    uint32_t half0, half1;
    uint32_t period0, period1;
    uint32_t cycles,cycles0, cycles1;
    uint32_t tbit;
    int16_t i;

    int16_t baud; 
    uint8_t leader; 
    uint8_t start;
    uint8_t end;

    uint8_t parityFlag;
    uint8_t endian; 
    int8_t trailer; 
    int8_t polarityMode;
};

#endif
