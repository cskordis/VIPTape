#include "RamExternal.h"
#include "Display.h"

RamExternal::RamExternal(uint8_t cs, uint8_t mosi, uint8_t miso, uint8_t sck) :
  _cs(cs), _mosi(mosi), _miso(miso), _sck(sck) {}

void RamExternal::begin() {
  pinMode(_cs, OUTPUT); digitalWrite(_cs, HIGH);
  pinMode(_mosi, OUTPUT);
  pinMode(_miso, INPUT);
  pinMode(_sck, OUTPUT); digitalWrite(_sck, LOW);
}

void RamExternal::select() { digitalWrite(_cs, LOW); }
void RamExternal::deselect() { digitalWrite(_cs, HIGH); }

uint8_t RamExternal::spiTransfer(uint8_t data) {
  uint8_t received = 0;
  for (int8_t i = 7; i >= 0; i--) {
    digitalWrite(_mosi, (data & (1 << i)) ? HIGH : LOW);
    digitalWrite(_sck, HIGH);
    received <<= 1;
    if (digitalRead(_miso)) received |= 1;
    digitalWrite(_sck, LOW);
  }
  return received;
}

void RamExternal::writeByte(uint16_t addr, uint8_t val) {
  select();
  spiTransfer(0x02);  // WRITE
  spiTransfer((addr >> 8) & 0xFF);
  spiTransfer(addr & 0xFF);
  spiTransfer(val);
  deselect();
}

uint8_t RamExternal::readByte(uint16_t addr) {
  select();
  spiTransfer(0x03); // READ
  spiTransfer((addr >> 8) & 0xFF);
  spiTransfer(addr & 0xFF);
  uint8_t val = spiTransfer(0x00);
  deselect();
  return val;
}

void RamExternal::writeStatus(uint8_t val) {
  select(); spiTransfer(0x01); spiTransfer(val); deselect();
}

uint8_t RamExternal::readStatus() {
  select(); spiTransfer(0x05); uint8_t val = spiTransfer(0x00); deselect(); return val;
}