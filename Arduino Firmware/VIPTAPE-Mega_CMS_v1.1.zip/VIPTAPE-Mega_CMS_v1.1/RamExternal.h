#ifndef RamExternal_H
#define RamExternal_H

#include <Arduino.h>
#include "SystemConfig.h"

class RamExternal {
public:
    RamExternal(uint8_t cs, uint8_t mosi, uint8_t miso, uint8_t sck);
    void begin();
    void writeBit(uint16_t addr, uint8_t val);
    void writeByte(uint16_t addr, uint8_t val);
    uint8_t readByte(uint16_t addr);
    void writeStatus(uint8_t val);
    uint8_t readStatus();
    void erase(uint16_t progressStep=6554);

private:
    uint8_t _cs, _mosi, _miso, _sck;
    //void clear(uint16_t size);
    //void clearWithProgress(uint32_t size, void (*progressCb)(uint8_t));
    void select();
    void deselect();
    uint8_t spiTransfer(uint8_t data);
};

#endif
