
#ifndef Utility_H
#define Utility_H

#include <MCUFRIEND_kbv.h>
#include <string.h>


/*Functions to return*/

const char* getEndianString(int value) {
  switch(value) {
    case 0: return "LSB";
    case 1: return "MSB";
    default: return "";
  }
}
const char* getParityStringx(int value) {
  switch (value) {
    case 0: return "None";
    case 1: return "Odd";
    case 2: return "Even";
    default: return "None";
  }
}


const char* getParityString(int value) {
  switch (value) {
    case -1: return "None";
    case 0: return "Odd";
    case 1: return "Even";
    default: return "None";
  }
}


const char* getBitString(int value) {
  switch (value) {
    case 0: return "0";
    case 1: return "1";
    case -1: return "None";
    default: return "None";
  }
}

const char* getPolarityString(int value) {
  switch (value) {
    case 0: return "Falling zero crossing";
    case 1: return "Rising zero crossing";
    default: return "Not Defined";
  }
}
/* Function to center text with padding */
void centerText(MCUFRIEND_kbv &tft, char* text, int y, int padding, uint16_t textColor, uint16_t bgColor, uint8_t textSize) {

  if (!textSize) {textSize=1;} 
  int cw = 6 * textSize;          /* character width in pixels */
  int textLength = strlen(text) ; /* text length*/
  int width;
  if (tft.getRotation()==0||tft.getRotation()==2) {width = tft.width() / cw;}
  else {width= tft.height() / cw;}
 
  if (padding==0){
    padding = (width - textLength) / 2;
  }
  String padded = "";
  String repeatedString = " ";

  for (int i = 0; i < padding; i++) {
    padded += repeatedString; 
  }
  
  String paddedText = padded + text + padded;
  if ((width - textLength) % 2 == 1) {paddedText += " ";} /* If totalLength is odd, adjust padding to ensure exact length*/
  tft.setTextSize(textSize);
  tft.setTextColor(textColor, bgColor);
  tft.setCursor(0, y);
  tft.print(paddedText);
}


void positionText(MCUFRIEND_kbv &tft, char* text, int x , int y, int width,uint16_t textColor, uint16_t bgColor, uint8_t textSize) {

  if (!textSize) {textSize=1;} 
  int cw = 6 * textSize;          /* character width in pixels */
  int textLength = strlen(text) ; /* text length*/
 
  int padding = (width - textLength) / 2;
  
  String padded = "";
  String repeatedString = " ";

  for (int i = 0; i < padding; i++) {
    padded += repeatedString; 
  }
  
  String paddedText = padded + text + padded;
  if ((width - textLength) % 2 == 1) {paddedText += " ";} /* If totalLength is odd, adjust padding to ensure exact length*/
  
  tft.setTextSize(textSize);
  tft.setTextColor(textColor, bgColor);
  tft.setCursor(x, y);
  tft.print(paddedText);
  }

#endif