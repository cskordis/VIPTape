#pragma once
#include <Arduino.h>
#include "CassetteParams.h"


enum DecodeError {
    DECODE_OK = 0,
    DECODE_ERR_PARITY,
    DECODE_ERR_STOPBIT,
    DECODE_ERR_TIMEOUT,
    DECODE_ERR_FRAMING,
    DECODE_ERR_UNKNOWN
};


class CassetteDecoder {
public:
  CassetteDecoder(uint8_t pin); 
  CassetteDecoder(uint8_t pin, const CassetteParams* params);
  void begin(Stream& s);
  void setParams(const CassetteParams* p);
  const CassetteParams* getParams() const { return _p; }
  void reset();
  void setOutput(Stream* s) { _out = s; }
  bool isDone() const { return _done; }


  // Feed a half-cycle (edge-to-edge) period in microseconds.
  void feedPeriod(uint32_t us);
  // Byte retrieval (non-blocking)
  bool available() const { return _byteReady; }
  uint8_t read();

  void poll();
  bool decodeFinished() const;
  void clearDecodeFinished();
  DecodeError lastError() const { return _lastError; }
  bool hasError() const { return _lastError != DECODE_OK; }
  void clearError() { _lastError = DECODE_OK; }


private:
  static CassetteDecoder* instance;
  static void isrThunk();

  void handlePeriod(uint32_t us);
  bool periodToBit(uint32_t fullCycle, uint8_t& bit);
  void emitByte();
  bool _done;
  const CassetteParams* _p;
  uint8_t _pin;
  Stream* _out;

  volatile uint32_t _lastEdge;
  volatile uint32_t _pendingPeriod;
  volatile bool     _hasPeriod;

  uint32_t _waitStartTime;
  uint8_t _startQual;
  uint8_t _cycle0Count;
  uint8_t _cycle1Count;
  uint8_t  _bitCount;
  uint8_t  _byte;
  uint8_t  _parity;
  uint16_t _leaderCount;
  uint8_t  _stopCount;
  uint8_t  _counter;

  bool _decodeFinished = false;
  DecodeError _lastError = DECODE_OK;

  volatile bool _byteReady = false;
  volatile uint8_t _lastByte = 0;


  enum State {
    WAIT_LEADER,
    WAIT_START,
    READ_DATA,
    READ_PARITY,
    READ_STOP
  } _state;
 
};
