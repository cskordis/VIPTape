#ifndef FILEANALYZER_H
#define FILEANALYZER_H

#include <Arduino.h>
#include <limits.h>
#include <SD.h>
#include <SPI.h>
#include <stdlib.h>
#include "SystemConfig.h"




#define BUFFER_SIZE 512

struct FileAnalysis {
  String format;
  size_t dataLength;
  size_t numPages;
  uint32_t startAddr;  // Keep uint32_t for Intel Hex analysis
  uint32_t endAddr;
};

class FileAnalyzer {
private:
  // Helpers
  void trimTrailing(String& s);
  bool isValidHex(const String& hexStr);
  uint8_t hexToByte(const String& hexStr);
  FileAnalysis parseIntelHexAnalysis(File& file);  // Analysis
  size_t parseIntelHexExtraction(File& file, uint8_t* buffer, size_t bufferSize, uint32_t& minAddr, uint32_t& maxAddr);  // Extraction to buffer
  bool parseIntelHexRecord(const String& record, size_t& hexDataLen, uint32_t& minAddr, uint32_t& maxAddr, uint32_t& currentBaseAddr, bool& eofFound, uint32_t& currentExpectedAddr, bool& firstData, uint8_t* buffer, size_t bufferSize, size_t& bufferOffset);  // Buffer-based
  FileAnalysis parseAsciiHexStreaming(File& file);

  size_t extractAsciiHexData(File& file, uint8_t* buffer, size_t bufferSize);
  size_t extractBinaryData(File& file, uint8_t* buffer, size_t bufferSize);

public:
  FileAnalyzer() {}

  FileAnalysis analyzeFileStreaming(File& file);
  size_t extractData(File& file, uint8_t* buffer, size_t bufferSize = UINT_MAX);  // Returns filled bytes, caps at bufferSize

  void dumpFromBuffer(uint8_t* buffer, size_t len);  // Debug dump
};

#endif