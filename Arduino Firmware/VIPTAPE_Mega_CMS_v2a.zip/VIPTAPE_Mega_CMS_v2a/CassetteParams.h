#pragma once
#include <Arduino.h>

enum BitOrder {
  MSB_FIRST,
  LSB_FIRST
};

enum ParityMode {
  PARITY_NONE,
  PARITY_ODD,
  PARITY_EVEN
};

enum PolarityMode {
  POLARITY_NEGATIVE,
  POLARITY_POSITIVE
};


struct CassetteParams {
  const char* name;
  uint16_t bit0;
  uint16_t bit0_min;
  uint16_t bit0_max;

  uint16_t bit1;
  uint16_t bit1_min;
  uint16_t bit1_max;

  uint8_t  leaderBit;
  uint16_t leaderBits;
  uint16_t leaderTime;

  uint8_t  startBit;

  BitOrder   bitOrder;
  ParityMode parity;

  uint32_t interByteTimeout_us;

  uint8_t  stopBit;
  uint8_t  stopBits;

  uint8_t  trailerBit;
  uint16_t trailerTime;

  uint16_t bit0_cycle;
  uint16_t bit1_cycle;

  PolarityMode polarity;

};
