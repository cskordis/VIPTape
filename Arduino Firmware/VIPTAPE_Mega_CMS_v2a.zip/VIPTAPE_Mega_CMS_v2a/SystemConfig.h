/////////////////////////////////////////////////////////////////
/*             Costas Skordis July 2025                        */
/*                                                             */
/*          Configure your screen settings here                */
/*    Modify lines appropriate to your device                  */
/*                                                             */
/*                                                             */
/////////////////////////////////////////////////////////////////

#define TITLE           "VIPTAPE"             // Title
#define VERSION         "CMS v2a"             // Version 
#define DISPLAY_SPLASH  1                     // Splash screen 0 - disabled, 1 - enabled
#define DISPLAY_TITLE   1                     // Display title screen 0 - disabled, 1 - enabled
#define SERIAL_BAUD     115200
#define SERIALDEBUG     0                     // Serial 0 - disabled, 1 - enabled, 2 - verbose (Note: When serial is enabled, may affect timings with the protocols to some computer types like the Dream 6800)
#define ORIENTATION     0                     // Portrait
#define SD_CS           10                    // SD card chip select pin
#define DEFAULT_MODE    0                     // Default casette mode at start up
#define BASEFILE        "FILE"                // Default base name for unspecified file when saving
#define FILENAME_SIZE   9                     // Maximum filename size (characters + terminator)

#define MESSAGE1        "Designed By"         // Line 1 of message on initial load screen
#define MESSAGE2        "JOSH BENSADON"       // Line 2 of message on initial load screen
#define MESSAGE3        "Software By"         // Line 3 of message on screen saver
#define MESSAGE4        "COSTAS SKORDIS"      // Line 4 of message on screen saver

#define MESSAGE5        "THANK YOU"           // Line 1 of message on screen saver
#define MESSAGE6        "JOSEPH WEISBECKER"   // Line 2 of message on screen saver

/* Ram SPI */
#define ramCS   27
#define ramMISO 26
#define ramCLK  25
#define ramMOSI 24

#define tapeOut A9
#define tapeIn  18

/* Ram Test*/
#define RAMTEST 2                            // Clear and verify onboard Ram :  0 - Disabled, 1 - Read, 2 - Read and Verify
#define RAMSTART 0

/* Touchscreen pins (adjust based on your shield) */
#define XP 8
#define YP A3
#define XM A2
#define YM 9

/* Touch screen calibrated co-ordinates - adjust accordingly after running calibration */
#define TS_MINX 933
#define TS_MAXX 90
#define TS_MINY 72
#define TS_MAXY 919

#define MINPRESSURE 2
#define MAXPRESSURE 1000

#define TEXTSIZE    2
#define TEXTSIZE1   1
#define TEXTSIZE2   2
#define TEXTSIZE3   3
#define TEXTSIZE4   4

#define MAX_ARRAY     256
#define MAX_FILECOUNT 256

#define TOP_DISP        45
#define ITEMS_PER_PAGE  10
#define CHAR_HEIGHT     (8 * TEXTSIZE + 3)
#define CHAR_WIDTH      8
#define Y_OFFSET        60 
#define FILE_DISP       TOP_DISP - 2
#define INACTIVITY_THRESHOLD 300000  // 5 minutes in milliseconds

/* Assign human-readable names to some common 16-bit color values: */
#define BLACK         0x0000
#define BLUE          0x001F
#define RED           0xF800
#define GREEN         0x07E0
#define CYAN          0x07FF
#define MAGENTA       0xF81F
#define YELLOW        0xFFE0
#define WHITE         0xFFFF
#define GRAY          0x8410
#define NAVY          0x0080
#define DARKBLUE      0x008B
#define MEDIUMBLUE    0x00CD
#define DARKGREEN     0x6400
#define TEAL          0x8080
#define DARKCYAN      0x8B8B
#define DEEPSKYBLUE   0xBFFF
#define DARKTURQUOISE 0xCED1

#define BACKGROUND BLUE                  // Background color
#define FOREGROUND WHITE                 // Foreground color
#define DIRECTORY  WHITE                 // Directory text color
#define HILIGHT    YELLOW                // Highlight text color 
#define ALERT      RED                   // Alert color


/* Physical buttons */
#define BUTTONS      4 
#define BUTTON_UP    44 //30  
#define BUTTON_DOWN  36 //22 
#define BUTTON_YES   30 //44 
#define BUTTON_NO    22 //36   

/* Keyboard Button dimensions and spacing */
#define BUTTON_WIDTH  35
#define BUTTON_HEIGHT 30
#define BUTTON_SPACING 2
#define BUTTON_START_X 10
#define BUTTON_START_Y 55

/*Screen buttons*/
#define NUM_SCREENS  3
#define NUM_BUTTONS  7



