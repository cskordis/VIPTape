#include "CassetteDecoder.h"

CassetteDecoder* CassetteDecoder::instance = nullptr;

CassetteDecoder::CassetteDecoder(uint8_t pin)
: _pin(pin),
  _p(nullptr)
{
}

CassetteDecoder::CassetteDecoder(uint8_t pin, const CassetteParams* params)
  : _p(params),
    _pin(pin),
    _out(nullptr),
    _lastEdge(0),
    _pendingPeriod(0),
    _hasPeriod(false),
    _waitStartTime(0),
    _startQual(0),
    _state(WAIT_LEADER),
    _bitCount(0),
    _byte(0),
    _parity(0),
    _leaderCount(0),
    _stopCount(0),
    _cycle0Count(0),
    _cycle1Count(0),
    _done(false),
    _counter(0) {
}

void CassetteDecoder::begin(Stream& s) {
  _out = &s;
  instance = this;
  pinMode(_pin, INPUT);
  attachInterrupt(digitalPinToInterrupt(_pin), isrThunk, CHANGE);
  clearDecodeFinished();
  if (_out) _out->println(String(_p->name) + F(" CASSETTE DECODER READY"));
}

void CassetteDecoder::setParams(const CassetteParams* params) {
  _p = params;
  reset();
}

void CassetteDecoder::feedPeriod(uint32_t us) {
  handlePeriod(us);
}

uint8_t CassetteDecoder::read() {
  _byteReady = false;
  return _lastByte;
}

void CassetteDecoder::reset() {
  _state = WAIT_LEADER;
  _leaderCount = 0;
  _startQual = 0;
  _bitCount = 0;
  _byte = 0;
  _parity = 0;
  _stopCount = 0;
  _waitStartTime = 0;
  _decodeFinished = false;
  _byteReady = false;
  _done = false;
  _counter=0;
  clearError();
}


void CassetteDecoder::isrThunk() {
  uint32_t now = micros();
  if (instance->_lastEdge == 0) {
    instance->_lastEdge = now;
    return;
  }
  uint32_t delta = now - instance->_lastEdge;
  instance->_lastEdge = now;
  instance->_pendingPeriod = delta;
  instance->_hasPeriod = true;
}

bool CassetteDecoder::decodeFinished() const {
  return _decodeFinished;
}

void CassetteDecoder::clearDecodeFinished() {
  _decodeFinished = false;
}

void CassetteDecoder::poll() {
  if (_lastEdge != 0) {
      if ((micros() - _lastEdge) > 500000) {
          _done = true;
          return;
      }
  }
  if (!_hasPeriod) return;
  noInterrupts();
  uint32_t p = _pendingPeriod;
  _hasPeriod = false;
  interrupts();
  handlePeriod(p);
}

bool CassetteDecoder::periodToBit(uint32_t fullCycle, uint8_t& bit) {

  if (fullCycle >= _p->bit1_min && fullCycle <= _p->bit1_max) { 
    bit = 1;
    return true;
  }
  if (fullCycle >= _p->bit0_min && fullCycle <= _p->bit0_max) {
    bit = 0;
    return true;
  }
  return false;
}

void CassetteDecoder::handlePeriod(uint32_t us) {
  static uint32_t halfAccum = 0;
  static bool haveHalf = false;

  if (!haveHalf) {
    halfAccum = us;
    haveHalf = true;
    return;
  }

  uint32_t fullCycle = halfAccum + us;
  haveHalf = false;

  uint8_t bit;
  uint8_t xbit;
 
  if (!periodToBit(fullCycle, xbit)) {
    if (_state == READ_DATA && _startQual == 1) {
      _decodeFinished = true;
      _state = WAIT_LEADER;
      _leaderCount = 0;
      _startQual = 0;
      _waitStartTime = micros();
      }
    else {return;}
    }

  if (xbit == 0) {
    ++_cycle0Count;
    _cycle1Count = 0;
  }
  if (xbit == 1) {
    ++_cycle1Count;
    _cycle0Count = 0;
  }
  
  if (_p->bit0_cycle > 0 && _p->bit0_cycle == _cycle0Count) {
    bit = 0;
  
  } else if (_p->bit1_cycle > 0 && _p->bit1_cycle == _cycle1Count) {
    bit = 1;

  } else {
    return;
  }
  _cycle0Count = 0;
  _cycle1Count = 0;

 switch (_state) {
    case WAIT_LEADER:
      if (bit == _p->leaderBit) {
        if (++_leaderCount >= _p->leaderBits) {
          _state = WAIT_START;
          _startQual = 0;
        }
      } else {
        _leaderCount = 0;
      }
      break;

    case WAIT_START:
      if (_startQual == 1 && _p->interByteTimeout_us > 0 && (micros() - _waitStartTime) > _p->interByteTimeout_us) {
        _decodeFinished = true;
        _lastError = DECODE_ERR_TIMEOUT;
        _state = WAIT_LEADER;
        _leaderCount = 0;
        _startQual = 0;
        _waitStartTime = micros();
        break;
      }
      
      if (bit == _p->startBit) {
        _state = READ_DATA;
        _bitCount = 0;
        _byte = 0;
        _parity = 0;
      }
      break;

    case READ_DATA:
      if (_p->bitOrder == LSB_FIRST) {
        _byte |= (bit << _bitCount);
      } else {
        _byte = (_byte << 1) | bit;
      }
      _parity ^= bit;
      _bitCount++;
      if (_bitCount == 8) {
           if (_p->parity != PARITY_NONE) {
          _state = READ_PARITY;
        } else {
          emitByte();
          goto after_byte;
        }
      }
      break;

    case READ_PARITY:
      if (_p->parity == PARITY_ODD) {
        if ((_parity ^ bit) != 1) goto parity_error;
      } else if (_p->parity == PARITY_EVEN) {
        if ((_parity ^ bit) != 0) goto parity_error;
      }
      emitByte();
      goto after_byte;

parity_error:
      if (_out) _out->println(F("PARITY ERROR"));
      _lastError = DECODE_ERR_PARITY;
      _decodeFinished = true;
      _state = WAIT_LEADER;
      _leaderCount = 0;
      _startQual = 0;
      break;

after_byte:
      if (_p->stopBits > 0) {
        _state = READ_STOP;
        _stopCount = 0;
      } else {
        _state = WAIT_START;
        _startQual = 1;
        _waitStartTime = micros();
      }
      break;

    case READ_STOP:
      if (bit == _p->stopBit) {
        if (++_stopCount >= _p->stopBits) {
          _state = WAIT_START;
          _startQual = 1;
          _waitStartTime = micros();
          _byteReady = true;

        }
      } else {
        if (_out) _out->println(F("STOP BIT ERROR"));
        _lastError = DECODE_ERR_STOPBIT;
        _decodeFinished = true;
        _state = WAIT_LEADER;
        _leaderCount = 0;
        _startQual = 0;
      }
      break;
  }
}

void CassetteDecoder::emitByte() {
  _lastByte = _byte;
  _byteReady = true;

  // Optional debug print
  if (_out) {
    if (_byte < 0x10) _out->print('0');
    _out->print(_byte, HEX);
    _out->print(" ");
    if (_counter++ == 16 ) {_out->println(); _counter = 0;}
  }
}
