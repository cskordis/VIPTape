#ifndef DISPLAY_H
#define DISPLAY_H

#include <MCUFRIEND_kbv.h>

// Declare the TFT object so all files can use it
extern MCUFRIEND_kbv tft;

#endif
