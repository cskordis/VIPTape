#ifndef FILELOADER_H
#define FILELOADER_H

#include <Arduino.h>
#include <SD.h>
#include "RamExternal.h"
#include "SystemConfig.h"

enum FileType { FILE_UNKNOWN, FILE_INTEL_HEX, FILE_ASCII_HEX, FILE_BINARY };

class FileLoader {
public:
    FileLoader(RamExternal &ram);
    FileType detectFileType(File &file);
    void loadFile(File &file, uint16_t &startAddr, uint16_t &endAddr,unsigned long &fileSize,String &fileType);

private:
    RamExternal &_ram;
    void loadIntelHex(File &file, uint16_t &startAddr, uint16_t &endAddr);
    void loadAsciiHex(File &file, uint16_t &startAddr, uint16_t &endAddr);
    void loadBinary(File &file, uint16_t &startAddr, uint16_t &endAddr);
    bool verifyIntelHexLine(String &line);
    void printProgressBar(uint8_t percent);
};

#endif
