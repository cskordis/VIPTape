#include "CassetteProtocols.h"

// NOTE: Keep the protocol table *only* in this .cpp so the array is complete here.
// This prevents "incomplete type" sizeof errors and avoids multiple-definition issues.
// name, bit0, bit0_min, bit0_max, bit1 bit1_min, bit1_max, leaderBit, leaderBits, leaderTime, startBit, bitOrder, parity, interByteTimeout_us, stopBit, stopBits, trailerBit, trailerTime, bit0_cycle, bit1_cycle, polarity


const CassetteParams cassetteProtocols[] = {

  {"VIP", 500, 420, 620, 1250, 1050, 1450, 0, 200, 5000, 1, LSB_FIRST, PARITY_EVEN, 20000, 0, 0, 0, 0, 1, 1, POLARITY_POSITIVE},
  {"ELF II", 1250, 1000, 1350, 416, 380, 520, 1, 200, 5000, 0, MSB_FIRST, PARITY_ODD, 20000, 0, 0, 0, 0, 1, 1,  POLARITY_NEGATIVE},
  {"HUG 1802", 2000, 1400, 2600, 1000, 200, 1200, 1, 200, 5000, 0, MSB_FIRST, PARITY_ODD, 20000, 0, 0, 0, 0, 1, 1, POLARITY_NEGATIVE},
  {"KCS 300", 833, 600, 1350, 416, 300, 520, 0, 0, 5000, 1, LSB_FIRST, PARITY_EVEN, 20000, 0, 0, 0, 0, 4, 8, POLARITY_POSITIVE},
  {"KCS 1200", 416, 300, 520, 208, 150, 350, 0, 0, 5000, 1, LSB_FIRST, PARITY_EVEN, 20000, 0, 0, 0, 0, 4, 8, POLARITY_POSITIVE}
};

const uint8_t cassetteProtocolCount = sizeof(cassetteProtocols) / sizeof(cassetteProtocols[0]);

