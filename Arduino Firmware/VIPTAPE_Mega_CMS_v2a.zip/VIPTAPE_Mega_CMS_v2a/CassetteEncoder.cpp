#include "CassetteEncoder.h"

CassetteEncoder::CassetteEncoder(uint8_t outPin)
: _pin(outPin)
{
    pinMode(_pin, OUTPUT);
    digitalWrite(_pin, LOW);
}

void CassetteEncoder::setParams(const CassetteParams* p) {
  _p = p;
}


void CassetteEncoder::configure(const CassetteParams* p)
{
    _p = p;
    _lastError = ENCODE_OK;

    if (!_p) {
        _lastError = ENCODE_ERR_NO_PARAMS;
        return;
    }

    _half0_us = p->bit0 / 2;
    _half1_us = p->bit1 / 2;

    if (_half0_us == 0 || _half1_us == 0 ||
        p->bit0_cycle == 0 || p->bit1_cycle == 0) {
        _lastError = ENCODE_ERR_INVALID_PARAMS;
    }
}

void CassetteEncoder::reset()
{
    digitalWrite(_pin, LOW);
    clearError();
}

void CassetteEncoder::sendLeader()
{
    if (_lastError != ENCODE_OK || !_p) return;

    if (_p->leaderBit == 0 || _p->leaderBit == 1) {
        for (uint16_t i = 0; i < _p->leaderTime; i++) {
            sendBit(_p->leaderBit);
        }
    }
}

void CassetteEncoder::sendByte(uint8_t b)
{
    if (_lastError != ENCODE_OK || !_p) return;

    uint8_t ones = 0;

    // Start bit
    if (_p->startBit == 0 || _p->startBit == 1) {
        sendBit(_p->startBit);
    }
    // Data bit
    if (_p->bitOrder == LSB_FIRST) {
        for (uint8_t i = 0; i < 8; i++) {
            uint8_t bit = (b >> i) & 1;
            if (bit) ones++;
            sendBit(bit);
        }
    } else {
        for (int8_t i = 7; i >= 0; i--) {
            uint8_t bit = (b >> i) & 1;
            if (bit) ones++;
            sendBit(bit);
        }
    }

    // Parity
    if (_p->parity != PARITY_NONE) {
        uint8_t parity = ones & 1;
        if (_p->parity == PARITY_ODD) {parity = !parity;}  // even = invert odd result
        sendBit(parity);
    }

    // Stop bits
    for (uint8_t i = 0; i < _p->stopBits; i++) {
        Serial.println(_p->stopBits);
        sendBit(_p->stopBit);
    }
}

void CassetteEncoder::sendTrailer()
{
    if (_lastError != ENCODE_OK || !_p) return;

    if (_p->trailerBit == 0 || _p->trailerBit == 1) {
        for (uint16_t i = 0; i < _p->trailerTime; i++) {
            sendBit(_p->trailerBit);
        }
    }
}

void CassetteEncoder::sendBit(uint8_t bit)
{
    uint16_t half   = (bit == 0) ? _half0_us : _half1_us;
    uint16_t cycles = (bit == 0) ? _p->bit0_cycle : _p->bit1_cycle;
    for (uint16_t i = 0; i < cycles; i++) {
        writeHigh();
        delayMicroseconds(half);
        writeLow();
        delayMicroseconds(half);
    }
}

void CassetteEncoder::writeHigh()
{
 

    if (_p->polarity == POLARITY_POSITIVE)
        digitalWrite(_pin, HIGH);
    else
        digitalWrite(_pin, LOW); 
}

void CassetteEncoder::writeLow()
{
    if (_p->polarity == POLARITY_POSITIVE)
        digitalWrite(_pin, LOW);
    else
        digitalWrite(_pin, HIGH);
}
