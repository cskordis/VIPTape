// TinyBasConvert.cpp
#include "TinyBasConvert.h"
#include "SystemConfig.h"
#include <Arduino.h>
#include <string.h>

// System area template: DRUNK_BAS.wav's COMPLETE 256-byte system area,
// used VERBATIM. This is a clean-slate restart: rather than layering
// inferred corrections from multiple partial captures (which still didn't
// load correctly on real hardware), use the one configuration proven by
// nature of DRUNK_BAS.wav loading successfully, and change only what must
// legitimately differ per program.
//
// An authoritative disassembly of this exact ROM family was found this
// session (jefftranter/6800, eta-3400/tinybasic.lst) documenting the real
// memory map:
//   0x00-0x0F  Not used by Tiny BASIC
//   0x10-0x1F  Temporaries
//   0x20-0x21  Lowest address of user program space (progStart)
//   0x22-0x23  Highest address of user program space (RAM top)
//   0x24-0x25  Program end + stack reserve (progEnd)
//   0x26-0x27  Top of GOSUB stack
//   0x28-0x2F  Interpreter parameters
//   0x82-0xB5  Variables A-Z  <-- the REAL variable storage area
// This superseded an earlier wrong guess that 0x00-0x1F was variable
// storage (it's actually just "Temporaries"). See convert() below for how
// this is used.
const uint8_t TinyBasConvert::SYSTEM_TMPL[256] = {
    0x00, 0xFC, 0x07, 0xEC, 0xEF, 0xEF, 0xEF, 0xE6, 0xEE, 0xE3, 0xEA, 0xE9, 0xE8, 0xE4, 0xEE, 0xC0,
    0xEE, 0xE0, 0xE6, 0xE8, 0xEE, 0xE0, 0xE2, 0xE0, 0xEA, 0xE2, 0xE8, 0xE0, 0xE6, 0xE2, 0xEA, 0xE2,
    0x01, 0x00, 0x0F, 0xFF, 0x05, 0x74, 0x0F, 0xFF, 0x04, 0xE2, 0x23, 0xD3, 0x00, 0x34, 0x00, 0x30,
    0x53, 0x41, 0x56, 0x45, 0x0D, 0x50, 0x52, 0x49, 0x4E, 0x54, 0x20, 0x22, 0x4D, 0x61, 0x64, 0x65,
    0x20, 0x69, 0x74, 0x20, 0x61, 0x63, 0x72, 0x6F, 0x73, 0x73, 0x20, 0x74, 0x68, 0x65, 0x20, 0x62,
    0x72, 0x69, 0x64, 0x67, 0x65, 0x2E, 0x22, 0x0D, 0x49, 0x43, 0x21, 0x22, 0x0D, 0x07, 0x22, 0x0D,
    0x58, 0x58, 0x58, 0x58, 0x58, 0x58, 0x58, 0x58, 0x58, 0x58, 0x58, 0x58, 0x58, 0x58, 0x58, 0x58,
    0x58, 0x58, 0x58, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x05, 0x00, 0x4E, 0x00,
    0x60, 0xC2, 0x00, 0x19, 0x00, 0x19, 0x00, 0x03, 0x00, 0x00, 0x00, 0x03, 0x00, 0x02, 0x00, 0x05,
    0x00, 0x00, 0x00, 0x05, 0x00, 0x0F, 0x00, 0x00, 0x00, 0x04, 0xCC, 0xF9, 0xFA, 0xEA, 0xEC, 0xE1,
    0x11, 0x16, 0x39, 0x10, 0x00, 0x00, 0x10, 0x16, 0x13, 0x19, 0x11, 0x16, 0x12, 0x1A, 0x00, 0x05,
    0x00, 0x05, 0x00, 0x00, 0x00, 0x02, 0x04, 0xC4, 0x00, 0x30, 0x11, 0x36, 0x1C, 0x52, 0x00, 0x01,
    0x00, 0x35, 0x00, 0x80, 0x22, 0x77, 0xEF, 0x18, 0xA1, 0x18, 0xA1, 0x03, 0xD8, 0x78, 0x00, 0x31,
    0x16, 0x14, 0x01, 0x8C, 0xEC, 0x00, 0x00, 0xFE, 0xFF, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0xFC, 0x19, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x03, 0x13, 0x00, 0xE0,
    0xC1, 0x6F, 0x00, 0xCB, 0x05, 0x74, 0xCE, 0x1A, 0x13, 0x1E, 0x31, 0x12, 0x13, 0x11, 0x32, 0x1E
};

void TinyBasConvert::writeChar(uint32_t &dst, char c) {
    _ram.writeByte(dst++, (uint8_t)c);
}
void TinyBasConvert::writeCRLF(uint32_t &dst) {
    writeChar(dst, '\r'); writeChar(dst, '\n');
}
void TinyBasConvert::writeHex8(uint32_t &dst, uint8_t v) {
    static const char H[] = "0123456789ABCDEF";
    writeChar(dst, H[v>>4]);
    writeChar(dst, H[v&0xF]);
}
void TinyBasConvert::writeHex16(uint32_t &dst, uint16_t v) {
    writeHex8(dst, (uint8_t)(v>>8));
    writeHex8(dst, (uint8_t)(v&0xFF));
}
void TinyBasConvert::writeS1Record(uint32_t &dst, uint16_t addr,
                                    uint8_t *data, uint8_t len) {
    uint8_t count = len + 3;  // addr(2) + data + checksum(1)
    uint16_t sum = count + (addr>>8) + (addr&0xFF);
    for (uint8_t i = 0; i < len; i++) sum += data[i];
    uint8_t chk = (~sum) & 0xFF;
    writeChar(dst,'S'); writeChar(dst,'1');
    writeHex8(dst, count);
    writeHex16(dst, addr);
    for (uint8_t i = 0; i < len; i++) writeHex8(dst, data[i]);
    writeHex8(dst, chk);
    writeCRLF(dst);
}

uint32_t TinyBasConvert::convert(uint16_t srcStart, uint16_t srcEnd,
                                  uint32_t dstBase) {
    _err = nullptr;

    // ---- Pass 1: parse source lines into [hi][lo][text][0D] in a temp area.
    const uint32_t SCRATCH = dstBase + 8192UL; // scratch after S-record output
    uint32_t progPtr = SCRATCH + 256;           // leave 256 bytes for system area

    uint16_t s = srcStart;
    while (s <= srcEnd) {
        while (s <= srcEnd) {
            uint8_t c = _ram.readByte(s);
            if (c != '\r' && c != '\n' && c != ' ' && c != '\t') break;
            s++;
        }
        if (s > srcEnd) break;

        uint32_t lineno = 0;
        bool gotDigit = false;
        while (s <= srcEnd) {
            uint8_t c = _ram.readByte(s);
            if (c >= '0' && c <= '9') { lineno = lineno*10 + (c-'0'); gotDigit=true; s++; }
            else break;
        }
        if (!gotDigit) { _err = "Line has no number"; return 0; }
        if (lineno == 0 || lineno > 65535) { _err = "Bad line number"; return 0; }

        if (s <= srcEnd && _ram.readByte(s) == ' ') s++;

        _ram.writeByte(progPtr++, (uint8_t)(lineno >> 8));
        _ram.writeByte(progPtr++, (uint8_t)(lineno & 0xFF));

        while (s <= srcEnd) {
            uint8_t c = _ram.readByte(s++);
            if (c == '\r' || c == '\n') break;
            _ram.writeByte(progPtr++, c);
        }
        if (s <= srcEnd && _ram.readByte(s) == '\n') s++;

        _ram.writeByte(progPtr++, 0x0D);
    }

    uint32_t progEnd = progPtr;
    uint16_t progEndAddr = PROG_START + (uint16_t)(progEnd - (SCRATCH+256));

    // ---- Build system area at SCRATCH. Bytes 0x00-0x2F are the literal
    // template from the genuine DRUNK_BAS.wav capture -- INCLUDING 0x01-0x02
    // (FC 07). Re-decoding a SECOND genuine capture (LOD_BAS.wav, a real
    // SAVE of a different program that loads correctly) against this one
    // proved SYSTEM_TMPL is not a pure "constant template": besides
    // prog-start/prog-end, offset 0x0028-0x0029 also changed between the two
    // real captures (04 E2 in DRUNK_BAS.wav's session vs 00 00 in
    // LOD_BAS.wav's) -- almost certainly a variable-table pointer that must
    // read as "empty" (0000) for a program with no variables defined, not be
    // left at whatever stale value happened to be in the template's original
    // session. Left unpatched, BASIC's LOAD-complete code reading this field
    // as a resume/variable pointer would explain the immediate "all 8s"
    // crash on real hardware. (Offset 0x0026-0x0027 also drifted by 2 bytes
    // between the two captures -- 0F FF vs 0F FD -- but that looks like
    // incidental stack-pointer noise at the moment of SAVE rather than
    // something LOAD depends on, so it is left as the template value for
    // now.)
    // ---- Build system area at SCRATCH. FULL 256-byte template, built from a
    // 3-way consensus of THREE genuine tape captures (DRUNK_BAS.wav,
    // LOD_BAS.wav, ET3400TestReal.wav) -- see the comment above SYSTEM_TMPL's
    // definition. This supersedes the earlier assumption that 0x0030-0x00FF
    // was safe to zero: several stretches there (e.g. 0x2A-0x34 including
    // literal "SAVE\r", and 0xC7-0xF3) are IDENTICAL across all three
    // captures and are real interpreter/system state, not session leftovers.
    uint32_t sysPtr = SCRATCH;
    for (uint16_t i = 0; i < 256; i++) _ram.writeByte(sysPtr+i, SYSTEM_TMPL[i]);
    // Patch prog start (0x0020-0x0021)
    _ram.writeByte(sysPtr+0x20, (uint8_t)(PROG_START>>8));
    _ram.writeByte(sysPtr+0x21, (uint8_t)(PROG_START&0xFF));
    // Patch prog end (0x0024-0x0025)
    _ram.writeByte(sysPtr+0x24, (uint8_t)(progEndAddr>>8));
    _ram.writeByte(sysPtr+0x25, (uint8_t)(progEndAddr&0xFF));
    // Patch variable storage (0x0082-0x00B5, confirmed by ROM disassembly
    // to be the REAL A-Z variable area -- NOT 0x00-0x1F or 0x28-0x29 as
    // earlier guesses assumed) to empty/zero, since Test.bas uses no
    // variables. Everything else is DRUNK_BAS.wav's own verbatim,
    // proven-working system area.
    for (uint16_t a = 0x82; a <= 0xB5; a++) _ram.writeByte(sysPtr+a, 0x00);

    // ---- Pass 2: write S-records to dstBase
    // NO S0 header. Same verification as the S9 removal above: all four
    // genuine captures start directly with the first real S1 record
    // (address 0000), no S0 preamble at all.
    uint32_t dst = dstBase;

    const uint8_t REC_LEN = 16;
    uint8_t buf[16];
    uint16_t imgAddr = 0;
    uint32_t imgPtr = SCRATCH;
    uint32_t imgEnd = SCRATCH + 256 + (progEnd - (SCRATCH+256));

    while (imgPtr < imgEnd) {
        uint8_t n = REC_LEN;
        if (imgPtr + n > imgEnd) n = (uint8_t)(imgEnd - imgPtr);
        for (uint8_t i = 0; i < n; i++) buf[i] = _ram.readByte(imgPtr+i);
        writeS1Record(dst, imgAddr, buf, n);
        imgPtr += n; imgAddr += n;
    }

    // S9 end record -- RESTORED. Correction: earlier this session S9 was
    // removed based on a checksum-validated regex search finding no
    // "properly formed" S9 record in genuine captures. That search was too
    // strict. The official Heath ETA-3400 monitor source code (LOAD routine
    // at $16A5, confirmed from the printed Software Reference Manual) shows
    // the loader ONLY checks for the literal characters 'S' then '9' to
    // detect end-of-transmission -- it never reads or validates a
    // count/address/checksum for the S9 record at all:
    //   JSR ICT / CMPA #'S' / BNE (loop) / JSR ICT / CMPA #'9' / BEQ (EOF!)
    // So a genuine capture's post-data bytes being unparseable as a
    // "valid" S9 record doesn't mean S9 is absent -- the hardware doesn't
    // need it to be valid, just present. Removing S9 meant the loader kept
    // waiting forever for another 'S' after the real program ended, which
    // matches the "receives everything, then hangs" symptom exactly.
    writeChar(dst,'S');writeChar(dst,'9');writeChar(dst,'0');writeChar(dst,'3');
    writeChar(dst,'0');writeChar(dst,'0');writeChar(dst,'0');writeChar(dst,'0');
    writeChar(dst,'F');writeChar(dst,'C');writeCRLF(dst);

    if (SERIALDEBUG) {
        Serial.print(F("TinyBAS: "));
        Serial.print((uint16_t)(progEnd-(SCRATCH+256)));
        Serial.print(F(" prog bytes, S-record image at dstBase, "));
        Serial.print((uint16_t)(dst-dstBase));
        Serial.println(F(" bytes"));
    }

    return dst - dstBase;
}
