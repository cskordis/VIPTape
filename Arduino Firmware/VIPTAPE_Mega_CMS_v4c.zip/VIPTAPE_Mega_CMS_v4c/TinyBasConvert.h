// TinyBasConvert.h - Convert ETA-3400 Tiny BASIC source text to a KCS-loadable
// S-record image.  Validated against a genuine DRUNK_BAS.wav memory dump.
//
// Tiny BASIC memory layout:
//   0x0000-0x00FF : system area (ROM-set interpreter workspace + key pointers)
//   0x0100+       : program lines, each = [lineno_hi][lineno_lo][text][0x0D]
//   Pointer 0x0020-0x0021 : program start (always 0x0100)
//   Pointer 0x0024-0x0025 : program end
//
// The S-record image is written as ASCII text into external RAM so the existing
// KCS encoder can send it byte-for-byte to the ETA-3400.

#pragma once
#include "RamExternal.h"

class TinyBasConvert {
public:
  TinyBasConvert(RamExternal &ram) : _ram(ram) {}

  // Convert BASIC source text at [srcStart..srcEnd] in external RAM.
  // Writes the resulting S-record ASCII text into external RAM starting at
  // dstBase.  Returns the number of bytes written (0 on error).
  uint32_t convert(uint16_t srcStart, uint16_t srcEnd, uint32_t dstBase);

  const char *error() const { return _err; }

private:
  RamExternal &_ram;
  const char   *_err = nullptr;

  // System area template: ROM-invariant bytes 0x0000-0x002F from genuine
  // DRUNK_BAS.wav decode; 0x0030-0x00FF zeroed (program-specific runtime state).
  static const uint8_t SYSTEM_TMPL[256];
  static const uint16_t PROG_START = 0x0100;

  // Helpers
  uint8_t  hexVal(char c);
  void     writeHex8(uint32_t &dst, uint8_t v);
  void     writeHex16(uint32_t &dst, uint16_t v);
  void     writeChar(uint32_t &dst, char c);
  void     writeS1Record(uint32_t &dst, uint16_t addr,
                         uint8_t *data, uint8_t len);
  void     writeCRLF(uint32_t &dst);
};
