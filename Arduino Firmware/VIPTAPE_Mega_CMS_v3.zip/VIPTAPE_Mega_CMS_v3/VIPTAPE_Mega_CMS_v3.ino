/*
Main Code by Josh Bensadon, with the help of some Libraries. :)
The regular Adafruit "TouchScreen.h" library only works on AVRs
Different mcufriend shields have Touchscreen on different pins and rotation.
Run the TouchScreen_Calibr_native sketch for calibration of your shield and substitute values in SystemConfig.h
User interface by Costas Skordis July 2025

Added Cassette protocol for VIP, ELF II and HEC/ETI660

User interface by Costas Skordis July 2025

All files can be found at https://github.com/cskordis/VIPTape.git
 

Version 0.5 - Refactored for new user interface and made code more modularized
Version 1.0 - Release new user interface with bug fixes to UI screen
Version 2.0 - Add logic to cater for KCS300, KCS1200, ELF II, HEC/ETI-660 and VIP cassette protocols
			      - Modularized functions
            - 0 = big endian (MSB-first), 1 = little endian (LSB-first)
            - Polarity, 0 = Low to High (Rising), 1 = High to Low ()
            - Refactored more to improve functionality and expandability. CassetteProtocols hold the definition of the cassette interfaces
            - Decoding and Encoding are done in seperate modules.
            - Removal of unused variables and arrays.
            - must be used on VIPTAPE PCB version 2 and above that uses D18 for the input pin with updated LM358 op amp / comparator circuit
            - save last mode type to SD to set up the modetype on reboot
Version 3.0 - Add logic to cater for ORAO cassette protocols            
*/
#include <Adafruit_GFX.h>
#include <TouchScreen.h>
#include <SD.h>
#include <SPI.h>
#include <stdint.h>
#include "SplashImage.h"
#include "SystemConfig.h"
#include "Utility.h"
#include "RamExternal.h"
#include "FileLoader.h"
#include "Display.h"
#include "CassetteParams.h"
#include "CassetteProtocols.h"
#include "CassetteDecoder.h"
#include "CassetteEncoder.h"
#include "OraoReceive.h"

uint8_t currentProtocol = DEFAULT_MODE;
uint8_t lastProtocol = DEFAULT_MODE;
CassetteEncoder cassetteEncoder(tapeOut);
CassetteDecoder cassetteDecoder(tapeIn, &cassetteProtocols[currentProtocol]);

unsigned long highStartUs = 0;
bool lastLevel = LOW;
uint32_t lastByteTime = 0;

/* Initialize TouchScreen */
TouchScreen ts = TouchScreen(XP, YP, XM, YM, 300);

// Button objects
Adafruit_GFX_Button up_btn, down_btn, next_btn, prev_btn, yes_btn, no_btn, play_btn, rec_btn;

// Setup external ram
RamExternal ram(ramCS, ramMOSI, ramMISO, ramCLK);
uint32_t ramAddr = 0;

FileLoader loader(ram);

/* File system variables */
File root;
File myFile;

// Global variables for touch coordinates
String currentFile = "";
String currentName = "";
String currentPath = "/";
int fileCount = 0;
int currentIndex = 0;
int displayStart = 0;
int actionFlag = 0;          // Flag to drive current Record or Play logic. 0 - Record or 1 - Play or 2 - Yes/No
String fileList[MAX_ARRAY];  // Array to store file/directory names
char fileName[16];

/*File and SRAM attributes*/
uint16_t startAddr = 0;
uint16_t endAddr = 0;
String fileExt = "";
unsigned long fileSize = 0;

long pages = 0;  // Number of 255 byte pages

/* Screen saver variables*/
unsigned long lastActivityTime = 0;  // Timestamp of the last user activity
bool screensaverActive = false;      // Flag to indicate screensaver state
int hangTime = 0;                    // default hangtime for displays

// Keyboard layout (simplified: A-Z, 0-9, _, ., *)
const char keys[7][6] = {
  { 'A', 'B', 'C', 'D', 'E', 'F' },
  { 'G', 'H', 'I', 'J', 'K', 'L' },
  { 'M', 'N', 'O', 'P', 'Q', 'R' },
  { 'S', 'T', 'U', 'V', 'W', 'X' },
  { 'Y', 'Z', '0', '1', '2', '3' },
  { '4', '5', '6', '7', '8', '9' },
  { '_', '.', ' ', '@', ' ', '*' }
};

int keyboardEntry = 0;
// saveFilename storage
char saveFilename[FILENAME_SIZE] = "";  // Max characters + null terminator
int saveFilenameLength = 0;

/* Buttons */
String pressed;
int touched;
// Structure to hold button state for debouncing
struct ButtonState {
  int currentState;                // Current state of the button
  int lastState;                   // Previous state of the button
  unsigned long lastDebounceTime;  // Last time the button was toggled
};

ButtonState buttonStates[BUTTONS];                                           // Array to store state for each button
const unsigned long debounceDelay = 50;                                      // Debounce time in milliseconds
const int buttonPins[] = { BUTTON_UP, BUTTON_DOWN, BUTTON_YES, BUTTON_NO };  // Array of button pins
const int numButtons = BUTTONS;                                              // Number of buttons

int selectedItem = 0;  // Currently selected item index
int currentPage = 0;   // Current page number
unsigned long lastDebounceTime = 0;

// Define touch areas (for 240x320 portrait orientation)
int numAreas;

struct ButtonCoords {
  uint16_t xMin, xMax, yMin, yMax;
  const char *name;
};

const uint8_t numValidButtons[NUM_SCREENS] = { 6, 6, 2 };

ButtonCoords screenButtons[NUM_SCREENS][NUM_BUTTONS] = {
  {
    { 0, 40, 0, 40, "Up" },
    { 45, 195, 0, 40, "Type" },
    { 200, 240, 0, 40, "Down" },
    { 0, 40, 270, 310, "Prev" },
    { 200, 240, 270, 310, "Next" },
    { 100, 140, 270, 310, "Record" },
  },
  {
    { 0, 40, 0, 40, "Up" },
    { 45, 195, 0, 40, "Type" },
    { 200, 240, 0, 40, "Down" },
    { 0, 40, 270, 310, "Prev" },
    { 200, 240, 270, 310, "Next" },
    { 100, 140, 270, 310, "Play" },
  },
  {
    { 0, 40, 270, 310, "Yes" },
    { 200, 240, 270, 310, "No" },
  },
};


bool getLastMode() {
  lastProtocol = DEFAULT_MODE; // default / safe value

  File f = SD.open("_VIP.CFG", FILE_READ);
  if (!f) return false;

  f.seek(0);

  if (!f.available()) {   // empty file
    f.close();
    return false;
  }

  long v = f.parseInt();  // parse as long to avoid uint8 wrap issues
  f.close();

  if (SERIALDEBUG) {
    Serial.print(F("Read protocol "));
    Serial.println(v);
  }

  if (v >= 0 && v < cassetteProtocolCount) {
    currentProtocol = (uint8_t)v;
    lastProtocol    = (uint8_t)v;
    return true;
  }

  // invalid number in file
  return false;
}

bool saveLastMode() {
  if ((int)lastProtocol == (int)currentProtocol) {return true;}
  SD.remove("_VIP.CFG");
  File f = SD.open("_VIP.CFG", FILE_WRITE);
  if (!f) {
    if (SERIALDEBUG) Serial.println(F("Open failed"));
    return false;
  }

  f.seek(0);
  f.println((int)currentProtocol); 
  f.close();

  if (SERIALDEBUG) {
     Serial.println();
     Serial.println(F("Protocol saved "));
     Serial.println((int)currentProtocol);
     }
  return true;
}

// ------------------------------------------------------------------
// PROTOCOL SELECTION
// ------------------------------------------------------------------

void nextProtocol() {
  currentProtocol++;
  if (currentProtocol >= cassetteProtocolCount)
    currentProtocol = 0;

  applyProtocol();
}

void prevProtocol() {
  if (currentProtocol == 0)
    currentProtocol = cassetteProtocolCount - 1;
  else
    currentProtocol--;

  applyProtocol();
}

void applyProtocol() {
  const CassetteParams *p = &cassetteProtocols[currentProtocol];
  cassetteDecoder.setParams(p);
  cassetteEncoder.setParams(p);
  cassetteDecoder.reset();
}

bool eraseRam(uint32_t sizeBytes) {
  const uint32_t step = sizeBytes / 10;  // 10% progress
  uint32_t nextMark = step;
  uint8_t pct = 0;

  if (SERIALDEBUG) {
    Serial.println(F("Erasing AND TESTING external ram with 0xFF"));
    Serial.println(F("Press 'NO' button to abort"));
  }
  tft.setTextColor(YELLOW, BACKGROUND);
  tft.setCursor(0, tft.height() - 120);
  tft.println("Clearing RAM");
  tft.setCursor(tft.width() - 20, tft.height() - 120);
  tft.print("%");
  for (uint32_t addr = 0; addr < sizeBytes; addr++) {
    ram.writeByte((uint16_t)addr, 0x00);
    uint8_t v = ram.readByte((uint16_t)addr);
    if (v != 0x00) {
      if (SERIALDEBUG) {
        Serial.print(F("SRAM ERROR at 0x"));
        Serial.print(addr, HEX);
        Serial.print(F(" read "));
        Serial.println(v, HEX);
      }
      char addrStr[5];
      sprintf(addrStr, "%04X", addr);
      tft.setCursor(tft.width(), tft.height() - 100);
      tft.setTextColor(BLACK, RED);
      tft.print(String("Error at ") + addrStr);
      tft.setTextColor(FOREGROUND, BACKGROUND);
      delay(1000);
      return false;
    }
    if (digitalRead(BUTTON_NO) == LOW) {
      if (SERIALDEBUG) { Serial.println(F("SRAM erase/test CANCELED")); }
      centerText(tft, "Cancelled", tft.height() - 100, 0, RED, BLACK, 2);
      delay(1000);
      return false;
    }
    if (addr >= nextMark && pct < 100) {
      pct += 10;
      nextMark += step;
      if (SERIALDEBUG) {
        Serial.print(F("Clearing RAM "));
        Serial.print(pct);
        Serial.println(F("%"));
      }
      tft.setCursor(tft.width() - 55, tft.height() - 120);
      tft.print(pct);
      delay(5);
    }
  }
  if (SERIALDEBUG) { Serial.println(F("SRAM erase + test PASSED (100%)")); }
  tft.setCursor(tft.width() - 30, tft.height() - 120);
  tft.setTextColor(WHITE, GREEN);
  tft.print("OK");
  return true;
}

void setup() {

  /*Initialize Serrial if flagged to start*/
  if (SERIALDEBUG) {
    Serial.begin(SERIAL_BAUD);
    delay(1000);
    Serial.println("");
    Serial.println("Starting.....");
  }

  /* Initialize TFT */
  tft.reset();
  tft.begin(tft.readID());
  tft.setRotation(0);  // Portrait orientation
  tft.fillScreen(BLACK);
  tft.setTextColor(WHITE);
  tft.setTextSize(TEXTSIZE);

   // Start decoder
  cassetteDecoder.begin(Serial);

  /* Initialize external ram */
  ram.begin();
  ramAddr = 0;
  /* Initialize SD card */
  if (!SD.begin(SD_CS)) {
    tft.setTextColor(RED);
    tft.setCursor(10, 10);
    tft.println("SD Card Init Failed");
    while (1);
  }
  /* get last saved protocol*/
  getLastMode();
  applyProtocol();

  // Initialize SPI
  SPI.begin();
  delay(500);
  pinMode(SS, OUTPUT);

  // Initialize external 23LC512 SRAM (used by the "decode to SRAM" path)
  /*Set up modes*/

  pinMode(BUTTON_YES, INPUT_PULLUP);
  pinMode(BUTTON_NO, INPUT_PULLUP);
  pinMode(BUTTON_UP, INPUT_PULLUP);
  pinMode(BUTTON_DOWN, INPUT_PULLUP);

  pinMode(tapeOut, OUTPUT);
  cassetteEncoder.pulseBit(0);

  pinMode(tapeIn, INPUT);
  digitalWrite(tapeIn, HIGH);

  for (int i = 0; i < numButtons; i++) {
    pinMode(buttonPins[i], INPUT_PULLUP);  // Button pins with internal pull-up
    // Initialize button states
    buttonStates[i].currentState = HIGH;
    buttonStates[i].lastState = HIGH;
    buttonStates[i].lastDebounceTime = 0;
  }

  /* Navigation buttons*/
  up_btn.initButton(&tft, tft.width() - 218, tft.height() - 300, 40, 40, WHITE, CYAN, BLACK, "Up", 2);
  down_btn.initButton(&tft, tft.width() - 28, tft.height() - 300, 50, 40, WHITE, CYAN, BLACK, "Down", 2);

  next_btn.initButton(&tft, tft.width() - 28, tft.height() - 22, 50, 40, WHITE, YELLOW, BLACK, "Next", 2);
  prev_btn.initButton(&tft, tft.width() - 212, tft.height() - 22, 50, 40, WHITE, YELLOW, BLACK, "Prev", 2);

  play_btn.initButton(&tft, tft.width() - 115, tft.height() - 22, 60, 40, WHITE, CYAN, BLACK, "Play", 2);
  rec_btn.initButton(&tft, tft.width() - 120, tft.height() - 22, 90, 40, WHITE, RED, BLACK, "Record", 2);

  yes_btn.initButton(&tft, tft.width() - 212, tft.height() - 22, 50, 40, WHITE, CYAN, BLACK, "Yes", 2);
  no_btn.initButton(&tft, tft.width() - 28, tft.height() - 22, 50, 40, WHITE, RED, BLACK, "No", 2);

  tft.fillScreen(BACKGROUND);
  if (DISPLAY_TITLE) { displayTitle(1000); }
  if (RAMTEST) {
    eraseRam(RAMSIZE);
    delay(1000);
  }
  if (DISPLAY_SPLASH) { showScreenSaver(1000); }
  ResetMode(1);
  loadDirectory(currentPath);
  displayFiles(1);
  lastActivityTime = millis();  // Initialize activity time
}

/* Button debounce method to return button pressed*/
bool debounceButton(int index) {
  bool buttonPressed = false;
  int reading = digitalRead(buttonPins[index]);

  // Check if the button state has changed
  if (reading != buttonStates[index].lastState) {
    buttonStates[index].lastDebounceTime = millis();  // Reset debounce timer
  }

  // Check if the button state has been stable for the debounce delay
  if ((millis() - buttonStates[index].lastDebounceTime) > debounceDelay) {
    if (reading != buttonStates[index].currentState) {
      buttonStates[index].currentState = reading;
      // Detect button press (LOW due to INPUT_PULLUP)
      if (buttonStates[index].currentState == LOW) {
        buttonPressed = true;
        lastActivityTime = millis();  // Reset activity timer
      }
    }
  }

  buttonStates[index].lastState = reading;
  return buttonPressed;
}

/* Display file attributes */
void displayInfo(uint16_t startAddr, uint16_t endAddr, uint32_t fileSize, String fileExt) {
  int dotIndex = currentName.lastIndexOf('.');
  String fname;

  if (dotIndex != -1) {
    fname = currentName.substring(0, dotIndex);
  } else {
    fname = currentName;
  }

  tft.fillScreen(BACKGROUND);
  centerText(tft, "File To Be Loaded", 10, 0, BLUE, CYAN, 2);
  centerText(tft, fname.c_str(), 40, 0, WHITE, BACKGROUND, 2);
  tft.setCursor(228, 40);
  tft.print(fileExt);
  if (fileExt == 'H') {
    centerText(tft, "Hex Mode", 55, 0, BLUE, GREEN, 2);
    tft.setTextColor(YELLOW, BLUE);
    if (SERIALDEBUG) { Serial.println("Hex Mode"); }
  }
  tft.setCursor(0, 80);
  tft.print("Bytes: ");
  tft.print(fileSize);
  tft.setCursor(0, 100);
  if (currentProtocol == 6 || currentProtocol == 7) {tft.print("Blocks: ");}
  else {tft.print("Pages: ");}
  tft.print((fileSize + 255) / 256);
  if (fileExt != "H") {
    if (currentProtocol == 0 || currentProtocol == 1) {
      startAddr = 0;
      endAddr = fileSize - 1;
    } else if (currentProtocol == 2) {
      startAddr = 1536;
      endAddr = startAddr + endAddr;
    } else if (currentProtocol == 3) {
      startAddr = 512;
      endAddr = startAddr + endAddr;
    } else if (currentProtocol == 6 || currentProtocol == 7) {
      startAddr = 1024;
      endAddr = startAddr + endAddr;
    }
  }
  char hexStart[5];
  char hexEnd[5];
  sprintf(hexStart, "%04X", startAddr);
  sprintf(hexEnd, "%04X", endAddr);
  tft.setCursor(0, 120);
  tft.print("Start Address : " + String(hexStart));
  tft.setCursor(0, 140);
  tft.print("End Address   : " + String(hexEnd));
  centerText(tft, "Proceed?", 160, 0, BLUE, YELLOW, 2);
}


/* Display files and directories of the current page */
void displayFiles(int erase) {
  if (erase == 1) { tft.fillScreen(BACKGROUND); }
  const CassetteParams *p = cassetteDecoder.getParams();
  if (p) {
    centerText(tft, p->name, 10, 0, WHITE, BLUE, TEXTSIZE);
    if (SERIALDEBUG) { Serial.println(p->name); }
  }
  drawButtons(); /*Draw navigation buttons*/

  String dirName = currentPath;
  if (dirName == "/") { dirName = "Root"; }
  tft.setTextColor(WHITE);
  root.rewindDirectory();
  centerText(tft, dirName.c_str(), FILE_DISP, 0, WHITE, BLUE, TEXTSIZE);

  tft.setTextSize(TEXTSIZE);
  if (SERIALDEBUG) {
    Serial.println("Directory : " + dirName);
    Serial.println("File List");
  }

  // Display files
  for (int i = 0; i < ITEMS_PER_PAGE; i++) {
    int fileIndex = displayStart + i;
    if (fileIndex >= fileCount) break;

    // Highlight current selection
    if (fileIndex == currentIndex) {
      tft.fillRect(0, ((i + 1) * CHAR_HEIGHT) + TOP_DISP, tft.width(), CHAR_HEIGHT, YELLOW);
      tft.setTextColor(BLACK);
    } else {
      tft.setTextColor(WHITE);
    }
    tft.setCursor(0, ((i + 1) * CHAR_HEIGHT) + TOP_DISP);
    tft.println(fileList[fileIndex]);
    if (SERIALDEBUG) { Serial.println(fileList[fileIndex]); }
  }
}

/* Display file attributes */
void displayFileToSaveInfo() {
  tft.fillScreen(BACKGROUND);
  centerText(tft, "File To Save", 10, 0, BLUE, CYAN, 2);
  tft.setCursor(0, 30);
  tft.setTextColor(YELLOW, BLUE);
  tft.println(currentFile);
  tft.setCursor(228, 30);
  centerText(tft, "Proceed To Save", 120, 0, BLUE, YELLOW, 2);
}

void displayTitle(int hangTime) {
  tft.fillScreen(BACKGROUND);
  centerText(tft, TITLE, 5, 0, YELLOW, BACKGROUND, 3);
  centerText(tft, VERSION, 40, 0, FOREGROUND, BACKGROUND, 2);
  /*Special messaging*/
  centerText(tft, MESSAGE1, 70, 0, FOREGROUND, BACKGROUND, 2);
  centerText(tft, MESSAGE2, 90, 0, FOREGROUND, BACKGROUND, 2);

  centerText(tft, MESSAGE3, 120, 0, FOREGROUND, BACKGROUND, 2);
  centerText(tft, MESSAGE4, 140, 0, FOREGROUND, BACKGROUND, 2);
  tft.setTextSize(2);

  if (SERIALDEBUG) { Serial.println(VERSION); }
  if (hangTime > 0) { delay(hangTime); }
}

/* Directory methods */
void loadDirectory(String path) {
  // Clear previous list
  fileCount = 0;
  for (int i = 0; i < MAX_FILECOUNT; i++) {
    fileList[i] = "";
  }
  // Open directory
  root = SD.open(path);
  if (!root) {
    tft.fillScreen(BACKGROUND);
    tft.setCursor(0, 0);
    tft.println("Failed to open directory!");
    return;
  }
  // If not root, add parent directory option
  if (path != "/") {
    fileList[fileCount] = "..";
    fileCount++;
  }
  // Read directory contents
  while (true) {
    File entry = root.openNextFile();
    if (!entry) break;
    String name = String(entry.name());
    if (name.equalsIgnoreCase("System Volume Information") || name.equalsIgnoreCase("SYSTEM~1")) {
      continue;
    } else if (name.equalsIgnoreCase(".Trashes") || name.equalsIgnoreCase("$RECYCLE.BIN")) {
      continue;
     } else if (name.equalsIgnoreCase("_VIP.CFG")) {
      continue;  
    } else if (name.charAt(0) == '.')  {
      continue;
    }
    if (fileCount < MAX_FILECOUNT) {
      fileList[fileCount] = String(entry.name());
      if (entry.isDirectory()) {
        fileList[fileCount] += "/";
      }
      fileCount++;
    }
    entry.close();
  }
  root.close();

  /* Reset selection */
  currentIndex = 0;
  displayStart = 0;
}

void navigateToSelection(int display) {
  // Handle directory navigation
  if (fileList[currentIndex] == "..") {
    // Go up one directory
    int lastSlash = currentPath.lastIndexOf('/', currentPath.length() - 2);
    if (lastSlash >= 0) {
      currentPath = currentPath.substring(0, lastSlash + 1);
      loadDirectory(currentPath);
    }
  } else if (fileList[currentIndex].endsWith("/")) {
    // Enter directory
    currentPath += fileList[currentIndex];
    loadDirectory(currentPath);
  }
  if (display) { displayFiles(1); }
}

void moveSelection(int delta) {
  int newIndex = currentIndex + delta;

  // Constrain index
  if (newIndex < 0) newIndex = 0;
  if (newIndex >= fileCount) newIndex = fileCount - 1;

  // Update display start if needed
  if (newIndex < displayStart) {
    displayStart = newIndex - (newIndex % ITEMS_PER_PAGE);
  }
  if (newIndex >= displayStart + ITEMS_PER_PAGE) {
    displayStart = newIndex - (ITEMS_PER_PAGE - 1);
  }

  // Update selection
  currentIndex = newIndex;
  displayFiles(1);
}

void drawButtons() {
  if (SERIALDEBUG) { Serial.println("Action Flag: " + String(actionFlag)); }
  if (actionFlag == 0) {
    down_btn.drawButton(false);
    next_btn.drawButton(false);
    prev_btn.drawButton(false);
    up_btn.drawButton(false);
    rec_btn.drawButton(false);

  } else if (actionFlag == 1) {
    down_btn.drawButton(false);
    next_btn.drawButton(false);
    prev_btn.drawButton(false);
    up_btn.drawButton(false);
    play_btn.drawButton(false);

  } else if (actionFlag == 2) {
    yes_btn.drawButton(false);
    no_btn.drawButton(false);
  }
}
void drawKeyboard() {
  tft.fillRect(10, 10, tft.width() - 20, 40, GRAY);
  tft.setCursor(15, 25);
  tft.setTextColor(BLACK);
  tft.setTextSize(2);
  tft.print(saveFilename);

  for (int row = 0; row < 7; row++) {
    for (int col = 0; col < 6; col++) {
      int x = BUTTON_START_X + col * (BUTTON_WIDTH + BUTTON_SPACING);
      int y = BUTTON_START_Y + row * (BUTTON_HEIGHT + BUTTON_SPACING);
      tft.fillRect(x, y, BUTTON_WIDTH, BUTTON_HEIGHT, BLUE);
      tft.setCursor(x + 12, y + 10);
      tft.setTextColor(WHITE);
      tft.setTextSize(2);
      if (keys[row][col] == '*') {
        tft.print("OK");
      } else if (keys[row][col] == '@') {
        tft.print("<<");
      } else {
        tft.print(keys[row][col]);
      }
    }
  }
}

void updatesaveFilenameDisplay() {
  // Clear saveFilename area
  tft.fillRect(10, 10, tft.width() - 20, 40, GRAY);
  // Display updated saveFilename
  tft.setCursor(15, 25);
  tft.setTextColor(BLACK);
  tft.setTextSize(2);
  tft.print(saveFilename);
}

String buildBaseName(const String &baseFile, uint32_t number, int totalLen) {
  String result = baseFile;
  if (result.length() > totalLen)
    result = result.substring(0, totalLen);
  int missing = totalLen - result.length();
  if (missing > 0) {
    // Make a padded number wide enough
    char buf[16];
    snprintf(buf, sizeof(buf), "%015lu", (unsigned long)number);
    int bufLen = strlen(buf);
    const char *tail = buf + (bufLen - missing);
    result += tail;  // append just enough digits to reach totalLen
  }
  return result;
}

// Convert a raw 10-byte, space-padded tape-header filename into a safe SD
// filename.  Trailing pad spaces are trimmed, letters are upper-cased, anything
// that isn't A-Z/0-9/_/- becomes '_', and the result is capped at 8 chars so it
// stays friendly to the SD library's 8.3 naming.  Returns "" when the header
// carried no name (all spaces / empty) -- the caller then keeps VIPTAPE's own
// filename, so a nameless SAVE is unaffected.
String sanitizeTapeName(const char* raw) {
  if (raw == nullptr) return String("");
  char buf[11];
  uint8_t n = 0;
  for (uint8_t i = 0; i < 10 && raw[i] != '\0'; i++) buf[n++] = raw[i];
  buf[n] = '\0';
  while (n > 0 && buf[n - 1] == ' ') buf[--n] = '\0';   // trim pad spaces
  String out;
  for (uint8_t i = 0; i < n; i++) {
    char c = buf[i];
    if (c >= 'a' && c <= 'z') c -= 32;
    bool ok = (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
              c == '_' || c == '-';
    out += ok ? c : '_';
    if (out.length() >= 8) break;
  }
  return out;
}

String getUniqueFileName() {
  uint32_t fileNumber = 0;
  const int TOTAL_LEN = FILENAME_SIZE - 1;
  String fileName;

  while (fileNumber < 100000000UL) {
    String baseName = buildBaseName(BASEFILE, fileNumber, TOTAL_LEN);
    fileName = String(currentPath) + baseName + ".BIN";

    if (!SD.exists(fileName.c_str())) {
      return fileName;
    }
    if (SERIALDEBUG) { Serial.println(fileName); }
    fileNumber++;
  }
  if (SERIALDEBUG) { Serial.println("Error: no unique filename available."); }
  return "";
}

void drawFileSaved() {
  tft.fillScreen(BACKGROUND);
  tft.setCursor(0, 80);
  tft.print("Bytes: ");
  tft.print(ramAddr);
  tft.setCursor(0, 100);
  if (currentProtocol == 6 || currentProtocol == 7) {tft.print("Blocks: ");}
  else {tft.print("Pages: ");}
  tft.print((ramAddr + 255) / 256);
}

/* Get file information*/
void getFile(uint16_t &startAddr, uint16_t &endAddr, unsigned long &fileSize, String &fileExt) {

  if (SERIALDEBUG) { Serial.println("Opening file: " + currentFile); }

  File f = SD.open(currentFile);
  if (!f) {
    centerText(tft, "ERROR Opening File", 200, 0, BLACK, RED, 2);
    if (SERIALDEBUG) { Serial.println("ERROR Opening File"); }
    return;
  }
  FileLoader loader(ram);
  loader.loadFile(f, startAddr, endAddr, fileSize, fileExt);
  f.close();
  if (SERIALDEBUG) {
    Serial.println("Load complete.");
    Serial.println("File type : " + String(fileExt));
    Serial.println("File size : " + String(fileSize));
    Serial.print("Start     : 0x");
    Serial.println(startAddr, HEX);
    Serial.print("End       : 0x");
    Serial.println(endAddr, HEX);
  }
}
/*
========================================================================================================================================
Tape Methods
========================================================================================================================================
*/
// ----------------------------------------------------------------------------
// Helper: write an ORAO 'O' (object) file to SD as Intel HEX so the load
// address is preserved and the existing FileLoader can re-read it.
// 'B' (BASIC) files use the existing writeFile() path -- they're plain text.
// ----------------------------------------------------------------------------
static void writeOraoIntelHex(uint16_t loadAddr, uint32_t size) {
  // Open with the current filename (the user has already chosen the SD path)
  myFile = SD.open(currentFile, FILE_WRITE);
  if (!myFile) {
    if (SERIALDEBUG) Serial.println("Error opening file");
    centerText(tft, "ERROR", 10, 0, WHITE, RED, 2);
    delay(1000);
    return;
  }
  centerText(tft, "Writing HEX", 10, 0, BLUE, CYAN, 2);
  delay(500);

  static const char hexChars[] = "0123456789ABCDEF";
  uint32_t off = 0;
  while (off < size) {
    uint8_t recLen = (size - off > 16) ? 16 : (uint8_t)(size - off);
    uint16_t addr  = (uint16_t)(loadAddr + off);
    uint8_t  sum   = recLen + (uint8_t)(addr >> 8) + (uint8_t)(addr & 0xFF) + 0x00;

    myFile.write(':');
    myFile.write(hexChars[recLen >> 4]);            myFile.write(hexChars[recLen & 0x0F]);
    myFile.write(hexChars[(addr >> 12) & 0x0F]);    myFile.write(hexChars[(addr >> 8) & 0x0F]);
    myFile.write(hexChars[(addr >> 4)  & 0x0F]);    myFile.write(hexChars[ addr       & 0x0F]);
    myFile.write('0');                              myFile.write('0');   // record type 00 = data

    for (uint8_t i = 0; i < recLen; i++) {
      uint8_t v = ram.readByte((uint16_t)(loadAddr + off + i));
      sum += v;
      myFile.write(hexChars[v >> 4]);  myFile.write(hexChars[v & 0x0F]);
    }
    uint8_t cs = (uint8_t)(-(int8_t)sum);
    myFile.write(hexChars[cs >> 4]);   myFile.write(hexChars[cs & 0x0F]);
    myFile.write('\r');                myFile.write('\n');
    off += recLen;
    lastActivityTime = millis();
  }
  // EOF record
  myFile.print(F(":00000001FF\r\n"));
  myFile.close();

  tft.fillScreen(BLACK);
  centerText(tft, "Writing completed", 10, 0, BLUE, YELLOW, 2);
  delay(1000);
}

void ReadData() {
  ramAddr = 0;
  bool okToFile = false;
  const char *errMsg = "";

  // Re-arm the decoder for the protocol we're about to decode.  setParams()
  // does reset() AND re-applies the correct interrupt edge mode (ORAO=RISING,
  // async=CHANGE).  This guarantees a decode can never run with a stale edge
  // mode left over from a previous operation -- a stale RISING mode on an async
  // protocol doubles every measured period out of its accept window, so the
  // leader never locks and only a single stray byte is ever captured.  That is
  // exactly the "async saves only 1 byte" failure; this line prevents it.
  const CassetteParams *p = cassetteDecoder.getParams();
  cassetteDecoder.setParams(p);

  bool oraoMode = (p->framing == FRAMING_BLOCK_ORAO);

  if (oraoMode) {
    // -------------------- ORAO 'B' / 'O' framing --------------------
    OraoReceive oraoRx(ram, cassetteDecoder);
    lastByteTime = millis();
    unsigned long startTime = millis();

    while (true) {
      cassetteDecoder.poll();

      if (cassetteDecoder.available()) {
        uint8_t b = cassetteDecoder.read();
        OraoReceive::Status s = oraoRx.feed(b);
        lastByteTime = millis();

        if (s == OraoReceive::OR_DONE) {
          ramAddr = oraoRx.dataBytes();
          // Append the $1A EOF marker so the stored file matches what a real
          // ORAO tape carries (and what loads back cleanly via SendData()).
          ram.writeByte((uint16_t)ramAddr, 0x1A);
          ramAddr++;
          okToFile = true;
          break;
        }
        if (s == OraoReceive::OR_ERROR) {
          errMsg = "Decode error";
          okToFile = false;
          break;
        }
      }

      // No bytes at all after 15 s -> nothing is coming; abort.
      if (oraoRx.dataBytes() == 0 && (millis() - startTime) > 15000UL) {
        errMsg = "No data";
        okToFile = false;
        break;
      }

      // Data started but the tape died mid-file (never saw $1A).  Wait longer
      // than the ~2.3 s inter-block leader gap before giving up, then save
      // what we have so a partial capture isn't lost.
      if (oraoRx.dataBytes() > 0 && (millis() - lastByteTime) > 5000UL) {
        ramAddr = oraoRx.dataBytes();
        ram.writeByte((uint16_t)ramAddr, 0x1A);
        ramAddr++;
        okToFile = true;
        break;
      }

      lastActivityTime = millis();
    }

    // If the SAVE carried a filename in its header (e.g. SAVE"TEST" -> "TEST"),
    // use that as the output file name, overriding whatever VIPTAPE had chosen.
    // A blank/nameless header leaves currentFile untouched (typed name or the
    // auto FILExxxx default).  Only done once we know we'll actually write.
    if (okToFile) {
      String tapeName = sanitizeTapeName(oraoRx.filename());
      if (tapeName.length() > 0) {
        currentFile = currentPath + tapeName + ".BIN";
        if (SERIALDEBUG) Serial.println("Tape filename   : " + currentFile);
      }
    }

    if (errMsg[0] != '\0') {
      centerText(tft, errMsg, 100, 0, WHITE, RED, 2);
      delay(1000);
      cassetteDecoder.clearError();
    }

  } else {
    // -------------------- original async-protocol path (unchanged) --------
    while (true) {
      cassetteDecoder.poll();
      if (cassetteDecoder.available()) {
        uint8_t b = cassetteDecoder.read();
        ram.writeByte(ramAddr++, b);
        lastByteTime = millis();
      }

      if (errMsg[0] != '\0') { okToFile = false; break; }

      if (ramAddr > 0 && millis() - lastByteTime > 2000) {
        okToFile = true;
        break;
      }

      if (cassetteDecoder.decodeFinished()) {
        if (cassetteDecoder.hasError()) {
          okToFile = false;
          switch (cassetteDecoder.lastError()) {
            case DECODE_ERR_PARITY:  errMsg = "Parity error";  goto message_error;
            case DECODE_ERR_STOPBIT: errMsg = "Stop bit error"; goto message_error;
            case DECODE_ERR_TIMEOUT: errMsg = "Tape timeout";  goto message_error;
            default:                 errMsg = "Error unknown"; goto message_error;
message_error:
            centerText(tft, errMsg, 100, 0, WHITE, RED, 2);
            delay(1000);
            cassetteDecoder.clearError();
            break;
          }
        }
      }
      lastActivityTime = millis();
    }
  }

  saveLastMode();
  if (SERIALDEBUG) Serial.println(okToFile);
  if (okToFile) { writeFile(); }
}

void ReadDataX() {
  ramAddr = 0;
  bool okToFile = true;
  const char *errMsg = "";
  cassetteDecoder.reset();

  const CassetteParams *p = cassetteDecoder.getParams();
  const bool oraoMode = (p && p->framing == FRAMING_BLOCK_ORAO);
  OraoReceive oraoRx(ram, cassetteDecoder);
  if (oraoMode) oraoRx.begin();

  // Live diagnostic state for ORAO-mode hardware troubleshooting.
  // Prints a one-line summary every ~1s so you can see, in real time,
  // whether edges are arriving, whether cycles fall in the bit-0/bit-1
  // windows, and how far the decoder has progressed.  Quiet when SERIALDEBUG=0.
  unsigned long loadStartMs = millis();
  unsigned long lastDiagMs  = loadStartMs;
  const unsigned long HARD_TIMEOUT_MS = 30000UL;  // safety net so the LOAD
                                                  // always terminates even
                                                  // if no byte ever decodes
  if (oraoMode && SERIALDEBUG) {
    Serial.println(F("--- ORAO LOAD START (live diagnostics) ---"));
    Serial.println(F("t(ms)  state             edges  cycles  bit0  bit1  oor   lastUs  min/max         bytes maxState        sEnt sFail sLock lastShift"));
  }

  while (true) {
    cassetteDecoder.poll();
    if (cassetteDecoder.available()) {
      uint8_t b = cassetteDecoder.read();
      if (oraoMode) {
        OraoReceive::Status s = oraoRx.feed(b);
        if (s == OraoReceive::OR_DONE) {
          ramAddr = oraoRx.dataBytes();
          if (oraoRx.type() == 'O') {
            startAddr = oraoRx.loadAddr();
            endAddr   = oraoRx.endAddr();
          } else {
            startAddr = 0;
            endAddr   = (ramAddr > 0) ? (uint16_t)(ramAddr - 1) : 0;
          }
          break;
        }
        if (s == OraoReceive::OR_ERROR) {
          okToFile = false;
          errMsg = "ORAO format error";
          break;
        }
      } else {
        ram.writeByte(ramAddr++, b);
      }
      lastByteTime = millis();
    }

    // Live diagnostic line every ~1s
    if (oraoMode && SERIALDEBUG && (millis() - lastDiagMs) >= 1000) {
      lastDiagMs = millis();
      Serial.print(millis() - loadStartMs); Serial.print('\t');
      Serial.print(cassetteDecoder.debugStateName()); Serial.print('\t');
      Serial.print(cassetteDecoder.debugEdgesSeen());     Serial.print('\t');
      Serial.print(cassetteDecoder.debugFullCycles());    Serial.print('\t');
      Serial.print(cassetteDecoder.debugBit0Count());     Serial.print('\t');
      Serial.print(cassetteDecoder.debugBit1Count());     Serial.print('\t');
      Serial.print(cassetteDecoder.debugOutOfRange());    Serial.print('\t');
      Serial.print(cassetteDecoder.debugLastCycleUs());   Serial.print('\t');
      Serial.print(cassetteDecoder.debugMinCycleUs());    Serial.print('/');
      Serial.print(cassetteDecoder.debugMaxCycleUs());    Serial.print('\t');
      Serial.print(cassetteDecoder.debugBytesEmitted());  Serial.print('\t');
      Serial.print(cassetteDecoder.debugMaxStateName());  Serial.print('\t');
      Serial.print(cassetteDecoder.debugSyncEnters());    Serial.print('\t');
      Serial.print(cassetteDecoder.debugSyncFails());     Serial.print('\t');
      Serial.print(cassetteDecoder.debugSyncLocks());     Serial.print('\t');
      Serial.println(cassetteDecoder.debugLastSyncShift(), HEX);
    }

    if (errMsg!= "") {
          okToFile= false;
          break;
    }

    // Async-mode end-of-tape: 2s of silence after at least one byte received.
    if (!oraoMode && ramAddr > 0 && millis() - lastByteTime >2000) {
      okToFile= true;
      break;
    }

    // Hard 30s timeout for ORAO mode -- protects against "just sits waiting"
    // when no byte ever decodes, which the silence-timeout (gated on
    // _anyByteEmitted) deliberately can't catch.
    if (oraoMode && (millis() - loadStartMs) > HARD_TIMEOUT_MS) {
      okToFile = false;
      errMsg = "Timeout (no decode)";
      if (SERIALDEBUG) {
        Serial.println(F("--- ORAO HARD TIMEOUT (30s) ---"));
        Serial.print(F("decoder state    : "));
        Serial.println(cassetteDecoder.debugStateName());
        Serial.print(F("leaderCount      : "));
        Serial.println(cassetteDecoder.debugLeaderCount());
        Serial.print(F("edges total      : "));
        Serial.println(cassetteDecoder.debugEdgesSeen());
        Serial.print(F("bit0/bit1/oor    : "));
        Serial.print(cassetteDecoder.debugBit0Count());  Serial.print(F(" / "));
        Serial.print(cassetteDecoder.debugBit1Count());  Serial.print(F(" / "));
        Serial.println(cassetteDecoder.debugOutOfRange());
        Serial.print(F("max state reached: "));
        Serial.println(cassetteDecoder.debugMaxStateName());
        Serial.print(F("sync enters/fails/locks: "));
        Serial.print(cassetteDecoder.debugSyncEnters()); Serial.print(F(" / "));
        Serial.print(cassetteDecoder.debugSyncFails());  Serial.print(F(" / "));
        Serial.println(cassetteDecoder.debugSyncLocks());
        Serial.print(F("last shift reg   : 0x"));
        Serial.println(cassetteDecoder.debugLastSyncShift(), HEX);
        Serial.print(F("bytes emitted    : "));
        Serial.println(cassetteDecoder.debugBytesEmitted());
      }
      break;
    }

    // ORAO-mode end-of-tape: decoder reports tape silence (>500ms no edges).
    // Accept whatever we received as long as at least one full block came in.
    if (oraoMode && cassetteDecoder.isDone()) {
      if (oraoRx.dataBytes() > 0) {
        ramAddr = oraoRx.dataBytes();
        if (oraoRx.type() == 'O') {
          startAddr = oraoRx.loadAddr();
          endAddr   = oraoRx.endAddr();
        } else {
          startAddr = 0;
          endAddr   = (uint16_t)(ramAddr - 1);
        }
        okToFile = true;
      } else {
        okToFile = false;
        errMsg = "No data received";
        // Diagnostic: dump decoder state so we can see WHERE on the tape we
        // bailed.  state/leaderCount/syncMatch tell us if we got past the
        // leader and how far the sync hunt progressed; type/blocksReceived
        // tell us if any block header was parsed.
        if (SERIALDEBUG) {
          Serial.println(F("--- ORAO LOAD FAILED ---"));
          Serial.print(F("decoder state    : "));
          Serial.println(cassetteDecoder.debugStateName());
          Serial.print(F("leaderCount      : "));
          Serial.println(cassetteDecoder.debugLeaderCount());
          Serial.print(F("syncMatch        : "));
          Serial.println(cassetteDecoder.debugSyncMatch());
          Serial.print(F("blockBytesRead   : "));
          Serial.println(cassetteDecoder.debugBlockBytesRead());
          Serial.print(F("bitCount in byte : "));
          Serial.println(cassetteDecoder.debugBitCount());
          Serial.print(F("us since lastEdge: "));
          Serial.println(cassetteDecoder.debugUsSinceLastEdge());
          Serial.print(F("anyByteEmitted   : "));
          Serial.println(cassetteDecoder.debugAnyByteEmitted() ? F("true") : F("false"));
          Serial.print(F("edges total      : "));
          Serial.println(cassetteDecoder.debugEdgesSeen());
          Serial.print(F("full cycles      : "));
          Serial.println(cassetteDecoder.debugFullCycles());
          Serial.print(F("bit0 / bit1 / oor: "));
          Serial.print(cassetteDecoder.debugBit0Count());  Serial.print(F(" / "));
          Serial.print(cassetteDecoder.debugBit1Count());  Serial.print(F(" / "));
          Serial.println(cassetteDecoder.debugOutOfRange());
          Serial.print(F("last cycle us    : "));
          Serial.println(cassetteDecoder.debugLastCycleUs());
          Serial.print(F("min/max cycle us : "));
          Serial.print(cassetteDecoder.debugMinCycleUs()); Serial.print(F(" / "));
          Serial.println(cassetteDecoder.debugMaxCycleUs());
          Serial.print(F("rx type          : '"));
          Serial.print(oraoRx.type() ? oraoRx.type() : '?');
          Serial.println(F("'"));
          Serial.print(F("rx blocks recv'd : "));
          Serial.println(oraoRx.blocksReceived());
          Serial.print(F("rx dataBytes     : "));
          Serial.println(oraoRx.dataBytes());
          Serial.print(F("max state reached: "));
          Serial.println(cassetteDecoder.debugMaxStateName());
          Serial.print(F("sync hunt enters : "));
          Serial.println(cassetteDecoder.debugSyncEnters());
          Serial.print(F("sync hunt fails  : "));
          Serial.println(cassetteDecoder.debugSyncFails());
          Serial.print(F("sync hunt locks  : "));
          Serial.println(cassetteDecoder.debugSyncLocks());
          Serial.print(F("last shift reg   : 0x"));
          Serial.println(cassetteDecoder.debugLastSyncShift(), HEX);
        }
      }
      break;
    }
    
    if (cassetteDecoder.decodeFinished()) {   
      if (cassetteDecoder.hasError()) {
        okToFile = false;
        switch (cassetteDecoder.lastError()) {
                                                                               
          case DECODE_ERR_PARITY:
            errMsg = "Parity error";
            goto message_error;

          case DECODE_ERR_STOPBIT:
            errMsg = "Stop bit error";
            goto message_error;

          case DECODE_ERR_TIMEOUT:
            errMsg = "Tape timeout";
            goto message_error;

          default:
            errMsg = "Error unknown";
            goto message_error;

message_error:
            centerText(tft, errMsg, 100, 0, WHITE, RED, 2);
            delay(1000);
            cassetteDecoder.clearError();
            break;
        }
      }
    }
  lastActivityTime = millis();  // Initialize activity time
  }
  saveLastMode();
  Serial.println(okToFile);
  if (okToFile) {
    if (oraoMode && oraoRx.type() == 'O') {
      // Object file: write Intel HEX so load address survives round trip.
      writeOraoIntelHex(oraoRx.loadAddr(), oraoRx.dataBytes());
    } else {
      // Async mode, or ORAO 'B' (plain text): existing binary write.
      writeFile();
    }
  }
  if (!okToFile && errMsg && errMsg[0]) {
    centerText(tft, errMsg, 100, 0, WHITE, RED, 2);
    delay(1000);
  }
}

void writeFile() {
  uint32_t a;
  byte v;
  // FILE_WRITE opens an existing file for *append*, which would corrupt a
  // re-save under the same name (now possible when the tape header supplies a
  // fixed filename like TEST.BIN).  Remove any existing file first so a SAVE
  // overwrites cleanly, matching real cassette behaviour.
  if (SD.exists(currentFile.c_str())) SD.remove(currentFile.c_str());
  myFile = SD.open(currentFile, FILE_WRITE);
  if (myFile) {
    centerText(tft, "Writing file", 10, 0, BLUE, CYAN, 2);
    delay(500);
    for (word a = 0; a < ramAddr; a++) {
      v = ram.readByte(a); 
      myFile.write(v);
      lastActivityTime = millis();  // Initialize activity time
    }
    myFile.close();
    if (SERIALDEBUG) { Serial.println("done."); }
    
      tft.fillScreen(BLACK);
      centerText(tft, "Writing completed", 10, 0, BLUE, YELLOW, 2);
      delay(1000);
  } else {
    // if the file didn't open, print an error:
    if (SERIALDEBUG) { Serial.println("Error opening file"); }
    centerText(tft, "ERROR", 10, 0, WHITE, RED, 2);
     delay(1000);
  }
}

// Encoder reader callback for ORAO sendOraoFile().  srcIndex runs 0..N-1 where
// N = endAddr - startAddr + 1; we just translate to an absolute RAM address.
static uint8_t oraoEncoderReader(uint32_t srcIndex, void* /*ctx*/) {
  return ram.readByte((uint16_t)(startAddr + srcIndex));
}

void SendData() {

  const CassetteParams *p = &cassetteProtocols[currentProtocol];
  cassetteEncoder.configure(p);
  if (SERIALDEBUG) {
    Serial.println("Cassette Mode   : " + String(p->name));
    Serial.println("Bit 0           : " + String(p->bit0) + " uS");
    Serial.println("Bit 1           : " + String(p->bit1) + " uS");
    Serial.println("Start Bit       : " + String(getBitString(p->startBit)));
    Serial.println("Stop Bit        : " + String(getBitString(p->stopBit)));
    Serial.println("Parity          : " + String(getParityString(p->parity)));
    Serial.println("Endian          : " + String(getEndianString(p->bitOrder)));
    Serial.println("Leader Bit      : " + String(getBitString(p->leaderBit)));
    Serial.println("Leader Count    : " + String(p->leaderBits));
    Serial.println("Leader Time     : " + String(p->leaderTime) + " mS");
    Serial.println("Trailer         : " + String(getBitString(p->trailerBit)));
    Serial.println("Trailer Time    : " + String(p->trailerTime) + " mS");
    Serial.println("Polarity Mode   : " + String(getPolarityString(p->polarity)));
    Serial.println("Reading data from device......");
    Serial.println("Transferring data to device......");
  }
  tft.fillScreen(BACKGROUND);
  centerText(tft, "Transferring file", 10, 0, BLUE, YELLOW, 2);
  centerText(tft, "Please wait", 50, 0, BLUE, YELLOW, 2);

  noInterrupts();

  if (p->framing == FRAMING_BLOCK_ORAO) {
    // ----- ORAO block-mode send -----------------------------------------
    // For 'O' (object) mode the load/end addresses come from FileLoader
    // (Intel HEX preserves them; for binary input they default to 0..size-1).
    // For 'B' (BASIC) mode the addresses are unused -- the file is just text.
    // ORAO header filename (up to 10 chars).  Priority:
    //   1. the name the user typed when saving (saveFilename), else
    //   2. the actual file being sent (currentName), with path + extension
    //      stripped, else
    //   3. the BASEFILE default.
    // sendOraoFile() pads to 10 chars with spaces and truncates beyond 10.
    char oraoName[11];
    {
      String n;
      if (saveFilenameLength > 0) {
        n = String(saveFilename);
      } else {
        n = currentName;                       // e.g. "/PROGS/TEST4.BIN"
        int slash = n.lastIndexOf('/');
        if (slash >= 0) n = n.substring(slash + 1);
        int dot = n.lastIndexOf('.');
        if (dot > 0) n = n.substring(0, dot);  // strip extension
      }
      if (n.length() == 0) n = String(BASEFILE);
      uint8_t i = 0;
      for (; i < 10 && i < (uint8_t)n.length(); i++) oraoName[i] = n[i];
      oraoName[i] = '\0';
    }
    const char* fname = oraoName;
    if (SERIALDEBUG) Serial.println("ORAO name       : " + String(fname));

    uint32_t total = (uint32_t)endAddr - (uint32_t)startAddr + 1;
    cassetteEncoder.sendOraoFile(fname, total, startAddr, endAddr,
                                 oraoEncoderReader, nullptr);
  } else {
    // ----- Async-serial send (unchanged) --------------------------------
    cassetteEncoder.sendLeader();
    int c = 0;
    char hexStr[5];
    for (uint32_t addr = startAddr; addr <= endAddr; addr++) {
      uint8_t v = ram.readByte(addr);
      if (SERIALDEBUG) {
        sprintf(hexStr, "%02X", v);
        Serial.print(" ");
        Serial.print(hexStr);
        Serial.print(" ");
        c++;
        if (c > 16) {
          c = 0;
          Serial.println(" ");
        }
      }
      cassetteEncoder.sendByte(v);
    }
    cassetteEncoder.sendTrailer();
  }

  interrupts();
  
  saveLastMode();
  if (SERIALDEBUG) {
    Serial.println(" ");
    Serial.println("Transfer complete.");
  }
  tft.fillScreen(BLACK);
  centerText(tft, "Transfer complete", 10, 0, BLUE, YELLOW, 2);
  delay(1000);
}
void showScreenSaver(int hangTime) {
  tft.fillScreen(BLACK);
  tft.drawBitmap(0, 0, cosmac, 240, 320, FOREGROUND);
  /*Special messaging*/
  centerText(tft, MESSAGE5, 245, 0, BLUE, BLACK, 2);
  centerText(tft, MESSAGE6, 265, 0, BLUE, BLACK, 2);

  if (hangTime > 0) delay(hangTime);
}

void activateScreenSaver() {
  screensaverActive = true;
  tft.fillScreen(BLACK);  // Clear the screen
  if (SERIALDEBUG) { Serial.println("Screen saver activated"); }
}

void deactivateScreenSaver() {
  screensaverActive = false;
  tft.fillScreen(BLACK);        // Clear the screensaver content
  lastActivityTime = millis();  // Reset activity timer
  if (SERIALDEBUG) { Serial.println("Screen saver de-activated"); }
}

void ResetMode(int full) {
  saveFilename[FILENAME_SIZE] = "";
  saveFilenameLength = 0;
  if (full == 1) {
    currentName = "";
    currentPath = "/";
    currentIndex = 0;
  }
  currentFile = "";
  actionFlag = 0;
  keyboardEntry = 0;
}

void loop() {

  unsigned long currentTime = millis();
  // Check for inactivity
  if (!screensaverActive && (currentTime - lastActivityTime >= INACTIVITY_THRESHOLD)) {
    activateScreenSaver();
    showScreenSaver(0);
  } else {
    /* Check button press*/
    if (debounceButton(0)) {
      pressed = "Up";
    } else if (debounceButton(1)) {
      pressed = "Down";
    } else if (debounceButton(2)) {
      pressed = "Yes";
      if (currentFile != "" && actionFlag == 1) {
        pressed = "Play";
      }
    } else if (debounceButton(3)) {
      pressed = "No";
    } else {
      pressed = "*";
    }

    if (SERIALDEBUG) {
      if (pressed != "*") { Serial.println("Button " + pressed); }
    }

    TSPoint pc = ts.getPoint();
    // Restore pin states (shared pins with TFT)
    pinMode(YP, OUTPUT);
    pinMode(XM, OUTPUT);
    if (pc.z > MINPRESSURE && pc.z < MAXPRESSURE) {
      touched = 1;
    } else {
      touched = 0;
    }
    if (touched == 1 || pressed != "*") {
      if (screensaverActive) {
        deactivateScreenSaver();
        displayFiles(1);
      } else {
        lastActivityTime = millis();  // Reset activity timer
        // Map touch coordinates to screen coordinates
        int16_t x = map(pc.x, TS_MINX, TS_MAXX, 0, tft.width());
        int16_t y = map(pc.y, TS_MINY, TS_MAXY, 0, tft.height());
        numAreas = numValidButtons[actionFlag];
        for (int i = 0; i < numAreas; i++) {
          if (x >= screenButtons[actionFlag][i].xMin && x <= screenButtons[actionFlag][i].xMax && y >= screenButtons[actionFlag][i].yMin && y <= screenButtons[actionFlag][i].yMax) {
            Serial.println(screenButtons[actionFlag][i].name);
            pressed = screenButtons[actionFlag][i].name;
            if (pressed == "Play" && actionFlag == 0) { pressed = "Record"; }
            break;
          }
        }
        if (SERIALDEBUG) {
          Serial.println("Button: " + pressed);
          Serial.println("Touched: " + String(touched));
        }

        if (keyboardEntry == 1) {
          for (int row = 0; row < 7; row++) {
            for (int col = 0; col < 6; col++) {
              int xk = BUTTON_START_X + col * (BUTTON_WIDTH + BUTTON_SPACING);
              int yk = BUTTON_START_Y + row * (BUTTON_HEIGHT + BUTTON_SPACING);
              if (x >= xk && x <= xk + BUTTON_WIDTH && y >= yk && y <= yk + BUTTON_HEIGHT) {
                char key = keys[row][col];
                if (SERIALDEBUG) { Serial.println(String("Character : " + key)); }

                if (key == '*') {
                  if (saveFilenameLength == 0) {
                    currentFile = getUniqueFileName();
                  } else {
                    currentFile = currentPath + saveFilename + ".BIN";
                  }
                  keyboardEntry = 2;
                  actionFlag = 2;
                  displayFileToSaveInfo();
                  drawButtons();
                  if (SERIALDEBUG) {
                    Serial.print("saveFilename entered: ");
                    Serial.println(currentFile);
                  }
                  saveFilename[0] = '\0';
                  saveFilenameLength = 0;
                } else if (key == '@') {
                  if (saveFilenameLength > 0 || saveFilenameLength == 0) {
                    saveFilenameLength--;
                    saveFilename[saveFilenameLength] = '\0';
                    if (saveFilenameLength < 0) {
                      saveFilename[0] = '\0';
                      saveFilenameLength = 0;
                    }
                    updatesaveFilenameDisplay();
                  }
                }

                else if (saveFilenameLength == (FILENAME_SIZE - 1) || saveFilenameLength > (FILENAME_SIZE - 1)) {
                  continue;
                }

                else if (saveFilenameLength < (FILENAME_SIZE - 1)) {  // Add character if not at limit
                  saveFilename[saveFilenameLength++] = key;
                  saveFilename[saveFilenameLength] = '\0';
                  updatesaveFilenameDisplay();
                }
                lastActivityTime = millis();  // Initialize activity time
                delay(200);  // Debounce
              }
            }
          }
        } else {
          /* Play */
          if (pressed == "Play" && currentFile != "" && actionFlag == 1) {
            getFile(startAddr, endAddr, fileSize, fileExt);
            displayInfo(startAddr, endAddr, fileSize, fileExt);
            actionFlag = 2;
            drawButtons();
          }
          /* Record */
          else if (pressed == "Record" && currentFile == "" && actionFlag == 0 && keyboardEntry == 0) {
            keyboardEntry = 1;
            if (SERIALDEBUG) { Serial.println("Keyboard Entry"); }
            tft.fillScreen(BLACK);
            drawKeyboard();
          }
          /* Up */
          else if (pressed == "Up") {
            if (SERIALDEBUG) { Serial.println("Up"); }
            if (fileList[currentIndex] == "..") {
              navigateToSelection(1);
            } else {
              moveSelection(-1);
            }
          }
          /* Down */
          else if (pressed == "Down") {
            moveSelection(1);
            if (SERIALDEBUG) { Serial.println("Down"); }
          }

          /* Previous page */
          else if (pressed == "Prev") {
            if (SERIALDEBUG) { Serial.println("Prev page"); }
            if (fileList[currentIndex] == "..") {
              navigateToSelection(1);
            } else {
              moveSelection(-ITEMS_PER_PAGE);
            }
          }
          /* Next page */
          else if (pressed == "Next") {
            if (SERIALDEBUG) { Serial.println("Next page"); }
            moveSelection(ITEMS_PER_PAGE);
          }
          /* No option*/
          else if (pressed == "No") {
            if (SERIALDEBUG) {
              Serial.println(currentFile);
              Serial.println("No");
            }
            ResetMode(0);
            loadDirectory(currentPath);
            displayFiles(1);
          }
          /* Yes option*/
          else if (pressed == "Yes") {
            if (SERIALDEBUG) {
              Serial.println(currentFile);
              Serial.println("Yes");
            }
            if (keyboardEntry == 2) {
              if (SERIALDEBUG) { Serial.println(currentFile); }
              tft.fillScreen(BACKGROUND);
              centerText(tft, "Reading....", 10, 0, BLUE, CYAN, 2);
              centerText(tft, "Please wait", 50, 0, BLUE, CYAN, 2);
              ReadData();
              ResetMode(0);
              keyboardEntry = 0;
              actionFlag = 0;
              loadDirectory(currentPath);
              displayFiles(1);
            } else if (currentFile != "") {
              SendData();
              keyboardEntry = 0;
              actionFlag = 0;
              ResetMode(0);
              loadDirectory(currentPath);
              displayFiles(1);
            } else {
              if (fileList[currentIndex] == ".." || fileList[currentIndex].endsWith("/")) {
                navigateToSelection(1);
              } else {
                currentFile = currentPath + fileList[currentIndex];
                currentName = fileList[currentIndex];
                actionFlag = 1;
                navigateToSelection(1);
              }
            }
          } else if (pressed == "Type") {
            nextProtocol();
            const CassetteParams *p = cassetteDecoder.getParams();
            if (p) {
              positionText(tft, p->name, 42, 10, 12, WHITE, BLUE, TEXTSIZE);
              if (SERIALDEBUG) { Serial.println(p->name); }
            }
          }

          /* Select item */
          else if (y > Y_OFFSET && y < (Y_OFFSET + CHAR_HEIGHT * ITEMS_PER_PAGE)) {
            int selectedItem = ((y - Y_OFFSET) / CHAR_HEIGHT) + displayStart;
            if (selectedItem >= 0 && selectedItem < fileCount) {
              currentIndex = selectedItem;
              if (fileList[currentIndex] == "" || fileList[currentIndex] == ".." || fileList[currentIndex].endsWith("/")) {
                currentFile = "";
                currentName = "";
                actionFlag = 0;
              } else {
                currentFile = currentPath + fileList[currentIndex];
                currentName = fileList[currentIndex];
                actionFlag = 1;
              }
              navigateToSelection(1);
              if (SERIALDEBUG) {
                Serial.println("Selected : " + currentFile);
                Serial.println(pressed);
              }
            }
          }
          delay(200); /* Debounce delay*/
        }
      }
    }
  }
}
